---
course_code: "T0034B"
title: "Hydraulics and Rock Mechanics"
credits: "7.5"
title_sv: "Hydraulik och bergmekanik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2026-06-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Samhällsbyggnadsteknik"
subject_group_scb: "Civil and Environmental Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0034B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0034B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t00/t0034b-hydraulik-och-bergmekanik"
---

# Hydraulics and Rock Mechanics (T0034B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and T0013B Rock Engineering and Rock Mechanics 7,5 ECTS B0002B Structural engineering 7,5 ECTS F0004T Physics 1 7,5 ECTS or corresponding courses

## Selection

The selection is based on 1-165 credits.

## Course Aim

1. solve basic problems based on the fundamental laws of hydraulics (e.g. calculating hydrostatis pressure, water level, flow velocity and flow rate.

2. determine flow conditions and calculate how flow transitions from one conditions to the other.

3. identify correct calculation procedure and solve basic hydraulics problems in open channel flow.

4. calculate and evaluate the stress state of underground constructions in rock using analytical and empirical models and propose optimal geometry and orientation of underground constructions in rock.

5. identify possible failure mechanisms and based on that select and apply appropriate failure criteria to analytically and empirically analyze and evaluate the stability of underground constructions in rock.

6. calculate and evaluate the deformation and strain state of underground constructions in rock with analytical and empirical models.

7. present and discuss in writing their analyses, models, results and conclusions

## Contents

This course covers the following topics in hydraulics:

- Hydrostatic pressure and resulting forces on different constructions.

- The three fundamental laws of hydraulics: continuity equation, momentum equation, and energy equation (Bernoulli’s equation).

- Applications of fundamental laws to flow in pressurized pipes and open channels.

- Flow conditions, transitions between flow conditions, and how this affects the determination of starting point and calculation procedure in open channel flow.

This course covers the following topics in rock mechanics:

- Repetition rock mechanics - repetition of relevant content from previous courses in rock mechanics.

- Stresses - The stress state, Mohr’s stress circles, Principal stresses, Primary stresses, Secondary stresses.

- Strength - mechanical properties of rock (intact and rock mass), failure mechanisms, failure criteria, test methods.

- Deformations - strain, Mohr’s strain circles, modulus of elasticity.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

This course includes the following teaching and learning activities:

- Lectures - a mix of several teaching/learning activities: (i) short theory review where the lecturer explains the most important theoretical aspects related to the course content and (ii) together solve and/or discuss typical hydraulics and rock mechanical problems and questions which gives you the opportunity to work in different ways with several aspects around analyzes of different systems/constructions from a practical and theoretical point of view and train calculation procedures for problems related to these.

- Assignments - You work together with other students and use your knowledge to solve various problems. You present your work in written reports. You train to use and apply the different methods that have been presented in lectures and literature to typical problems in hydraulics and rock mechanics as well as explain your solutions.

- Between lectures - You are expected to prepare for each lecture by working through the recommended material, recommended exercises and study questions so that you are ready to contribute and participate in the learning activities (problem solving, discussion, etc.) during the lectures, computer exercises, as well as the field and laboratory exercises.

- Laboratory exercise about open channel flow where you together with other students carry out measurements in a hydraulic flume and present your results and related calculations in a written report. The exercise connect theory to reality to gain additional understanding of channel flow.

Teaching in hydraulics may take place in English.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through:

- Assignments in rock mechanics - Consists of problems where you practice and apply your theoretical knowledge, understanding, and abilities as well as conducting analyses and explaining your results in writing.

- Written exam in rock mechanics - You solve problems like those encountered during the course (in lectures and assignments) to test your individual knowledge, understanding, skill and abilities. You are allowed to use the course compendium during the written exam.

- Laboratory exercise on open channel flow – a written group report is handed in.

- Written exam in hydraulics - You solve problems like those encountered during the course (in lectures and assignments) to test your individual knowledge, understanding, skill and abilities. You are allowed to use the formula sheet during the written exam.

Goals 1-3 and 7 are examined with a written report (module 0004, graded pass/fail) and a written examen (module 0003, graded G U 3 4 5). Active participation is required during the laboratory exercise.

Goals 4-7 are examined with a written exam (module 0001, graded G U 3 4 5) and through written hand-ins (module 0002, graded pass/fail)

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The hydraulics part of this course (modules 0001 and 0002) correspond to the hydraulics part of the course Natural Water Transport Processes (course code V0017 until study year 2021/2022, after that V0021) and in V0014B Hydraulics & geology; therefore this course cannot be part of the same degree as V0017B, V0021B, or V0014B. The rock mechanics part (modules 0003 and 0004) corresponds to parts of the courses Fundamentals of Rock Mechanics (T0014B) and Fundamentals of Rock Mechanics (T7001B); therefore this course cannot be included in the same degree as T0014B or T7001B.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written Exam hydraulics | GU345 | 3.3 | Mandatory | S27 |  |
| 0002 | Laboration hydraulics | UG | 0.5 | Mandatory | S27 |  |
| 0003 | Written exam rock mechanics | GU345 | 2.7 | Mandatory | S27 |  |
| 0004 | Assignment report | UG | 1 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-06-17
