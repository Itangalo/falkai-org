---
course_code: "P0001B"
title: "Construction Management"
credits: "7.5"
title_sv: "Bygg- och anläggningsproduktion"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2023-06-02"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0001B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p00/p0001b-bygg--och-anlaggningsproduktion"
---

# Construction Management (P0001B)

## Main field of study

., Civil Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and V0018B Planning and Construction in Civil Engineering or P0009B Civil and Building Engineering Design or similar course

## Selection

The selection is based on 1-165 credits.

## Course Aim

The students should during the course acquire knowledge about the principles of cost calculating, procurement, planning and production methods in construction.

## Contents

The course deals with product development and construction management of construction objects from an contractor perspective. The content focuses on providing knowledge and skills, primarily in construction production, where the contractor is the main actor. Theoretical lectures are mixed with practical assignments as well as external lecturers to give the student a knowledge and understanding of the construction industry.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course combines knowledge elements (lectures and work) with group elements with assignments during parts of the course. The course contains a major project assignment to practice skills in group work, industry-relevant data collection and report writing. The group assignment trains the student in both written and oral presentation. To support the project work, supervision is planned in parallel with own work. Submissions consist of tender calculations and written material. During the course, students will also be able to individually reflect on their own learning. In this reflection task, a proper reflection (on your learning) is expected linked to external lectures with experts in each area.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Written examination at the end of the course. In addition to passed written examinations and project assignments.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course P0001B is equal to ABP101

## Remarks

Due to similar content, the course cannot be included in a degree together with P0004B or other courses with similar content.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0006 | Course assignments | UG | 5.5 | Mandatory | S27 |  |
| 0007 | Short written exam | UG | 2 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
