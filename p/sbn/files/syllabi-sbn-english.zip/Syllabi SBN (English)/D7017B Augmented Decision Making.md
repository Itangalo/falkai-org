---
course_code: "D7017B"
title: "Augmented Decision Making"
credits: "7.5"
title_sv: "Augmented decision-making"
valid: "Spring 2025 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7017B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7017b-augmented-decision-making"
---

# Augmented Decision Making (D7017B)

## Entry requirements

At least 90 credits completed courses including basic knowledge in mathematics, programming and artificial intelligence, equivalent to the courses S0001M Mathematical Statistics, D0009E Introduction to Programming, and D0032E Introduction to AI. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 30-285 credits

## Course Aim

Knowledge and Understanding:

1. Knowledge of fundamental concepts of system engineering and system thinking.

2. Understanding the concepts of RAMS (Reliability, Availability, Maintainability and Safety), Life cycle analysis, and PHM (Prognostics Health Management) in industrial contexts.

Competence and Skills:

3. Design and develop the concepts, technologies, and methodologies in industrial contexts from a system perspective using industrial AI.

Judgement and Approach:

4. Assess the relevance and applicability of system engineering and system thinking in diverse industrial situations.

## Contents

This course covers:

- Concepts of system engineering and system thinking
- Concepts of RAMS (Reliability, Availability, Maintainability and Safety), Life cycle analysis, and PHM (Prognostics Health Management)
- Augmented decision making
- Case Studies and Practical Applications in industrial domains

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The teaching includes lectures and assignments, including laboratory work. The lectures can be a combination of online, self-study, and/or classroom interaction. Students will be working on assignments that will be a combination of mandatory and optional tasks such as developing software solutions and practical report writing as well as lab sessions.

One introductory lecture is scheduled in the beginning of course which includes course introduction with overview of the course, assignments, and detail of the study guide.

The course will run in a hybrid mode. Some modules will have a classroom lecture session followed by an assignment solving session. Some modules will have online study material followed by an assignment solving session and another follow up session for the assignments.

There are 5 assignments with 2 sessions allocated for each assignment. For the success in the assignment, it is essential that the students prepare and learn the preliminaries before the sessions. It is also beneficial if the students try to resolve the assignment before the session. Given that the students have prepared, they are expected to be able to solve the assignment during the solving session with the support of the course staff. There is also a wrap up session for each assignment in case there is not enough time to perform all the demonstrations during the solving session.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. This course contains formative assessments (for learning) and summative assessments (of learning). The purpose of the summative assessments (in the form of assignments and reports) is to examine the intended learning outcomes, while the purpose of the formative assessments (in-class discussions, reflections, quizzes, group work, feedback) is to support learning. All assignments will be processed during the course with feedback from teachers and/or peers. The format of the assignments will be report writing, practical assignments, and seminars. To pass the course, all the assignments must be completed.

To pass each of the assignments, the solution must first be demonstrated during the solving session or the wrap up session allocated for the assignment. After the demonstration is evaluated as satisfactory, the files must be submitted through Canvas for assessment and grading.

The assignments will determine the grade (3,4,5). All the assignments carry equal weight. The overall grade will be the mean grade of all the assignments.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Compulsory assignments | GU345 | 7.5 | Mandatory | S25 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14
