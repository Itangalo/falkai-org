---
course_code: "K0006K"
title: "Water Chemistry"
credits: "7.5"
title_sv: "Vattenkemi"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Kemi"
subject_group_scb: "Chemistry"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0006K&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k00/k0006k-vattenkemi"
---

# Water Chemistry (K0006K)

## Main field of study

Chemical Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Chemical Principles (K0016K)

## Selection

The selection is based on 1-165 credits.

## Course Aim

After taking the course, you should be able to - formulate and handle equilibrium systems; smaller systems on paper and more complicated by the use of calculation programs. - predict and when data is available calculate the displacement of the equilibrium by changes in temperature, pressure, ionic strength and composition. - interpret and in some cases construct equilibrium diagrams. You should have an understanding of the possibilities and limitations in using equilibrium modeling, for the regulation of the composition of various natural and industrial water types. The principles for water treatment and chlorines reactions in water shall be known, as well as the basis for chemical reaction kinetics. When relevant, identify and propose actions to maintain a sustainable development.You should also further improve your communicative skills, especially with focus on producing well-structured and formulated written reports

## Contents

Part 1: A short introduction to the characteristics of water and water types. Then the activity concept is discussed with focus on the dependence of the ionic strength, as well as the influence of changes in the temperature and other thermodynamic dependencies. Redox-, complex-, solubility- and distribution equilibria and a short introduction to gas equilibria.will finalise part 1. Part 2: Acid-base equilibria, including heterogeneous equilibria, alkalinity, water purification and reaction kinetics. An introduction to surface complexation equilibria and also examples of the handling of industrial and environmental systems. Different equilibrium principles are studied with the use of diagrams and mathematical calculations. The influence of temperature, ionic strength as well as the alkalinity concept will be discussed. The theory is applied in laboratory experiments. A computer simulation is included in the laboratory exercise item.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures and laboratory exercises. The first lecture is compulsory as well as the laboratory exercises.

A study visit may be arranged during the course.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Graded exam and participation in study visits, when arranged for part 2. Approved labexercises, simulations and well-structured and formulated written reports. The final grade for the course will be derived from the results from the written exam.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K0006K is equal to KGK013

## Remarks

Syllabus can be downloaded from LTUs learning platform

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0008 | Written exam | GU345 | 6 | Mandatory | A07 |  |
| 0005 | Laboratory work | U G# | 1.5 | Inactive | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
