---
course_code: "P7006B"
title: "Virtual Construction"
credits: "7.5"
title_sv: "Datorstödd byggproduktion"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7006B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7006B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p70/p7006b-datorstodd-byggproduktion"
---

# Virtual Construction (P7006B)

## Main field of study

Civil Engineering, .

## Entry requirements

Basic understanding about the building process and the role of construction in the construction process. Basic knowledge in 3D modeling, planning methods and cost estimation, equivalent course P0001B Construction Management. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After the course the student should individually and together with others, be able to
- explain and critically process the role of models and other digital information sources for data driven construction planning
- apply model based quantity take-offs from building information models to create cost estimates of construction projects
- apply model based time planning for construction projects with feasible rhythm and ability to tackle disturbances.
- apply automation for parts of the planning process using programming and generative artificial intelligence.
- explain the importance of standards and classification within virtual construction

## Contents

The course covers the conditions that apply to BIM and the broader concept of virtual construction, with the perspective of the construction contractor. The student will learn how BIM and other digital information sources affect and facilitate the planning and preparation work and the demands it place on the information that comes from different stakeholders and processes for data driven decisions. The student will during the course get to use standard computer tools from the industry.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The first part of the course consists of lectures and practical exercises in a computer environment that trains the students' understanding of the content presented during the lectures. In the second part of the course, students in small groups get to apply knowledge from the first part in a project with a more open problem setting, but also take part of guest lectures that deepen and/or broaden the student's view of virtual construction as well as participating in a workshop. The course ends with a written and oral presentation of the groups' results.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The examination consists of individual tasks and a group project. The rating scale is U G on individual modules and project work. The entire course is graded U 3 4 5. All separate assignments need to be conducted to get grade 3. The final grade for the course is based on course credits that the students gather during the course. The system is described in detail in the study guide that will be distributed at the beginning of the course. Mandatory attendance applies to the workshop and the final presentation. All assignments should be written in correct English.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment report | U G# | 3 | Inactive | A08 |  |
| 0002 | Project assignment | U G# | 4.5 | Inactive | A08 |  |

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13

## Syllabus established

by Department of Civil and Environmental Engineering 2008-01-22
