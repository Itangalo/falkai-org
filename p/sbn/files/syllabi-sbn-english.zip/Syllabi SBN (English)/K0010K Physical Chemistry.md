---
course_code: "K0010K"
title: "Physical Chemistry"
credits: "7.5"
title_sv: "Fysikalisk kemi"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Kemi"
subject_group_scb: "Chemistry"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0010K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0010K&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k00/k0010k-fysikalisk-kemi"
---

# Physical Chemistry (K0010K)

## Main field of study

Chemical Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Chemical Principles (K0016K)

## Selection

The selection is based on 1-165 credits.

## Course Aim

The goal of the course is that the student, after completion of the course, should:

1. be able to calculate properties on nonideal gases

2. be able to apply the three laws of thermodynamics

3. be able to use thermodynamic state functions in chemical calculations

4. be used with the concepts the activity and partial molar quantities

5. be able to construct and interpret phase diagrams

6. be able to calculate the electromotive force from the thermodynamic functions

7. be able to present analytical expressions for the rate of chemical reactions

8. be used with equipment and to get the practical and calculations skills during the laboratory works, “bombcalorimetry” and “chemical kinetics”, and be able to get and present results and to write up laboratory reports supported by recommended templates

## Contents

This course covers the following parts:

Chemical thermodynamics

ideal- and non-ideal gases, thermodynamic state functions (enthalpy, entropy, Gibbs free energy), activity, partial molar quantities, colligative properties and phase diagrams.

Electrochemical equilibrium

Nernst equation, Debye-Hückel equations for electrolytes, electrical conductivity, types of electrodes and electrochemical cells, cell reactions and electro-motive force, corrosion and corrosion protection.

Chemical kinetics

reaction order, reaction mechanisms, the activation energy and Arrhenius equation.

The course includes two laboratory works:

(i) A combustion experiment on an unknown substance/material with the aid of a bomb calorimeter and calculations of the enthalpy of combustion for this substance/material. (ii) Determination of the rate constants of a chemical reaction at different temperatures and calculations of the activation energy of the reaction using the Arrhenius equation.

Theory is applied in both assignments and laboratory exercises.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The course is presented in the form of lectures, tutorials with problems and laboratory exercises. Lectures include both theory and derivation of equations, which then are explained and discussed with students with specific calculation examples/exercises and mini competitions. Lectures cover the course goals 1-7.

Assignments consist of preselected problems in every of the five main topics of the course; these problems are handed in to the teacher before the tutorials, are assessed and added to the credits obtained during the final written examination. Assignments cover the course goals 1-8.

The laboratory works are linked to the lectures and train the practical goal 8. The students work in groups with the practical laboratory exercises. Each laboratory work includes preparatory mandatory exercises and questions, which have to be submitted before the beginning of the laboratory works. Laboratory reports should be written up and submitted in groups or individually. The laboratory exercises are mandatory.

The 1st lecture is compulsory for all students. The absence can be granted by the course coordinator.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The learning objectives 1-8 are examined through a written individual examination with grades U, 3, 4, 5. The written examination also validates the knowledge that the students have acquired in learning objective 8 during the laboratory work. Bonus points from the assignments and well-written and submitted on-time laboratory reports are included in the final grade.

Approved laboratory reports examine the learning objective 8.

All included examination parts must be completed for the final grade on the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K0010K is equal to KGK023

## Remarks

The presence at the 1st lecture and at all laboratory exercises is compulsory.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 6 | Mandatory | A07 |  |
| 0002 | Laboratory work | U G# | 1.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
