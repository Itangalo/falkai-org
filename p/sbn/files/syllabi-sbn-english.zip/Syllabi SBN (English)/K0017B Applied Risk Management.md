---
course_code: "K0017B"
title: "Applied Risk Management"
credits: "7.5"
title_sv: "Tillämpad riskhantering"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-01-11"
education_level: "First cycle"
grade_scale: "UG"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0017B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k00/k0017b-tillampad-riskhantering"
---

# Applied Risk Management (K0017B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and 45 hp courses in technology/science. The course K0007B Risk and safety - Basic course must be included

## Selection

The selection is based on 1-165 credits.

## Course Aim

After the course, students should be able to give examples of how methods for risk management can be used. The student should have an understanding of legacy within organizational and structural fire protection and risk management. The student shall demonstrate the ability to prevent accidents and injuries, and design and plan for risk assessment actions. The student should demonstrate the ability to analyze and evaluate complex issues regarding fire protection. The student should be able to present information in writing, oral presentation and opposition.

## Contents

The course consists of lectures, seminar, study visits, group work and individual assignments.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course has different parts which are performed individually or in groups. Necessary information will be provided on the lectures, seminars, via literature and study visits.The students are trained in report writing, oral presentation and opposition.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

To pass the course requires attendance and active participation at oral presentations, seminars and study visits, and to be approved on written reports and assignments. In order to obtain the approved final grade, 80% attendance is also required at lectures. In addition, the student must participate actively in group work and oral presentations.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K0017B is equal to K0014B, K0009B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0009 | Assignment report | UG | 1.5 | Mandatory | S27 |  |
| 0010 | Oral presentation | UG | 1 | Mandatory | S27 |  |
| 0011 | Report | UG | 1.5 | Mandatory | S27 |  |
| 0012 | Lectures, seminars and study visits | UG | 1.5 | Mandatory | S27 |  |
| 0013 | Group project | UG | 2 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-01-11

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-02-14
