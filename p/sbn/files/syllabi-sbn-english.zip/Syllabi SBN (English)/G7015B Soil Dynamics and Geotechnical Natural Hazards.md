---
course_code: "G7015B"
title: "Soil Dynamics and Geotechnical Natural Hazards"
credits: "7.5"
title_sv: "Jorddynamik och naturliga geotekniska faror"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-02-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7015B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7015b-jorddynamik-och-naturliga-geotekniska-faror"
---

# Soil Dynamics and Geotechnical Natural Hazards (G7015B)

## Main field of study

Civil Engineering, .

## Entry requirements

90hp in Civil Engineering of which the course G0003B Soil Mechanics or equivalent shall be included. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

- ILO1: Introduce the students into the concepts of risks, hazards and consequences based on natural hazards related to geotechnical engineering.

- ILO2: Explain the general concepts of simple mechanical models to be used to analyse natural hazards like e.g. earthquakes.

- ILO3: See the link between soil mechanics and geotechnical earthquake engineering. Understand the consequences of - and the choice and design of protection measures against effects of earthquakes.

- ILO4: Understand the mechanism of gravity driven hazards Judge potential consequences and measures.

- ILO5: Relate the influence of climate change and extreme meteorological events on gravity driven hazards, permafrost, floods and e.g. sea level rise.

- ILO6: Identify “man-made” hazards and analyse the interaction between cause and consequence.

- ILO7: Confront the students with the value of actual research on natural hazards and enable the students to read and understand complex comprehensive scientific literature and to critically assess public available information.

## Contents

This course deals with the impact of different hazard processes to civil engineering structures. The following areas are part of the course:
- Introduce the students to the course and basic risk analyses as cause of hazards and consequences.
- Basics of soil dynamics including simple mechanical models and wave propagation.
- Effects of earthquake and protection methods.
- Gravity driven hazards under extreme meteorological events.
- Flood protection measures.
- Man-made induced hazards.
- Influence of climate change on permafrost and other hazards.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

This course includes teaching and learning activities such as:

- Lectures: They are a mix of several teaching/learning activities: (i) the lecturer will shortly explain the main theoretical aspects related to the content of the course and (ii) all together discussing typical phenomenon where natural hazards are related to geomechanics, thereby providing the students an opportunity to practice applying the theoretical knowledge as well as practicing discussing and analysing actual events.

- Computer exercises: The students will be introduced to different numerical applications.

- Assignments: The students work together with other students applying gained knowledge to solve different problems. The work is presented in written assignments as well as a seminar assignment. The students practice problem solving and explaining the work in written as well as oral form.

- Outside of lectures: The students are expected and encouraged to prepare before each lecture by working through the recommended material, recommended exercises or using publically available material so that they are prepared to contribute and participate in discussions during the lectures.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through the solved assignments and the seminar assignment.

- Assignments: Consist of problems where you practice and apply your theoretical knowledge, understanding, and abilities as well as conducting analyses and explaining your results in writing. These are linked to ILO2+5 as well as ILO 4-5, while ILO 6 might be the cause of the hazard. The following ILO’s are examined in the different assignments:

    - Assignment 1, ILO 7 and ILO 3-6, but the focus in the assessment is especially how the critical assessment of available information is handled (ILO 7)

    - Assignment 2, ILO 2+3

    - Assignment 3, ILO 4+5

- Seminar assignment: ILO 7 and ILO 3-6. The written work as well as the oral presentation are taken into consideration

The course is graded with differentiated grades.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a

conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Construction Assignments | UG | 5 | Mandatory | S27 |  |
| 0004 | Seminar Assignment | UG | 2.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11
