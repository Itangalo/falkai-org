---
course_code: "G7011B"
title: "Road and Railway Engineering, Advanced Course"
credits: "7.5"
title_sv: "Vägar och järnvägar, fortsättningskurs"
valid: "Autumn 2023 Sp 1 - Autumn 2025 Sp 2"
decision_date: "2021-04-20"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7011B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7011B&lasPeriod=218&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7011b-vagar-och-jarnvagar-fortsattningskurs"
---

# Road and Railway Engineering, Advanced Course (G7011B)

## Main field of study

Civil Engineering, Maintenance Engineering

## Entry requirements

G0003B Soil Mechanics and G0002B Road and railway engineering or equivalent courses. Good knowledge in English, equivalent to English B/6.

## Selection

The selection is based on 30-285 credits

## Course Aim

The aim of the course is to prepare the student to work within the road- and railway industry from an geotechnical engineering perspective.

In this course the student will work with background as engineer also with

- The road and railway planning process in both

- The road transportation system

- The railway transportation system

The topics extreme climate conditions, maintanence and influence of loading scenarios will be covered in detail linked to actual design concerns of the Swedish Road and Railway Administration.

## Contents

Railways:

- Background of a railway system

- Railway tracks behaviour (i.e., on stabilized and unstabilised ground)

- Common problems and current reinforcement techniques of railway tracks

Soil behaviour

- Basic concepts of Soil investigation in field and laboratory

- Soil behaviour related to road and railways

- Cyclic and dynamic soil behaviour and their related challenges

Frost action:

- Frost action in soil phenomena, its effects on infrastructures and preventive measures.

- Use of FEM software (GeoStudio) to estimate frost penetration under road structures. Introduction to the software with a focus on the ongoing research project “ Impact of culverts on frost penetration in road and railway embankments”

Roads:

- Pavement design

- Design of superstructure in flexible pavements using design software

- Overview of in situ methods used to evaluate condition of road structures.

- Maintenance of the infrastructure: planning, common techniques, routine maintenance, winter maintenance.

- Summary of common road and pavement damages, description mechanisms causing them.

- Regarding infrastructure maintenance and damages focus lies on appropriate design procedures and remediation techniques to ensure longevity of the structures.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. Teaching is given in classes, including problem-solving and informal discussions. Laboratory work. Use of Computer codes relevant to the topic (Geostudio, Design of roads) Assignments solved by the students. The Seminar assignment allows to learn the overall perspective of the geotechnical engineering in a societal based project.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Students will be assessed in their understanding of theory and their ability to apply it. Intended learning outcome is assessed through a seminar assignment. Grading scale G/U 3 4 5. Additional assignments need to be completed for a course grade. Assignments are graded G/U 3 4 5 and will contribute to the final grade.

It is compulsory to attend laboratory work and lecture regarding GeoStudio and other programs.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment report, theory | U G# | 1.5 | Mandatory | A14 |  |
| 0002 | Assignment reports, applications | GU345 | 6 | Mandatory | A14 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-04-20

## Syllabus established

by Eva Gunneriusson 2014-02-04
