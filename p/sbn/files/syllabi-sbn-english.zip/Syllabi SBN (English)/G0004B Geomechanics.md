---
course_code: "G0004B"
title: "Geomechanics"
credits: "7.5"
title_sv: "Geomekanik"
valid: "Autumn 2007 Sp 1 - Present"
decision_date: "2007-01-31"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Items/credits Number       Type                                                            Credits     Grade  0001         Written exam                                                    3           GU345  0002         Required assignment                                             4.5         U G#"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0004B&lasPeriod=154&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g00/g0004b-geomekanik"
---

# Geomechanics (G0004B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Good knowledge in structural mechanics, geology and soil behaviour.

## Selection

The selection is based on 1-165 credits.

## Examiner

Hans Mattsson

## Course Aim

To obtain practically applicable knowledge about soil and rock as a construction material. In soil mechanics be able to derive and utilise models for bearing capacity, settlements, lateral earth pressure and stability. Achieve enough knowledge about stress, deformation, strength and stability in rock to be able to use common design models. Master general project skills as group work and written presentation.

## Contents

Bearing capacity of soils (10%) Bearing capacity of shallow foundations. Inclined loads and effective area. Settlements (15%) Classical consolidation theory and calculation of settlements. Time dependency. Earth pressure (10%) Active and passive Rankine earth pressures against retaining structures. Excavation problems. Slope stability (15%) Stability of slopes with a circular slip surface. Undrained and drained behaviour. Stability charts. Rock stress (10%) Deformation and failure of rock (25%) Design and stability of underground constructions (10%) Design and stability of rock slopes (5%)

## Realization

The teaching consists of lectures, laboratory assignments, assignments etc. The lectures are a mixture of theory and problem solving.

## Examination

Written examination, written tests and assignments.

## Overlap

The course G0004B is equal to ABG104

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Items/credits Number       Type                                                            Credits     Grade

0001         Written exam                                                    3           GU345

0002         Required assignment                                             4.5         U G#

## Literature

*Literature. Valid from Autumn 2007 Sp 1* Stipulated latest three weeks before the course starts.

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
