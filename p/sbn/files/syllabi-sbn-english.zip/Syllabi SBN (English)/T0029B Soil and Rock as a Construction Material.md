---
course_code: "T0029B"
title: "Soil and Rock as a Construction Material"
credits: "7.5"
title_sv: "Jord och berg som konstruktionsmaterial"
valid: "Spring 2026 Sp 3 - Autumn 2026 Sp 2"
decision_date: "2024-02-14"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0029B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0029B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t00/t0029b-jord-och-berg-som-konstruktionsmaterial"
---

# Soil and Rock as a Construction Material (T0029B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Swedish upper secondary school courses Physics 2, Chemistry 1, Mathematics 3c or Mathematics D. Or: Physics level 2, Chemistry level 1, Matematics Further level 1c.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project assignment - group | U G# | 3.5 | Mandatory | A24 |  |
| 0002 | Project assignment - individual | U G# | 2 | Mandatory | A24 |  |
| 0003 | Oral presentation | U G# | 1 | Mandatory | A24 |  |
| 0004 | Study visit | U G# | 1 | Mandatory | A24 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14
