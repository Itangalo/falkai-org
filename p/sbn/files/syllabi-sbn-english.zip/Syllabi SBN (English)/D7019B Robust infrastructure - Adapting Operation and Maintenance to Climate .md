---
course_code: "D7019B"
title: "Robust infrastructure - Adapting Operation and Maintenance to Climate Change"
credits: "7.5"
title_sv: "Robust infrastruktur - Anpassning av drift och underhåll till klimatförändringar"
valid: "Autumn 2025 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2025-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7019B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7019B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7019b-robust-infrastruktur---anpassning-av-drift-och-underhall-till-klimatforandringar"
---

# Robust infrastructure - Adapting Operation and Maintenance to Climate Change (D7019B)

## Entry requirements

Courses of at least 90 ECTS in one of the following areas: Maintenance Engineering, Mechanical Engineering, Civil Engineering, or equivalent. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 30-285 credits

## Course Aim

The aim of the course is to provide comprehensive knowledge, theory, tools, and practical applications for adapting transport infrastructure operation and maintenance to the challenges posed by climate change.

After completing the course, the student should be able to

Knowledage and Understanding

1. Describe the role of transport infrastructure in achieving the Sustainable Development Goals (SDGs).

2. Describe reliability, robustness and reseilinece principles to climate adaptation strategies.

Competence and Skills

3. Analyze climate projections and their impact on transport infrastructure assets.

4. Perform life-cycle cost assessments of different adaptation strategeies of operation and maintenance

5. Identify the potential risks, challenges and requirements to achieve a resilient transport system.

Judgment and Approach

6. Evaluate and critically review information collected in the course.

## Contents

This course covers concepts and theories essential for developing climate-resilient operation and maintenance strategies for transport infrastructure systems. Key topics include an overview of sustainable development goals (SDGs) as they apply to transport networks, future climate projections with Representative Concentration Pathways (RCPs) and Shared Socioeconomic Pathways (SSPs), and methods for assessing climate hazards, exposure, vulnerabilities, and associated risks and cascading impacts on infrastructure.

cr                                                                               1                   13

Furthermore, course includes the principles of Reliability, Availability, Maintainability, and Safety (RAMS) in relation to climate change impacts. Additionally, the course utilizes Life Cycle Cost (LCC) assessment to evaluate the monetary impacts of future climate hazards and impacts on infrastructure operations and maintenance and to guide the selection of suitable climate adaptation actions.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. Lectures will present the core concepts with examples, using slides and board. The lectures can be a combination of online, self-study, and/or classroom interaction. Group assignments integrated into lectures will reinforce students' understanding of each topic through collaborative problem-solving, where they will apply, explain, analyze, or identify relevant subject aspects. Additionally, students will engage in extended group projects and individual exercises to deepen their grasp of each topic. For group projects, students will submit a report and deliver a group presentation, allowing for feedback from peers and the instructor for further refinement. Individual assignments will be reviewed by instructors, who will offer constructive feedback and guidance to support students' learning progress.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Knowledge and understanding will be assessed through project reports, seminars and assignments. Skills and abilities, as well as judgment and attitudes, are examined through project assignments and oral and written presentations. The oral presentation takes place through presentations and discussions. Written reporting takes place via assignments, project assignments, and reflections. All included examination parts must be completed for the final grade in the course (7.5 credits, grade scale: G 3 4 5).

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Assignments | U G# | 3.5 | Mandatory | A25 |  |
| 0004 | Project work | GU345 | 4 | Mandatory | A25 |  |
| cr |  |  |  | 1 | 13 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
