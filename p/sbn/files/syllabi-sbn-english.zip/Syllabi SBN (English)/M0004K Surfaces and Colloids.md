---
course_code: "M0004K"
title: "Surfaces and Colloids"
credits: "7.5"
title_sv: "Ytor och kolloider"
valid: "Spring 2026 Sp 3 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Kemiteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M0004K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M0004K&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/m00/m0004k-ytor-och-kolloider"
---

# Surfaces and Colloids (M0004K)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and The courses M0031M Linear Algebra and Differential Equations and K0010K Physical Chemistry or corresponding and proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The aim of the course is that the student, after completion of it, should be able to:

- define and explain basic surface and colloidal concepts such as surface energy, surface potential, coagulation, capillary condensation, viscosity, and hydrophobicity

- describe diffusion and light scattering properties of colloidal particles

- explain the association properties of surfactants, i.e., how they form aggregates in water

- discuss phenomena related to adsorption in interfaces between different phases such as air-water, solid-water, and solid-gas phases

- apply the DLVO theory and explain factors that influence colloidal stability, i.e., how to prevent or facilitate aggregation

- identify and categorize expressions within rheology and be able to describe factors that influence viscosity

- relate surface and colloid chemical theory to various applications in industrial processes such as mineral processing, food processing, etc.

- formulate mathematical solutions to simple surface and colloid chemical problems, linked to the phenomena covered in the theoretical parts of the course

## Contents

The course deals with

- the colloidal state,

- kinetic and optical properties,

- adsorption equilibria at the interface between different phases,

- charged interfaces,

- colloidal stability, and

- emulsions and foams.

The theory is applied during laboratory and calculation exercises. For example, zeta potential measurement can provide information about the surface charge, and contact angle measurement can be considered as a method for assessing surface hydrophobicity.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures, exercise sessions, and laboratory exercises. Theory and practical exercises are weighed together to apply the theoretical contents in the laboratory work and exercises. The students are expected to actively take part in lectures as well as exercises. For an active dialog between student and the teacher, small exercises and discussions will be arranged as part of the theoretical lectures. This gives the teacher greater opportunities to ensure that students are absorbing the theoretical information and the possibility to correct if there are any misunderstandings. Exercises and laboratory assignments aim to give a more concrete understanding for the theory and its links to practical applications.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is examined as follows: approved laboratory reports, participation in exercise sessions, and an approved written examination are prerequisites for an approved course.

Both theory and calculation tasks are included in the examine order to challenge the student’s ability to deal with surface chemistry problems and answer theoretical questions analytically and contribute to a deeper understanding of the subject. Differentiated grades are applied. Grade scale: 3-4-5.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course M0004K is equal to K7002K

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 5 | Mandatory | A16 |  |
| 0002 | Laboratory report | U G# | 1.5 | Mandatory | A16 |  |
| 0003 | Calculation assignments | U G# | 1 | Mandatory | A16 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2016-01-19
