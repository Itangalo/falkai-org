---
course_code: "D7004B"
title: "Operation and Maintenance Engineering"
credits: "7.5"
title_sv: "Drift och underhållsteknik"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7004B&lasPeriod=216&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7004b-drift-och-underhallsteknik"
---

# Operation and Maintenance Engineering (D7004B)

## Main field of study

Civil Engineering

## Entry requirements

60 ECTS in engineering subjects

## Selection

The selection is based on 30-285 credits

## Course Aim

This course is designed to provide the participants, with the fundamental concepts, principles, and process knowledge of reliability and maintenance engineering and management, to allow them to participate in basic maintenance program development and surveillance analysis. After completion of the course, the participants will be able to:

- Model and analyze reliability of a non-repairable system.

- Perform basic reliability analysis of repairable items,

- Assess related risks of a failure,

- Employ different maintenance strategies,

- Plan and conduct the Reliability Centered Maintenance (RCM) methodology,

- Perform basic maintenance interval optimization.

- Describe the role of human factor in a safe and effective maintenance operation.

## Contents

Within the course, various aspects of Reliability and maintenance engineering will be discussed as follow:

- Fundamentals of RAMS (Reliability, Availability, Maintainability and Safety)

- System performance assessment

- Parametric and non-parametric reliability life data analysis

- Basic reliability analysis of repairable systems

- System reliability analysis

- Risk analysis in engineering

- Reliability-centered maintenance

- Maintenance modeling and optimization

- Condition-based maintenance techniques

- Human factor in maintenance engineering

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. Lectures will present the core concepts with examples, using slides and board. The lectures will be supported by group assignments, to reinforce the understanding of each topic. The students are required to interact for solving a problem, applying, explaining, analysis or identifying an aspect of the subject that presented. The students will also work on a number of extended group project and individual exercises and assignment to strengthen their learning of each topic. In case of group work, the student requires to submit a report supported by a group presentation, to get comments for improvement from the participants and the instructor. Individual assignments will be reviewed by the teachers to provide the students constructive comments and guidance.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course will be assessed based on a final written exam and assignments during the course. The final grade is given in accordance with the written exam, quality of the assignments and active participation in discussions and group presentations.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

Transition terms 1000

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 5 | Mandatory | A07 |  |
| 0003 | Assignment reports | U G# | 2.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
