---
course_code: "T7004K"
title: "Industrial Catalysis"
credits: "7.5"
title_sv: "Industriell katalys"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2018-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Kemisk teknologi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7004K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7004K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7004k-industriell-katalys"
---

# Industrial Catalysis (T7004K)

## Main field of study

Chemical Engineering

## Entry requirements

Physical chemistry, organic chemistry, inorganic chemistry, chemical equilibrium and chemical technology.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completed course the student shall: -be able to explain the importance of catalysis in chemical process and chemical industry today -be able to explain some basic concepts in catalysis, such as: adsorption and desorption, adsorption isotherms, surface area, porosity, dispersion, reactions mechanism, kinetics and zeolites -be able to describe and explain the most common methods for characterization of a catalyst -be able to describe and explain how to derive a reaction expression -be able to describe and explain some of the most important chemical industrial processes with respect to the catalyst used and the reaction condition

## Contents

Introduction, the importance of catalysis in industry and society and basic principles. Physical adsorption and chemisorption on surfaces. Adsorption isotherms. Bonding of reactants to catalyst surfaces. Specific surface areas and porosity. Pore size distribution. Kinetics for catalytic reactions. Adsorption – kinetics. Catalyst preparation. Structured catalysts and zeolite. Catalyst characterization by SEM, XRD, gas adsorption and other techniques Catalyst deactivation. Acid catalysis and zeolites. Processing of petroleum and hydrocarbons. Catalytic oxidation. Synthesis gas and associated processes. Steam reforming. The water gas shift reaction. Methanation. Ammonia production. Nitric acid. Methanol and formaldehyde. Fischer-Tropsch. Catalysis for environmental protection and energy production. Three way catalysts for automobiles.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The instruction consists of lectures, exercises and a comprehensive laboratory project including preparation, characterization and testing of novel, innovative catalysts. The project is presented orally and written. The student will, in addition to get theoretical knowledge in industrial catalysis, develop their practical laboratory skills and oral/written presentation abilities.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The examination comprises laboratory project and written exam with grades according to U (failed), 3, 4 and 5. To pass the laboratory project, the oral and written presentation has to be passed. The grades are failed or passed. Students who have failed an examination on five occasions will not be allowed further resits.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

Transition terms 2500

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4.5 | Mandatory | A07 |  |
| 0002 | Laboratory work | U G# | 3 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2018-02-13

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
