---
course_code: "V7002B"
title: "Urban Stormwater Management"
credits: "7.5"
title_sv: "Dagvatten"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "VA-teknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V7002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V7002B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/v70/v7002b-dagvatten"
---

# Urban Stormwater Management (V7002B)

## Main field of study

Natural Resources Engineering

## Entry requirements

60 hp courses in technology/natural science. For the course occasion in Swedish: Good knowledge in Swedish, equivalent to Swedish 3. For the course occasion in English: Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course participants should be able to

1. Describe urban hydrology and its effect on stormwater runoff

2. Describe and characterize the quality of stormwater and snow and pollution sources

3. Describe and explain the impact of urban stormwater on natural environments regarding both flows/volumes and quality

4. Know different types of sewer systems and describe their function

5. Describe snow management and explain challenges related to it

6. Explain, design and compare the function of different types of blue-green infrastructure to achieve a sustainable stormwater management targeting treatment and retention.

7. Describe and explain the importance of urban stormwater for different stakeholder groups and disciplines as well as how and why these groups have to collaborate to achieve a successful long-term stormwater management.

8. Describe the importance of stormwater in the planning process.

9. Describe ecosystem services connected to stormwater management.

10. Know different computer models for stormwater management and be able to use selected models on a basic level.

11. Calculate stormwater flows and volumes with the rational method and know alternative methods for these calculations.

12. Design and dimension stormwater management facilities

13. Be able to express yourself scientifically

## Contents

This course covers stormwater in urban areas with a focus on sustainable, modern stormwater management including blue-green infrastructure. Questions that will be highlighted are the quantity and quality of stormwater, stormwater systems and facilities as well as their function and dimensioning. In addition to these technical features, the course deals with stormwater in planning and ecosystem services that blue-green infrastructure can provide. The course introduces computer models that can be used for modeling of stormwater systems.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The course includes lectures, seminars, calculation seminars, study visits, a computer lab and group work.

In addition to the theoretical background, the lectures also provide extensive opportunities for discussions of stormwater management. Lectures are held in seminar form where discussions among the students will be part of the teaching and are strongly encouraged.

Since the focus is on blue-green infrastructure, an assignment covers function and design of such a technology. A group work focuses on the creation of a sustainable stormwater management concept. This concept is created by students with different knowledge and backgrounds together. The stormwater management is discussed based on their different backgrounds both in the report and during the report in relation to the other groups' reports.

A seminar and an assignment provide a first insight into computer modeling tools. During a compulsory study visit, various stormwater facilities are visited in the field.

During the spring semester, the course is given on campus in Luleå. During the autumn semester, the course is given as a distance course with three compulsory meetings.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through two exams. One exam (module 0018) covers stormwater management in general (connected to goals 1-10) while the other (module 0014) focuses on the design and dimensioning process for stormwater control measures (goals 6, 11, and 12). Both exams have the grading scale U G 3 4 5.

The examination will also include a literature study (module 0017) which will (early in the course) assess the student’s ability to understand, explain and discuss a chosen stormwater technology (goals 3, 6, 9) as well as the ability to find, assess and summarise scientific literature (goal 13).

Compulsory attendance at a study visit (module 0017) is included in the course examination and provides insights in stormwater control measures/blue green infrastructure in practice (goals 4-6).

A modelling task (module 0019) assesses the student’s ability to use a computer model connected to stormwater management (goal 10).

A group assignment (module 0016) related to a case study assesses the student’s ability to understand a stormwater management system including various aspects of stormwater management with multifunctional blue-green infrastructure (goals 1-3, 6-7, 9, 11-12). The group assignment is assessed through a written assignment as well as a mandatory oral presentation and discussion.

All modules except the exams are graded G U. All modules must be passed to achieve a final grade.

If a student does not attend a compulsory part of the course (as specified in course schedule), these has to be completed the year after, depending on availability.

Both exams are given according to LTU’s exam schedule for the corse given at LTU in term 4. For the distance course one additional exam time is provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course V7002B is equal to ABV002, V0019B

## Remarks

The course cannot be part of the same exam as course V0019B.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0014 | Written exam | GU345 | 2.5 | Mandatory | A07 |  |
| 0018 | Short written exam | GU345 | 1.5 | Mandatory | A07 |  |
| 0020 | Modeling assignment | UG | 0.5 | Mandatory | S27 |  |
| 0021 | Group assignment stormwater management | UG | 2 | Mandatory | S27 |  |
| 0022 | Stormwater control measures: literature study and studyvisit | UG | 1 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
