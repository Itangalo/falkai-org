---
course_code: "G7010B"
title: "Soil modelling with the finite element program PLAXIS"
credits: "7.5"
title_sv: "Jordmodellering med finita elementprogrammet PLAXIS"
valid: "Autumn 2025 Sp 1 - Present"
decision_date: "2025-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7010B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7010B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7010b-jordmodellering-med-finita-elementprogrammet-plaxis"
---

# Soil modelling with the finite element program PLAXIS (G7010B)

## Main field of study

Civil Engineering

## Entry requirements

90 ECTS in engineering subjects including a course in Soil Mechanics or Geomechanics. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 30-285 credits

## Course Aim

The learning outcomes of the course are:

(1) Be able to apply the commercial finite element program PLAXIS for analyses of soil structures.

(2) Be familiar enough with the mathematical background to the non-linear finite element method to be able to judge if the results obtained are accurate.

(3) Be able to determine parameter values to constitutive models in the program out from soil tests.

(4) Practice the general skills written and oral presentation.

## Contents

The course covers how to use the finite element program PLAXIS. Main fields of application for the software. Lectures about chosen parts of the mathematical background to the program; with emphasis on the constitutive models included. Field and laboratory methods to determine the values of the parameters included in the constitutive models. General advises about potential restrictions and pitfalls involved in finite element analysis. When should finite element analyses be performed and when is analytical calculation tools good enough? After a finite element simulation is finished, the results should be critically evaluated, hereby, you get an opportunity to use your knowledge from previous courses in geotechnical engineering. The course also includes training in scientific writing and oral presentation.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The major part of the course is carried out by practical exercises with the software on your own or in groups. Teachers will be available for guidance. Lectures are given on the theoretical parts of the course that are described in Course content. Five assignments where students on their own or in groups work with PLAXIS are handed in to the teacher that correct them and gives feedback. One of these assignments deals with how to determine values to parameters in constitutive models. In addition, a larger modelling project of practical art is carried out in groups and is presented in a written seminar paper. The seminar papers are also presented orally at a seminar specially arranged for this. Each group should act as an opponent group on another group’s paper and oral presentation. Feedback on each group’s paper and oral presentation will also be given by the teacher. Observe that the teacher will give advises about presentation technique, how to handle nervousness etc. in connection to the seminar presentations.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Learning outcomes (1) and (2) are assessed by correcting the assignments and the seminar paper. Learning outcome (3) is assessed when the assignment that deals with determination of model parameter values is corrected. Learning outcome (4) are about general skills and they are assessed in connection to the seminar presentations. Each module assignments and seminar essay are graded according to the grading scale GU345. All exams included in the modules need to be completed for a course grade. The course grade is given as a weighted average value of the grades of the modules.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Seminar essay | GU345 | 3.7 | Mandatory | A12 |  |
| 0002 | Assignments | GU345 | 3.8 | Mandatory | A12 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Eva Gunneriusson 2012-03-14
