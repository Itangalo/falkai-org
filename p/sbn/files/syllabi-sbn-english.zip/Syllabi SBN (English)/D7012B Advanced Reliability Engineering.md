---
course_code: "D7012B"
title: "Advanced Reliability Engineering"
credits: "7.5"
title_sv: "Avancerad tillförlitlighetsteknik"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7012B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7012b-avancerad-tillforlitlighetsteknik"
---

# Advanced Reliability Engineering (D7012B)

## Main field of study

Maintenance Engineering

## Entry requirements

At least 60 ECTS in one of the following areas: Maintenance Engineering, Energy Engineering, Mechanical Engineering, Materials Science, Civil Engineering or equivalent, and a minimum of 15 ECTS in mathematics.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course participants should be able to:

- demonstrate understanding of the fundamental definitions and underlying concepts related to reliability engineering.

- apply both parametric and non-parametric techniques to analyse failure data and estimate relevant model parameters.

- perform probabilistic failure modelling of repairable units using e.g. renewal processes, Poisson processes, nonhomogenous Poisson process

- model the failure behaviour of a multi-unit system

- determine optimal reliability-based maintenance strategies to fulfil system functions

## Contents

Within the course, various aspects of Reliability and maintenance engineering will be discussed as follow:

- Introduction to RAMS and fundamental concepts

- Product reliability, reliability data, and data sources

- Reliability data collection and problems with data

- Preliminary data analysis

- Non-parametric and parametric approaches for analyzing reliability data

- Modelling first failure – standard distributions (Non-repairable units)

- Model selection, parameter estimation and hypothesis testing

- Confidence limits and underlying concept

- Reliability analysis of repairable units

- The Mean Cumulative Function (MCF) for recurrent event data

- Reliability analysis of maintained multi-unit systems

- Reliability based Maintenance modeling and optimization

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. Lectures will present the core concepts with examples, using slides and board. The lectures will be supported by group assignments during the lecture, to reinforce their understanding of each topic. The students are required to interact for solving a problem, applying, explaining, analysis or identifying an aspect of the subject that presented. The students will also work on a number of extended group project and individual exercises and assignment to strengthen their learning of each topic. In case of group work, the student requires to submit a report supported by a group presentation, to get comments for improvement from the participants and the instructor. Individual assignments will be reviewed by the teachers to provide the students constructive comments and guidance.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Intended learning outcome are assessed through a written exam and assignments. The final grade is given in accordance with the written exam, quality of the assignments and active participation in discussions and group presentations.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Written exam | GU345 | 5 | Mandatory | A17 |  |
| 0004 | Assignment reports | U G# | 2.5 | Mandatory | A17 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2017-02-10
