---
course_code: "D0011B"
title: "Introduction to Operation and Maintenance Engineering - Basic"
credits: "7.5"
title_sv: "Introduktion till drift- och underhållsteknik - grundbegrepp"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0011B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0011B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0011b-introduktion-till-drift--och-underhallsteknik---grundbegrepp"
---

# Introduction to Operation and Maintenance Engineering - Basic (D0011B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Swedish upper secondary school courses Physics 2, Chemistry 1, Mathematics 3c or Mathematics D. Or: Physics level 2, Chemistry level 1, Matematics Further level 1c.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

After completing the course, participants should be able to:

Knowledge and understanding: 1. understand why maintenance is needed for technical systems 2. demonstrate basic knowledge of maintenance engineering and dependability 3. demonstrate knowledge of the national gender equality goals and regulations for gender equality in working life.

Competence and Skills: 4. calculate availability performance and perform basic reliability and life cycle cost analyses 5. apply methods for risk analysis within operation and maintenance engineering 6. provide examples of the prerequisite for gender equality in working life

Judgement and approach: 7. demonstrate insight into human error and its impact on maintenance work

## Contents

This course covers:

- Definitions and fundamental concepts

- Methods for condition monitoring

- Reliability calculations and system reliability for series and parallel systems

- Maintainability of technical systems

- Human error

- Maintenance support performance and indicators for operational efficiency

- Life cycle cost analysis

- Risk analysis methods

- Gender equality in the workplace

- National gender equality goals and regulations

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course combines theoretical lectures and self-study with oral presentations and seminars. Students are expected to prepare for seminars by reviewing the assigned material. Active participation in mandatory seminars is required. The gender equality module consists of recorded lectures and literature.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

To obtain a passing grade in the course, all assignments, quizzes, and seminars must be completed with a passing grade.

- Written assignments assess competence and skills related to learning objectives (4–5).

- Seminars assess knowledge and understanding as described in learning objectives (1–2), as well as judgement and approach in learning objective (7).

- Quiz in the gender equality module assess knowledge and understanding related to learning objective (3) and competence and skills related to learning objective (6).

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Seminars | GU345 | 4 | Mandatory | S13 |  |
| 0006 | Assignment reports | U G# | 3 | Inactive | S13 |  |
| 0007 | Gender equality module | U G# | 0.5 | Inactive | S13 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13

## Syllabus established

by Eva Gunneriusson 2013-01-18
