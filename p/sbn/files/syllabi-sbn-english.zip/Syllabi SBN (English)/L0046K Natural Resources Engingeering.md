---
course_code: "L0046K"
title: "Natural Resources Engingeering"
credits: "7.5"
title_sv: "Naturresursteknik"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Naturresursteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0046K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0046K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0046k-naturresursteknik"
---

# Natural Resources Engingeering (L0046K)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Swedish upper secondary school courses Physics 2, Chemistry 1, Mathematics 4 or Mathematics E. Or: Physics level 2, Chemistry level 1, Mathematics Further level 2 or Mathematics E.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

After completing the course participants should be able to

Knowledge and understanding

- Describe and reflect on society's needs and supply of natural resources ore, minerals and water

- Explain and critically relate to the concept of sustainable development

- Outline the planet's origin and structure, ore and mineral deposits, global geochemical and hydrological cycles

- Briefly describe society's technical systems for water and waste management

- Generally describe methods for extraction of ore and minerals and consequences for the environment

- Give examples of the engineer's role and responsibility for sustainable development in his profession

Competence and skills

- Use the library's databases to search for scientific literature

Judgement and approach After completing the course module on gender equality, the student must show an understanding of set gender equality goals, regulations for gender equality in working life and give examples of prerequisites for gender equality in working life.

## Contents

This course covers the need, use, occurrence and availability of ore and water. The concept of sustainable development. The origin and development of the atmosphere and the origin and structure of planet earth. Chemical weathering processes and the global oxygen and carbon cycles. Natural and urban hydrological cycles. Society's systems for water and waste management. The role of engineer. Information retrieval in scientific databases. Equality.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. This course includes lectures and seminars, as well as a compulsory literature research with mandatory tasks. A compulsory study trip for two days is included with a following reflection task. The course have a group work where the students immerse themselves into a chosen issue with guidance from the teachers. The task is reported individually and in a cross group seminar. The course module on gender equality consists of recorded lectures and literature.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The theoretical parts of the course (learning objectives 1-5) are examined with a written exam with grades (U G 3 4 5).

In-depth study of sustainable development and the role of engineer is examined through active participation in group work and in subsequent seminars and is graded with (U/G).

Compulsory participation in study visits and submission of reflection assignments is graded with a (U/G).

Information search where mandatory assignments are included is examined with grade (U/G).

The course module on gender equality is examined through quizzes with grade (U/G).

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Written exam | GU345 | 4 | Mandatory | A13 |  |
| 0002 | Study visit | U G# | 1 | Inactive | A13 |  |
| 0004 | Library, literature search | U G# | 0.5 | Inactive | A13 |  |
| 0007 | Seminars | U G# | 1.5 | Inactive | A13 |  |
| 0008 | Quiz, gender | U G# | 0.5 | Inactive | A13 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2013-01-25
