---
course_code: "G0003B"
title: "Soil Mechanics"
credits: "7.5"
title_sv: "Geoteknik gk"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-01-11"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0003B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g00/g0003b-geoteknik-gk"
---

# Soil Mechanics (G0003B)

## Main field of study

Civil Engineering, .

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and M0011T Strength of Materials and Solid Mechanics or B0002B Structural Engineering or a similar course.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The learning outcomes of the course are:

(1) Be able to apply the basic areas: quaternary geology, characteristics of soils and soil mechanics, both individually and in the applied areas of the course: bearing capacity, settlements, lateral earth pressure, base heave in excavations and stability.

(2) Be able to derive and apply mathematical models for bearing capacity, settlements, lateral earth pressure, base heave in excavations and stability.

(3) In group work be able to plan and solve practical geotechnical problems related to the applied areas of the course.

(4) Be able to perform geotechnical tests in field and laboratory and thereafter evaluate the results.

(5) Ability to work effectively in group.

## Contents

Quaternary geology (5%)

How the soils have been formed.

Nature of soils and classification (10%)

Soil behavior. Nature of soil. Soil mineralogy. Soil formation and soil deposits. Determination of soil composition and engineering properties. Permeability and capillarity. Soil water and interaction between particles and soil water. Soil fabric.

Stresses in soil (5%)

Mean stress and deviatoric stress. Total stress, pore water pressure and effective stress. Stress increase due to surface loading.

Strength and deformation characteristics of soils (20%)

Relation between stresses and strains in dry and saturated soils. Undrained and drained strength. Consolidation theory. Shear tests and triaxial tests. Oedometer tests.

Bearing capacity of soils (15%)

Bearing capacity of shallow foundations. Inclined loads and effective area.

Settlements (15%)

Classical consolidation theory and calculation of settlements. Time dependency.

Lateral earth pressure (10%)

Active and passive Rankine earth pressures against retaining structures.

Base heave in excavations (5%)

Safety factors for different failure modes

Slope stability (15%)

Stability of slopes with a circular slip surface. Undrained and drained behavior. Stability charts.

Project assignment connected to a practical case. The assignment consists of several parts that together covers the applied areas of the course. The assignment is carried out in student groups of approximately four students. Geotechnical tests in field and laboratory to determine soil parameters. These type of soil parameters are used in the applied areas of the course. The soil tests are performed with the help of video instructions and supervision. The tests are performed in groups of approximately four students.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course is divided into two parts. The first part, during approximately the first three weeks of the course, contains quaternary geology, characteristics of soils and soil mechanics and are composed mainly by lectures and problem solving classes. This part is finished by a non-compulsory smaller exam. The students that obtain a pass will get bonus points to the ordinary exam. The second part of the course is structured around the project assignment and its sections, which are analogous to the applied areas of the course: bearing capacity, settlements, lateral earth pressure/base heave in excavations and stability. For each section, an introductory lecture for the assignment part, one or more theoretical lectures and problem solving classes are given. In the end of each section, the student groups are handing in a written report for the present part of the assignment which will be corrected by the teachers. Each part of the assignment is marked when it is corrected and when a group has passed all parts of the assignment bonus points could be obtained to the ordinary exam if the teachers believe that the students work was especially good. In the second part of the course, geotechnical soil tests in field and laboratory are performed group wise. The soil tests in the laboratory are presented by each group by a recorded film that describes each test, the results and the evaluation of the results. The film is corrected by the teachers. The soil tests in field are presented by each group by a written report where the tests, the results and the evaluation of the results are discussed. The written report are corrected by the teachers. A student group that has passed the soil test part of the course can obtain bonus points to the ordinary exam if their work is especially good. In the work with the project assignment and the soil tests the students are trained in: group work, written presentation and work in laboratory.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The learning outcomes (1) and (2) are assessed through a written individual exam. The grading scale is GU345. Learning outcome (3) is assessed by correction of the project assignment. The grading scale is UG#. Learning outcome (4) is assessed by correction of the film and the report in the soil test part of the course. The grading scale is UG#. Learning outcome (5) is a general skill that is assessed at the same time as learning outcomes (3) and (4). All exams included in the modules need to be completed for a course grade. The course grade is given according to the grading of the written exam. Observe that bonus points to the written exam could be obtained from the results of the non-compulsory smaller exam, the project assignment and the soil test part according to what is described in realization.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course G0003B is equal to ABG102

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 3 | Mandatory | A07 |  |
| 0004 | Project work | UG | 3 | Mandatory | S27 |  |
| 0005 | Laboratory work | UG | 1.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-01-11

## Syllabus established

by Department of Civil and Environmental Engineering 2007-01-31
