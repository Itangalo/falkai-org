---
course_code: "V7014B"
title: "Senior Design project in Sanitary Engineering"
credits: "30"
title_sv: "Projektkurs i VA-teknik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "UG"
subject: "VA-teknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V7014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V7014B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/v70/v7014b-projektkurs-i-va-teknik"
---

# Senior Design project in Sanitary Engineering (V7014B)

## Entry requirements

Courses within technology/built environment /natural resources engineering equivalent of at least 200 hp and at least 15 hp within the subject of sanitary engineering or equivalent. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

The overall goal of the course is that the student practices, develops and is able to apply theory and methods to solve unstructured problems relevant to a profession as Master of Science in Environmental Engineering within the field Urban Water Engineering.

This means that on completion of the course the student is able to:

- Formulate a relevant problem for investigation from a chosen subject within the subject area Urban Water Engineering.

- Apply knowledge and proficiency that has been acquired during the period of study to a complex development project or a smaller research project in an independent and systematic manner.

- Choose and justify the study method for an investigation.

- Analyse and defend the problem formulated in a correct manner with respect to science and engineering, without complete information.

- Locate and critically review information and summarise this in a scientific manner.

- Plan, structure and execute a project within research, development or investigation.

- Judge the scientific and practical relevance of the results obtained.

- Work to a timetable.

- Express themselves well in writing in a verbally and scientifically correct manner.

- Create and execute a presentation of the results of the project, defending the conclusions.

- Critically review the work of others in a constructive and scientific manner.

## Contents

The content of the senior design project is designed in collaboration with the supervisor. The degree project always contains a theoretical foundation in the form of a literature survey that highlights the area of technology and the methodology, summarised in a scientific manner.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course is carried out as an individual project in which the student is working independently with the study. The topic is clearly related to urban water engineering and could be chosen by the student or suggested by the supervisor. The student shall contact the course examiner before the start of the course to assess fulfillment of the entry requirements and to identify a suitable project. The study should not only be a literature study. A scientific report should be written, and oral presentation given.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.
- Written presentation of individual work.

In the report the student shows the ability to:

    - Justify the chosen problem of study

    - Select and justify the study methods

    - Collect information relevant to the problem formulation with an explicit connection to the chosen theory/method

    - Present in writing the information collected in a relevant manner

    - Analyse and defend the formulated problem from the chosen theory and methods

    - Critically review the relevance of the results obtained from a scientific and engineering point of view

    - Express themselves in writing in a correct linguistic and scientific manner.

- Oral presentation of own work

- Public discussion of the work of others

- Attendance at presentations of the senior design project work of others

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The department provides active supervision for a period of two terms from the start of the project.

The degree project is performed individually; only in exceptional cases may at most two students carry out the degree project together.

In cases in which the degree project is carried out by two students, this shall be clearly visible in the scope and depth of the report

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Approved oral presentation, written presentation and opposition | UG | 30 | Mandatory | S27 |  |
| 0004 | Project start, registration | UG | 0 | Mandatory | S27 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-06-14
