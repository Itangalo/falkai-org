---
course_code: "P0006K"
title: "High Temperature Processes"
credits: "7.5"
title_sv: "Högtemperaturprocesser"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "UG"
subject: "Processmetallurgi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0006K&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p00/p0006k-hogtemperaturprocesser"
---

# High Temperature Processes (P0006K)

## Main field of study

Chemical Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and K0016K Chemical Principles,K0010K Physical Chemistry or corresponding courses.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course, the student shall be able to

- describe and explain the unit processes which are common within high temperature processes

- describe and apply the theoretical bases for high temperature processes

- from a theoretical and practical view give an account for the extraction of the most common metals

- describe techniques for gas cleaning in high temperature processes and hypothetically design and justify the selections of equipment

- in oral and written presentation suggest solutions to technical problems related to high temperature processes

- exemplify the role and responsibility towards sustainable development within the engineer’s professional practice.

## Contents

High temperature processes is an introductory course that addresses the basics of iron, steel and copper production from a sustainable perspective. The course deals with the theoretical fundamentals and practical aspects of manufacturing by including process technology, environmental awareness and thermodynamics. The course mainly consists of the following parts:

Unit operations connected to high temperature processes such as melting and converting furnaces, etc.

Unit operations connected to gas cleaning of process gases from high temperature processes such as different filter types and cyclones.

Thermodynamics with focus on high temperature chemistry such as heat balances and solution chemistry. In this part, the software FactSage is introduced.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

In the education lectures are combined with exercises, laboratory experiments, project tasks and study trips.

The lectures and exercises will give the students the opportunity to practically and theoretically describe high temperature processes and train the ability to make calculations related to the processes. Laboratory experiments and project tasks related to the industry are carried out as group work. As the laboratory experiments are carried out, the students will perform and evaluate tests and in a written report present the sequence of work and the results attained. Performing the project task the students will, based on computer simulations and other course contents, suggest and justify choices of process techniques for industrial high temperature processes. The project task is shown in oral and written presentation.

The study trips connect contents from lectures, laboratory exercises and project task with applications in the industry.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Approved results for laboratory exercise and project task including oral and written presentation. For laboratory exercise and project task the marks not approved or approved are given. The knowledge in high temperature processes is continuously examined during the course with seminars and assignments with the marks not approved or approved.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course P0006K is equal to P0001K

## Remarks

Compulsory attendance at the first lecture, seminars, laboratory exercise, study trips, project introduction and project presentations. The course is given at basic level and is included in the MSc programme in Sustainable process and chemical engineering. A study guide for the course is found in Canvas.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Seminars and assignments | UG | 5.3 | Mandatory | S27 |  |
| 0004 | Required assignment | UG | 2.2 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17
