---
course_code: "T0028B"
title: "International construction"
credits: "7.5"
title_sv: "Utlandsbyggande"
valid: "Autumn 2017 Sp 1 - Present"
decision_date: "2017-06-16"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Items/credits Number          Type                                                              Credits      Grade  0001            Participated in the study tour and approved report                7.5          U G#"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0028B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0028B&lasPeriod=198&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t00/t0028b-utlandsbyggande"
---

# International construction (T0028B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and The course V0011B Planning and Construction and at least two of T0013B Rock Engineering and Rock Mechanics, K0013B Structural Design and P0001B Construction Management

## Selection

The selection is based on 1-165 credits.

## Examiner

Martin Nilsson

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Overlap

The course T0028B is equal to K0018B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Items/credits Number          Type                                                              Credits      Grade

0001            Participated in the study tour and approved report                7.5          U G#

## Literature

*Literature. Valid from Autumn 2017 Sp 1*

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2017-06-16

## Syllabus established

by Eva Gunneriusson, Assistant Director of Undergraduate Studies at the Department of Civil, Environmental and Natural Resources Engineering 0204-06-12
