---
course_code: "P0016A"
title: "Residential satisfaction"
credits: "7.5"
title_sv: "Boendetillfredställelse"
valid: "Autumn 2009 Sp 1 - Present"
decision_date: "2007-02-28"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Items/credits Number       Type                                                            Credits      Grade  0001         Individual projectwork                                          7.5          GU345"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0016A"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0016A&lasPeriod=162&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p00/p0016a-boendetillfredstallelse"
---

# Residential satisfaction (P0016A)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and General eligibility for approval includes knowledge in ArchiCAD or similar CAD application and basic ergonomics.

## Selection

The selection is based on 1-165 credits.

## Examiner

Géza Fischl

## Course Aim

After having finished the course the student should be able to
- Describe the psychological concepts for environmental description
- Apply the relevant psychological concepts for communicating design ideas
- Develop a specific environment with ArchiCAD and Art-lantis
- Oral and visualize presentation of ideas

## Contents

Theoretical and practical application for
- Describing psychological concepts that are influencing human experience in the built environment
- Basic place design
- Practice of ArchiCAD and Art-lantis
- Case study about a place design

## Realization

The course is based on lectures, seminars, and individual project works. Supervision is provided for the individual project work.

## Examination

Oral and visual presentation of the individual project work is required for the passing grade. Attendance to certain lectures is obligatory. Attendance to supervision and the final presentation is compulsory are obligatory.

## Overlap

The course P0016A is equal to ARP122

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Items/credits Number       Type                                                            Credits      Grade

0001         Individual projectwork                                          7.5          GU345

## Literature

*Literature. Valid from Autumn 2007 Sp 1* Evans, G. W. & McCoy, J. M. (1998). When buildings dont work: The role of architecture in human health. Journal of Environmental Psychology, 18, 85-94. Grossmann, P. R. & Wisenblit, Z. J. (1999). What we know about consumers color choice. Journal of Marketing Practice, 5, 78-88.

## Last revised

The syllabus has been confirmed by the Department of Human Work Sciences 2007-02-28

## Syllabus established

The syllabus has been confirmed by the Department of Human Work Sciences 2007-02-28
