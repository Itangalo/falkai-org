---
course_code: "L7001A"
title: "Experimental Acoustics and Dynamics"
credits: "7.5"
title_sv: "Experimentell akustik och dynamik"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Teknisk akustik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7001A"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7001A&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l70/l7001a-experimentell-akustik-och-dynamik"
---

# Experimental Acoustics and Dynamics (L7001A)

## Entry requirements

Knowledge in acoustics corresponding to either Sound and vibration (L0008A), Architectural acoustics (L0009A), Mechanical vibrations (M0015T) or Vehicle dynamics (M0019T).

## Selection

The selection is based on 30-285 credits

## Course Aim

After the course, the student shall know how to:

- carry out experimental modal analysis measurements for determination of dynamic parameters of vibrating structures

- carry out sound intensity measurements

- calculate energy transfer within a vibrating system using statistical energy analysis

- independently plan, perform and report experimental testing.

## Contents

Advanced measurement and analysis techniques involving auto and cross correlation, coherence and frequency response functions.

Fundamental statistical energy analysis.

Experimental modal analysis and operative deflection shapes.

Sound intensity measurements for sound power and radiation characteristics.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. Lectures and demonstrations including theory and applied problems. Laboratory exercises and a project work that practically illustrate the theory and how to solve a specific problem of experimental nature.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Written exam. Laboratory works with written reports. Project work including oral and written presentation.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course L7001A is equal to ARF105

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4.5 | Mandatory | A07 |  |
| 0002 | Lab, assignment report,project work | GU345 | 3 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The syllabus has been confirmed by the Department of Human Work Sciences 2007-02-28
