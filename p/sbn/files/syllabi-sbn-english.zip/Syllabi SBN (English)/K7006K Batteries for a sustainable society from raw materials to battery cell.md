---
course_code: "K7006K"
title: "Batteries for a sustainable society: from raw materials to battery cells"
credits: "7.5"
title_sv: "Batterier för ett hållbart samhälle: från råmaterial till battericeller"
valid: "Spring 2020 Sp 3 - Present"
decision_date: "2020-03-06"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Kemi"
subject_group_scb: "Chemistry"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7006K&lasPeriod=202&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7006k-batterier-for-ett-hallbart-samhalle-fran-ramaterial-till-battericeller"
---

# Batteries for a sustainable society: from raw materials to battery cells (K7006K)

## Entry requirements

BSc in Chemistry, Metallurgy, Materials Sciences or at least 180 ECTS from a Chemical Engineering programme. The studies should include courses in General Chemistry (for example K0016K), Inorganic Chemistry (for example K0011K) and Physical Chemistry (for example K0010K). Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 30-285 credits

## Examiner

Faiz Ullah Shah

## Course Aim

The goal of the course is that the student, after completion of the course, should

- be able to explain and apply basic electrochemistry in the analysis of different types of electrochemical cells and batteries

- have knowledge on different types of batteries, super capacitors, fuel cells, and their properties

- have knowledge on electrodes, electrolytes and structure of batteries and how they are produced from raw materials

- be able to explain how different parameters influence on the performance and stability of batteries: chargedischarge cycling, temperature, the electrochemical window

- be able to analyse most common electrochemical mechanisms for electrodes materials and how they are changing upon intercalation, alloying, conversion, etc.

- be able to describe the most common ionic conductivity mechanisms in electrolytes

- be able to identify the most common minerals containing Li, Co, Mn, Ni and graphite

- have knowledge about the most important ore types containing Li, Co, Mn, Ni, and graphite, and where these types of ores are mined in the world today

- have knowledge about known deposits of Li, Co, Mn, Ni, and graphite in the Swedish bedrock

- have knowledge on common extraction processes for Li, Co, Ni and graphite

- have knowledge on different recycling processer for lithium-ion batteries and their limitations

## Contents

The course covers basics of electrochemistry. The structure and properties of Helmhotz layers and interfaces in batteries and their importance for the performance of batteries is discussed in detail.

Structure of batteries, different types of electrodes and electrode materials, electrolytes will be covered by both theory and in practical exercises.

Deposit types for Li, Co, Mn, Ni, and graphite, and their mode of occurrence globally and in Sweden, humans need for metals, mineral identification.

Overview of metallurgical processes. Lectures on common process routes for extraction of Li, Co, Mn, Ni and graphite with focus on methods for production of lithium products for battery production as lithium hydroxide. Lectures on commercial recycling processes and overview of research connected to recycling of lithium-ion batteries.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The course is presented in the form of lectures, seminars with assignments and laboratory exercises. Laboratory exercises and assignments are compulsory. The presence at the 1st lecture and at all laboratory exercises is compulsory.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Approved laboratory reports and approved assignments (not differentiated). Approved written examination with differentiated grades, U 3 4 5.

## Remarks

During week 33 (August 10-14, 2020) teaching will take place at Uppsala University.

During week 34-35 (August 17-28, 2020) teaching will take place at Luleå University of Technology.

Study trips to Northvolt AB in Västerås (during week 33 or 35) and Skellefteå (during week 34 or 35) are also planned. Costs related to all trips and accommodation should be covered by students themselves.

The written examination will take place at Luleå University of Technology during week 35 (August 24-28, 2020).

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 6 | Mandatory | S20 | Yes |
| 0002 | Laboratory work | U G# | 1.5 | Mandatory | S20 | Yes |

## Literature

*Literature. Valid from Spring 2020 Sp 3* Helena Berg “Batteries for electric vehicles (materials and electrochemistry)” ISBN 9781107085930. Compendia with assignments and instructions for laboratory exercises.

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-03-06
