---
course_code: "L0049K"
title: "Sustainable Resource Engineering 1"
credits: "15"
title_sv: "Hållbar mineralutvinning 1"
valid: "Spring 2026 Sp 3 - Autumn 2026 Sp 2"
decision_date: "2022-02-11"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0049K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0049K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0049k-hallbar-mineralutvinning-1"
---

# Sustainable Resource Engineering 1 (L0049K)

## Main field of study

Natural Resources Engineering, Geosciences

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Upper secondary school courses English 6, Physics 2, Chemistry 1, Mathematics 3c or Mathematics D. Or: English level 2, Physics level 2, Chemistry level 1, Mathematics Further level 1c .

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

The course provides basic knowledge of the mineral and metal value chain, how the different parts of the value chain are connected and the relation to the surrounding society and environment.

After completing the course, the student should be able to:

Knowledge and understanding

1. Describe the mineral and metal value chain based on scientific basis.

2. Be able to describe and to some extent use technologies for the use of mineral resources.

3. Be able to collect technical and scientific data

Competence and skills

4. Demonstrate the ability to search for and gather scientific information about the mineral and metal value chain.

5. Demonstrate the ability to solve tasks within given time frames.

6. Be able to present and discuss orally and in writing the mineral and metal value chain and its societal context.

Judgement and approach

7. Show insight into the role of minerals and metals in society and how they are extracted, and have knowledge of the current state of the art

8. Make assessments with respect to technical and scientific effects.

## Contents

The course is a project course that provides basic knowledge of the mineral and the metal value chain. Including how to find, mine, extract and recycle minerals and metals and how this affects the surrounding environment. The course consists of different parts along the value chain in project form, both independent work and group work in various forms in collaboration with companies in the area. The course consists of both practical and theoretical elements and of importance is oral and written presentation.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. Project work in groups and independently combined with lectures, field exercises and laboratory work.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Goals/ILOs are assessed through written project submissions as well as oral project presentations and written subprojects / assignments

Project work 1, 3 and oral presentation 1, 3 assess ILOs 1,4,5,6,7,8

Project work 2 and oral presentation 2 assess ILOs 2,5,6,7,8

Assignment / subproject assess ILOs 2,3,5,6

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project Work 1 | U G# | 3 | Mandatory | A22 |  |
| 0002 | Project Work 2 | U G# | 3 | Mandatory | A22 |  |
| 0003 | Project Work 3 | U G# | 3 | Mandatory | A22 |  |
| 0004 | Oral Presentation and Opposition 1 | U G# | 0.7 | Mandatory | A22 |  |
| 0005 | Oral Presentation and Opposition 2 | U G# | 0.7 | Mandatory | A22 |  |
| 0006 | Oral Presentation and Opposition 3 | U G# | 0.7 | Mandatory | A22 |  |
| 0007 | Project part/Assignment report 1 | U G# | 1.3 | Mandatory | A22 |  |
| 0008 | Project part/Assignment report 2 | U G# | 1.3 | Mandatory | A22 |  |
| 0009 | Project part/Assignment report 3 | U G# | 1.3 | Mandatory | A22 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11
