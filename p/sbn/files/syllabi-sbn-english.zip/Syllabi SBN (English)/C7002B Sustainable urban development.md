---
course_code: "C7002B"
title: "Sustainable urban development"
credits: "7.5"
title_sv: "Hållbar stadsutveckling"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2022-02-10"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=C7002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=C7002B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/c70/c7002b-hallbar-stadsutveckling"
---

# Sustainable urban development (C7002B)

## Main field of study

Architecture

## Entry requirements

F7003B Urban Morphology or corresponding course Good knowledge in English, equivalent to English B/6.

## Selection

The selection is based on 30-285 credits

## Course Aim

The course aims to explore and apply theories of sustainability in urban planning practice. The course covers aspects of social, ecological and economic sustainability.

After completing the course, participants should be able to:

Knowledge and understanding

- Describe and explain the concept of sustainability.

- Describe national and international agreements and goals for sustainable urban development.

Competence and skills

- Interpret how social, ecological and economic sustainability is applicable in urban planning.

- Analyse sustainability dimensions in a city at a comprehensive planning level.

- Based on the analysis, make an urban development proposal.

- Present the urban development proposal orally and through text and illustrations.

Judgement and approach

- Reflect on and explain the possibilities and limitations for implementing a sustainable urban development in local planning and in urban development projects.

## Contents

This course explores and implements theories of urban development in the practical application. The course covers aspects of social, ecological and economic sustainability related to land use, density, infrastructure, movement patterns, conservation, green, blue and white structures, and public spaces. The course is based on literature studies and analyses of a selected urban area, as an iterative process throughout the course.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. This course includes teaching and learning activities such as lectures, literature seminars, project work, and supervision.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course aims are examined by seminars and a project task. To pass the seminars (U/G) active participation is required. To pass the project work active participation is required and a pass for the oral, written and visual presentations. The project work is graded by G/U 3 4 5.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

Transition terms 1000

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project work | GU345 | 6 | Mandatory | A07 |  |
| 0002 | Seminars | U G# | 1.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-10

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
