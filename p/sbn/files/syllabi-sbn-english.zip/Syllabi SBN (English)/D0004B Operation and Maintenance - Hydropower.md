---
course_code: "D0004B"
title: "Operation and Maintenance - Hydropower"
credits: "7.5"
title_sv: "Drift och underhåll - Hydropower"
valid: "Autumn 2026 Sp 1 - Present"
decision_date: "2026-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0004B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0004b-drift-och-underhall---hydropower"
---

# Operation and Maintenance - Hydropower (D0004B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and 60 ECTS in engineering subjects

## Selection

The selection is based on 1-165 credits.

## Course Aim

The aim of the course is to provide students with knowledge and understanding of concepts, methods, and theories in maintenance engineering. After completing the course, the student should be able to:

Knowledge and understanding:

1. describe definitions and fundamental concepts in reliability and maintenance engineering

2. demonstrate knowledge of the maintenance process, maintenance objectives, maintenance strategies, and key performance indicators within asset management

3. describe the system structure, operation, and maintenance of hydropower systems

Competence and Skills:

4. perform reliability analysis and life cycle cost analysis

5. apply methods for condition monitoring of rotating machinery

6. apply methods for risk analysis within operation and maintenance engineering

## Contents

This course covers:

- Definitions and fundamental concepts
- The maintenance process within asset management
- Maintenance strategy: policy, maintenance objectives, and key performance indicators
- Reliability-centered maintenance (RCM) and FMECA
- Maintainability and human error
- Calculation of availability and system reliability (series and parallel systems)
- Life cycle cost analysis (LCC)
- System knowledge and maintenance within hydropower
- Condition monitoring and condition-based maintenance
- Maintenance applications within hydropower and rotating machinery

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course combines theoretical lectures and self-study with assignments, oral presentations, and seminars. Students are expected to prepare for seminars by reviewing the assigned material. Active participation in mandatory seminars is required.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

To obtain a passing grade in the course, all assignments and seminars must be completed with a passing grade.

- Assignments assess knowledge, skills, and abilities related to learning outcomes (3–6).

- Seminars assess knowledge and understanding as described in learning outcomes (1–2).

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course D0004B is equal to ABD012

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Assignments | GU345 | 4 | Mandatory | A26 |  |
| 0006 | Seminars | GU345 | 3.5 | Mandatory | A26 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13

## Syllabus established

by Department of Civil and Environmental Engineering 2007-01-31
