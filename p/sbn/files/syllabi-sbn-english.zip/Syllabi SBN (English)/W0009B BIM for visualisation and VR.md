---
course_code: "W0009B"
title: "BIM for visualisation and VR"
credits: "7.5"
title_sv: "BIM för visualisering och VR"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-06-15"
education_level: "First cycle"
grade_scale: "UG"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=W0009B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=W0009B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/w00/w0009b-bim-for-visualisering-och-vr"
---

# BIM for visualisation and VR (W0009B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Basic knowledge in AutoCad and Revit or ArchiCad corresponding to K0001B Computer Tools in Engineering or P0009B Civil and Building Engineering Design.

## Selection

The selection is based on 1-165 credits.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course W0009B is equal to W0007B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Project tasks | UG | 5 | Mandatory | S27 |  |
| 0004 | Assignment reports | UG | 2.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-06-15
