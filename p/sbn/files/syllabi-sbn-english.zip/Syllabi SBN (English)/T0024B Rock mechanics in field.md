---
course_code: "T0024B"
title: "Rock mechanics in field"
credits: "7.5"
title_sv: "Praktisk bergmekanik"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0024B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0024B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t00/t0024b-praktisk-bergmekanik"
---

# Rock mechanics in field (T0024B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and - basic knowledge of tunnelling and blasting corresponding to the course T0013B Rock Engineering and Rock Mechanics or equivalent knowledge
- basic theoretical knowledge in rock mechanics such as stresses and deformations in rock corresponding to the course T0014B Fundamentals of Rock Mechanics or equivalent knowledge

## Selection

The selection is based on 1-165 credits.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 3 | Mandatory | A13 |  |
| 0002 | Required assignment | U G# | 4.5 | Mandatory | A13 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13

## Syllabus established

by Eva Gunneriusson 2013-02-08
