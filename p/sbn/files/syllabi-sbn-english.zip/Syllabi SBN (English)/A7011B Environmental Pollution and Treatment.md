---
course_code: "A7011B"
title: "Environmental Pollution and Treatment"
credits: "7.5"
title_sv: "Miljöföroreningar och reningsteknik"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-06"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Miljöteknik"
subject_group_scb: "Environmental Care and Environmental Protection"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=A7011B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=A7011B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/a70/a7011b-miljofororeningar-och-reningsteknik"
---

# Environmental Pollution and Treatment (A7011B)

## Main field of study

Natural Resources Engineering, .

## Entry requirements

At least 90 hp in Chemical Engineering, Geoscience or Natural Resource Engineering. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, students should have gained a fundamental understanding of environmental pollution, its sources, risks, and treatment techniques.

After completing the course, participants should be able to:
- Describe sources and types of pollutants in air, water, soil and waste.
- Explain chemical and physical processes influencing contaminant transport, transformation, and fate in the environment.
- Identify and discuss major inorganic and organic pollutants (e.g. metals, PFAS, POPs, pesticides).
- Evaluate treatment and remediation technologies for polluted air, water and soil.
- Interpret relevant environmental legislation and policies related to pollution control.
- Assess environmental risks associated with pollution and propose mitigation strategies.
- Collaborate in groups to critically review scientific literature and present in-depth knowledge about one specific contaminant.

## Contents

The course covers the following topics:
- Occurrence and sources of pollution in air, water, soil, and waste.
- Chemical and physical properties of pollutants, including metals, persistent organic pollutants (POPs), PFAS, and pesticides.
- Transport and transformation processes in the environment.
- Health and ecological risks associated with environmental pollutants.
- Environmental legislation and regulatory frameworks for pollution control.
- Treatment and remediation methods for contaminated media, including physical, chemical and biological techniques.
- Contaminant-specific case studies illustrating pollution problems and remediation approaches.
- Group work focused on one contaminant, including a literature review, written report and oral presentation.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The course consists of lectures, literature-based group projects, and seminars.

Students work in groups to gain in-depth knowledge about one contaminant through literature study, written report, and oral presentation. Active participation in discussions and seminars is encouraged to deepen understanding of pollution issues and remediation strategies.

All course material and communication will be available via the learning platform CANVAS.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through:

- A written exam evaluating understanding of all Intended Learning Outcomes (ILOs).

- A group project including written report, oral presentation, and peer discussion.

To pass the course, students must pass both components.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4.5 | Mandatory | A26 |  |
| 0002 | Group project (report and oral presentation) | U G# | 3 | Inactive | A26 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-06
