---
course_code: "F7001B"
title: "Planning methods"
credits: "7.5"
title_sv: "Planeringsmetoder"
valid: "Spring 2026 Sp 3 - Autumn 2026 Sp 2"
decision_date: "2022-02-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7001B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f70/f7001b-planeringsmetoder"
---

# Planning methods (F7001B)

## Main field of study

Architecture

## Entry requirements

F0002B Urban Design or corresponding course. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course participants should be able to:

Knowledge and understanding

- Describe different qualitative methods and quantitative methods used in the planning process (valuations, forecasts, SWOT, Scenarios, backcasting, strategic environmental assessments, multi-criteria analysis, collaboration methods).

Competence and skills

- Search and evaluate policy information on the UN, EU, national, regional and local level

- Analyze the policy context of a society and discern a planning purpose, vision and goals

- Identify areas that can be developed to achieve society's planning visions and goals

- Investigate development strategies for planning

Judgement and approach

- Develop indicators to achieve set planning goals

- Make recommendations for the planning process

## Contents

This course focuses on the processes involved in the design and management of planning policy for the built environment, the tools and methods commonly used and the associated terminology. A particular focus is placed on the use of goal-setting, options, planning scenarios and indicators.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. This course includes lectures, seminars, and project work. The lectures and seminars illustrate the different methods that are available in the planning process. A focus in placed on understanding the terminology used around tools, the role of different tools and the appropriate contexts for their use in the planning system. Lecture also explore the various scale of planning policy. Through the project work the student will practice knowledge in managing and accessing development proposals and scenarios in the planning process. This includes the practice of academic report writing and visual/ oral explanation of work.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course goals are examined through the seminar and project work. The seminar is examined by active participation and graded with a G / U. To pass the project work requires active participation and an approved oral, written, and illustrated presentation. The project work is examined with grades G / U 3 4 5.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project work | GU345 | 6 | Mandatory | A07 |  |
| 0002 | Seminars | U G# | 1.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
