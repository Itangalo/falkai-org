---
course_code: "K7028B"
title: "Project Course, Design of Timber Structures"
credits: "7.5"
title_sv: "Beräkningsprojekt, träkonstruktion"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2026-02-13"
education_level: "Second cycle"
grade_scale: "U G VG"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7028B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7028B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7028b-berakningsprojekt-trakonstruktion"
---

# Project Course, Design of Timber Structures (K7028B)

## Main field of study

.

## Entry requirements

At least 90 credits within the field Civil Engineering or corresponding. Including the courses K7026B Design of Timber Structures 1 and K0019B Wood as a Construction Material or similar. In addition, English 6/level 2 and Swedish 3/level 3 are required.

## Selection

The selection is based on 30-285 credits

## Course Aim

Upon completion of the course, students should be able to:

Knowledge and Understanding

- account for how a timber structure can be efficiently calculated using applicable software based on the finite element method

- describe the advantages and disadvantages of different modelling strategies for the same problem

- account for critical aspects and bottlenecks in modelling

- account for the importance of modelling assumptions for the results

- account for differences in results from analytical and numerical solutions

Skills and Abilities

- choose an appropriate modelling strategy to analyze a timber structure

- analyze a timber structure under different scenarios with regard to strength, stiffness, and stability

- develop practical proficiency in a software to model and analyze a timber structure

- assess the results of a simulation

- compare results from analytical calculations with numerical calculations

- manage and document own work

Judgement and Approach

- determine a model's suitability and ability to solve a problem

- evaluate the reliability of the model for different parameter choices and in comparison with analytical calculations

## Contents

The course consists of a calculation project based on different problems concerning a timber structure. The calculations should be solved using software for the finite element method as well as analytically. The latter for comparison purposes.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course is given as a distance course. The student manages their own work analyzing a suitable structure, which is regularly checked with the teacher. The student chooses a timber structure and a problem statement which will then be analyzed with the software RFEM. Skills and abilities are built up through practice in the software and tutorials with the teacher. Certain calculations should also be made analytically to compare with numerical solutions. The project is checked halfway through and presented at the end of the course.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Examination is carried out through a final presentation and project report where a problem description, model assumptions, and results shall be presented.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K7028B is equal to W7012T

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Report | U G VG | 6 | Mandatory | S27 |  |
| 0003 | Final presentation | UG | 1.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13
