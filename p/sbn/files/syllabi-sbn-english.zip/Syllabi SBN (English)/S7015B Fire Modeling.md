---
course_code: "S7015B"
title: "Fire Modeling"
credits: "7.5"
title_sv: "Brandmodellering"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2022-02-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Brandteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7015B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/s70/s7015b-brandmodellering"
---

# Fire Modeling (S7015B)

## Entry requirements

S0006B Analysis and Design of Fire Loading in Buildings, as well as one of the options S0003B Fire Dynamics I and S7002B Fire Dynamics II or S7014B Fire Dynamics

Corresponding courses also provide eligibility.

## Selection

The selection is based on 30-285 credits

## Course Aim

Knowledge and understanding

After completing the course, the student should be able to:

- define the scientific foundations and proven experience for CFD-calculations (Computational Fluid Dynamics), in particular in fire safety engineering, as well as define the most important current research and development areas in CFD for fire modelling.

- define the general working process for CFD and fire modelling.

Skills and abilities

After completing the course, the student should be able to show the ability to:

- compute turbulent flows.

- explain, solve and judge problems in combustion, flame spread and thermo- and fluiddynamics applied to fires.

- explain different numerical methods.

- solve problems in fire safety engineering with CFD by critically and systematically integrating knowledge in order to simulate and judge scenarios, also with limited available information.

- plan, perform, and interpret complex fire modelling projects, as well as clearly and scientifically present the results.

- show ability for teamwork as well as ability for dialogue with different groups in clearly presenting and discussing the conclusions from fire simulations, as well as presenting and discussing the knowledge and arguments behind the simulations.

Judgement and attitude

After completing the course, the student should be able to:

- judge different models and working processes for CFD-modelling applied to various fire scenarios, as well as show insight about the responsibility of the engineer to choose and account for parameters in such a way that the results are used correctly.

- show ability to identify the student’s own need for further knowledge in fire modeling and for continuous competence development.

## Contents

The course deals with

- Introduction to CFD

- Working process for CFD

- Fluid dynamics and fundamental equations

- Length and time scales in fires

- Turbulent flows: Introduction to turbulence, length and time scales, Large Eddy Simulations, Reynolds Averaged Navier-Stokes and Direct Numerical Simulation

- Combustion and heat transfer

- Numerical methods: fundamental equations, discretization, interpolation and error propagation, meshing techniques, boundary conditions

- Simulation of radiation

- Flame spread

- Different computer programs

- Validation and critical evaluation of CFD

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The teaching is based on self-studies, lectures, quizzes, partial exams, project assignments with oral and written presentation, as well as reflexion assignment.

In order to achieve the course’s goals regarding knowledge and understanding, the student should independently study the specified course literature and participate at the lectures.

In order to achieve the course’s goals regarding skills and abilities, the student should also do the individual quizzes and partial exams, actively participate in the project assignments, including written and oral presentation, as well as actively participate in the consultation offered for these assignment. The project assignments are group assignments.

In order to achieve the course’s goals regarding judgement and attitude, the student should also participate in discussions on the course contents at lectures, group assignments, as well as doing the reflexion assignment.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. In order to pass the course all partial exams, project assignments and the reflexion assignment must be approved by the teacher. The grade, with grading scale F 3 4 5, is determined as a weighted mean value of the results from the partial exams, the project assignments, and the reflexion assignment.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Short written exams | GU345 | 4.5 | Mandatory | S23 |  |
| 0002 | Assignment reports | GU345 | 3 | Mandatory | S23 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11
