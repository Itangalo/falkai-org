---
course_code: "K0002B"
title: "Building materials"
credits: "7.5"
title_sv: "Byggmaterial"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2022-02-11"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0002B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k00/k0002b-byggmaterial"
---

# Building materials (K0002B)

## Main field of study

Architecture, Civil Engineering, .

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Swedish upper secondary school courses Physics 2, Chemistry 1, Mathematics 4 or Mathematics E. Or: Physics level 2, Chemistry level 1, Mathematics Further level 2 or Mathematics E.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

The aim of the course is for the student to develop basic knowledge in building materials.

After completing the course, the student:

1. knows common building materials and their properties

2. is able to account for the basic properties of common building materials in heat and moisture

3. Be able to reflect on problems arising from the production and use of building materials

4. show awareness of potential risks with different building materials.

5. be able to perform basic measurements with technical equipment used in a concrete lab (including analysis).

6. be able to give examples of how to achieve sustainable construction

## Contents

The course deals with the different building materials and their manufacturing, use and most important properties. Students will learn basic concepts and calculations in heat and humidity issues. The course provides a brief introduction to sustainable construction and the environmental impact of building materials. The laboratory offers the opportunity to produce test specimens and perform measurements in an experimental lab.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

Teaching consists of lectures given by several teachers. Lectures focus on the theoretical background of the subject area. Practical skills are trained through calculations / exercises in the classroom, homework and in laboratory tasks. The work in the laboratory is performed in groups and results from the laboratories are documented in lab rapports by the groups. Laboratory work and exercises are linked to the lectures.

Document management takes place in the learning platform Canvas.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

During the course, students will work with written assignments, which will be graded U / G.

During the course, students will work in the lab and write a lab report, which will be graded U / G.

The exam is written and graded U, 3,4,5.

An approved course grade presupposes that all three parts (calculation assignments, laboratory work including report and exam) are approved.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K0002B is equal to ABK031

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4.5 | Mandatory | A07 |  |
| 0002 | Assignment | U G# | 1.5 | Inactive | A07 |  |
| 0003 | Laboratory and group work | U G# | 1.5 | Inactive | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
