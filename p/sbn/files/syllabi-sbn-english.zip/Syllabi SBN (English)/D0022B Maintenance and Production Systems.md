---
course_code: "D0022B"
title: "Maintenance and Production Systems"
credits: "7.5"
title_sv: "Underhåll och produktionssystem"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2020-02-14"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0022B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0022b-underhall-och-produktionssystem"
---

# Maintenance and Production Systems (D0022B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and D0010B Maintenance Strategy or corresponding course.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The course aims to provide the student with in-depth understanding of maintenance of productions systems. After completing the course, the student should:

- understand systems and processes in different industrial sectors

- have in-depth knowledge of how maintenance of different production systems is planned and evaluated

- have basic knowledge and understanding of maintenance management systems

- have the ability to perform measurements for inspection and condition monitoring

- have basic skills in digitalization, the Internet of Things, and data management related to maintenance

## Contents

The course includes the following:

- processes and production systems for various industrial sectors

- maintenance processes, strategies and maintenance activities for different production systems

- methods for inspection and condition monitoring

- tools for maintenance data management and maintenance planning

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The course is given on campus with the opportunity to participate remotely. Mandatory attendance at presentation of assignments. Compulsory attendance at campus and study visits can be required.

The course is conducted using pre-recorded theoretical elements followed by discussion sessions, according to the "flipped classroom" concept. It is assumed that students are prepared for the discussion session by going through the assigned material. Active participation in class is expected. The course also includes laboratory work and study visits.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. To obtain a passing grade in the course, the assignments and the group and laboratory work must be completed with a passing grade.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Assignments | GU345 | 4 | Mandatory | S21 |  |
| 0003 | Group work/laboratory work | UG | 3.5 | Mandatory | S27 |  |

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-02-14
