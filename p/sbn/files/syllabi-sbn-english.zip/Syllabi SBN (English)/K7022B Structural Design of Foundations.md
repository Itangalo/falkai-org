---
course_code: "K7022B"
title: "Structural Design of Foundations"
credits: "7.5"
title_sv: "Dimensionering av grundkonstruktioner"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Konstruktionsteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7022B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7022b-dimensionering-av-grundkonstruktioner"
---

# Structural Design of Foundations (K7022B)

## Main field of study

Civil Engineering, .

## Entry requirements

At least 90 credits completed courses where 30 credits of courses in building materials, structural engineering, structural design and soil mechanics should be included, for instance K0002B Building Materials, B0002B Structural Engineering, K0013B Structural Design and G0003B Soil Mechanics. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course students should be able to:

Knowledge and Understanding:

1. Describe the various types of foundations, and classify the materials commonly used in foundation construction.

2. Identify the appropriate type of foundation depending on the type of superstructure and the soil conditions.

3. Define the appropriate load combinations required for the structural design of foundations.

Competence and Skills:

1. Perform structural checks on foundations to ensure they meet safety and code requirements, including checks for bending capacity, shear capacity, punching shear resistance, and serviceability requirements.

2. Specify the necessary reinforcement details and sizing for different types of foundations, accounting for bending, shear, punching shear forces, and serviceability requirements.

3. Interpret and apply relevant building codes and standards to foundation design, including those pertaining to load factors, material properties, and safety under ultimate and serviceability limit states (ULS, SLS).

Judgment and Approach:

1. Recognize and address structural and technical difficulties associated with the choice of foundation type, including challenges stemming from soil conditions and construction limitations.

2. Produce well-organized technical reports and documentation related to the structural design of foundations, including construction drawings.

## Contents

During this course, the students will learn about:

- Overview of foundation types and their function.

- Type of failures in foundations

- Structural loads on foundations

- Soil-structure interaction

- Overview of relevant design codes and standards

- Interpretation and application of design codes

- Safety factors and load combinations

- Desing of shallow foundations

- Desing of deep foundations

- Design of retaining walls

- Design of special foundation types

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

This course encompasses instructional lectures in which the theory and foundational concepts are presented and illustrated by the instructor. Additionally, a guest lecturer, with substantial expertise in structural foundation design, delivers a dedicated lecture to share their professional insights. The course also features seminars where students actively engage in hands-on problem-solving exercises related to foundation design. The teacher is available for guidance and supervision during these seminars, particularly for project work. As part of the course, students are tasked with individually or collaboratively designing the foundation for a building as a practical project.

Lectures: In this course, multiple lectures are presented to convey the theory and fundamental principles of structural foundation design, with the instructor providing explanations and practical demonstrations. These lectures establish the essential knowledge base upon which students construct their understanding.

Guest Lecturer: To enhance the educational journey, a guest lecturer enriches the experience by sharing their invaluable real-world expertise in the field of structural foundation design. This practical perspective augments the course, offering students insights from an industry professional to broaden their understanding.

Seminars: An integral component of our course consists of interactive seminars in which students actively participate in problem-solving exercises centered on the structural design of foundations. These sessions provide students with the chance to put their theoretical knowledge into practice. In cases where students need assistance, the teacher is readily available to offer guidance and support.

Project Work: A significant component of this course revolves around the hands-on project, where students, either individually or in small groups, take on the challenge of designing a structure's foundation. This practical undertaking provides students with an opportunity to apply their skills in a real-world context and acquire valuable insights. Within the framework of the project assignment, students will also partake in peer-review activities, encouraging collaborative learning.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. This course is examined by few different forms of assignments: written reports, calculation/design assignments, oral presentations, quizzes.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignments | GU345 | 7.5 | Mandatory | A24 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14
