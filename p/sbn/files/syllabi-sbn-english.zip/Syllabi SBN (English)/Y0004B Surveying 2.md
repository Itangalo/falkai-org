---
course_code: "Y0004B"
title: "Surveying 2"
credits: "7.5"
title_sv: "Byggmätning 2"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "U G VG *"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=Y0004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=Y0004B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/y00/y0004b-byggmatning-2"
---

# Surveying 2 (Y0004B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Basic surveying 1 (Y0003B) or corresponding.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The course aims to develop basic knowledge and practical skills in detailed measurement in construction, civil engineering and design measurement, as well as an understanding of backbone network measurement. After completing the course participants should be able to…

Knowledge and understanding

Search for information in governing documents HMK and SIS, and know how they are applied in construction and civil engineering measurement.

Interpret and describe the basics of laser scanning, photogrammetry and UAV.

Check models that form the basis for quantity control and machine control.

Quality-assured measurements, and have an understanding of basic fault theory and tolerances in building and construction measurement.

Check, calibrate and adjust, GNSS rover, balance and total station.

Competence and skills

Establish simpler construction site networks for GNSS and total station measurement.

Perform and calculate a double-weighted high-speed train.

Reduce and process batch measurements.

Judgement and approach

Prepare a simpler measurement report in accordance with "good measurement practice".

## Contents

The course deals with the following:

Balancing train

Batch measurement

Construction site network and adaptations

Detailed measurement with GNSS, total station, balancing instruments, and data processing

Measurement for design

Laying of bolt groups and concrete structures

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures, laboratory work, arithmetic exercises, individual work, group work, field exercises.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is examined through design assignments and a written test.

Grading takes place according to grade scale G U VG. All included examination parts must be completed for the final grade on the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Written test | U G VG * | 4 | Mandatory | A08 |  |
| 0005 | Assignment report | UG | 3.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2008-01-22 and is valid from H08.
