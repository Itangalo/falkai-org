---
course_code: "M0002K"
title: "Environmental Analysis"
credits: "7.5"
title_sv: "Miljöanalys"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Miljöteknik"
subject_group_scb: "Environmental Care and Environmental Protection"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M0002K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M0002K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/m00/m0002k-miljoanalys"
---

# Environmental Analysis (M0002K)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Mastering of solution equilibria in natural waters comparable to what is given in the course K0006K, Water Chemistry.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The course aims to create knowledge of various existing tools for assessing environmental impacts, energy consumption, etc., depending on different process selection, material selection, etc., and to be able to critically examine the results obtained.

After completing the course, participants should be able to

- Explain the approach in life cycle analysis and environmental impact assessments,

- Describe how geographical information systems are used to generate planning data,

- Perform simpler life cycle analyses,

- Prepare parts of the technical basis for assessing potential environmental impact,

- Explain and critically relate to the term of sustainable development at national and global level; how it arose, evolved over time, its various contemporary definitions, expressions and ethical starting point,

- Explain the economic legal and political instruments available, both nationally and internationally, and be able to critically relate to their design, limitations and applications towards the sustainable development of society in general and the development and application of technology in particular,

- Demonstrate the ability to develop and design products, processes and systems with regard to human conditions and needs and society's goals for economically, socially and ecologically sustainable development.

## Contents

This course covers

Life cycle analysis:

- Theoretical aspects of LCA: What type of basic data is required, what assumptions are made, how does this affect the outcome of an LCA?

- PC lessons and PC labs

Geographical information systems:

- What does GIS mean, how is information handled and extracted.

- PC lessons and a PC lab

Environmental impact assessments:

- When and how is an EIA prepared, what technical basis is required, how are society's interests defined.

- Social impact statement

- The legal system around environmental issues and EIA

- Project

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The teaching consists of lectures, PC lessons, PC labs and a large project.

The lectures shall give the students the opportunity to plan and perform simple analyses as well as to be able to explain theoretical terms.

The PC lessons are devoted to practicing calculation procedures and techniques.

The PC labs are performed in groups and introduce the assignments, which are completed later, and which train the student to plan and perform life cycle analysis and GIS work in groups, as well as to report the results in technical summaries.

The project is devoted to in groups describe, analyze, evaluate, interpret, report and present results for an EIA based on process engineering data material. The project is reviewed in two seminars, where the first is devoted to presenting the data material and the planned work to other groups. The groups may represent different stakeholder interests with regard to EIA: companies, society, authorities, etc., and shall, based on these roles, prepare various documents and pleas. The second seminar is devoted to review the work performed in the form of a simulated environmental assessment where the various stakeholder groups are allowed to represent their interests.

Assignments and project report must be technically, statistically and linguistically correct.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Assignments, project assignments and seminars are mandatory. Assignments, seminars and projects are assessed with points in these parts. Information and reports must be submitted within the prescribed period, otherwise the maximum achievable points will be reduced for the module. The total score production gives the total grade for the course, which is given with graded grades on the scale U G 3 4 5.

- For grade 3, the student must be able to describe procedures for and perform routine life cycle analyses, GIS extractions and be able to describe the sequence of an EIA.

- For grade 4, the student must be able to evaluate and interpret LCA and GIS data as well as review results from an EIA.

- For grade 5, the student must be able to apply their knowledge to new data material, interpret, report and present the results and defend their conclusions.

Students who fail five exams do not have the right to take additional exams.

Mandatory attendance at the first lecture.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Assignment work | GU345 | 4.5 | Mandatory | S15 |  |
| 0004 | Project | GU345 | 3 | Mandatory | S15 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2011-02-04
