---
course_code: "L0008B"
title: "Cartographic Visualization"
credits: "7.5"
title_sv: "Kartografisk visualisering"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2023-06-02"
education_level: "First cycle"
grade_scale: "UG"
subject: "Geografisk informationsteknologi"
subject_group_scb: "Geographic Information Technology and Surveying"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0008B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0008B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0008b-kartografisk-visualisering"
---

# Cartographic Visualization (L0008B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

After approved course the student

- shall be able to produce well designed and informative maps,

- has obtained a deepened understanding to methods and techniques for visualizing geographical data from different data sources with focus on practical application.

## Contents

- Cartography Cartographic basics Visual variables Generalization Symbolizing Colour systems and colouration Lettering a map Layout Presentation of statistics Maps from different data sources Maps for different kinds of media, Web, Smartphones

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. All the course material and software can be found on LTU’s Citrix portal. There you can also find more detailed descriptions of the course contents and its realization. There are no pre-recorded lectures, nor are there any mandatory gatherings.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course aims are examined through assignments that will be completed individually or in groups of two people and by a project assignment which will be examined throughout the course. The grading of the assignments and the project assignment will be carried out according to U/G scale. All assignments should be completed to receive a final grade. Assignments are available on LTU’s Citrix portal.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course L0008B is equal to ABL030

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Assignment | UG | 4.5 | Mandatory | S27 |  |
| 0004 | Project work | UG | 3 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
