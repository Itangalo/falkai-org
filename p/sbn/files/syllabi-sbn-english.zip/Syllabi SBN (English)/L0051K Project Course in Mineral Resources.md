---
course_code: "L0051K"
title: "Project Course in Mineral Resources"
credits: "15"
title_sv: "Projektkurs i mineralresurser"
valid: "Autumn 2026 Sp 1 - Present"
decision_date: "2026-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0051K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0051K&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0051k-projektkurs-i-mineralresurser"
---

# Project Course in Mineral Resources (L0051K)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and At least 90 credits completed courses within the technical areas of Geosciences/Natural Resources Technology, including the courses O0041K Geosciences, O0042K Mineralogy and Crystallography, L0050K Geochemistry, P0008K Mineral and Metallurgical Process Technology or equivalent courses. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The student develops knowledge in a field not covered by ordinary courses and to learn to work independently, close to research. This means that on completion of the course, the student is able to:

- Formulate a relevant problem for investigation from a chosen subject within the subject area Mineral Resources.

- Apply knowledge and proficiency acquired during the period of study to a complex development project or a smaller research project independently and systematically.

- Choose and justify the study method for an investigation.

- Analyse and defend the problem formulated correctly with respect to science and engineering, without complete information.

- Locate and critically review information and then summarise it scientifically.

- Plan, structure, and execute a project within research, development or investigation.

- Express themselves well in writing in a verbally and scientifically correct manner.

## Contents

The examiner specifies the content of the course in a detailed course description at the course occasion. The courses are often given close to ongoing research projects at the Department of Civil, Environmental and Natural Resources.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The realization of the course is specified by the examiner in a detailed course description at the course occasion. The courses are placed late in the program, so the students are expected to take a bigger responsibility for their learning compared to basic courses.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The examination of the course is specified by the examiner in a detailed course description at the course occasion and can consist of written reports, written/verbal presentations, written/verbal tests and/or seminars.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project assignment | GU345 | 15 | Mandatory | A26 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13
