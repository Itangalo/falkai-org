---
course_code: "D0002B"
title: "Operation and Maintenance"
credits: "7.5"
title_sv: "Drift och underhåll"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-04-20"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0002B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0002b-drift-och-underhall"
---

# Operation and Maintenance (D0002B)

## Main field of study

Civil Engineering, Maintenance Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Linear Algebra and Calculus (M0048M) and Mathematical Statistics (S0001M) or corresponding courses.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The aim of the course is to provide students with knowledge and understanding of concepts, theories and methods in maintenance engineering. After completing the course, the student should have skills to perform analyses for a reliable and economical operation. The knowledge can be applied for those active in the field of infrastructure and civil engineering.

## Contents

The course contains:

- Maintenance and dependability concepts

- Calculation of availability and reliability of serial and parallel systems

- Condition monitoring and condition-based maintenance

- Remaining useful life prediction models

- Life cycle cost analysis

- Maintenance organization, client and contractor relationship

- Methods for risk analysis and maintenance planning

- Maintenance applications for road, rail, bridge, and civil engineering

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures, group work, seminars and laboratory work.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Approved assignments. Written exam with differentiated grades.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course D0002B is equal to ABD004

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Written exam | GU345 | 4 | Mandatory | A07 |  |
| 0005 | Group work/Assignment reports | UG | 3.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-04-20

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
