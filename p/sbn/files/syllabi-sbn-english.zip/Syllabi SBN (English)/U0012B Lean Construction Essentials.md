---
course_code: "U0012B"
title: "Lean Construction Essentials"
credits: "1.5"
title_sv: "Lean Construction grund"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2024-02-19"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=U0012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=U0012B&lasPeriod=212&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/u00/u0012b-lean-construction-grund"
---

# Lean Construction Essentials (U0012B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Attendence Seminars | U G# | 0.5 | Mandatory | A23 |  |
| 0002 | Participation in reflections and discussions | U G# | 0.5 | Mandatory | A23 |  |
| 0003 | Written exam | U G# | 0.5 | Mandatory | A23 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-19
