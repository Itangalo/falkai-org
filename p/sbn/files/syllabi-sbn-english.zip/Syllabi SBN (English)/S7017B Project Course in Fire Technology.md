---
course_code: "S7017B"
title: "Project Course in Fire Technology"
credits: "30"
title_sv: "Projektkurs i brandteknik"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2024-02-19"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Brandteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7017B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/s70/s7017b-projektkurs-i-brandteknik"
---

# Project Course in Fire Technology (S7017B)

## Entry requirements

At least 60 credits in total in the fields of fire technology, physics and chemistry. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2. For exchange students, the examiner makes an individual assessment of the qualifications depending on the type of project.

## Selection

The selection is based on 30-285 credits

## Course Aim

The student shall independently design, carry out and report a project within the subject of Fire technology.

Upon completion of the course the student will be able to:

- Formulate a relevant problem for investigation within the subject of Fire Technology.

- Apply your theoretical knowledge that you acquired during your studies to a research project in an independent and systematic way.

- Choose and justify the study research methods.

- Effectively plan and implement a project work within the chosen research topic.

- Solve problems independently in the project.

- Locate and critically review scientific information relevant to the project.

- Evaluate your results by using the theoretical knowledge you learned.

- Write a scientific report, give an oral presentation and defend the conclusions.

## Contents

The project topic is related to the current research frontiers of Fire technology and will be defined in cooperation with the examiner.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The student will work independently under the guidance of a teacher that will be assigned based on the chosen research topic. Students will be given access to relevant laboratory facilities of Fire Technology, including analytical instrumentation. Prior to use of scientific and analytical equipment, appropriate training and safety instructions will be given. Students will have regular communication with the teacher to ensure that they receive appropriate support and monitor the progress of the project.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The learning objectives are examined through a written report and an oral presentation with grades according to G, U, 3, 4 and 5. Practical application of the learning outcomes is examined via the project work.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Passed oral and written presentation | GU345 | 30 | Mandatory | S25 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-19

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-19
