---
course_code: "T7010K"
title: "Chemical Reaction Engineering"
credits: "7.5"
title_sv: "Kemisk reaktionsteknik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-02-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Kemisk teknologi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7010K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7010K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7010k-kemisk-reaktionsteknik"
---

# Chemical Reaction Engineering (T7010K)

## Main field of study

Chemical Engineering

## Entry requirements

M0048M Linear Algebra and Calculus, M0049M Linear Algebra and Differential Equations, K0010K Physical Chemistry and B0003K Transport Processes or corresponding courses. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

The goals of the course are that the student should, after completing the course:

1. have obtained the basic theoretical foundations for being able to select and dimension reactors for the implementation of chemical processes and to determine the operating mode and optimization of these reactors.

2. be able to mathematically describe chemical reactors (limited to the topics covered in the course).

3. be able to solve simple reaction technical problems with the help of computer tools such as MATLAB.

4. be able to describe and explain how the most common chemical reactors work and their advantages and disadvantages.

## Contents

Introduction to numerical methods and MATLAB. Mass and energy balances, reaction kinetics, ideal batch, tank and tube reactors, adiabatic equilibrium processes, reactor capacity, pressure drop in chemical reactors, selectivity, yield and reactor stability.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The teaching-learning activities are comprised of lectures, tutorial sessions, assignments and a laboratory exercise.

- The lectures illustrate the most important theory behind chemical reaction technology. During the tutorial sessions, the instructor presents how the most common types of problems are solved.

- Compulsory assignments are solved in smaller groups, aiming at getting the student to practise mathematical modelling of reactors/reactor systems and analysing the models, and to develop oral presentation skills.

- In the laboratory exercise, the students are given the opportunity to work in groups, practise written presentation, independent problem solving and theory regarding chemical reactors.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The examination consists of a written exam, assignments, and laboratory work.

- Intended learning outcome 1 and 2 are assessed through a written exam. The exam is graded as U (failed, less than 50% done correct), 3, 4 and 5.

- Intended learning outcome 3 is assessed through assignments. The assignments are graded as passed or failed, this part is examined continuously during the course.

- Intended learning outcome 4 is assessed through a laboratory. Attend the lab exercise and write a report are mandatory. The grade passed or failed will be given.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course T7010K is equal to T0006K

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4 | Mandatory | S23 |  |
| 0004 | Laboratory work | UG | 1 | Mandatory | S27 |  |
| 0005 | Assignments | UG | 2.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11
