---
course_code: "W7003B"
title: "Virtual design"
credits: "7.5"
title_sv: "Datorstödd projektering"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-04-20"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Träbyggnad"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=W7003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=W7003B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/w70/w7003b-datorstodd-projektering"
---

# Virtual design (W7003B)

## Main field of study

., Civil Engineering

## Entry requirements

W0007B CAD&VR or P0009B Civil and Building Engineering Design or equivalent knowledge. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course the student should be able to deliver correctly formatted drawings following the rules set by the Swedish standard Bygghandlingar 90.

After completing the course, the student should be able to:

- Model building objects in 3D

- Read and understand construction drawings

- Produce construction drawings with the appropriate level of detail

- Annotate construction drawings with reflection on shape chosen technical solutions according to rules in BBR (Boverket)

After completing the course, the student shall understand:

- The building design process and how it interacts with the building process

- The role of building information modeling in construction

- How virtual models are quality audited with each other

- How import and export between software for building information modeling works

## Contents

The course will cover building information modelling in the later stage of building design process i.e. from 3D-model to generation of 2D-drawings. The role of the drawing and how to construct it to serve the contractors is stressed in the course.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The students work independently during the first part of the course and are examined in two individual assignments. During the project assignment, the students work in groups of 5-6 people and must then plan and carry out the project assignment within a given time and resource framework. The skills in construction that are trained in the course are the ability to understand and describe built objects, the ability to communicate solutions downstream in the construction process and the ability to document technical solutions in drawing and writing. The course is based on your own work in a computer environment.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The examination consists of two individual assignments and a project work in groups with different subassignments. The grading scale is U G on individual elements and project work. The grade U 3 4 is given for the entire course. The final grade for the course is governed by the course credits (0-100p) that the student has collected during the course. The system is described in detail in the study guide that is distributed at the start of the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

Course is given in Swedish or English if international students are present. The course is included as a specialization course in the for Civil engineering at master level. And Kursen ges på avancerad nivå och ingår som inriktningskurs i inriktningen Byggande inom civilingenjör Väg- och Vatten samt obligatorisk inom civilingenjör Brandteknik.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Project assignment | UG | 4.5 | Mandatory | S27 |  |
| 0004 | Assignment reports | UG | 3 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via

My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-04-20

## Syllabus established

by Department of Civil and Environmental Engineering 2008-01-22
