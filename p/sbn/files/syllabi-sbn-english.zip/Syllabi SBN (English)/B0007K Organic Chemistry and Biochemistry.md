---
course_code: "B0007K"
title: "Organic Chemistry and Biochemistry"
credits: "7.5"
title_sv: "Organisk kemi och biokemi"
valid: "Autumn 2024 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2024-02-14"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Kemi"
subject_group_scb: "Chemistry"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B0007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B0007K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/b00/b0007k-organisk-kemi-och-biokemi"
---

# Organic Chemistry and Biochemistry (B0007K)

## Main field of study

Chemical Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and K0016K Chemical principles or equivalent

## Selection

The selection is based on 1-165 credits.

## Course Aim

After passing the course, the student should have basic knowledge in organic chemistry and biochemistry that can be applied in later courses in the Master of Science (MSc) program in Sustainable Process and Chemical Engineering.

After the course, students are expected to be able to:

1. Describe organic compounds, their chemical structures, nomenclature and reaction mechanisms

2. Explain the relationship between structure and properties of some natural and synthetic polymers

3. Describe how some commercially important organic compounds are produced in the industry and their properties/ functionality 4. Describe the biochemical reactions that occur in living organisms for them to be able to transfer energy and synthesize macro molecules

5. Describe how biochemical processes can be used in practical applications

6. Carry out, evaluate and report experimental work in groups

7. Be able to identify knowledge needs and discuss and develop in the subject

## Contents

Initially, the course deals with the concept of organic compounds, which form the basis for the cell's molecular structure and function, which is dealt with in the later part of the course. The course also highlights how some common organic compounds are used commercially as well as examples of industrial biochemical processes.

Part 1: Organic Chemistry

This part covers primarily the following topics:

1. Classification of organic compounds and their nomenclature (alkanes, alkenes, alkynes, aromatics, ethers, alcohols, aldehydes, ketones, carboxylic acids and halogenated hydrocarbons)

2. Isomerism: geometrical and stereo isomerism

3. Addition and substitution reactions and mechanisms

4. Chemistry of some synthetic polymers (polyurethanes, polylactic acid, polyhydroxybutyrates)

5. Introduction to industrial and medicinal chemistry

Part 2: Biochemistry

This part covers primarily the following topics:

1. Structure and function of natural polymers (polypeptides, polysaccharides and nucleic acids)

2. Structure and function of lipids and biological membranes

3. Enzymatic catalysis of reactions and regulation of enzyme activity

4. Bioenergetics and metabolism

5. Biotechnological processes in research and the industry

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The teaching consists of lectures, compulsory assignments and discussions about these, as well as laboratory work. Active participation in the lectures contributes to learning the basics of the subject and the assignments provide training in both writing and orally describing and explaining issues within the subject. The labs train skills in laboratory work, collaboration and problem solving, as well as oral and written communication. Furthermore, the insight into the subject, as well as the subject's connection to society, is broadened through various guest lectures given by researchers and industry representatives.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Learning outcomes 1-5 and 7 are examined through approved written assignments and discussions during the course, as well as individual written exams for part 1 and part 2 of the course, with the grade scale G/U. The results from these two exams form the basis for the final grade, according to grade scale U 3 4 5. Learning outcome 6 is assessed through two laboratory sessions and subsequent written reports, with the grade scale G/U. All included examination parts must be completed for the final grade on the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course B0007K is equal to K0002K, B0005K

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0004 | Assignments | U G# | 2 | Mandatory | A10 |  |
| 0006 | Laboratory work | U G# | 1.5 | Mandatory | A10 |  |
| 0007 | Written exam biochemistry | GU345 | 2 | Mandatory | A10 |  |
| 0008 | Written exam organic chemistry | GU345 | 2 | Mandatory | A10 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Department of Chemical Engineering and Geosciences 2010-08-05
