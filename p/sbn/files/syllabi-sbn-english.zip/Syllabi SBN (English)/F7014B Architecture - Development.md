---
course_code: "F7014B"
title: "Architecture - Development"
credits: "7.5"
title_sv: "Arkitekturutveckling"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2022-06-15"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7014B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f70/f7014b-arkitekturutveckling"
---

# Architecture - Development (F7014B)

## Entry requirements

Bachelors degree in Architecture or Construction (i.e. completion of the first three years of MSc Architecture). Approved courses; Engineering Architecture F0007B, F0012B Conceptual Design, CAD + VR W0007B, Urban Design F0002B and Construction Project Management P0007B.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing this course students will:

Knowledge and understanding

have insight into current research and development within the theme of the current project work.

Competence and skills

- develop or design project proposals, products or processes with regard to people's conditions and needs and society's goals for economically, socially and ecologically sustainable development.

- carry out a qualified project that can include parts of a house building and / or city building within a given framework.

- be able to independently carry out an investigation or development work.

- present their results to the group both in writing and orally.

Judgement and approach

- assess technology's possibilities and limitations in own solutions to problems and reflect on this limitation in the presentation of projects.

- with a holistic view critically, independently and creatively identify, formulate and handle issues in order to solve project task.

- assess the ethical and work environment consequences if projects are realized.

## Contents

This course covers Architecture with a focus on building construction and/ or urban design. Literature searches, seminars, sketch and design tasks, the use of CAD and computer tools for the preparation, presentation and documentation of projects.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. This course applies the knowledge students have acquired in previous basic level courses. Application is through participation in the planning and implementation of an advanced investigation or development project. The work is performed in part individually and partly in groups. Tutorials takes place in groups and individually. External tutors and lecturers with professional experience may apply. Submissions shall be of a high grade, supported by reference literature and references. The work should be delivered in a way so that it is clear to a person who is not familiar with the project and is only receiving the results of the work. The course is an architecture and design based course. Students are expected to make presentations in the form of drawings with high-quality figures and models (both digitally and physically). Students will need to reflect on the end result of their project.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course includes literature seminars and workshops on methodology for project implementation. Group and individual evaluation is undertaken by the course examiner. For final grading, participation in and attendance of seminars, tutorials, workshops, presentations of the project work and participation in the written report (in the form of a joint course record of the set theme) is required. Intended learning outcome Knowledge and understanding is examined through Seminar (G U). Other Intended learning outcome is examined through the project work (G U 3 4 5).

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Seminar | U G# | 1 | Mandatory | A14 |  |
| 0006 | Project work | GU345 | 6.5 | Mandatory | A14 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via

My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-06-15

## Syllabus established

by Eva Gunneriusson 2014-02-10
