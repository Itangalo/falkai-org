---
course_code: "F0021B"
title: "Urban Design"
credits: "7.5"
title_sv: "Urban design"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-02-11"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F0021B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F0021B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f00/f0021b-urban-design"
---

# Urban Design (F0021B)

## Main field of study

Architecture

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and 60 ECTS in the engineering discipline of architecture, including:
- Knowledge in the planning and building process corresponding to F0007B Engineering architecture or equivalent course
- Knowledge in sketching, drawing and illustration techniques corresponding to D0021A Architectural sketching or D0054A Sketching and drawing or equivalent course

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course participants should be able to:

Knowledge and understanding
- Conduct an inventory of an area and describe the strengths, weaknesses, opportunities and threats

Competence and skills
- Formulate qualitative and quantitative goals for the development of the area
- Show the ability to design a proposal for a neighborhood area based on a planning program
- Deliver a detailed proposal for subdivision of the design proposal

Judgement and approach
- Communicate design ideas in text and visualizations

## Contents

This course covers the processes undertaken to develop an urban design strategy at the neighbourhood scale. The course is designed to reflect the different stages in the actual planning process and gives skills in preparing inventories, establish programs, urban design, and detailed study of the area.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. This course includes lectures, literature seminar, group work, oral presentations and a group review of another group’s project work. The lectures and literature illustrate how different approaches can be taken to analysing an area and developing urban design proposals. The group work is designed to give guidance on project development. Though the project assignment, students will practice knowledge of preparing urban design inventories, concept design development and progression to more detailed urban design proposals. In particular, a high quality, graphic, poster presentation will be developed by students.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course aims are examined in four parts (i-iv). The Inventory & Analysis (i), Structure (ii), and detailed design (iii) are assessed in group supervision sessions. The final examination (iv) is by formal oral/ poster presentation with an invited audience. To pass the course requires active participation in the project work, a pass for the oral/ poster presentation, and at least 80% attendance at lectures. A critical review of another group’s poster report must also be carried out. Part I and II are assessed with a grading of U/G. Part III and IV with U,G,3,4,5

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course F0021B is equal to F0002B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Phase 3 | GU345 | 2.3 | Mandatory | A21 |  |
| 0004 | Phase 4 | GU345 | 2.2 | Mandatory | A21 |  |
| 0005 | Phase 2 | UG | 1.5 | Mandatory | S27 |  |
| 0006 | Phase 1 | UG | 1.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17
