---
course_code: "X7015B"
title: "Degree project in Timber Structures, Master"
credits: "15"
title_sv: "Examensarbete i träkonstruktion, magister"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2026-02-13"
education_level: "Second cycle"
grade_scale: "UG"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X7015B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/x70/x7015b-examensarbete-i-trakonstruktion-magister"
---

# Degree project in Timber Structures, Master (X7015B)

## Main field of study

.

## Entry requirements

At least 30 credits completed courses of the degree requirements. Appointed examiner determines if the student has the depth required for the proposed thesis. In addition, English 6/level 2 and Swedish 3/level 3 are required.

## Selection

The selection is based on 30-285 credits

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course X7015B is equal to W7014T

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Oral presentation | UG | 0 | Mandatory | S27 |  |
| 0006 | Public discussion of other degree project | UG | 0 | Mandatory | S27 |  |
| 0007 | Start of degree project | UG | 0 | Mandatory | S27 |  |
| 0008 | Accepted report | UG | 15 | Mandatory | S27 | Yes |

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13
