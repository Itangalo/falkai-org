---
course_code: "P0008K"
title: "Mineral and Metallurgical Process Technology"
credits: "7.5"
title_sv: "Mineralteknisk och metallurgisk processteknik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2025-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Processmetallurgi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0008K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0008K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p00/p0008k-mineralteknisk-och-metallurgisk-processteknik"
---

# Mineral and Metallurgical Process Technology (P0008K)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Knowledge of minerals (mineralogy) corresponding to O0042K Mineralogy and Crystallography, and basic chemistry corresponding to P0007K Chemical Reactions in Mineral resource Engineering.Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The course provides the possibility to acquire the basic knowledge in Extractive metallurgy (mechanical process technology and high temperature processes).

After completing the course participants should be able to:

- Explain theoretical concepts within mechanical process technology

- Describe and explain common unit operations and machines used for mineral processing with a focus on iron ore beneficiation.

- Do standard calculations for mineral process analysis and design

- Describe and explain the unit operations which are common within high temperature processes with focus on iron and steel.

- Describe and apply the theoretical bases for high temperature processes

- From a theoretical and practical view explicate the extraction of iron

## Contents

Introduction to mineral processing

- Characterization of disperse systems.

- Review of unit operations and mineral beneficiation processes: Comminution, classification, concentration, dewatering

- Laboratory classes: Grinding, classification, magnetic separation

- Exercises: Particle size distributions, assessment of mineral processes

Introduction to high temperature processes with focus on iron and steel production from a sustainable perspective.

- Review of unit operations and process systems

- Laboratory class: agglomeration, reduction, smelting

Introduction to thermodynamics with focus on high temperature processes

- Mass and heat balances for high temperature processes

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. This course includes teaching and learning activities such as lectures, exercises, laboratory classes and field trips. The lectures provide the possibility for the students to be able to describe and explain the operating principles of unit operations and describe theoretical concepts. Exercises are used for training of calculation procedures. The laboratory classes (performing the lab and writing report) are done in groups. The students are trained to do investigations and work in groups and to evaluate, describe and report investigations. The field trips provide the possibility for the students to learn to describe industrial process technology.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through laboratory classes and exercises, written examinations and field trips. The laboratory classes and exercises as well as field trips are compulsory and are only graded pass – fail. Approved laboratory exercises, a structured and well-formulated written report and participation in laboratory lessons is required for passing the laboratory classes. The reports might have to be written in English.

The theoretical understanding of the field of study is checked by a written individual full exam, graded 3 4 5. For grade 3, the student must be able to describe what is included in the field of study and to do routine calculations. For grade 4, the student must be able to explain what is included in the field of study and report investigation results. For grade 5, the student must be able to apply the acquired knowledge to partly new theoretical and practical problems.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam mineral processing | GU345 | 2 | Mandatory | S26 |  |
| 0002 | Written exam process metallurgy | GU345 | 2 | Mandatory | S26 |  |
| 0005 | Field trips | UG | 0.5 | Mandatory | S27 |  |
| 0006 | Laboratory work and exercises | UG | 3 | Mandatory | S27 |  |

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
