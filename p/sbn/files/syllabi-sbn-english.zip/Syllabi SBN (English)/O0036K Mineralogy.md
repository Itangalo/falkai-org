---
course_code: "O0036K"
title: "Mineralogy"
credits: "7.5"
title_sv: "Mineralogi"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0036K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0036K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o00/o0036k-mineralogi"
---

# Mineralogy (O0036K)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and O0035K Geology, basic course or corresponding.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After the course, students should be able to apply theoretical mineralogical knowledge and optical methods to identify geologically, economically and technically important minerals, and be able to account for the minerals' chemical and physical properties and their most common way of occurrence.

Students should be able to perform microscopic determination of the minerals and explain the principle of X-ray diffractometric measurements and their application in mineralogy.

Following completion of the course, students should be familiar with solid state chemistry to the extent that they can explain and apply concepts in crystallography. The students should also be able to explain and use concepts such as unit cell, crystal system, Bravais lattice, Miller index, and be able to use these to describe the order of atoms in different crystal structures. The student should also be able to explain concepts such as solid solutions, substitution and mixed series of minerals.

## Contents

During the course, students work with theoretical aspects of crystallography, mineralogy and X-ray diffraction, in combination with practical elements where this knowledge is applied to characterize crystal structures. Students are given an in-depth review of the optical theory that underlies petrographic microscopy and mineral identification with a polarization microscope in transmitted and reflected light. A review of a selection of geologically, technically and economically important minerals (ore mineral, industrial mineral) and mineral groups (silicates, salts, oxides, sulphides, sulphates, carbonates) is combined with practical exercises, where students apply their knowledge for mineral identification.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The subject is presented in the form of class lectures by several lecturers and mandatory exercises in X-ray diffraction, crystallography, microscopy and mineral identification. The exercises are partly teacher-supervised and partly individual. The exercises will be partly linked to lectures and performed in parallel.

Document management takes place in the learning platform CANVAS.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Short written exams are performed after each course module with differentiated grades (grade scale: 5 4 3 U). In order to pass the course, the student must complete and report in writing all practical assignments and pass them.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0009 | Short written exam, Mineral identification | GU345 | 2 | Mandatory | A08 |  |
| 0011 | Short written exam, Opaque microscopy | GU345 | 1.5 | Mandatory | A08 |  |
| 0013 | Short written exam, Transmission microscopy | GU345 | 1.5 | Mandatory | A08 |  |
| 0014 | Short written exam, Crystallography and X-ray diffraction | GU345 | 1.5 | Mandatory | A08 |  |
| 0015 | Excercises | U G# | 1 | Mandatory | A08 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Department of Chemical Engineering and Geosciences 2008-01-22
