---
course_code: "O0035K"
title: "Geology, basic course"
credits: "7.5"
title_sv: "Geologi, grundkurs"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-01-11"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0035K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0035K&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o00/o0035k-geologi-grundkurs"
---

# Geology, basic course (O0035K)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Swedish upper secondary school courses General Science 1b or 1a1+1a2, Social Studies 1b or 1a1+1a2, English 6. Or: English level 2, General Science level 1b or level 1a2, Social Studies level 1b or level 1a2.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

After the course the student will be able to explain basic geological concepts and processes of importance for those that will work with environment, natural resources, rocks and soil. The student should also be able to recognize and describe common minerals, rock and soils but also have knowledge about their origin uses. The students should also be able to search, compile and orally present geological information and have a general knowledge about the Swedish bedrock.

## Contents

The composition and internal structure of Earth.

Plate tectonics and driving forces.

Minerals and mineral identification methods.

Rock forming processes, magmatic, sedimentary and metamorphic rocks.

Structural geology.

Geological time scale, earth history and evolution.

Regional geology and geology of Sweden.

Quaternary geology and exogenic processes.

Glaciation and sea level changes.

Regolith, origin and properties.

Construction and interpretation of geological maps.

Economic geology. Ore, industrial minerals and energy resources.

Geological excursions and mine visit.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures where basic theory is presented and explained. Methods for the identification of minerals, rocks and soils are dedicated through practical exercises, laboratory sessions and field exercises. The use of structural geological concepts and methods as well as basic understanding of the production of geological maps are trained through practical exercises. Knowledge of Sweden's bedrock is achieved through lectures and own project work. Theoretical knowledge translates into practical applications and increased understanding through field exercises and excursions. Compulsory parts are oral presentation of project assignments, laboratory sessions, field exercises, excursions and practical exercise reports.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Graded practical exams and written exam at the end of the course. Approved practicals.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course O0035K is equal to K0023K, KGO006

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Written Exam General Geology | GU345 | 4.5 | Mandatory | A08 |  |
| 0004 | Practical exam minerals | GU345 | 1 | Mandatory | A08 |  |
| 0005 | Practical exam rocks | GU345 | 1 | Mandatory | A08 |  |
| 0007 | Field Exercise, Exercise with Assignment Report and Individual Project Work | UG | 1 | Mandatory | S27 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-01-11

## Syllabus established

by Institutionen för Tillämpad kemi och geovetenskap 2008-01-22 att gälla från H08. 2008-01-22
