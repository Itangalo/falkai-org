---
course_code: "X7003B"
title: "Degree project in Civil Engineering, Master"
credits: "30"
title_sv: "Examensarbete i Väg- och vattenbyggnad, master"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2013-02-06"
education_level: "Second cycle"
grade_scale: "UG"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X7003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X7003B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/x70/x7003b-examensarbete-i-vag--och-vattenbyggnad-master"
---

# Degree project in Civil Engineering, Master (X7003B)

## Main field of study

Civil Engineering

## Entry requirements

At least 60 credits from completed courses required for the degree. The appointed examiner decides if the student has the depth of knowledge required for the proposed degree project.

## Selection

The selection is based on 30-285 credits

## Course Aim

The overall goal of the course is that the student practices, develops and is able to apply theory and methods to solve unstructured problems within the main are of study Civil Engineering in the correct manner.

This means that on completion of the course the student is able to:
- Formulate a relevant problem for investigation from a chosen subject within the main area of study Civil Engineering.
- Apply knowledge and proficiency that has been acquired during the period of study to a complex development project or a smaller research project in an independent and systematic manner.
- Choose and justify the study method with explicit understanding of the influence of the choice on the results of the study.
- Analyse and defend the problem formulated in a scientifically correct manner, whilst lacking all the information required.
- Locate and critically review information and summarise this in a scientific manner.
- Plan, structure and execute a research or development project.
- Judge the scientific relevance of the results obtained.
- Work to a timetable.
- Express themselves well in writing and linguistically in a scientifically correct manner.
- Create and execute a presentation of the results of the project, defending the conclusions.
- Critically review the work of others in a constructive and scientific manner.

## Contents

The content of the degree project is designed in collaboration with the supervisor. The degree project always contains a theoretical foundation in the form of a literature survey that highlights the area of technology and the methodology, summarised in a scientific manner.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The student independently plans and executes the degree project; the supervisor is available for assistance. A timetable for the entire project is included in the degree project, which is continuously reviewed.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.
- Written presentation of individual work. In the report the student shows the ability to:
    - Justify the chosen problem of study
    - Select and justify the study methods with explicit understanding of the influence of the methods on the results of the study
    - Collect information relevant to the problem formulation with an explicit connection to the theory and methods chosen
    - Present in writing the information collected in a relevant manner
    - Analyse and defend the formulated problem from the chosen theory and methods
    - Critically review the scientific relevance of the results obtained
    - Express themselves in writing in a correct linguistic and scientific manner.
- Oral presentation of own work
- Public discussion of the work of others
- Attendance at presentations of the degree project work of others.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The department provides active supervision for a period of two terms from the start of the project. The degree project is performed individually; only in exceptional cases may at most two students carry out the degree project together. In cases in which the degree project is carried out by two students, this shall be clearly visible in the scope and depth of the report.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Start of degree project | UG | 0 | Mandatory | S27 |  |
| 0006 | Oral presentation | UG | 0 | Mandatory | S27 |  |
| 0007 | Public discussion of others & degree project | UG | 0 | Mandatory | S27 |  |
| 0008 | Approved report | UG | 30 | Mandatory | S27 | Yes |

## Syllabus established

by Eva Gunneriusson 2013-02-06
