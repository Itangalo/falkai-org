---
course_code: "L0023B"
title: "Introduction to QGIS"
credits: "7.5"
title_sv: "Introduktion till QGIS"
valid: "Autumn 2025 Sp 1 - Present"
decision_date: "2025-02-13"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Geografisk informationsteknologi"
subject_group_scb: "Geographic Information Technology and Surveying"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0023B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0023B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0023b-introduktion-till-qgis"
---

# Introduction to QGIS (L0023B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

The course introduces students to the basics of geographic information systems (GIS) and equips them with practical skills in QGIS. With the help of curated tutorials, students will independently navigate, analyze, and visualize spatial data in QGIS.

After completing this course, students will be able to:

- Navigate QGIS Software: Demonstrate efficient navigation of the QGIS interface, including workspace customization and tool usage.

- Apply Coordinate Systems: Select and apply appropriate coordinate systems and projections for spatial datasets.

- Manipulate Spatial Data: Import, organize, and manage spatial data in vector and raster formats to build up geographic databases.

- Create Visualizations: Design and create professional-quality maps with effective symbology and labeling.

- Design simpler applications: Complete independent projects using QGIS tools to

## Contents

Basic-Intermediate GIS Operation: Introduction to the Topic of Geographic Information Systems (GIS)

- Concept, structure and function

- OpenStreetMap data and QGIS software

Practical exercises include:

- Work with attributes

- Table and database management

- Processing

- Create and edit data

- Cartography

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. Detailed descriptions of the course content and course materials can be found under LTU’s learning platform Canvas and the university’s own document folder. There are no recorded lectures nor any mandatory gatherings. The literature book and online resources contain the learning materials and must be followed according to their instructions.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The objectives of the course are examined with assignments that are done individually or in groups of two people and that are examined during the course. Grading of assignments is done according to a grading scale U/G. All assignments must be completed for the final grade.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

Courses to be followed via the internet require that the student has access to some form of broadband connection.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignments | U G# | 7.5 | Mandatory | A25 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
