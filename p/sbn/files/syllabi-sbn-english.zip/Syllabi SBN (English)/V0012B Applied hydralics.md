---
course_code: "V0012B"
title: "Applied hydralics"
credits: "7.5"
title_sv: "Tillämpad hydraulik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "VA-teknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0012B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/v00/v0012b-tillampad-hydraulik"
---

# Applied hydralics (V0012B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and F0004T Physics 1 or similar course

## Selection

The selection is based on 1-165 credits.

## Course Aim

After the course the student should be able to:

1. Calculate hydrostatic pressure on basic constructions under water

2. Describe and apply the fundamental laws in hydraulics

3. Identify and solve hydraulic problems for liquid flow in pipes

4. Describe sprinkler systems and other pressurised water systems which are parts of fire protection systems in buildings and society and be able to explain the principles of dimensioning of these systems

5. Describe the systems for potable water and wastewater and be able to explain the function of its components

6. Identify risks and safety aspects concerning the urban water system and the connection to civil protection.

## Contents

The course is divided into three parts which aim at giving basic knowledge in hydraulics as well as two applications: sprinkler systems and urban water and sanitation systems. Further aims are to increase the understanding how these systems affect each other in relation to the civil protection and operation of the urban water and sanitation systems.

- In the hydraulics part, basic knowledge in hydraulic concepts and laws such as state of flows, equation of continuity, momentum and energy equation are given as well as pipe flows, head losses, friction losses, and pumps and pipe dimensioning.

- Within the area of society’s water fire protection systems, basic knowledge of sprinkler systems in buildings (design and function) and supply of fire extinguishing water and fire hydrants, are the focus in this course.

- Within the area of the urban water and sanitation systems, basic knowledge about pipe systems, waste water treatment, drinking water reservoirs, production and distribution, and storm water systems are given. Furthermore, pollutant transport via these systems and associated risks connected to civil protection and the operation of urban water and sanitation systems.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The three parts of the course will be realized according to the following:

- Through lectures and reading the course literature basic theoretical knowledge in hydraulics is obtained. Exercises during class and individual practice will help the student to learn how to carry out calculations. Furthermore, there are two mandatory laboratory exercises (moment 0010) when the theoretical part is put in to practice.

- Through lectures and reading the course literature basic knowledge about sprinkler systems, their design and functioning, are obtained. Included is also the assignment concerning calculations of a sprinkler system design which is carried out in groups and presented in a written report (item 0002). In order to obtain a broader understanding, a mandatory visit to study a sprinkler system is included (item 0003).

- Through lectures and reading the course literature, basic theoretical knowledge of the urban water system and how this is related to and dependent on the civil protection is obtained as well as pollution transport via the urban water systems. Comprehensive descriptions of supply of fire extinguishing water with fire hydrants and sprinkler systems is also included. A mandatory seminar concerning risk and safety aspects of the urban water system will be held (item 0004)

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. To pass this course, all items of the examination have to be passed. The final grade is obtained by calculating the credit weighed average from the grade of items 0002, 0007 and 0009. Fulfilments of the course aims 1-3 is tested by written examination (item 0007) and also include two laboratory exercises (item 0006). Fulfilments of course aim 4 is tested by a calculation assignment (item 0002) as wells as active participation in a study visit and the associated lecture (0003), course aim 5 and 6 are tested by written examination (item 0008) and seminar (item 0004). In the case that the student does not participate in any the scheduled study visits, it may be carried out any other time the course is given, if there are vacancies available. In the case that the student does not participate in one or more of the scheduled lab occasions, it may be carried out any other time the lab is given, if there are vacancies available.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Task | GU345 | 1.8 | Mandatory | A08 |  |
| 0007 | Written exam | GU345 | 3 | Mandatory | A08 |  |
| 0009 | Short written exam | GU345 | 1 | Mandatory | A08 |  |
| 0011 | Seminar | UG | 0.7 | Mandatory | S27 |  |
| 0012 | Laboratory work | UG | 0.5 | Mandatory | S27 |  |
| 0013 | Study visit | UG | 0.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2008-01-22 and is valid from H08.
