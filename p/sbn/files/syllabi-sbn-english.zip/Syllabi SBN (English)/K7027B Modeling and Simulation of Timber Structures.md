---
course_code: "K7027B"
title: "Modeling and Simulation of Timber Structures"
credits: "7.5"
title_sv: "Modellering och simulering av träkonstruktioner"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-13"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7027B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7027B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7027b-modellering-och-simulering-av-trakonstruktioner"
---

# Modeling and Simulation of Timber Structures (K7027B)

## Main field of study

.

## Entry requirements

At least 90 credits within the field Civil Engineering or corresponding. Including the courses K7026B Design of Timber Structures 1, K0019B Wood as a Construction Material or corresponding. In addition, English 6/level 2 and Swedish 3/level 3 are required.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, the student shall be able to:

Knowledge and Understanding

- Explain the fundamental principles of the Finite Element Method (FEM).

- Describe how the Finite Element Method can be used to analyse timber structures under different scenarios.

- Explain the influence of modelling assumptions on simulation results.

Skills and Abilities

- Select appropriate modelling assumptions regarding element discretization, boundary conditions, and material parameters in order to model a timber structure.

- Analyse a timber structure under different scenarios with respect to strength, stiffness, and stability.

- Evaluate the results of a simulation.

Judgement and Approach

- Assess the applicability of the Finite Element Method during the design process.

- Evaluate the suitability of a model for addressing various design problems.

- Assess the reliability of the method for different parameter selections.

## Contents

The course provides knowledge and understanding of modelling using the Finite Element Method (FEM).

The following topics and concepts are covered:

- Fundamental theory of the Finite Element Method

- Element types and discretization in 1D, 2D, and 3D

- Solution of quasi-static problems

- Solution of dynamic problems and vibration analysis

- Introduction to nonlinear problems

- Material modelling of wood and wood-based structural elements

- Practical exercises

The course focuses primarily on linear problems, and the practical computer exercises are conducted using a common finite element software package.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course is conducted as a distance course. Knowledge and understanding are developed through lectures, independent study of literature, and supplementary materials. Skills and abilities are trained through theoretical exercises and practical assignments. The learning progression is continuously monitored by the supervisor through dedicated supervision sessions.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Student knowledge and skills are continuously assessed through both theoretical and practical components.

Theoretical knowledge is examined via multiple quizzes that require good comprehension and insight into the course content.

Practical skills in applying the acquired methods and theories are assessed through individual written assignments and an oral presentation.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not

previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K7027B is equal to W7011T

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written assignment | U G# | 3.5 | Inactive | A26 |  |
| 0002 | Quiz | U G# | 3 | Inactive | A26 |  |
| 0003 | Oral examination | U G# | 1 | Inactive | A26 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13
