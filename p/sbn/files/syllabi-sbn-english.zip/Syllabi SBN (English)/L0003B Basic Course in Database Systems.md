---
course_code: "L0003B"
title: "Basic Course in Database Systems"
credits: "7.5"
title_sv: "Databaser, en introduktion"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Geografisk informationsteknologi"
subject_group_scb: "Geographic Information Technology and Surveying"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0003B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0003b-databaser-en-introduktion"
---

# Basic Course in Database Systems (L0003B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Basic Course in Programming, for example ABL005 or analogous knowledge acquired through other courses or proved practical work.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After approved course the students shall know how to

- explain and describe basic concepts within database theory and relational database theory in particular.

- construct databases (data modeling) from a depicted reality.

- master basics in the SQL language and be able to construct simple applications that use some database manager.

- document their work according to established methodology.

## Contents

- Database management systems

- Relational databases

- SQL, data definition and data manipulation

- Database design, object and data modeling

- Embedded database management and SQL in some host language

- Transactions and concurrency

- Map management, only theoratically

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. All the course material can be found on LTU’s Citrix portal. There you can also find more detailed descriptions of the course contents and its realization. There are no pre-recorded lectures, nor are there any mandatory gatherings.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course is target examined through assignments that will be completed individually or in groups of two people who will be examined throughout the course. Marking of the assignments will be made according to U/G marking scale. All assignments should be completed to receive a final mark. Deliverables are available on LTU’s Citrix portal.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course L0003B is equal to ABL006

## Remarks

A course that is completed online demands that the student has access to some form of broadband connection.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment | U G# | 7.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Department of Civil and Environmental Engineering 2007-01-31
