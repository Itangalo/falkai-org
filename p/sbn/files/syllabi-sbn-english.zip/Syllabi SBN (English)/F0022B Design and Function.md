---
course_code: "F0022B"
title: "Design and Function"
credits: "7.5"
title_sv: "Gestaltning och funktion"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2026-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F0022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F0022B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f00/f0022b-gestaltning-och-funktion"
---

# Design and Function (F0022B)

## Main field of study

Architecture

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and At least 60 credits completed courses within the field Architecture including knowledge of:
- Using different scales and drawing types, e.g. F0007B Engineering Architecture or equivalent.
- Sketching and drawing, e.g. D0054A Sketching and drawing or equivalent.
- Architectural design processes for different contexts, e.g. F0012B Conceptual design and F0021B Urban design or equivalent.

## Selection

The selection is based on 1-165 credits.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project work | GU345 | 6 | Mandatory | S27 |  |
| 0003 | Seminars | UG | 1.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13
