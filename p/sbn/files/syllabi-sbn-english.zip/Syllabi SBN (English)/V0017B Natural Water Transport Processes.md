---
course_code: "V0017B"
title: "Natural Water Transport Processes"
credits: "7.5"
title_sv: "Naturliga vattentransportprocesser"
valid: "Autumn 2021 Sp 1 - Autumn 2025 Sp 2"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "U G#"
subject: "VA-teknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0017B&lasPeriod=205&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/v00/v0017b-naturliga-vattentransportprocesser"
---

# Natural Water Transport Processes (V0017B)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and F0004T Physics 1 and F0006T Physics 3 or corresponding. Good knowledge in English, equivalent to English 6

## Selection

The selection is based on 1-165 credits.

## Examiner

Kelsey Flanagan

## Course Aim

Upon completing this course, you should be able to:

- carry out hydrological calculations regarding water balance, run-off, evaporation and snow melt
- do calculations using the unit hydrograph and linear reservoir method
- carry out measurements in streams (profile, level, flow)
- calculate one-dimensional groundwater flow and groundwater extraction in confined and unconfined aquifers
- describe the fundamental laws of hydraulics and solve problems based on these theories, e.g. calculate water levels, velocities and flows
- set up and solve hydraulic problems for water flow in channels and weirs
- generate and evaluate a model for snow melt and runoff and carry out a sensitivity analysis
- Describe different flow conditions in channels and water courses and the transition from one state to another

## Contents

This course gives you an overall understanding for natural water transport processes and their calculation in hydrology and water flow. More specifically, the following issues are covered: Water cycle, water fluxes (precipitation, surface and ground water run-off, evaporation), and water storages in lakes, rivers, snow and ground water. Open channel flow: continuous equation, momentum equation, energy equation, open channel flows including different types of flows conditions and transition between flows.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

This course includes lessons in the classroom and other learning activities, including take-home calculation exercises carried out individually, a compulsory field exercise and a computer modelling exercise, both carried out in groups. Due to weather conditions the field exercise is carried out during Study period 1 in September.

Through the course, students will practice collaboration (field and modelling exercises), written communication (field exercise), problem-solving (calculation exercises) and spoken communication (field exercise, oral examinations and modelling exercises).

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course aims are examined through four oral examinations based on sets of take-home exercises as well as a written report of the mandatory field exercise, each assessed on a pass-fail basis. All modules must be validated to obtain credit for the course.

## Overlap

The course V0017B is equal to V0014B, V0021B

## Remarks

The course corresponds to parts of the course O011K Geology and Hydrology and V0014B Hydraulics and geology and these courses can not be included in the same degree.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Take-home exam 1 | U G# | 1.1 | Mandatory | A12 |  |
| 0004 | Take-home exam 4 | U G# | 1.5 | Mandatory | A12 |  |
| 0005 | Field task | U G# | 0.4 | Mandatory | A12 |  |
| 0006 | Take-home exam 2 | U G# | 2.5 | Mandatory | A12 |  |
| 0007 | Take-home exam 3 | U G# | 2 | Mandatory | A12 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Literature

*Literature. Valid from Autumn 2017 Sp 1* Hamill, L., (2011). Understanding Hydraulics. 3 ed. Basingstoke: Palgrave Macmillan. ISBN: 9780230242753. Davie, T. (2008): Fundamentals of hydrology. 2nd ed. London; New York: Routledge. ISBN: 0-415-22028-9 (hbk); ISNB: 0-415-22029-7 (pbk). (accessible as e-book in the library) Lundberg, A. (2009): Kompendium i hydrologi. Geovetenskap, Luleå tekniska universitet. (made available i Canvas)

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2012-03-14
