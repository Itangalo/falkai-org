---
course_code: "O0043K"
title: "Structures and Deformation"
credits: "7.5"
title_sv: "Strukturer och deformation"
valid: "Autumn 2025 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2025-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Malmgeologi"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0043K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0043K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o00/o0043k-strukturer-och-deformation"
---

# Structures and Deformation (O0043K)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and O0041K Geoscience or corresponding course.Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The course aims for the student, through the study of geologically deformed rocks, to:

1. Identify the most common geological structures,

2. Explain how these structures were formed,

3. Conduct field experiments using proven methods, and evaluate rock and fracture parameters as well as rock mass quality with analytical, empirical, and numerical methods,

4. Visualize structural geological measurement data and identify structurally controlled failure modes in rock slopes and underground constructions using spherical projection and engineering geological descriptions of the rock mass, and, where possible, calculate safety against failure,

5. Present and discuss in writing their analyses, models, results, and conclusions.

## Contents

The course covers:

- Structural Geology – Mountain-building processes, stress and strain, secondary structures in bedrock such as deformation zones and folding, and measurement of structures in the field.

- Rock Material – Theoretical and practical work with rock mechanics investigations and rock mass classification, geological structures in rock and their significance for mechanical behavior, structure-controlled fractures, spherical projection, field data collection and analysis, presentation of engineering work and field data, etc.

- Slope Stability – Structure-controlled failure modes in slopes, circular shear failure in slopes, stability analysis of slopes, safety factors, the effect of groundwater pressure, and the effect of drainage.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

- Lectures – These are a mix of several teaching/learning activities: (i) brief theoretical reviews where the lecturer explains key theoretical aspects related to the course content, and (ii) collaborative problem-solving and/or discussion of typical problems and questions. This provides an opportunity to engage with multiple aspects of empirical and analytical stability analyses of various underground rock constructions from both practical and theoretical perspectives, as well as to practice calculation procedures related to these issues.

- Computer Exercises – During these sessions in the computer lab, we practice various numerical applications and how they can be used to analyze fracture data and the stability of underground rock constructions.
- Field Exercises – Here, you will practice performing and evaluating field tests.
- Assignments – You will work with other students to apply your knowledge in solving various problems. This will involve using empirical and analytical analyses to process collected field data as well as theory from lectures. You will present your process and results in writing.
- Between Lectures – You are expected to prepare for each lecture by reviewing the recommended materials, exercises, and study questions so that you are ready to actively participate in learning activities (problem-solving, discussions, etc.) during lectures and computer exercises.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

- Field Exercise – Through practice in the field and submission of a written solution. (ILO 3, 4, 5)
- Written Exam – You answer questions and solve problems similar to those encountered during the course (in lectures and assignments) to test your individual knowledge, understanding, skills, and abilities. (ILO 1, 2, 4, 5)

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 3.5 | Mandatory | A25 |  |
| 0002 | Field excersice | U G# | 4 | Mandatory | A25 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
