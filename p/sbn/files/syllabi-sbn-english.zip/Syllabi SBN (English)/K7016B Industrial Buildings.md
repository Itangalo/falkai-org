---
course_code: "K7016B"
title: "Industrial Buildings"
credits: "7.5"
title_sv: "Hallbyggnader"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2022-11-03"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Konstruktionsteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7016B&lasPeriod=213&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7016b-hallbyggnader"
---

# Industrial Buildings (K7016B)

## Entry requirements

Knowledge in building materials corresponding to B0002B Building Materials Knowledge in strength of materials and solid mechanics and structural mechanics correspondning to B0002B Structural Engineering and B7004B Structural Mechanics I. Knowledge in structural design corresponding to K0013B Structural Design or W7006B/K7012B Structural Design

## Selection

The selection is based on 30-285 credits

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project work | GU345 | 3 | Mandatory | A19 |  |
| 0002 | Project work | GU345 | 4.5 | Mandatory | A19 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-11-03

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-02-14
