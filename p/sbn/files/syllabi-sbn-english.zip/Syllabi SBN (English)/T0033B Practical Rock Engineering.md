---
course_code: "T0033B"
title: "Practical Rock Engineering"
credits: "7.5"
title_sv: "Praktisk bergteknik"
valid: "Autumn 2025 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2025-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0033B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0033B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t00/t0033b-praktisk-bergteknik"
---

# Practical Rock Engineering (T0033B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and T0013B Introduction to Rock Engineering or equivalent.

## Selection

The selection is based on 1-165 credits.

## Course Aim

By the end of this course, students will be able to: 1. Evaluate different rock excavation techniques and methodologies in civil and mining engineering, 2. Determine design parameters for slopes, tunnels, caverns and mine openings 3. Choose suitable mining methods (open pit or underground) for different orebodies and geological settings, and 4. Develop practical problem-solving skills for real-world engineering challenges.

## Contents

Module 1: Introduction to Practical Rock Engineering Module 2: Design Processes for Rock Engineering Module 3: Stability and Monitoring in Rock Constructions Module 4: Surface and Underground Mining

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

Module 1: Introduction to Practical Rock Engineering
- State of the art in Rock Engineering
- Types of Rock Engineering Constructions
- Rock Excavation Methods and Processes
- Quiz 1

Module 2: Design Processes for Rock Constructions
- Design Consideration for Civil Construction
- Design Consideration for Mining Construction
- Construction Methodologies for Civil and Mining Constructions
- Design of large slopes
- Quiz 2
- Assignment 1

Module 3: Stability and Monitoring in Rock Constructions
- Methods for Stability Analyses and Assessment
- Monitoring Systems in Rock Engineering
- Real Time Monitoring in Mining Applications
- Introduction to Risk Management
- Quiz 3
- Assignment 2

Module 4: Surface and Underground Mining
- Introduction to the mining value chain
- Mining methods selections process
- Open pit mining
- Underground mining
- Quiz 4
- Assignment 3

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

- Assignments – Consists of problems where students practice and apply their theoretical knowledge, understanding, and abilities, conducting analyses (empirical and analytical) and explaining their results in writing. (ILO 1, 2)

- Quiz – will be given at the end of each module as means to recap and re-evaluate how well the students have understood the concepts presented in each module. (ILO 1, 2)

- Written Exam – Students answer questions and solve problems similar to those encountered during the course (in lectures and assignments) to test their individual knowledge, understanding, skills, and abilities. (ILO 1, 2, 4)

)

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be

assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 3.5 | Mandatory | A25 |  |
| 0002 | Assignments | U G# | 3 | Mandatory | A25 |  |
| 0003 | Quiz | U G# | 1 | Mandatory | A25 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
