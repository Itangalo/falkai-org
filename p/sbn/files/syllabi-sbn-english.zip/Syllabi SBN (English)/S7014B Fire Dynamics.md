---
course_code: "S7014B"
title: "Fire Dynamics"
credits: "7.5"
title_sv: "Branddynamik"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2023-06-02"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Brandteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7014B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/s70/s7014b-branddynamik"
---

# Fire Dynamics (S7014B)

## Entry requirements

90hp courses in Fire Engineering and/or Civil Engineering

## Selection

The selection is based on 30-285 credits

## Course Aim

Knowledge and understanding

After completing the course, the student should be able to:

- define fire growth and energy release rate from free burning fires

- explain how a room affects the fire development and explain the development of pressure profiles in fire scenarios

- explain application areas and limitations for different hand calculation methods and for computer models for fire dynamics calculations

- define the most important scientific foundations and proven experience for fire dynamics, as well as define some current research and development areas

Skills and abilities

After completing the course, the student should be able to show the ability to:

- compute different quantities in a fire scenario

- define different types of fire gas ventilation and compute properties for these

- solve problems for dimensioning of fire protection with motivated assumptions and judgement of the reasonability of the results, with hand calculations as well as with computer calculations

- plan, perform, analyze and clearly and scientifically present the results from fire experiments

Judgement and attitude

After completing the course, the student should be able to:

- judge different models and methods in the analysis of fire scenarios

- show insight in the responsibility of the engineer to choose and account for parameters in such a way that the results are used correctly

## Contents

The course deals with

- Different stages of the room fire

- Energy release rate and mass loss rate for different types of fires and fuels. Time dependent energy release rate. Alpha-t2 growth. Impact of the room on the energy release rate. Design of curve for energy release rate vs. time

- Flame heights, mean flame height, flame height correlations

- Strong and weak plumes. Plume correlations. Ceiling jets

- Calculation of pressure forces. Pressure profiles. General about flows in buildings. Bernoulli’s equation. Ideal gas law. Different types of pressures. Calculation of pressure, velocity and mass flow through openings. Graphical visualization of pressure differences in buildings in fire situations

- Temperatures in room fires. Fire gas temperatures. Energy balance. Heat transfer coefficient. Correlations for calculation gas temperatures. Fully developed fires. Calculations of temperatures in a room with different models.

- Equations of conservation and how these are used to calculate smoke filling for room fires.

- The concentration of toxic gases in the fire smoke is treated based on the yield concept and plume equations.

- General about computer models, especially about two zone models.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The teaching is based on self-studies, lectures, tutorials, quizzes, laborations with oral and written presentation, as well as reflexion assignment.

In order to achieve the course’s goals regarding knowledge and understanding, the student should independently study the specified course literature and participate at the lectures.

In order to achieve the course’s goals regarding skills and abilities, the student should also actively participate in the tutorials, laborations as well as the written and oral presentation of these. The student should also do the individual quizzes. The laborations, one experimental and one computer based, are performed in groups.

In order to achieve the course’s goals regarding judgement and attitude, the student should also participate in discussions on the course contents at lectures, tutorials, laborations, as well as do the reflexion assignment.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The entire course content is examined with a written exam with grades U 3 4 5. In order to pass the course the student must also have passed the quizzes and must be approved by the teacher on the laborations and reflexion assignment.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course S7014B is equal to S7002B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4.5 | Mandatory | A22 |  |
| 0002 | Assignment reports | U G# | 3 | Mandatory | A22 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11
