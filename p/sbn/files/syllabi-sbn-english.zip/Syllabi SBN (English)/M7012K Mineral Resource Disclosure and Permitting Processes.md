---
course_code: "M7012K"
title: "Mineral Resource Disclosure and Permitting Processes"
credits: "7.5"
title_sv: "Offentliggörande av mineralresurser och tillståndsprocesser"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2023-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Mineralteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7012K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7012K&lasPeriod=212&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/m70/m7012k-offentliggorande-av-mineralresurser-och-tillstandsprocesser"
---

# Mineral Resource Disclosure and Permitting Processes (M7012K)

## Entry requirements

60 ECTS in geoscience, mining engineering, process engineering or equivalent areas or equivalent knowledge from practical experiences (at least 5 years). Substantiated with certificates from employers. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 30-285 credits

## Course Aim

The course aims to create knowledge of legislation relevant to mine development and mining production and of estimation and reporting of mineral resources. After completing the course, the student shall be able to:

- Know and explain the concepts of social and environmental impact assessments and understand the permitting procedures (incl. ESIA and stakeholder involvement)

- Establish parts of the technical documentation for the assessment of potential environmental impacts from mining and mineral processing

- Describe different methods used in resource estimation and explain established reporting standards and procedures for mineral resource disclosure

- Perform a simplier resource estimation calculation

## Contents

This course covers:

Mining-related legislation

- Nordic, EU-level and international environmental legislation

- Legislation related to land management, physical planning and natural resources

- Exploration and mining permits

Social and environmental impact assessment

- Prerequisites and procedures

- Technical project description and permit application

- Requirements on stakeholder participation, human and indigenous peoples rights, SLO

Resource estimation and reporting

- Block model basics and database for resource estimation

- International reporting standards

- Geometallurgical block modeling

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The teaching consists of lectures that are combined with assignments and a small project.

Lectures will give the students knowledge and understanding of different mining-related legislation and procedures in the permitting process as well as of reporting of disclosure of mineral resources.

The assignments and the project will train the student to independently work with and deepen selected sub-areas.

Seminars are devoted to in the group describing, analyzing, interpreting and presenting a complex topic in the thematic field.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Assignments as well as seminars and project are mandatory Assignments and project are assessed with grades in these parts. The seminars are graded passed/not passed. The total score production gives the total grade for the course, which is given at a grade scale of 3 4 5.

Mandatory attendance at the first lecture. Permission to be absent is given by the teacher responsible for the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignments | GU345 | 3 | Mandatory | A23 |  |
| 0002 | Seminars | U G# | 2 | Mandatory | A23 |  |
| 0003 | Project | GU345 | 2.5 | Mandatory | A23 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13
