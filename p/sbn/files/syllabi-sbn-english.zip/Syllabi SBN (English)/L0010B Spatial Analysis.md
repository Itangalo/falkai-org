---
course_code: "L0010B"
title: "Spatial Analysis"
credits: "7.5"
title_sv: "Geografisk analys"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-06-14"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Geografisk informationsteknologi"
subject_group_scb: "Geographic Information Technology and Surveying"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0010B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0010B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0010b-geografisk-analys"
---

# Spatial Analysis (L0010B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Basic Courses in Geographical Information Systems (GIS), for example L0020B, Geographic Information Technology or analogous knowledge acquired through other courses or proved practical work.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After approved course the students (the general GIS user as well as specialists):

- Shall be able to perform better and more qualitative geographical analysis in different application areas

- has obtained a deepened understanding of methods and techniques for modeling geographical data, with focus on practical application

## Contents

- Spatial analysis, Raster analysis ,Vector analysis, Network analysis

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. All the course material and software can be found on LTU’s Citrix portal. There you can also find more detailed descriptions of the course contents and its realization. There are no pre-recorded lectures, nor are there any mandatory gatherings. Lectures in text format, part of the course consists of courses from ESRI.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course aims are examined through assignments that will be completed individually which will be examined throughout the course. Marking of the assignments will be made according to U/G marking scale. All assignments should be completed to receive a final mark. Assignments are available on LTU’s Citrix portal.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be

assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course L0010B is equal to ABL032

## Remarks

Courses followed through Internet demands access to some sort of broadband connection.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment | U G# | 7.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-06-14

## Syllabus established

by Department of Civil and Environmental Engineering 2007-01-31
