---
course_code: "B7001K"
title: "Design of Biochemical/Chemical Process Plants"
credits: "7.5"
title_sv: "Projektering av biokemiska/kemiska processanläggningar"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2023-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Kemisk apparatteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B7001K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B7001K&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/b70/b7001k-projektering-av-biokemiska-kemiska-processanlaggningar"
---

# Design of Biochemical/Chemical Process Plants (B7001K)

## Main field of study

Chemical Engineering

## Entry requirements

Transport processes Unit operations Bioprocess engineering

## Selection

The selection is based on 30-285 credits

## Course Aim

The course utilises basic understanding of biochemical and chemical process engineering to design a biochemical/chemical process. Upon completion of the course the student should be able to:

1 demonstrate in-depth ability to carry out a complete design of a biochemical process plant

2 develop mass and energy balances for a process flow diagram

3 conduct an economic analysis of a designed process

4 apply a representative simulation program for modeling, evaluation and optimization of a selected process

5 present a process design both orally and in writing

## Contents

The course covers the following topics:

- Process design

- Process modelling and simulation

- Overview of unit operations

- Flow diagrams

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The course consists of lectures and a project work. The lectures will cover theory and offer practical training to enable students to learn how to use a representative process simulation program. The project work is a teaching and learning activity that will continue throughout the quarter. In the project work, the students will work in groups to independently design a complete process for the production of a bio-based chemical. The project work covers the entire process from raw materials input till the final product ready for sale and delivery to customers. Throughout the project work, the teachers of the course will support the students by arranging consultation meetings. To support the students in their project work, the students will submit a number of mandatory assignments during the quarter. At the end of the project work, students will submit a final written report and also present their project orally to practice written and oral communication skills.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course will be graded on the basis of the quality of the design project work (assignments, written report and oral presentation). Intended learning outcomes 1-4 are assessed through the assignments submitted during the project work. Intended learning outcome 5 will be assessed through the written report and oral presentation.

The student has to submit all assignments and reports within the given time frame and participate in the oral presentation; otherwise they are brought forward to the next time the course is given.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course B7001K is equal to KGB010

2500

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project work | GU345 | 7.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
