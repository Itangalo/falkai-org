---
course_code: "T7005K"
title: "Cellulose and Paper Technology"
credits: "7.5"
title_sv: "Cellulosa - och pappersteknik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2023-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Kemisk teknologi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7005K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7005K&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7005k-cellulosa---och-pappersteknik"
---

# Cellulose and Paper Technology (T7005K)

## Entry requirements

90 credits in Chemical Engineering, including the courses K0011K Inorganic Chemistry and B0007K Organic Chemistry and Biochemistry.

## Selection

The selection is based on 30-285 credits

## Course Aim

Knowledge and understanding

1. describe the structure of wood

2. describe and explain the sulphate process and mechanical pulp for the production of pulp

3. explain and describe pulp bleaching techniques

4. explain and describe techniques for paper production

5. describe the most common methods for pulp characterization

6. explain the relationship between fiber and paper properties

7. describe the process and use of recycled fibers

8. explain the importance of chemical recycling in a pulp mill

Skills and Abilities

9. demonstrate the ability to formulate, plan and carry out relevant experiments based on complex issues within set time frames

10. demonstrate the ability to compile, evaluate and present experimental experiments, both orally and in writing

11. show the ability to assess and compare experimental data and theoretical information

## Contents

In this course the following topics are discussed:

-Raw materials for pulp production

-Fibers and wood handling

-Processes for chemical and mechanical pulp

-Chemical recovery

-Bleaching

-Paper production

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures that will cover the theory for the learning objectives of the course. The course also includes laboratories to offer the students the opportunity to apply relevant processes and techniques within the pulp and paper industry. The laboratories also include training in project planning, collaboration, writing of reports and oral presentation.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The learning objectives are examined through a written individual exam. Grading takes place according to the grading scale G U 3 4 5. Practical application of the learning objectives is examined via laboratories carried out in collaboration with other students of the course. For an approved laboratory project, an approved written report is required, where the grades are failed or passed. All examination steps must be completed to receive a final grade of the course. Laboratory exercises and a written report must be completed and submitted within the course time frame, otherwise submitted material will be reviewed and assessed at the next course occasion.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course T7005K is equal to KGT005

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 6 | Mandatory | A07 |  |
| 0003 | Laboratory work | UG | 1.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
