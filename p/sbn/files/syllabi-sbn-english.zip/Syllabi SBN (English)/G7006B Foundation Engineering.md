---
course_code: "G7006B"
title: "Foundation Engineering"
credits: "7.5"
title_sv: "Grundläggningsteknik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7006B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7006B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7006b-grundlaggningsteknik"
---

# Foundation Engineering (G7006B)

## Main field of study

Civil Engineering, .

## Entry requirements

G0003B Soil Mechanics or corresponding course. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

To give the student knowledge in soil and ground improvement methods, foundation methods, support constructions and CRS-tests. The student should after completing the course be able to carry out a foundation project including choice of ground improvement method, foundation method and design.

The intended learning outcomes are:

The student should be able to apply:

- Eurocode for foundation design

- Theories for analyses and calculation of bearing capacity and settlements for shallow foundations

- Design for shallow and deep foundations

- Theories for analyses of bearing capacity and settlements for piles

- Design of single piles in cohesive and frictional soil

- Analyses of pile groups with vertical and horizontal load according to the displacement method

- Design of isostatic and semi-isostatic pile groups

- Earth pressures against a sheet pile wall with Rankine´s method

- Design of a cantilever sheet pile wall and an anchored sheet pile wall

- Principles for design of strut length

- Design of anchor plates

- Analyses with CRS-test

The student should also know about and be able to describe:

- Different methods for soil and ground improvement

- Interaction building-substructure

- Different kind of pile foundations and their classification

- Other types of deep foundations like diaphragm walls, soil anchors and caissons

- General three dimensional pile groups

- Different types of support constructions and sheet pile walls

The course also has as a goal to practice the general skills written and oral presentation.

## Contents

The course covers:

- Soil and ground improvement methods

- Shallow foundations

- Deep foundations

- general about pile foundations

- design of single piles

- stability of piles, impact wave analysis of piles

- pile groups

- Support constructions

- Cantilever sheet pile walls and anchored sheet pile walls

- CRS-tests

- Written and oral presentation of a seminar assignment

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The teaching is given by lectures including minor parts of problem solving. Five compulsory assignments are included in the course:

- K1: Shallow foundation

- K2: Bearing capacity and stability of piles

- K3: Design of a pile group

- K4: Design of a sheet pile wall

- K5: Ground improvement methods (Seminar assignment)

The assignments are solved in student groups of normally three students. K5 is larger seminar assignment where each group choose a ground improvement method to study closer, writes a paper about the chosen method and presents the paper orally at a seminar in the end of the course. Each group will also act as opponent on another groups work. In the seminar assignment the general skills written and oral presentation are practiced. All assignments are corrected by teachers and the student groups obtain feedback. The course is ended by an individual oral examination.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course is assessed through correction of the assignments and the individual oral examination. All the learning outcomes of the course are assessed at the oral examination. However, for the learning outcomes where it stands that the student should be “able to apply” that are connected to the assignments are assessed on a deeper level by the assignments. By the seminar assignment the general skills written and oral presentation are practiced. The teacher will give feedback on the presentation technique at the oral presentations. Both the modules Oral examination and Project work (assignments) have the grading UG#. All exams included in the modules need to be completed for a course grade. The course grade is a weighted average of the performance on the oral examination and the assignments and has the grading scale GU345.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course G7006B is equal to ABG115

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Oral examination | UG | 4.5 | Mandatory | S27 |  |
| 0004 | Project work | UG | 3 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
