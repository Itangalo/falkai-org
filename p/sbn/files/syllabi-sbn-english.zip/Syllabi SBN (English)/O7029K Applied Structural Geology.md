---
course_code: "O7029K"
title: "Applied Structural Geology"
credits: "7.5"
title_sv: "Tillämpad strukturgeologi"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2025-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O7029K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O7029K&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o70/o7029k-tillampad-strukturgeologi"
---

# Applied Structural Geology (O7029K)

## Entry requirements

At least 90 credits completed courses where at least 60 credits in the area of nature resource technology, geology or geoscience, including O0007K Structural Geology or equivalent. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

The course provides advanced knowledge in applied structural geology with focus on multi-scale ore-forming processes, mineral exploration, and mapping.

Knowledge and understanding

After completing the course, participants should be able to:

1. Explain and discuss the role of geological structures in ore forming systems in a variety of tectonic settings.

2. Analyze structural geological data to hypothesize on probable transport-trap characteristics in prospective areas and propose strategies on how to explore for these traps.

3. Reconstruct deformation histories of ore deposits and other rock volumes and discuss its implication on exploration as well as engineering geology.

4. Demonstrate the ability to apply knowledge acquired in the course to solve structural geological problems in groups.

Competence and skills

After completing the course, participants should be able to:

5. Identify, describe, and map common geological structures from micro to regional scale.

6. Demonstrate the ability to accurately collect structural geological data and be able to present geologically sound interpretations based on the data and the course literature to a variety of audiences.

Judgment and approach

After completing the course, participants should be able to:

7. Demonstrate insight into the role of structural geology to understand ore forming systems as well as to lower risk in infrastructural projects.

## Contents

This course in applied structural geology includes theoretical and practical elements. The course covers:

- Rock deformation in plastic vs. brittle regimes.
- Stress and strain analysis.
- Microstructures and kinematics.
- Lithospheric fluid transport/flow.
- Structural controls on ore formation in different tectonic settings.
- Deformation and modification of ore deposits.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course is given in English and consists of lectures where theory is presented and explained. Theoretical knowledge translates into practical applications and increased understanding through practical exercises, peerreviews, group discussions, and field excursions. Assignments that include concepts of petrology, exploration, and geographic information systems are given.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The intended learning outcomes of the course are assessed by four different assessments:

1. Project work assesses ILOs 1, 2, 3, 4, 5, 6, 7,

2. Individual assignments and presentations assess ILOs 2, 3, 5, 6, 7,

3. Field excursion assesses ILOs 5,6

4. Oral exam ILOs 1, 2, 3, 4, 5, 6, 7,

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project work | GU345 | 2 | Mandatory | S25 |  |
| 0004 | Oral examination | GU345 | 3 | Mandatory | S25 |  |
| 0005 | Individual assignments and presentations | UG | 1.5 | Mandatory | S27 |  |
| 0006 | Field excursion | UG | 1 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14
