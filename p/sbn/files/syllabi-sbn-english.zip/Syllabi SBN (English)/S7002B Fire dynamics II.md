---
course_code: "S7002B"
title: "Fire dynamics II"
credits: "7.5"
title_sv: "Branddynamik II"
valid: "Autumn 2023 Sp 2 - Autumn 2026 Sp 2"
decision_date: "2023-06-02"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Brandteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7002B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/s70/s7002b-branddynamik-ii"
---

# Fire dynamics II (S7002B)

## Entry requirements

S0003B Fire Dynamics I or corresponding course

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course participants should be able to

- explain and solve problems related to fire development with regard to production of smoke and toxic gases, and smoke filling times for enclosure fires

- explain and compute aspects of fire detection

- explain and compute aspects of smoke ventilation systems and smoke distribution

- explain the basics for how computer programs are used for simulation of fire development in buildings, as well as solve problems using a two zone program

## Contents

This course covers conservation equations and how smoke filling can be computed in enclosure fires based on these equations. A computer lab is part of the course where a two zone model is used to numerically compute smoke filling in more complex scenarios. Ventilation of fire gases is a central part of the course and is covered on a basic level, based on fundamental fluid mechanical principles, as well on a more applied level. Also, the concentration of toxic gases in the fire smoke is covered based on plyme equations and the concept of yield. Fire detection is also part of the course.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

This course includes teaching and learning activities such as lectures, problem solving classes, computer laboration, group assignments with written and oral presentation, and quiz. The course content in general is presented during the classes, with special more detailed emphasis on certain aspects. The computer laboration consists of a joint introduction with mandatory participation, followed by work in groups where each group hands in one written report. A group work deals with the scientific foundations of the subject where research articles are studied and their content is presented. This group work is complemented with an individual quiz.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through a written exam, which covers parts from the entire course, with grading U 3 4 5. In order to pass the course the student must also have performed the computer laboration and written a report that is approved by the teacher. The group work is examined by an oral presentation as well as by acting as opponent at other groups’ presentations. The quiz is examined in Canvas. Participation is mandatory at the introduction to the computer laboration and at the presentation of the group work.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course S7002B is equal to ABS128, S7014B

1000

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4.5 | Mandatory | A07 |  |
| 0002 | Assignment | U G# | 3 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02

## Syllabus established

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
