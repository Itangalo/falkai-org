---
course_code: "D7007B"
title: "Maintenance Engineering"
credits: "7.5"
title_sv: "Underhållsteknik"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2022-06-15"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7007B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7007B&lasPeriod=216&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7007b-underhallsteknik"
---

# Maintenance Engineering (D7007B)

## Main field of study

Maintenance Engineering

## Entry requirements

At least 60 ECTS in one of the following areas: Maintenance Engineering, Energy Engineering, Mechanical Engineering, Materials Science, Civil Engineering or equivalent, and a minimum of 15 ECTS in mathematics.

## Selection

The selection is based on 30-285 credits

## Course Aim

The aim of this course is to provide knowledge about the theory and application of operation and maintenance engineering of system, process and infrastructure. After completion of the course the students shall be able to:

- define and demonstrate insight in various definitions of reliability and maintenance engineering

- reflect on different types of maintenance strategies

- understand dependability and explain the relationship among its different modules; reliability, maintainability, supportability, availability, and safety (RAMS)

- determine different risks during the maintenance process

- explain the application of methodologies in maintenance decisions

- estimate costs during the life cycle phases of an asset

- integrate the concepts of RAMS, life cycle costing (LCC) and risk analysis for maintenance decision making

- evaluate different maintenance scenarios using modelling and optimization

## Contents

- Basics concepts of Maintenance Engineering, which includes the theory, process, and maintenance planning
- Reliability engineering
- RAMS analysis
- Life Cycle Costing (LCC)
- Risk Analysis
- Maintenance objective and strategy formulation
- Total Productivity Maintenance (TPM)
- Reliability Centered Maintenance (RCM)
- Condition based maintenance (CBM)
- Outsourcing and insourcing

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. This course will be handled in a flipped classroom manner with constructive alignment (linking of objectives with feedback and teaching activities). Students need to be prepared before coming for the lecture. The course is carried out through both individual and group assignments, and discussions with collaborative platform. In additions, students also need to participate in assignments and case study seminars.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Course objectives are assessed by assignments, active participation in seminars, case study and written exam.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0004 | Written exam | GU345 | 3 | Mandatory | A21 |  |
| 0005 | Seminars and assignment reports | GU345 | 4.5 | Mandatory | A21 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-06-15

## Syllabus established

by Eva Gunneriusson 2016-01-19
