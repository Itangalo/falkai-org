---
course_code: "F0019B"
title: "History of Architecture"
credits: "7.5"
title_sv: "Arkitekturhistoria"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "First cycle"
grade_scale: "UG"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F0019B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F0019B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f00/f0019b-arkitekturhistoria"
---

# History of Architecture (F0019B)

## Main field of study

Architecture

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and At least 30 hp courses in engineering and / or social science

## Selection

The selection is based on 1-165 credits.

## Course Aim

Knowledge and understanding

After the course, the student should be able to:

- Describe at a general level the main features of the history of architecture and urban design from antiquity to the present.

- Describe some important architectural and engineering contributions that have influenced the development of the discipline during different eras.

- Give examples of how architecture and urban planning have always been and are important areas for man's quest for a well-functioning world.

Competence and skills

After the course, the student should be able to:

- Describe and interpret the qualities in architecture and urban design from a historical perspective

Judgement and approach

After passing the course, the student will be able to:

- Reflect on the history of architecture and urban design, its role in the present, and what it can mean for the future.

## Contents

The course is an introductory course in the history of Western architecture and urban planning. The relation between building and society, climate and technology etc. The role of the architect and engineer during different eras.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course is based on lectures and exercises. For each main theme the students are given questions to help the learning.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Examination is done through exercises, seminars and essays.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course F0019B is equal to F0008B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Exercises | UG | 7.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-06-14
