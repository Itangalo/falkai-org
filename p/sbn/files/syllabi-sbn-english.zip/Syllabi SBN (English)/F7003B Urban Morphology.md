---
course_code: "F7003B"
title: "Urban Morphology"
credits: "7.5"
title_sv: "Urbanmorfologi"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-11-02"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7003B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f70/f7003b-urbanmorfologi"
---

# Urban Morphology (F7003B)

## Main field of study

Architecture

## Entry requirements

F0002B Urban Design or corresponding course. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

This course focuses on theories of urban form, housing patterns, urban planning and urban development nationally and internationally.

After completing the course, participants should be able to:

Knowledge and understanding

- Describe urban morphology theories of urban form, urban planning, urban development and urban design.

Competence and skills

- Analyse an urban environment through a selection of urban morphology theories.

- Present the urban environment analysis orally and through text and illustrations.

- Summarize urban morphology theories in a literature review.

Judgement and approach

- Reflect on and explain how urban development through urban morphology dimensions.

## Contents

This course covers theories of urban morphology and urban design regarding historical, social and economic dimensions of urban planning and urban development.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. This course includes teaching and learning activities such as lectures, literature seminars, project work, and supervision.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course aims are examined by seminars and a project task. To pass the seminars (U/G) active participation is required as well as a written literature assignment. To pass the project work active participation is required and a pass for the oral, written and visual presentations. The project work is graded by G/U 3 4 5.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project works | GU345 | 6 | Mandatory | A07 |  |
| 0003 | Seminars | UG | 1.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-11-02

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
