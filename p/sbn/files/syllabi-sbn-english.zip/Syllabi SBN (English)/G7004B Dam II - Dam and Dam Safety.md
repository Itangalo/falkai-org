---
course_code: "G7004B"
title: "Dam II - Dam and Dam Safety"
credits: "7.5"
title_sv: "Damm II - dammar och dammsäkerhet"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7004B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7004b-damm-ii---dammar--och-dammsakerhet"
---

# Dam II - Dam and Dam Safety (G7004B)

## Main field of study

Civil Engineering, Mechanical Engineering

## Entry requirements

Basic course in Solid and structural mechanics. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

Give students basic knowledge about the structure, design and function of hydropower dams and mine tailings dams. The student will have good knowledge about dam safety and dam maintenance. The student will have good knowledge about how to apply hydrological methods to dams and their safety. The intended learning outcomes are:

The student should be able to:

- Recognize the different construction methods of hydropower and tailings dams

- Identify dam zones and their type of functions

- Know the function and type of spillway, gates, emergency outlets (double safety)

- Understand the importance of water cycle in dam design

- Perform simple hydrological calculations

- Design open channel flow

- Identify and apply the concepts of flow lines in seepage calculation(dam body and foundation)

The student should be able to apply:

- Hydrological calculation tools

- Hydropower industry’s norms and methods of analysis for dam safety RIDAS, GruvRIDAS, ICOLD etc.

- Calculations of flow nets

- Stability analyses

- Different measurement methods for dams and their performance.

The student should understand:

- Factors that are affecting the dam safety: material transport caused by water flow, behaviour of the structure, foundation method

- Geophysical measurements for leakage and flow.

- Erosion; internal and external.

- Measurements in physical models.

- Scale factors.

- The significance of geology for the dam safety.

- Measures for improving safety

## Contents

Design of different types of hydropower dams:

- different parts of a dam and their functions

- construction (soil compaction etc)

- design guides: RIDAS, ICOLD etc

Different factors influencing dam safety

- material transport due to water flow

- behaviour of a dam, foundation, seepage etc.

- geophysical measuring methods

- slope stability etc.

Case records – dam failures and incidents

Maintenance of dams Introduction to tailings dams (design, function, safety etc.) Hydrology with application to dams and dam design - water accumulation area - snow accumulation, melting of snow - measuring methods and calculation models

Fluid flow with free water surface

Underground constructions

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. Lessons, exercises and assignments. Self-study and discussions. Laboratory work at Vattenfall’s research facility in Älvkarleby (if possible). Guest lecturers from industry.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Four assignments should be completed. The assignments aim to give the students the opportunity to apply the theoretical information provided during the course.

A1: Seminar assignment

Students should write a paper on a real life case study related to the subject “Dam and Dam safety”. Students can propose the case study or chose it from a list provided by the course responsible. In this assignment, students should: practice their critical review on real life issues of dam safety, and be able to highlight the technical aspects that apply to a particular case study.

A2: Seepage analysis

Seepage through and below dam bodies is an important safety issue in dam maintenance and design. In this assignment, students will make use of the numerical software SEEP/W by Geostudio to analyze flow patterns and seepage through sections of different kinds of embankment dams and foundations.

A3: Energy dissipation

Stilling basins are often used for reducing erosion on the downstream side of a water retention dam. In this assignment, students will design a hydraulic jump stilling basin for a hydropower dam.

A4: Laboratory assignment

Consists on compile the results from the laboratory work performed during the technical visit at the Vattenfall research station in Älvkarleby. During the visit, the student will perform different hydraulic laboratory work, and participate in guided tours inside the power station and on the dam. Students should present a report summarizing and discussing the results from the laboratory. If the technical visit is not possible, then a theoretical assignment is given on the same topic.
The final written exam includes both theoretical and practical questions related to Dam and Dam safety. The theoretical questions are in such way that students should apply their technical knowledge on giving suggestions to solve dam safety issues.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course G7004B is equal to ABG132, ABG108

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4.5 | Mandatory | A07 |  |
| 0004 | Assignments | UG | 3 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
