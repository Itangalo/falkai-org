---
course_code: "T7006B"
title: "Applied Blasting"
credits: "7.5"
title_sv: "Tillämpad sprängteknik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7006B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7006B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7006b-tillampad-sprangteknik"
---

# Applied Blasting (T7006B)

## Main field of study

Civil Engineering, .

## Entry requirements

Rock Engineering and Rock Mechanics T0013B or equivalent knowledge and Fundamentals of Rock Mechanics T0014B or equivalent knowledge. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2. .

## Selection

The selection is based on 30-285 credits

## Course Aim

Blasting is a chemical, physical and mechanical process that starts by firing the explosive and results in broken material at the end. This process has been used for many years in different mines and rock excavations (such as tunnels, caverns, quarries). Today, it is the most cost effective way to extract hard rock. Blasting is not only used for mining purposes but also in special cases such as demolition or tunnel excavation. The aim of the course is to help students develop knowledge in the rock blasting process; from the detonation to environmental aspects.

Knowledge and understanding

To pass the course, the student should be able to:

- Explain the concepts, definitions and terminologies in blasting.

- Describe explosive types and initiation systems

- Explain detonation theory

- Analyse propagation and attenuation characteristics of stress waves in rock mass

- Describe blast legislation and regulations.

Competence and skills

To pass the course, students shall be able to:

- Design a drilling and firing pattern of a surface or an underground blast.

- Evaluate and predict blast-induced damage in remaining rock mass.

- Evaluate and estimate the rock fragmentation post-blasting.

Judgement and approach

For a pass on the course, students shall demonstrate the ability to

- Evaluate a blast design which is subjected to environmental restrictions (vibrations, fly rocks and air blast).

## Contents

The following topics will be covered:

- General introduction of the drilling and blasting

- Explosives, types of products and chemistry

- Detonation theory

- Bench blasting: basics and design

- Underground blast design

- Safety precautions

- Blast damage to remaining rock

- Fragmentation theory

- Numerical modelling of blasting

- Environmental effects of blasting

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. This course includes lectures, self-study, project assignment in groups and oral presentation of the project assignment. During the course, a project assignment should be completed in groups and be presented at the end of the course.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through written exam with differentiated grades(5.0HP) and approved project assignments(2.5HP) during the course.

According to the ILOs, the ILOs under the headings of Knowledge and understanding and Judgement and approach are assessed through a written exam. The ILOs under Competence and skills are assessed through a project assignment, by written report.

Grades for the written exam are awarded according to a graded scale of G/U 3 4 5. i.e. Fail (U), Pass (3), Pass without distinction (4), Pass with distinction (5). The project assignment is graded with G/U. i.e. Fail (U), Pass (G).

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 5 | Mandatory | A07 |  |
| 0003 | Assignment report | UG | 2.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
