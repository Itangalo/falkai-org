---
course_code: "U7001K"
title: "Geometallurgy"
credits: "7.5"
title_sv: "Geometallurgi"
valid: "Spring 2024 Sp 3 - Autumn 2026 Sp 2"
decision_date: "2023-06-02"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Kemiteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=U7001K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=U7001K&lasPeriod=223&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/u70/u7001k-geometallurgi"
---

# Geometallurgy (U7001K)

## Entry requirements

Bachelor's degree or equivalent knowledge from practical experience (min. 5 years work experience) in process engineering or geology / mineralogy. English 6.

## Course Aim

The course aims at giving an introduction to the three subject areas geology, process mineralogy and mineral processing out of geometallurgical perspective as the common thread. The course shall primarily address LKAB:s ore types and processes but also take up other ore types.

After completion of the course the student should be able to:

- Identify and describe different ore types and their forming processes

- Analyze mineral properties of ores with respect to efficient beneficiation,

- Describe and explain the unit operations that are used within ore processing,

- Analyze the reasons for process selection based on the raw material properties,

- Describe the prerequisites for setting up a geometallurgical model and explain its elements.

## Contents

Geology:

Minerals and rocks: origin, formation and metamorphosis, ore geology for LKAB's ores and other types of iron ore;

Process mineralogy:

characterization of ore mineral and metallurgical products (composition, mineral textures, exposure) based on optical microscopy, electron microscopy in combination with quantitative analysis (Quemscan), XRD;

Mineral technology:

basic principles for LKAB's unit operations; equipment selection, link to process mineralogy, mineral engineering test work;

Metallurgy:

basic principles of iron production, product properties, customer requirements and quality; Geometallurgical modeling: geostatistical, process modeling in mineral engineering and metallurgy, particle-based material balancing.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The course's language of instruction and form of instruction are stated for each course occasion and appear on the course page on Luleå University of Technology's website.

The teaching consists of lectures, seminars, practical exercises and study visits (LKAB's laboratory work). Participation is mandatory in all parts except in the lectures.

The lectures will give students the opportunity to describe and explain the theory and connections between mineralogy in different ores and enrichment processes.

Practical exercises in geology, process mineralogy and mineral technology are performed in groups. Study visits shall give the opportunity for students to be able to account for advanced mineralogical investigations and technical test methods.

Seminars are devoted to group description, analysis, interpretation and presentation of a complex theme in the field of geometallurgical.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Lab exercises and the seminars are compulsory.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Laboratory work and practical exercise | U G# | 5 | Mandatory | S22 |  |
| 0003 | Seminars | U G# | 2.5 | Mandatory | S22 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-04-19
