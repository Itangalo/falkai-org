---
course_code: "K7017B"
title: "Special Assignment in Structural Engineering"
credits: "7.5"
title_sv: "Projektkurs i Byggkonstruktion"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Konstruktionsteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7017B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7017b-projektkurs-i-byggkonstruktion"
---

# Special Assignment in Structural Engineering (K7017B)

## Entry requirements

K0013B Structural Design or corresponding

## Selection

The selection is based on 30-285 credits

## Course Aim

The Senior Design Course in Structural Engineering aims to give students a rigorously challenging engineering experience through real-world case studies or ideas worth further research. After completing the course participants should be able to (outcome 1) synthesize and (outcome 2) apply the science, mathematics, engineering, and design skills taught in earlier courses. The course also provides students with the opportunity to apply and exercise the more advanced material taught in the previous years.

## Contents

This course covers aspect related to the behaviour of structural elements or entire structures under loads using different methods such as: experimentation, simulations, deepening of knowledge in specific areas, standard and advanced design and assessment of structures. The content of the course will be tailored to specific needs of the student in agreement with the teacher.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. This course includes own study and regular meetings with the teacher. It is expected that the student will participate actively in PhD projects and will collaborate with the research and education personnel from the Structural Engineering group. The student will have the opportunity to perform one or more of the activities in the following non-exhaustive list: laboratory testing, field investigations, finite element analysis or literature review, depending on the needs of the project and student.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The outcomes of the course are assessed as U or G, based on a report of 8 to 10 pages, presenting the topic studied based on a specific template which follows the IMRAD writing methodology.

I-introduction, M-methodology (outcome 2), R-results (outcome 2), A-analysis (outcome 1), D-discussions (outcome 1).

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

Additional course information, e.g. a notification if there has been a change/revision without the course code changing, a link to the course home page with course guide, etc

Transition terms If this course equivalent to a course that has been offered previously, provide the course name and course code.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment reports | U G# | 7.5 | Mandatory | A20 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-02-14
