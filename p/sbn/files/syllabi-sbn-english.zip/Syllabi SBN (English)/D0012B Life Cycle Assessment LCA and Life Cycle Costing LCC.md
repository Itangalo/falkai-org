---
course_code: "D0012B"
title: "Life Cycle Assessment (LCA) and Life Cycle Costing (LCC)"
credits: "7.5"
title_sv: "Livscykel- och livscykelkostnadsanalys"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-02-11"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0012B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0012b-livscykel--och-livscykelkostnadsanalys"
---

# Life Cycle Assessment (LCA) and Life Cycle Costing (LCC) (D0012B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on 1-165 credits.

## Course Aim

The course aims to provide students with general knowledge of life cycle assessment and life cycle costing in maintenance.

After completing the course the student should be able to:

- describe the environmental impact throughout a product's lifecycle

- perform basic life cycle analysis and life cycle cost analysis

- analyze dependability and maintenance costs using simulation tools

- analyze the most cost effective maintenance alternative

## Contents

The course covers:

- environmental impact throughout a product's lifecycle

- methods for life cycle assessment

- methods for life cycle costing

- dependability, reliability and maintenance cost models

- simulation tools to analyze life cycle costs

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of seminars, assignments, group work and laboratory work. At the seminars, specified course material and pre-recorded lectures are discussed. Active participation in the seminars is required to achieve knowledge of environmental impact and methodology for life cycle analysis and life cycle cost analysis. The laboratories provide introduction of software and simulation tools for analysis of dependability and estimation of maintenance costs. Compulsory attendance can be required.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. During the labs, the ability to use simulation tools for analysis of dependability and estimation of maintenance costs is examined. Knowledge and skills to describe a product's environmental impact using life cycle analysis and to perform life cycle cost analysis are examined through written assignments. The assignments are carried out both individually and in groups. An assignment is also presented orally during a seminar where the student is assessed on the ability to analyze maintenance and cost effectiveness for different alternatives. Grading criteria for G 3 4 5 are described in study guide.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0004 | Individual/group assignments | GU345 | 4.5 | Mandatory | A14 |  |
| 0005 | Laboratory work | UG | 3 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

by Eva Gunneriusson 2014-02-13
