---
course_code: "S0006B"
title: "Analysis and design of fire loading in buildings"
credits: "7.5"
title_sv: "Brandtekniska beräkningar"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-02-11"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Brandteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S0006B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S0006B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/s00/s0006b-brandtekniska-berakningar"
---

# Analysis and design of fire loading in buildings (S0006B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

Knowledge and understanding

After completing the course, the student should be able to:

- explain thermal exposure of fires on different materials and constructions

- explain the three different types of heat transfer

- explain the three different types of thermal boundary conditions

- define and select among the most common methods for temperature measurement in fires

Skills and abilities

After completing the course, the student should be able to show the ability to:

- solve problems on heat transfer from hot gases and radiation to surfaces

- solve problems using simple methods where the temperature of constructions exposed to surfaces is calculated

- estimate the time to ignition for materials under different thermal exposures

- show ability for teamwork and in writing and orally, in English and Swedish, in dialogue with different groups clearly present and discuss the conclusions from heat transfer calculations, as well as presenting and discussing the method for achieving the results

Judgement and attitude

After completing the course, the student should be able to:

- show ability for assessing the suitability for different types of methods for heat transfer problems considering relevant limitations and physical phenomena.

## Contents

The course contains fundamental knowledge in heat transfer by conduction, convection and radiation.

The course contains several areas where mathematical knowledge and abilities is developed and applied:

- The physical phenomena natural and forced convection are studied and applied in various fire safety engineering contexts.

- Heat transfer by radiation is important in fire safety engineering. Approximative methods for calculating radiation from flames are studied. The concepts of emissivity and view factors are introduced for calculating heat transfer between surfaces.

- The relation between convection and radiation is discussed in depth. The concept of adiabatic surface temperature is introduced, explained and applied in calculations.

- Temperature measurements in fires

- Ignitability

- Simple numerical methods

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching is based on lectures, assignments (laboration, quizzes, written and oral presentation of report). During the lectures the course content is presented and complemented with solving selected exercises. In the laboration the students obtain an in-depth and hands-on experience on heat transfer and the relative importance of conduction, convection and radiation.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course consists of two parts:

- Written exam with grading G U 3 4 5.

- The assignment part consists of several quizzes and laboration report. The laboration report is presented in written and orally. In order to pass the course it is required that the student participates actively at the laboration and at the presentation of the lab report. The grading of the assignment part is G U.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be

assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4.5 | Mandatory | S12 |  |
| 0004 | Assignments | UG | 3 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

by Department of Civil, Environmental and Natural Resources Engineering 2011-02-08
