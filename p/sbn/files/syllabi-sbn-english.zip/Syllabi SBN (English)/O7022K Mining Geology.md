---
course_code: "O7022K"
title: "Mining Geology"
credits: "7.5"
title_sv: "Gruvgeologi"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Malmgeologi"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O7022K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O7022K&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o70/o7022k-gruvgeologi"
---

# Mining Geology (O7022K)

## Main field of study

Geosciences

## Entry requirements

90 credits in Geoscience.

## Selection

The selection is based on 30-285 credits

## Course Aim

The purpose of the course is that the students should acquire an advanced understanding of the ore and mineral deposits' investigation and evaluation.

The student should be able to model the grade and tonnage of mineral deposits based on geological data in a 3D environment. The student should be able to explain how cut-off affects the size and grade of mineral resources and be able to use basic geostatistical methods for calculation of average content in drill cores and profiles based on grade, length and density data.

The student should be able to account for the difference in confidence level between inferred, indicated and measured mineral resources, as well as their distinction from mineral reserves. This includes the ability to explain how various modifying factors such as choice of mining methods, processing methods, metallurgical factors, environmental factors, social factors, legal factors and economic factors affect the feasibility of a mining project. The student should be able to critically analyze technical reports from mining and exploration projects with regard to how well they meet the requirements set by international industry standards for reporting mineral resources.

The student should be able to account for different strategies for grade control and mining mapping, and be able to choose methods based on the deposit geology and the mining method. The student should be able to collect geological information from mines to characterize ore boundaries and geological structures, and use this information to make estimates of dilution in active production environments.

## Contents

During the course, students work with various aspects in the value chain of mining projects and advanced exploration projects, from modelling mineral resources from geological data before mining, to the process of converting mineral resources to mineral reserves by applying modifying factors, to the mining geological methods used for further characterization and evaluation of deposits in connection with mining.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The subject is presented in the form of class lectures by several lecturers. In-depth study of the subject takes place through individual student projects based on a literature study of technical reports from mining projects and advanced exploration projects, written presentation, and group discussions in seminar form.

Practical skills are trained through exercises in mineral resource estimation methodology on paper and in software, calculation of ore sections, mining mapping, grade control and delineation of ore contacts. The exercises will be partly linked to lectures performed in parallel.

Document management takes place in the learning platform CANVAS

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Written exam is given with differentiated grades. Grading scale: 5 4 3 U. In order to pass the course, it is also required that the student complete and report practical assignments and individual project work, and get these improved by the examiner.

Reports that have not met the set quality requirements within one week after the end of the current reading period means that the grade has failed for the practical part. The practical part in its entirety may then be carried out at a future course opportunity, provided that vacant spots are available.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course O7022K is equal to O7011K

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4 | Mandatory | A16 |  |
| 0002 | Project work | GU345 | 2.5 | Mandatory | A16 |  |
| 0003 | Exercises | U G# | 1 | Mandatory | A16 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2016-02-10
