---
course_code: "O0008K"
title: "Petrology"
credits: "7.5"
title_sv: "Petrologi"
valid: "Autumn 2025 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2025-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Malmgeologi"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0008K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0008K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o00/o0008k-petrologi"
---

# Petrology (O0008K)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and O0035K Geology, basic course and O0036K Mineralogy or equivalent knowledge.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course, the student must be able to:

Knowledge and understanding

- relate rock-forming processes to plate tectonic processes and different geological formation environments

- connect rock properties such as chemical and mineralogical composition, textures, and structures to rock-forming processes

Skill and ability

- describe, identify and classify the most common sedimentary, igneous and metamorphic rocks and their structures in the field and under a microscope

- use basic methodology in field mapping

- document and report geological field data

## Contents

The course deals with formation processes, conditions, and environments of sedimentary, igneous, and metamorphic rocks, their relationship to plate tectonics, as well as the expression in the rocks' chemical and mineralogical composition, textures, and structures. Also included are rock identification methods like microscopy and mineralogical and geochemical classification charts. Furthermore, basic methodology in fieldwork, geological documentation and reporting is covered.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching is divided into four parts that include (1) igneous, (2) sedimentary, and (3) metamorphic rocks as well as (4) an excursion. The sections on rock types (1–3) consist of lectures where basic theory is presented and explained with a focus on knowledge and understanding. Practical exercises (individually and in groups) are linked to lectures and focus on the student's skills to describe, interpret and explain the textures and structures of rocks in the field and under a microscope, as well as to classify rocks. The excursion with field exercises aims to strengthen and deepen knowledge and abilities gained from the other parts as well as to introduce basic methodology in field mapping.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The teaching is divided into four parts that include (1) igneous, (2) sedimentary, and (3) metamorphic rocks as well as (4) an excursion. The sections on rock types (1–3) consist of lectures where basic theory is presented and explained with a focus on knowledge and understanding. Practical exercises (individually and in groups) are linked to lectures and focus on the student's skills to describe, interpret and explain the textures and structures of rocks in the field and under a microscope, as well as to classify rocks. The excursion with field exercises aims to strengthen and deepen knowledge and abilities gained from the other parts as well as to introduce basic methodology in field mapping.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course O0008K is equal to KGO005

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Exercises | U G# | 1.5 | Mandatory | A07 |  |
| 0011 | Excursion, Field Exercises and Report | U G# | 1.5 | Mandatory | A07 |  |
| 0012 | Partial exam: igneous rocks | GU345 | 1.5 | Mandatory | A07 |  |
| 0013 | Partial exam: sedimentary rocks | GU345 | 1.5 | Mandatory | A07 |  |
| 0014 | Partial exam: metamorphic rocks | GU345 | 1.5 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by the Department of Chemical Engineering and Geosciences 2007-02-28
