---
course_code: "X0004K"
title: "Degree Project in Mineral Resource Engineering, Bachelor"
credits: "15"
title_sv: "Examensarbete i Hållbar mineralutvinning, kandidat"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2026-02-13"
education_level: "First cycle"
grade_scale: "UG"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X0004K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X0004K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/x00/x0004k-examensarbete-i-hallbar-mineralutvinning-kandidat"
---

# Degree Project in Mineral Resource Engineering, Bachelor (X0004K)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and At least 135 credits completed courses as required for the degree. In addition to the above, the examiner decides whether the proposed degree project is within the subject area and student has the depth of knowledge required. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2

## Selection

The selection is based on 1-165 credits.

## Course Aim

The overall goal of the course is that the student practices, develops and is able to apply theory and methods to solve problems in a scientific manner that are relevant to work as a Bachelor of Science in Engineering within the area of Mineral Resource Engineering. This means that on completion of the course the student is able to:

- Formulate a relevant problem for investigation from a chosen subject within the subject area Mineral Resource Engineering.

- Apply knowledge and proficiency that has been acquired during the period of study to an investigation, development or smaller research project in an independent and systematic manner.

- Choose and justify the study methods for an investigation.

- Analyse and defend the problem formulated in a correct manner with respect to engineering.

- Locate and critically review information and summarise this in a manner appropriate to engineering.

- Plan, structure and execute an investigation or development project.

- Judge the relevance of the results obtained.

- Work to a timetable.

- Express themselves well in writing in a linguistically and scientifically correct manner.

- Create and execute a presentation of the results of the project, defending the conclusions.

- Critically review the work of others in a constructive manner.

## Contents

The content of the degree project is designed in collaboration with the supervisor. The degree project always contains a theoretical foundation in the form of a literature survey that highlights the area of technology and the methodology, summarized in a scientific manner.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The student independently plans and executes the degree project; the supervisor is available for assistance. A timetable for the entire project is included in the degree project, which is continuously reviewed.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

- Written presentation of individual work. In the report the student shows the ability to:

    - Justify the chosen problem of study

    - Select and justify the study methods

    - Collect information relevant to the problem formulation with an explicit connection to the chosen theory/methods

    - Present the information collected in writing in a relevant manner o      Analyse and defend the formulated problem from the chosen theory and methods

    - Critically review the relevance of the results obtained from a scientific and engineering point of view

    - Express themselves in writing in a correct linguistic and scientific manner.

- Oral presentation of own work

- Public discussion of the work of others

- Attendance at presentations of the degree project work of others.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The department provides active supervision for a period of one term from the start of the project. The degree project is performed individually; only in exceptional cases may at most two students carry out the degree project together. In cases in which the degree project is carried out by two students, this shall be clearly visible in the scope and depth of the report.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Oral presentation | UG | 0 | Mandatory | S27 |  |
| 0006 | Start of degree project | UG | 0 | Mandatory | S27 |  |
| 0007 | Approved report | UG | 15 | Mandatory | S27 | Yes |
| 0008 | Public discussion of others degree project | UG | 0 | Mandatory | S27 |  |

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13
