---
course_code: "V0018B"
title: "Planning and construction in civil engineering"
credits: "7.5"
title_sv: "Samhällsbyggande"
valid: "Autumn 2023 Sp 1 - Spring 2026 Sp 4"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0018B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0018B&lasPeriod=216&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/v00/v0018b-samhallsbyggande"
---

# Planning and construction in civil engineering (V0018B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Swedish upper secondary school courses Physics 2, Chemistry 1, Mathematics 4 or Mathematics E.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

Knowledge about

1. Structuring and writing of a technical report including reference list

2. Creating presentation material and oral presentation techniques

3. Retrieving information in the internet and scientific databases including critical assessment of the information; reference formatting in text

4. Calculations using spread sheets

5. Terms and definitions in civil engineering and construction process/work

6. Giving examples for roles and functions in civil engineering and challenges facing today’s civil engineering

7. Giving examples for systems integration in civil engineering

8. Giving examples for connections between civil engineering and sustainable development

9. Describing urban technical infrastructure

10. Describe the national gender equality goals and regulations for gender equality in working life and give examples of the prerequisite for gender equality in professional life

## Contents

This course provides an introduction to civil engineering and the construction process. The course describes challenges for future civil engineering and the complexity in construction processes, e.g. the interconnectivity and also possible conflicts between different infrastructure systems. Additionally, basic knowledge about gender equality in the workplace. Further, the course includes several general skills, e.g. writing of technical reports incl. reference formatting, presentation techniques, and spread sheet calculations.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The course is divided into several parts which are assessed continuously during the course. The teaching contains exercises, lectures, recorded lectures, seminars, and individual tasks. A project work covering current construction projects will be conducted continuously. All seminars, presentations, etc. are compulsory since they are part of the examination.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Structuring and writing of a technical report including referring is examined in seminars and quizzes (item 0007), two group tasks (items 0003 and 0006) and one individual task (item 0002). Creating presentation material and oral presentation techniques is examined by participation in a seminar (item 0005) and carrying out three presentations during the course of the course (0005, 0006 och 0008). Information retrieval is examined by participation at seminars, including hand-ins, and quizzes (item 0007) as well as in association with report writing (item 0006) and the construction dictionary (item 0002). Calculations using spread sheets are examined in a calculation report carried out in group (item 0003). Terms and definitions in civil engineering and construction processes is examined in a lexicon written by the student (item 0002) and knowledge regarding roles and challenges in the civil engineering sector as well as system integration and connections between civil engineering and sustainable development is examined in the seminar series and associated hand-ins (item 0005). System integration and connections between civil engineering and sustainable development is also examined in the technical report (item 0006). Describing urban technical infrastructure is examined in the calculation task (item 0003). The course goals related to equality goals and regulations as well as the prerequisite for gender equality in professional life is examined through quizzes (item 0009). To pass this course, all items of the examination have to be passed. All course items as well as the completed course are graded on the scale U G. In the case that the student does not participate in one or more of the scheduled seminars or study visit, it may be carried out the next time the course is given, if there are vacancies available.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course V0018B is equal to V0020B

## Remarks

The course is given exclusively in Swedish.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Construction dictionary | U G# | 1 | Mandatory | A15 |  |
| 0003 | Calculation task | U G# | 1.5 | Mandatory | A15 |  |
| 0005 | Seminars | U G# | 1 | Mandatory | A15 |  |
| 0006 | Technical report | U G# | 2 | Mandatory | A15 |  |
| 0007 | Information retrieval and report writing | U G# | 0.8 | Mandatory | A15 |  |
| 0008 | Presentation skills | U G# | 0.7 | Mandatory | A15 |  |
| 0009 | Quizzes on gender equality | U G# | 0.5 | Mandatory | A15 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2015-02-11
