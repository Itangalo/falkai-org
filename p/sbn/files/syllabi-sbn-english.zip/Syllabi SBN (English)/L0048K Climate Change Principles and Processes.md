---
course_code: "L0048K"
title: "Climate Change, Principles and Processes"
credits: "7.5"
title_sv: "Klimatförändringar, principer och processer"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0048K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0048K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0048k-klimatforandringar-principer-och-processer"
---

# Climate Change, Principles and Processes (L0048K)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and K0016K Chemical Principles or equivalent.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course participants should be able to

Knowledge and understanding

- Briefly explain origin and development of Earth’s atmosphere and discuss its significance for Earth’s climate (Learning objective 1)

- Briefly explain basic ocean dynamics and climate related processes in the ocean and discuss their significance for Earth’s climate (Learning objective 2)

- Give examples of, and explain how environmental archives can be used to provide knowledge about Earth’s historical climate (Learning objective 3)

Competence and skills

- Calculate and assess the natural and anthropogenic impact on the atmosphere and Earth’s climate with simple models (Learning objective 4)

- On a scientific basis, compile and present how some of the processes that control Earth's climate affect each other (Learning objective 5)

Judgement and approach

- On a scientific basis, reflect on how anthropogenic processes affect the climate (Learning objective 6)

## Contents

The course gives a basic introduction to Earth's climate system with focus on the atmosphere and the ocean. It contains basic knowledge about climate change and examples of what can be done to change the ongoing development. The course covers geochemical and physical concepts and information about processes required to understand changes in Earth's spheres. Methods for understanding historical climate and information about how models are used to predict future climate are discussed. Examples of how changes in climate affects ecosystems are given from different environments.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures and compulsory assignments, oral presentations and project work in groups with individual examination where the students are expected to participate actively.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through

- Written report and oral presentation of project work (U/G)

- Hand in and oral assignments (3 4 5)

Learning objective 1-4 and 6 are assessed through hand in and oral assignments.

Learning objective 5 is assessed through a written report and oral presentation of project work.

All exams included in the module need to be completed for a course grade.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Assignments | GU345 | 4.5 | Mandatory | A22 |  |
| 0004 | Project work | U G# | 3 | Inactive | A22 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11
