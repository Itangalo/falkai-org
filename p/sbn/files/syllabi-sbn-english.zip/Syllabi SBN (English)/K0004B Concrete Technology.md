---
course_code: "K0004B"
title: "Concrete Technology"
credits: "7.5"
title_sv: "Betongteknik"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2022-02-11"
education_level: "First cycle"
grade_scale: "U G VG *"
subject: "Konstruktionsteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0004B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k00/k0004b-betongteknik"
---

# Concrete Technology (K0004B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

The aim of the course is for the student to develop a basic knowledge in concrete technology.

After completing the course, the student should be able to:

1. Define the material concrete

2.Explain the basic properties of concrete in fresh, hardening and hardened condition

3. Give examples of concrete molds and their use

4. Demonstrate knowledge of reinforcement

5. Perform simple design calculations and design simple design elements

6. Master the basic techniques, measurements and analyzes used in a concrete lab.

## Contents

Concrete is the most widely used building material. The course provides extensive knowledge of concrete as a building material. The course provides an introduction to formwork and knowledge of reinforcement. The course also provides knowledge of the regulations used. In addition, the course provides an introduction to design calculations. The content of the course also includes a lab part where the students themselves get to know concrete in a practical way.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

Teaching consists of lectures given by two teachers. Lectures focus on the theoretical and theoretical background of the subject area. Practical skills are trained through calculations / exercises in the classroom, homework/project and in laboratory tasks. The work in the laboratory is performed in groups but results from the laboratories are documented in a lab rapport by each student. Laboratory work and exercises are linked to the lectures and will take place in parallel to the lectures. Study visits are carried out if possible to see practical applications in the industry.

Document management takes place in the learning platform Canvas.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. During the course the students will work on assignments, which will be U/G. The final exam is graded U/G/VG. Through this methods, all learning outcomes can be covered.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K0004B is equal to ABK124

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | U G VG * | 3 | Mandatory | A07 |  |
| 0002 | Assignment | U G VG * | 4.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
