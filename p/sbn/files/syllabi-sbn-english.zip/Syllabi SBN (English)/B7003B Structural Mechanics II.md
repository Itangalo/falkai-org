---
course_code: "B7003B"
title: "Structural Mechanics II"
credits: "7.5"
title_sv: "Byggnadsmekanik II"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Konstruktionsteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B7003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B7003B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/b70/b7003b-byggnadsmekanik-ii"
---

# Structural Mechanics II (B7003B)

## Main field of study

Civil Engineering, .

## Entry requirements

Basic courses in strength of materials and structural mechanics, like B0002B Structural engineering and B7004B Structural Mechanics I.

## Selection

The selection is based on 30-285 credits

## Course Aim

The aim of the course is that the student should be able to

- calculate critical load (instability) according to first and second order theories for 1-dimensional and 2-dimensional trusses and frames

- calculate deformations and stresses in slabs, plates and shells

- calculate shear forces and stresses of torsion of non-circular cross-sections

- plan and perform calculation tasks, process results and present them in writing (calculation report)

## Contents

Critical load (instability) for 1-dimensional elements

- according to first order theory

- with the influence of transverse forces

- stiffness matrix and load vector

- deriving Euler's buckling cases

Critical load (instability) for 2-dimensional trusses and frames

- according to first and second order theories

- stiffness matrix and load vector

- condensation of stiffness matrix and load vector

- criteria for instability

Deformations and stresses in

- plates

    - plane stress and plane strain conditions

    - Airy’s stress function

    - boundary conditions

    - symmetrical stress distributions

    - linear load on half space

    - holes

- slabs

    - Kirschoff’s slab theory

    - Reissner’s slab theory

    - energy equations

- shells

    - spherical shells

    - single curved shells

    - saddle surfaces

Section forces and stresses of torsion for statically determinate and indeterminate elements with non-circular cross-sections

- without prevented warping

    - Saint-Venant’s theory

    - thin-walled closed cross-sections

- with prevented warping

- shear centre and torsion centre

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The students participate in lectures where backgrounds and theories to the course content are derived, presented and exemplified.

The students practice calculation methodology and theories for the course content

- individually partly in practice sessions in classrooms for simpler structures, partly in the computer room in assignments

- in a group for larger structures in project tasks

Students practice the ability to plan, implement and report calculation tasks individually in assignments and in groups in project assignments.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Background, theories and calculation methodology for simpler structures (a few elements) are examined with a written final exam. Grading scale: U, 3, 4, 5.

Calculation methodology for larger structures is examined through written calculation reports of assignments and project assignments. Grading scale: U, G

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 6 | Mandatory | A08 |  |
| 0004 | Assignments | UG | 1.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2008-01-22 and is valid from H08.
