---
course_code: "K0018B"
title: "International construction"
credits: "7.5"
title_sv: "Utlandsbyggande"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2020-04-21"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0018B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0018B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k00/k0018b-utlandsbyggande"
---

# International construction (K0018B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and The course V0011B Planning and Construction and at least two of T0013B Rock Engineering and Rock Mechanics, K0013B Structural Design and P0001B Construction Management

## Selection

The selection is based on 1-165 credits.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K0018B is equal to T0028B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Participated in the study tour and approved report | U G# | 7.5 | Mandatory | S21 |  |

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-04-21
