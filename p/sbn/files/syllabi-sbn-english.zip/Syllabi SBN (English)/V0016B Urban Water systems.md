---
course_code: "V0016B"
title: "Urban Water systems"
credits: "7.5"
title_sv: "VA-system"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2009-01-20"
education_level: "First cycle"
grade_scale: "GU345"
subject: "VA-teknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0016B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/v00/v0016b-va-system"
---

# Urban Water systems (V0016B)

## Main field of study

Natural Resources Engineering, ., Civil Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and University-level courses equivalent to 60 credits, including at least 7.5 credits in mathematics (e.g. M0047M Differential Calculus) and 7,5 credits in Physics (e.g. F0004T Physics 1), as well as a basic knowledge of hydraulics (e.g. V0014B Hydraulics and geology, or equivalent).

## Selection

The selection is based on 1-165 credits.

## Course Aim

You should be able to:

Knowledge and understanding 1. Describe the systems for potable water and wastewater and be able to explain the function of its their components. 2. Describe different treatment units at drinking water and wastewater treatment plants and be able to explain their functions. 3. Describe differences in quality between different waters.

Competence and skills 4. Perform hydraulic calculations for pipes. 5. Dimension pipes, pumps and reservoirs for systems for potable water and wastewater. 6. Calculate storm water flows with the ”rational method” and the ”Time-area-method”. 7. Refer to references in written text according to common methods used in the engineering field of science, and present collected data in appropriate diagrams.

Judgement and approach 8. Give examples of advantages and disadvantages of different urban water systems based on technical aspects and do reflection about sustainability and relate these systems to the development of sustainable urban water systems and relate to UN sustainable development goals.

## Contents

This course gives you an overall picture of the urban water system and how it has developed over time. You achieve knowledge about how urban areas are supplied with drinking water and how the wastewater is treated. You learn to carry out hydraulic calculations on pipe systems and how to dimension the water supplying network as well as the sewer system. You also learn how other components in the water supplying system are dimensioned, such as water reservoirs and pumps. You will get the possibility to broaden your knowledge about the urban water system, for instance how the drinking water and sewage are managed at the countryside or learn about new types of pipe systems, such as vacuum systems. During the course, you do water quality analyses and get opportunities to meet and talk with urban water engineering, working in the water sector.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

Fundamental system knowledge is acquired by lectures, study questions and literature studies during the course. To achieve calculation knowledge, you participate at the lectures, do calculations exercises individually, and work with a calculation task in groups. The calculation task is presented by a written report and will be orally presented. The oral presentation is mandatory. A project task is carried out (group tasks) to get a deeper understanding of the systems for potable water and wastewater. Sustainability aspects will be involved in the project task. During the work with the project report you are introduced to common methods how to refer to literature references in the text. The project task is presented orally and with a written report in which the content as well as the quality of the reference management is evaluated.

During mandatory laboratory lesson, the water quality is investigated by laboratory analytical methods. A laboratory report is written in small groups, where the data presentation is in focus. To further penetrate sustainability aspects of urban water systems, a mandatory seminar is given. Active presence during the laboratory task, seminar and at presentations is compulsory.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Fundamental system knowledge (aims 1 and 2) is examined with a final exam (#0018) at the end of the course. Calculation and dimensioning (aims 4-6) are examined by one intermediate written exam (#0017) during the course. Both these written examinations are given grades. More comprehensive calculation knowledge (aims 5 and 6) is examined during the course by a calculation task (#0015) that is examined by a written report and an oral presentation. The project task (#0010), examining the aims that are related to a broader knowledge about the urban water system as well as reference management (aims 1, 2, 7 and 8) is examined by a written report and an oral presentation according to a graded scale. The laboratory, task (#0016) examines the course aims about water quality differences and data presentation (aims 3, 7) by a short written report graded with (F/P). The seminar (#0014) examines the course aims related to a broader knowledge about the urban water system (mål 1, 8), with active participation.

To achieve a final grade of the course you have to pass all the examination items and attend and be active at the mandatory seminar, laboratory lesson and scheduled oral presentation lessons. If you have not attended any of the scheduled laboratory lessons, you need to do the field task another year, if there is room for additional students.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a

conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0010 | Project task | GU345 | 1 | Mandatory | A09 |  |
| 0015 | Calculation task | GU345 | 1.7 | Mandatory | A09 |  |
| 0017 | Short written exam | GU345 | 3 | Mandatory | A09 |  |
| 0018 | Exam | GU345 | 1.3 | Mandatory | A09 |  |
| 0019 | Laboratory task and data presentation | UG | 0.3 | Mandatory | S27 |  |
| 0020 | Seminar | UG | 0.2 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Department of Civil and Environmental Engineering 2009-01-20
