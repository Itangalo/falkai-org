---
course_code: "C0025B"
title: "Society's Planning for Hazards"
credits: "7.5"
title_sv: "Samhällets planering för risker och kriser"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2024-02-19"
education_level: "First cycle"
grade_scale: "UG"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=C0025B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=C0025B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/c00/c0025b-samhallets-planering-for-risker-och-kriser"
---

# Society's Planning for Hazards (C0025B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Completed courses of 30 credits in technology or urban planning.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completed course, the student will be able to:

- describe different planning processes, and how legislation is steering these processes;

- participate with risk analyses in the planning process;

- show the ability to simulate risks and vulnerabilities in society’s planning with reference to relevant information;

- show knowledge on the scientific ground of the area; and

- write references in texts according to commonly used methods for scientific work.

## Contents

This course focuses on the management of risks in the planning of societies, the planning processes, and the commonly used terminology in the area, with a particular focus on comprehensive planning and thematic comprehensive planning.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course contains of lectures, study visit, literature seminar, a group project, and an individual review of another group’s project work. The lectures and literature mainly illustrate how different kinds of risks can be managed in the planning process, using risk analyses as a starting point; how legislation is used to guide the management of risks in the planning process; and different authorities and companies view on risk management in the planning of societies. Through the project assignment, students will practice knowledge of risk analyses in the planning of process, in particular in comprehensive planning and in a thematic comprehensive plan, as well as academic report writing. To delimit the extent of the project work, the software Ibero will be used.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. A pass grade for the course requires active participation in the project work, a pass for the oral and written report on project assignments, a pass for the literature seminar, participation in study visits and at least 80 % attendance at lectures. Review of another group’s report is conducted individually.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course C0025B is equal to C0024B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Study visit | UG | 0.2 | Mandatory | S27 |  |
| 0006 | Literature seminar | UG | 2 | Mandatory | S27 |  |
| 0007 | Project work | UG | 4.3 | Mandatory | S27 |  |
| 0008 | Lectures | UG | 1 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-19

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-19
