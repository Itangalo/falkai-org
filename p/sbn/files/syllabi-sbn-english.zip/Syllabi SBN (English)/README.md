# Course syllabi at SBN/CENE, Luleå University of Technology

257 active syllabi whose *Course offered by* field is the Department of Civil, Environmental and Natural Resources Engineering (SBN/CENE). Retrieved 2026-08-17 from LTU's syllabus archive (epok.ltu.se), English version, latest admission term. Converted from PDF to Markdown with YAML frontmatter.

The Swedish originals are in `../kursplaner SBN/`. Note that the syllabi themselves state that the Swedish version has interpretative precedence in the event of a conflict.

## Method

- All active syllabi at LTU were listed via the syllabus archive on ltu.se (1,508 unique courses, filtered on type = Course and discontinued = No).
- For each course the official syllabus PDF was retrieved from epok.ltu.se.
- Syllabi were filtered on the **Course offered by** field, which names the department.
- Distribution across LTU: ETKS 432, SRT 337, HLT 275, **SBN 257**, TVM 195, other 12.

## Courses by subject

### Väg- och vattenbyggnad (36)

- [C0022B Society's planning for hazards](C0022B%20Societys%20planning%20for%20hazards.md) – 7.5 cr, First cycle
- [D7001B Mine Automation](D7001B%20Mine%20Automation.md) – 7.5 cr, Second cycle
- [G0001B Road and Railroad Design with Computers](G0001B%20Road%20and%20Railroad%20Design%20with%20Computers.md) – 7.5 cr, First cycle
- [G0002B Road and railway engineering](G0002B%20Road%20and%20railway%20engineering.md) – 7.5 cr, First cycle
- [G0005B Solar Heating Systems](G0005B%20Solar%20Heating%20Systems.md) – 7.5 cr, First cycle
- [G0015B Road and railway engineering](G0015B%20Road%20and%20railway%20engineering.md) – 7.5 cr, First cycle
- [G7009B Tailing dams and dam safety](G7009B%20Tailing%20dams%20and%20dam%20safety.md) – 3 cr, Second cycle
- [G7011B Road and Railway Engineering, Advanced Course](G7011B%20Road%20and%20Railway%20Engineering%20Advanced%20Course.md) – 7.5 cr, Second cycle
- [K0002B Building materials](K0002B%20Building%20materials.md) – 7.5 cr, First cycle
- [K0007B Risk and safety - Basic course](K0007B%20Risk%20and%20safety%20-%20Basic%20course.md) – 7.5 cr, First cycle
- [K0011B Building Technology](K0011B%20Building%20Technology.md) – 7.5 cr, First cycle
- [K0013B Structural Design](K0013B%20Structural%20Design.md) – 7.5 cr, First cycle
- [K0015B Tools for Engineering Calculations and Reporting](K0015B%20Tools%20for%20Engineering%20Calculations%20and%20Reporting.md) – 15 cr, First cycle
- [K0017B Applied Risk Management](K0017B%20Applied%20Risk%20Management.md) – 7.5 cr, First cycle
- [K0018B International construction](K0018B%20International%20construction.md) – 7.5 cr, First cycle
- [K7018B Special Assignment in Building Materials](K7018B%20Special%20Assignment%20in%20Building%20Materials.md) – 7.5 cr, Second cycle
- [K7019B Building Materials Influence on Indoor Environment: Perception and Reality](K7019B%20Building%20Materials%20Influence%20on%20Indoor%20Environment%20Perception%20and%20Real.md) – 7.5 cr, Second cycle
- [K7026B Design of Timber Structures 1](K7026B%20Design%20of%20Timber%20Structures%201.md) – 7.5 cr, Second cycle
- [K7027B Modeling and Simulation of Timber Structures](K7027B%20Modeling%20and%20Simulation%20of%20Timber%20Structures.md) – 7.5 cr, Second cycle
- [K7028B Project Course, Design of Timber Structures](K7028B%20Project%20Course%20Design%20of%20Timber%20Structures.md) – 7.5 cr, Second cycle
- [K7029B Design of Timber Structures 2, Extreme Conditions and Safety](K7029B%20Design%20of%20Timber%20Structures%202%20Extreme%20Conditions%20and%20Safety.md) – 7.5 cr, Second cycle
- [T0028B International construction](T0028B%20International%20construction.md) – 7.5 cr, First cycle
- [T7025B Project Course in Rock and Soil](T7025B%20Project%20Course%20in%20Rock%20and%20Soil.md) – 7.5 cr, Second cycle
- [U0007B Building Technology](U0007B%20Building%20Technology.md) – 7.5 cr, First cycle
- [V0014B Hydraulics and geology](V0014B%20Hydraulics%20and%20geology.md) – 7.5 cr, First cycle
- [V0015B Sustainable Building](V0015B%20Sustainable%20Building.md) – 7.5 cr, First cycle
- [V0018B Planning and construction in civil engineering](V0018B%20Planning%20and%20construction%20in%20civil%20engineering.md) – 7.5 cr, First cycle
- [X0007B Degree Project in Civil Engineering, Bachelor](X0007B%20Degree%20Project%20in%20Civil%20Engineering%20Bachelor.md) – 15 cr, First cycle
- [X7003B Degree project in Civil Engineering, Master](X7003B%20Degree%20project%20in%20Civil%20Engineering%20Master.md) – 30 cr, Second cycle
- [X7004B Degree project in Fire Engineering, Master of Science in Engineering](X7004B%20Degree%20project%20in%20Fire%20Engineering%20Master%20of%20Science%20in%20Engineering.md) – 30 cr, Second cycle
- [X7006B Degree project in Civil Engineering, specialization Lean Construction, Master of Science in Engineering](X7006B%20Degree%20project%20in%20Civil%20Engineering%20specialization%20Lean%20Construction%20M.md) – 30 cr, Second cycle
- [X7009B Degree project in Civil Engineering, specialization Soil and Rock Engineering, Master of Science in Engineering](X7009B%20Degree%20project%20in%20Civil%20Engineering%20specialization%20Soil%20and%20Rock%20Engin.md) – 30 cr, Second cycle
- [X7010B Degree project in Civil Engineering, specialization Structural Engineering, Master of Science in Engineering](X7010B%20Degree%20project%20in%20Civil%20Engineering%20specialization%20Structural%20Engineer.md) – 30 cr, Second cycle
- [X7015B Degree project in Timber Structures, Master](X7015B%20Degree%20project%20in%20Timber%20Structures%20Master.md) – 15 cr, Second cycle
- [Y0004B Surveying 2](Y0004B%20Surveying%202.md) – 7.5 cr, First cycle
- [Y0009B Final year project, University diploma](Y0009B%20Final%20year%20project%20University%20diploma.md) – 7.5 cr, First cycle

### Underhållsteknik (32)

- [D0002B Operation and Maintenance](D0002B%20Operation%20and%20Maintenance.md) – 7.5 cr, First cycle
- [D0004B Operation and Maintenance - Hydropower](D0004B%20Operation%20and%20Maintenance%20-%20Hydropower.md) – 7.5 cr, First cycle
- [D0010B Maintenance Strategy](D0010B%20Maintenance%20Strategy.md) – 7.5 cr, First cycle
- [D0011B Introduction to Operation and Maintenance Engineering - Basic](D0011B%20Introduction%20to%20Operation%20and%20Maintenance%20Engineering%20-%20Basic.md) – 7.5 cr, First cycle
- [D0012B Life Cycle Assessment (LCA) and Life Cycle Costing (LCC)](D0012B%20Life%20Cycle%20Assessment%20LCA%20and%20Life%20Cycle%20Costing%20LCC.md) – 7.5 cr, First cycle
- [D0016B Reliability Engineering and Analysis in Maintenance](D0016B%20Reliability%20Engineering%20and%20Analysis%20in%20Maintenance.md) – 7.5 cr, First cycle
- [D0017B Senior Design Project in Operation and Maintenance Engineering](D0017B%20Senior%20Design%20Project%20in%20Operation%20and%20Maintenance%20Engineering.md) – 15 cr, First cycle
- [D0018B Senior Project in Maintenance Engineering](D0018B%20Senior%20Project%20in%20Maintenance%20Engineering.md) – 15 cr, First cycle
- [D0019B Human Factors for Safety in the Work Environment](D0019B%20Human%20Factors%20for%20Safety%20in%20the%20Work%20Environment.md) – 7.5 cr, First cycle
- [D0020B Internet of Things and Signal Analysis for Condition Monitoring](D0020B%20Internet%20of%20Things%20and%20Signal%20Analysis%20for%20Condition%20Monitoring.md) – 7.5 cr, First cycle
- [D0022B Maintenance and Production Systems](D0022B%20Maintenance%20and%20Production%20Systems.md) – 7.5 cr, First cycle
- [D0023B IoT-Enabled Condition Monitoring and Maintenance Technologies](D0023B%20IoT-Enabled%20Condition%20Monitoring%20and%20Maintenance%20Technologies.md) – 7.5 cr, First cycle
- [D7004B Operation and Maintenance Engineering](D7004B%20Operation%20and%20Maintenance%20Engineering.md) – 7.5 cr, Second cycle
- [D7007B Maintenance Engineering](D7007B%20Maintenance%20Engineering.md) – 7.5 cr, Second cycle
- [D7008B Condition Monitoring and Condition Based Maintenance](D7008B%20Condition%20Monitoring%20and%20Condition%20Based%20Maintenance.md) – 7.5 cr, Second cycle
- [D7009B Senior Design Project in Maintenance Engineering](D7009B%20Senior%20Design%20Project%20in%20Maintenance%20Engineering.md) – 30 cr, Second cycle
- [D7012B Advanced Reliability Engineering](D7012B%20Advanced%20Reliability%20Engineering.md) – 7.5 cr, Second cycle
- [D7015B Industrial AI and eMaintenance - Part I: Theories & Concepts](D7015B%20Industrial%20AI%20and%20eMaintenance%20-%20Part%20I%20Theories%20%20Concepts.md) – 7.5 cr, Second cycle
- [D7016B Industrial AI and eMaintenance - Part II: Practical Implementation](D7016B%20Industrial%20AI%20and%20eMaintenance%20-%20Part%20II%20Practical%20Implementation.md) – 7.5 cr, Second cycle
- [D7017B Augmented Decision Making](D7017B%20Augmented%20Decision%20Making.md) – 7.5 cr, Second cycle
- [D7018B Industrial AI for Operation and Maintenance](D7018B%20Industrial%20AI%20for%20Operation%20and%20Maintenance.md) – 7.5 cr, Second cycle
- [D7019B Robust infrastructure - Adapting Operation and Maintenance to Climate Change](D7019B%20Robust%20infrastructure%20-%20Adapting%20Operation%20and%20Maintenance%20to%20Climate%20.md) – 7.5 cr, Second cycle
- [D7020B Intelligent Asset Management](D7020B%20Intelligent%20Asset%20Management.md) – 7.5 cr, Second cycle
- [D7021B Reliability and Maintenance Engineering](D7021B%20Reliability%20and%20Maintenance%20Engineering.md) – 7.5 cr, Second cycle
- [D7022B Predictive Analytics and Condition Based Maintenance](D7022B%20Predictive%20Analytics%20and%20Condition%20Based%20Maintenance.md) – 7.5 cr, Second cycle
- [D7023B Intelligent Asset Management and Industrial AI](D7023B%20Intelligent%20Asset%20Management%20and%20Industrial%20AI.md) – 3 cr, Second cycle
- [U0003B Introduction to Operation and Maintenance Engineering](U0003B%20Introduction%20to%20Operation%20and%20Maintenance%20Engineering.md) – 7.5 cr, First cycle
- [U0004B Maintenance Strategy](U0004B%20Maintenance%20Strategy.md) – 7.5 cr, First cycle
- [U0005B Life Cycle Cost Analysis](U0005B%20Life%20Cycle%20Cost%20Analysis.md) – 7.5 cr, First cycle
- [U0006B Condition Based Maintenance](U0006B%20Condition%20Based%20Maintenance.md) – 7.5 cr, First cycle
- [X0009B Degree project in Maintenance Engineering, Bachelor of Science in Engineering](X0009B%20Degree%20project%20in%20Maintenance%20Engineering%20Bachelor%20of%20Science%20in%20Engin.md) – 15 cr, First cycle
- [X7013B Degree Project in Maintenance Engineering, master](X7013B%20Degree%20Project%20in%20Maintenance%20Engineering%20master.md) – 30 cr, Second cycle

### Geovetenskap (20)

- [L0041K Quaternary Geology](L0041K%20Quaternary%20Geology.md) – 7.5 cr, First cycle
- [L0047K Environmental geochemistry](L0047K%20Environmental%20geochemistry.md) – 7.5 cr, First cycle
- [L0048K Climate Change, Principles and Processes](L0048K%20Climate%20Change%20Principles%20and%20Processes.md) – 7.5 cr, First cycle
- [L0049K Sustainable Resource Engineering 1](L0049K%20Sustainable%20Resource%20Engineering%201.md) – 15 cr, First cycle
- [L0050K Geochemistry](L0050K%20Geochemistry.md) – 7.5 cr, First cycle
- [L0051K Project Course in Mineral Resources](L0051K%20Project%20Course%20in%20Mineral%20Resources.md) – 15 cr, First cycle
- [L7003K Senior Design Project in Applied Geology](L7003K%20Senior%20Design%20Project%20in%20Applied%20Geology.md) – 15 cr, Second cycle
- [L7021K Freshwater Geochemistry](L7021K%20Freshwater%20Geochemistry.md) – 7.5 cr, Second cycle
- [L7022K Senior Design Project in Applied Geology](L7022K%20Senior%20Design%20Project%20in%20Applied%20Geology.md) – 7.5 cr, Second cycle
- [L7027K Hydrogeochemistry](L7027K%20Hydrogeochemistry.md) – 7.5 cr, Second cycle
- [O0007K Structural Geology](O0007K%20Structural%20Geology.md) – 7.5 cr, First cycle
- [O0035K Geology, basic course](O0035K%20Geology%20basic%20course.md) – 7.5 cr, First cycle
- [O0036K Mineralogy](O0036K%20Mineralogy.md) – 7.5 cr, First cycle
- [O7029K Applied Structural Geology](O7029K%20Applied%20Structural%20Geology.md) – 7.5 cr, Second cycle
- [X0001K Degree Project in Natural Resources Engineering, Bachelor](X0001K%20Degree%20Project%20in%20Natural%20Resources%20Engineering%20Bachelor.md) – 15 cr, First cycle
- [X0004K Degree Project in Mineral Resource Engineering, Bachelor](X0004K%20Degree%20Project%20in%20Mineral%20Resource%20Engineering%20Bachelor.md) – 15 cr, First cycle
- [X7001K Degree project in Exploration and Environmental Engineering, Master](X7001K%20Degree%20project%20in%20Exploration%20and%20Environmental%20Engineering%20Master.md) – 30 cr, Second cycle
- [X7004K Degree project in Natural Resources Engineering, specialization Ore and Minerals, Master of Science in Engineering](X7004K%20Degree%20project%20in%20Natural%20Resources%20Engineering%20specialization%20Ore%20and.md) – 30 cr, Second cycle
- [X7015K Degree Project in Exploration Geosciences, Master](X7015K%20Degree%20Project%20in%20Exploration%20Geosciences%20Master.md) – 30 cr, Second cycle
- [X7016K Degree Project in Applied Environmental Geochemistry, master](X7016K%20Degree%20Project%20in%20Applied%20Environmental%20Geochemistry%20master.md) – 30 cr, Second cycle

### Arkitektur (19)

- [C0024B Society's Planning for Hazards](C0024B%20Societys%20Planning%20for%20Hazards.md) – 7.5 cr, First cycle
- [C0025B Society's Planning for Hazards](C0025B%20Societys%20Planning%20for%20Hazards.md) – 7.5 cr, First cycle
- [C7002B Sustainable urban development](C7002B%20Sustainable%20urban%20development.md) – 7.5 cr, Second cycle
- [F0018B Architectural History - A Modern Metropolis and its History - A Fieldtrip to Paris](F0018B%20Architectural%20History%20-%20A%20Modern%20Metropolis%20and%20its%20History%20-%20A%20Fieldt.md) – 7.5 cr, First cycle
- [F0019B History of Architecture](F0019B%20History%20of%20Architecture.md) – 7.5 cr, First cycle
- [F0020B Design and Function](F0020B%20Design%20and%20Function.md) – 7.5 cr, First cycle
- [F0021B Urban Design](F0021B%20Urban%20Design.md) – 7.5 cr, First cycle
- [F0022B Design and Function](F0022B%20Design%20and%20Function.md) – 7.5 cr, First cycle
- [F7001B Planning methods](F7001B%20Planning%20methods.md) – 7.5 cr, Second cycle
- [F7003B Urban Morphology](F7003B%20Urban%20Morphology.md) – 7.5 cr, Second cycle
- [F7007B Architectural Building Planning](F7007B%20Architectural%20Building%20Planning.md) – 7.5 cr, Second cycle
- [F7008B Architectural Building Programming](F7008B%20Architectural%20Building%20Programming.md) – 7.5 cr, Second cycle
- [F7014B Architecture - Development](F7014B%20Architecture%20-%20Development.md) – 7.5 cr, Second cycle
- [F7016B Detailed Planning](F7016B%20Detailed%20Planning.md) – 7.5 cr, Second cycle
- [F7017B Urban Spaces](F7017B%20Urban%20Spaces.md) – 7.5 cr, Second cycle
- [P0016A Residential satisfaction](P0016A%20Residential%20satisfaction.md) – 7.5 cr, First cycle
- [X0006B Degree Project in Architectural Engineering, Bachelor](X0006B%20Degree%20Project%20in%20Architectural%20Engineering%20Bachelor.md) – 15 cr, First cycle
- [X7005B Degree project in Architectural Engineering, specialization Building Design, Master of Science in Engineering](X7005B%20Degree%20project%20in%20Architectural%20Engineering%20specialization%20Building%20De.md) – 30 cr, Second cycle
- [X7008B Degree project in Architectural Engineering, specialization Urban Design, Master of Science in Engineering](X7008B%20Degree%20project%20in%20Architectural%20Engineering%20specialization%20Urban%20Desig.md) – 30 cr, Second cycle

### Brandteknik (14)

- [S0005B Project course in fire engineering](S0005B%20Project%20course%20in%20fire%20engineering.md) – 7.5 cr, First cycle
- [S0006B Analysis and design of fire loading in buildings](S0006B%20Analysis%20and%20design%20of%20fire%20loading%20in%20buildings.md) – 7.5 cr, First cycle
- [S0010B Structural Design and Fire](S0010B%20Structural%20Design%20and%20Fire.md) – 7.5 cr, First cycle
- [S0011B Fire Physics](S0011B%20Fire%20Physics.md) – 7.5 cr, First cycle
- [S7002B Fire dynamics II](S7002B%20Fire%20dynamics%20II.md) – 7.5 cr, Second cycle
- [S7008B Applied Fire Dynamics](S7008B%20Applied%20Fire%20Dynamics.md) – 7.5 cr, Second cycle
- [S7013B Fire Exposed Structures](S7013B%20Fire%20Exposed%20Structures.md) – 15 cr, Second cycle
- [S7014B Fire Dynamics](S7014B%20Fire%20Dynamics.md) – 7.5 cr, Second cycle
- [S7015B Fire Modeling](S7015B%20Fire%20Modeling.md) – 7.5 cr, Second cycle
- [S7016B Project Course in Fire Technology](S7016B%20Project%20Course%20in%20Fire%20Technology.md) – 15 cr, Second cycle
- [S7017B Project Course in Fire Technology](S7017B%20Project%20Course%20in%20Fire%20Technology.md) – 30 cr, Second cycle
- [S7018B Applied Fire Engineering](S7018B%20Applied%20Fire%20Engineering.md) – 7.5 cr, Second cycle
- [S7021B Hydrogen Jet Flames and Hydrogen Explosions](S7021B%20Hydrogen%20Jet%20Flames%20and%20Hydrogen%20Explosions.md) – 1.5 cr, Second cycle
- [X7014B Degree project in Civil Engineering, specialization Structural and Fire Engineering, Master of Science in Engineering](X7014B%20Degree%20project%20in%20Civil%20Engineering%20specialization%20Structural%20and%20Fire.md) – 30 cr, Second cycle

### Byggproduktion (13)

- [P0001B Construction Management](P0001B%20Construction%20Management.md) – 7.5 cr, First cycle
- [P0004B Construction management A- tender cost estimation](P0004B%20Construction%20management%20A-%20tender%20cost%20estimation.md) – 7.5 cr, First cycle
- [P0005B Construction management B- Construction Planning](P0005B%20Construction%20management%20B-%20Construction%20Planning.md) – 7.5 cr, First cycle
- [P0007B Project management](P0007B%20Project%20management.md) – 7.5 cr, First cycle
- [P0012B Engineering Design](P0012B%20Engineering%20Design.md) – 7.5 cr, First cycle
- [P7006B Virtual Construction](P7006B%20Virtual%20Construction.md) – 7.5 cr, Second cycle
- [P7014B Construction Supply Chain Management](P7014B%20Construction%20Supply%20Chain%20Management.md) – 7.5 cr, Second cycle
- [U0002B Industrialized Building](U0002B%20Industrialized%20Building.md) – 7.5 cr, First cycle
- [U0012B Lean Construction Essentials](U0012B%20Lean%20Construction%20Essentials.md) – 1.5 cr, First cycle
- [W0009B BIM for visualisation and VR](W0009B%20BIM%20for%20visualisation%20and%20VR.md) – 7.5 cr, First cycle
- [W7011B The Building as a System](W7011B%20The%20Building%20as%20a%20System.md) – 7.5 cr, Second cycle
- [Y0010B Civil Engineering, Practical Studies](Y0010B%20Civil%20Engineering%20Practical%20Studies.md) – 15 cr, First cycle
- [Y0011B Final Year Project, University Diploma](Y0011B%20Final%20Year%20Project%20University%20Diploma.md) – 7.5 cr, First cycle

### Berg- och mineralteknik (12)

- [T0024B Rock mechanics in field](T0024B%20Rock%20mechanics%20in%20field.md) – 7.5 cr, First cycle
- [T0029B Soil and Rock as a Construction Material](T0029B%20Soil%20and%20Rock%20as%20a%20Construction%20Material.md) – 7.5 cr, First cycle
- [T0030B Sustainable Resource Engineering 2](T0030B%20Sustainable%20Resource%20Engineering%202.md) – 15 cr, First cycle
- [T0031B Sustainable Mining Methods](T0031B%20Sustainable%20Mining%20Methods.md) – 7.5 cr, First cycle
- [T0032B Sustainable Mining and Tunneling](T0032B%20Sustainable%20Mining%20and%20Tunneling.md) – 7.5 cr, First cycle
- [T0033B Practical Rock Engineering](T0033B%20Practical%20Rock%20Engineering.md) – 7.5 cr, First cycle
- [T7001B Fundamentals of Rock Mechanics](T7001B%20Fundamentals%20of%20Rock%20Mechanics.md) – 7.5 cr, Second cycle
- [T7002B Design of Rock Constructions](T7002B%20Design%20of%20Rock%20Constructions.md) – 7.5 cr, Second cycle
- [T7006B Applied Blasting](T7006B%20Applied%20Blasting.md) – 7.5 cr, Second cycle
- [T7020B Applied Rock Mechanics](T7020B%20Applied%20Rock%20Mechanics.md) – 7.5 cr, Second cycle
- [T7023B Tunneling](T7023B%20Tunneling.md) – 7.5 cr, Second cycle
- [T7026B Mine Design and Mining Economy](T7026B%20Mine%20Design%20and%20Mining%20Economy.md) – 7.5 cr, Second cycle

### Geoteknik (12)

- [G0003B Soil Mechanics](G0003B%20Soil%20Mechanics.md) – 7.5 cr, First cycle
- [G0004B Geomechanics](G0004B%20Geomechanics.md) – 7.5 cr, First cycle
- [G0017B Snow and Ice](G0017B%20Snow%20and%20Ice.md) – 7.5 cr, First cycle
- [G7002B Senior Design Project in Soil Mechanics and Foundation Eng](G7002B%20Senior%20Design%20Project%20in%20Soil%20Mechanics%20and%20Foundation%20Eng.md) – 7.5 cr, Second cycle
- [G7003B Environmental Geotechnics](G7003B%20Environmental%20Geotechnics.md) – 7.5 cr, Second cycle
- [G7004B Dam II - Dam and Dam Safety](G7004B%20Dam%20II%20-%20Dam%20and%20Dam%20Safety.md) – 7.5 cr, Second cycle
- [G7006B Foundation Engineering](G7006B%20Foundation%20Engineering.md) – 7.5 cr, Second cycle
- [G7008B Soil Mechanics, Advanced Course](G7008B%20Soil%20Mechanics%20Advanced%20Course.md) – 7.5 cr, Second cycle
- [G7010B Soil modelling with the finite element program PLAXIS](G7010B%20Soil%20modelling%20with%20the%20finite%20element%20program%20PLAXIS.md) – 7.5 cr, Second cycle
- [G7013B Natural Energy Sources](G7013B%20Natural%20Energy%20Sources.md) – 7.5 cr, Second cycle
- [G7014B Senior Design Project in Soil Mechanics](G7014B%20Senior%20Design%20Project%20in%20Soil%20Mechanics.md) – 30 cr, Second cycle
- [G7015B Soil Dynamics and Geotechnical Natural Hazards](G7015B%20Soil%20Dynamics%20and%20Geotechnical%20Natural%20Hazards.md) – 7.5 cr, Second cycle

### Konstruktionsteknik (11)

- [B0002B Structural engineering](B0002B%20Structural%20engineering.md) – 7.5 cr, First cycle
- [B7003B Structural Mechanics II](B7003B%20Structural%20Mechanics%20II.md) – 7.5 cr, Second cycle
- [B7004B Structural Mechanics I](B7004B%20Structural%20Mechanics%20I.md) – 7.5 cr, Second cycle
- [K0004B Concrete Technology](K0004B%20Concrete%20Technology.md) – 7.5 cr, First cycle
- [K0016B Landscape architecture](K0016B%20Landscape%20architecture.md) – 7.5 cr, First cycle
- [K7015B Steel and Timber Structures](K7015B%20Steel%20and%20Timber%20Structures.md) – 7.5 cr, Second cycle
- [K7016B Industrial Buildings](K7016B%20Industrial%20Buildings.md) – 7.5 cr, Second cycle
- [K7017B Special Assignment in Structural Engineering](K7017B%20Special%20Assignment%20in%20Structural%20Engineering.md) – 7.5 cr, Second cycle
- [K7020B Steel Structures](K7020B%20Steel%20Structures.md) – 7.5 cr, Second cycle
- [K7021B Timber Structures](K7021B%20Timber%20Structures.md) – 7.5 cr, Second cycle
- [K7022B Structural Design of Foundations](K7022B%20Structural%20Design%20of%20Foundations.md) – 7.5 cr, Second cycle

### Miljöteknik (11)

- [A0013B Waste Science and Technology](A0013B%20Waste%20Science%20and%20Technology.md) – 7.5 cr, First cycle
- [A7001B Landfill Technology](A7001B%20Landfill%20Technology.md) – 7.5 cr, Second cycle
- [A7005B Environmental Engineering Microbiology](A7005B%20Environmental%20Engineering%20Microbiology.md) – 7.5 cr, Second cycle
- [A7007B Senior design projekt in Waste Science, advanced](A7007B%20Senior%20design%20projekt%20in%20Waste%20Science%20advanced.md) – 7.5 cr, Second cycle
- [A7008B Senior design projekt in Waste Science, advanced](A7008B%20Senior%20design%20projekt%20in%20Waste%20Science%20advanced.md) – 15 cr, Second cycle
- [A7009B Senior design projekt in Waste Science, advanced](A7009B%20Senior%20design%20projekt%20in%20Waste%20Science%20advanced.md) – 30 cr, Second cycle
- [A7011B Environmental Pollution and Treatment](A7011B%20Environmental%20Pollution%20and%20Treatment.md) – 7.5 cr, Second cycle
- [L7025K Environmental sampling and evaluation](L7025K%20Environmental%20sampling%20and%20evaluation.md) – 7.5 cr, Second cycle
- [L7026K Sampling and Evaluation of Environmental Data](L7026K%20Sampling%20and%20Evaluation%20of%20Environmental%20Data.md) – 7.5 cr, Second cycle
- [M0002K Environmental Analysis](M0002K%20Environmental%20Analysis.md) – 7.5 cr, First cycle
- [X7002K Degree project in Natural Resources Engineering, specialization Environment and Water, Master of Science in Engineering](X7002K%20Degree%20project%20in%20Natural%20Resources%20Engineering%20specialization%20Environ.md) – 30 cr, Second cycle

### Kemiteknik (10)

- [B7007K Senior Design Project in Biochemical and Chemical Engineering](B7007K%20Senior%20Design%20Project%20in%20Biochemical%20and%20Chemical%20Engineering.md) – 15 cr, Second cycle
- [K0024K Sustainable Process and Chemical Engineering](K0024K%20Sustainable%20Process%20and%20Chemical%20Engineering.md) – 7.5 cr, First cycle
- [K7007K Internship](K7007K%20Internship.md) – 30 cr, Second cycle
- [M0004K Surfaces and Colloids](M0004K%20Surfaces%20and%20Colloids.md) – 7.5 cr, First cycle
- [T0007K Chemical Process Technology](T0007K%20Chemical%20Process%20Technology.md) – 7.5 cr, First cycle
- [U7001K Geometallurgy](U7001K%20Geometallurgy.md) – 7.5 cr, Second cycle
- [X0002K Degree Project in Sustainable Process Engineering, Bachelor](X0002K%20Degree%20Project%20in%20Sustainable%20Process%20Engineering%20Bachelor.md) – 15 cr, First cycle
- [X7005K Degree project in Sustainable Process Engineering, spec Mineral and Metal Winning, Master of Science in Engineering](X7005K%20Degree%20project%20in%20Sustainable%20Process%20Engineering%20spec%20Mineral%20and%20Met.md) – 30 cr, Second cycle
- [X7011K Master Degree project, Sustainable Process & Chemical Engineering, specialization Minerals & Metallurgical Engineering](X7011K%20Master%20Degree%20project%20Sustainable%20Process%20%20Chemical%20Engineering%20specia.md) – 30 cr, Second cycle
- [X7012K Master Degree project, Sustainable Process and Chemical Engineering, specialization Chemical and Bioprocess Engineering](X7012K%20Master%20Degree%20project%20Sustainable%20Process%20and%20Chemical%20Engineering%20spe.md) – 30 cr, Second cycle

### Geografisk informationsteknologi (9)

- [L0002B Basic Programming](L0002B%20Basic%20Programming.md) – 7.5 cr, First cycle
- [L0003B Basic Course in Database Systems](L0003B%20Basic%20Course%20in%20Database%20Systems.md) – 7.5 cr, First cycle
- [L0005B ArcGIS](L0005B%20ArcGIS.md) – 7.5 cr, First cycle
- [L0008B Cartographic Visualization](L0008B%20Cartographic%20Visualization.md) – 7.5 cr, First cycle
- [L0010B Spatial Analysis](L0010B%20Spatial%20Analysis.md) – 7.5 cr, First cycle
- [L0021B ArcGIS Pro](L0021B%20ArcGIS%20Pro.md) – 7.5 cr, First cycle
- [L0022B Introduction to Python with a focus on Geographic Information Systems (GIS)](L0022B%20Introduction%20to%20Python%20with%20a%20focus%20on%20Geographic%20Information%20Systems%20.md) – 7.5 cr, First cycle
- [L0023B Introduction to QGIS](L0023B%20Introduction%20to%20QGIS.md) – 7.5 cr, First cycle
- [Y0003B Basic surveying](Y0003B%20Basic%20surveying.md) – 7.5 cr, First cycle

### VA-teknik (9)

- [V0012B Applied hydralics](V0012B%20Applied%20hydralics.md) – 7.5 cr, First cycle
- [V0016B Urban Water systems](V0016B%20Urban%20Water%20systems.md) – 7.5 cr, First cycle
- [V0017B Natural Water Transport Processes](V0017B%20Natural%20Water%20Transport%20Processes.md) – 7.5 cr, First cycle
- [V7002B Urban Stormwater Management](V7002B%20Urban%20Stormwater%20Management.md) – 7.5 cr, Second cycle
- [V7010B Senior design project in Urban - water](V7010B%20Senior%20design%20project%20in%20Urban%20-%20water.md) – 15 cr, Second cycle
- [V7013B Resource-oriented Water and Sanitation Systems](V7013B%20Resource-oriented%20Water%20and%20Sanitation%20Systems.md) – 7.5 cr, Second cycle
- [V7014B Senior Design project in Sanitary Engineering](V7014B%20Senior%20Design%20project%20in%20Sanitary%20Engineering.md) – 30 cr, Second cycle
- [V7015B Senior Design Project in Urban Water Engineering](V7015B%20Senior%20Design%20Project%20in%20Urban%20Water%20Engineering.md) – 7.5 cr, Second cycle
- [V7016B Senior Design Project in Urban Water Engineering](V7016B%20Senior%20Design%20Project%20in%20Urban%20Water%20Engineering.md) – 15 cr, Second cycle

### Mineralteknik (8)

- [M7001K Simulation of Mineral Processing](M7001K%20Simulation%20of%20Mineral%20Processing.md) – 7.5 cr, Second cycle
- [M7003K Mineral Processing](M7003K%20Mineral%20Processing.md) – 7.5 cr, Second cycle
- [M7007K Process mineralogy](M7007K%20Process%20mineralogy.md) – 7.5 cr, Second cycle
- [M7011K Technical-Economic Evaluation of Mineral Industry Projects](M7011K%20Technical-Economic%20Evaluation%20of%20Mineral%20Industry%20Projects.md) – 7.5 cr, Second cycle
- [M7012K Mineral Resource Disclosure and Permitting Processes](M7012K%20Mineral%20Resource%20Disclosure%20and%20Permitting%20Processes.md) – 7.5 cr, Second cycle
- [X7008K Degree project in Georesources Engineering, master](X7008K%20Degree%20project%20in%20Georesources%20Engineering%20master.md) – 30 cr, Second cycle
- [X7013K Degree project in Arctic Mineral Resources, specialization Mineral Entrepreneurship, master](X7013K%20Degree%20project%20in%20Arctic%20Mineral%20Resources%20specialization%20Mineral%20Entr.md) – 30 cr, Second cycle
- [X7014K Degree project in Arctic Mineral Resources, specialization Mineral Resource Management, master](X7014K%20Degree%20project%20in%20Arctic%20Mineral%20Resources%20specialization%20Mineral%20Reso.md) – 30 cr, Second cycle

### Processmetallurgi (8)

- [M7006K Geometallurgy](M7006K%20Geometallurgy.md) – 7.5 cr, Second cycle
- [P0006K High Temperature Processes](P0006K%20High%20Temperature%20Processes.md) – 7.5 cr, First cycle
- [P0008K Mineral and Metallurgical Process Technology](P0008K%20Mineral%20and%20Metallurgical%20Process%20Technology.md) – 7.5 cr, First cycle
- [P7005K Hydrometallurgy](P7005K%20Hydrometallurgy.md) – 7.5 cr, Second cycle
- [P7006K High Temperature Materials](P7006K%20High%20Temperature%20Materials.md) – 7.5 cr, Second cycle
- [P7007K Senior Design Project in Processmetallurgy](P7007K%20Senior%20Design%20Project%20in%20Processmetallurgy.md) – 7.5 cr, Second cycle
- [P7009K Design for Sustainable Processing](P7009K%20Design%20for%20Sustainable%20Processing.md) – 7.5 cr, Second cycle
- [P7012K Design for Sustainable Processing](P7012K%20Design%20for%20Sustainable%20Processing.md) – 3 cr, Second cycle

### Kemi (7)

- [B0007K Organic Chemistry and Biochemistry](B0007K%20Organic%20Chemistry%20and%20Biochemistry.md) – 7.5 cr, First cycle
- [K0006K Water Chemistry](K0006K%20Water%20Chemistry.md) – 7.5 cr, First cycle
- [K0010K Physical Chemistry](K0010K%20Physical%20Chemistry.md) – 7.5 cr, First cycle
- [K0011K Inorganic Chemistry](K0011K%20Inorganic%20Chemistry.md) – 7.5 cr, First cycle
- [K0025K Chemistry for Sustainable Development](K0025K%20Chemistry%20for%20Sustainable%20Development.md) – 7.5 cr, First cycle
- [K7006K Batteries for a sustainable society: from raw materials to battery cells](K7006K%20Batteries%20for%20a%20sustainable%20society%20from%20raw%20materials%20to%20battery%20cell.md) – 7.5 cr, Second cycle
- [KX002K Chemistry G1, Highschool Supplementary Course](KX002K%20Chemistry%20G1%20Highschool%20Supplementary%20Course.md) – 7.5 cr, Pre-university level

### Malmgeologi (6)

- [O0008K Petrology](O0008K%20Petrology.md) – 7.5 cr, First cycle
- [O0038K Economic Geology](O0038K%20Economic%20Geology.md) – 7.5 cr, First cycle
- [O0043K Structures and Deformation](O0043K%20Structures%20and%20Deformation.md) – 7.5 cr, First cycle
- [O7022K Mining Geology](O7022K%20Mining%20Geology.md) – 7.5 cr, Second cycle
- [O7023K Applied Field Exploration](O7023K%20Applied%20Field%20Exploration.md) – 3 cr, Second cycle
- [O7028K Geodata - from analysis to model](O7028K%20Geodata%20-%20from%20analysis%20to%20model.md) – 7.5 cr, Second cycle

### Kemisk teknologi (5)

- [T7004K Industrial Catalysis](T7004K%20Industrial%20Catalysis.md) – 7.5 cr, Second cycle
- [T7005K Cellulose and Paper Technology](T7005K%20Cellulose%20and%20Paper%20Technology.md) – 7.5 cr, Second cycle
- [T7006K Senior Design Project in Chemical Technology](T7006K%20Senior%20Design%20Project%20in%20Chemical%20Technology.md) – 7.5 cr, Second cycle
- [T7009K Advanced Chemical Reaction Engineering](T7009K%20Advanced%20Chemical%20Reaction%20Engineering.md) – 7.5 cr, Second cycle
- [T7010K Chemical Reaction Engineering](T7010K%20Chemical%20Reaction%20Engineering.md) – 7.5 cr, Second cycle

### Geofysik (4)

- [O0001K Applied Geophysics, basic course](O0001K%20Applied%20Geophysics%20basic%20course.md) – 7.5 cr, First cycle
- [O7001K Senior Design Project in Applied Geophysics](O7001K%20Senior%20Design%20Project%20in%20Applied%20Geophysics.md) – 7.5 cr, Second cycle
- [O7002K Senior Design Project in Applied Geophysics](O7002K%20Senior%20Design%20Project%20in%20Applied%20Geophysics.md) – 15 cr, Second cycle
- [O7003K Senior Design Project in Applied Geophysics](O7003K%20Senior%20Design%20Project%20in%20Applied%20Geophysics.md) – 30 cr, Second cycle

### Kemisk apparatteknik (3)

- [B7001K Design of Biochemical/Chemical Process Plants](B7001K%20Design%20of%20BiochemicalChemical%20Process%20Plants.md) – 7.5 cr, Second cycle
- [B7003K Bioprocess Engineering](B7003K%20Bioprocess%20Engineering.md) – 7.5 cr, Second cycle
- [B7005K Senior Design Project in Biochemical and Chemical Engineering](B7005K%20Senior%20Design%20Project%20in%20Biochemical%20and%20Chemical%20Engineering.md) – 7.5 cr, Second cycle

### Naturresursteknik (2)

- [L0046K Natural Resources Engingeering](L0046K%20Natural%20Resources%20Engingeering.md) – 7.5 cr, First cycle
- [O0040K Internship in natural resources engineering](O0040K%20Internship%20in%20natural%20resources%20engineering.md) – 15 cr, First cycle

### Teknisk akustik (2)

- [L7001A Experimental Acoustics and Dynamics](L7001A%20Experimental%20Acoustics%20and%20Dynamics.md) – 7.5 cr, Second cycle
- [Z7001B Architectural acoustics](Z7001B%20Architectural%20acoustics.md) – 7.5 cr, Second cycle

### Hydrologi (1)

- [G7012B Geohydrology](G7012B%20Geohydrology.md) – 7.5 cr, Second cycle

### Samhällsbyggnadsteknik (1)

- [T0034B Hydraulics and Rock Mechanics](T0034B%20Hydraulics%20and%20Rock%20Mechanics.md) – 7.5 cr, First cycle

### Trafikteknik (1)

- [C7001B Traffic in the city](C7001B%20Traffic%20in%20the%20city.md) – 7.5 cr, Second cycle

### Träbyggnad (1)

- [W7003B Virtual design](W7003B%20Virtual%20design.md) – 7.5 cr, Second cycle
