---
course_code: "G7003B"
title: "Environmental Geotechnics"
credits: "7.5"
title_sv: "Miljögeoteknik, förorenad mark"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7003B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7003b-miljogeoteknik-fororenad-mark"
---

# Environmental Geotechnics (G7003B)

## Main field of study

., Civil Engineering

## Entry requirements

Basic knowledge in Soíl mechanics.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, the student should be able to:

1. conduct remedial investigation and feasibility studies of contaminated soil

2. make risk assessment and propose suitable methods for remediation of contaminated soil

3. calculate contaminant transport in soils.

4. describe different liner material and liner system

5. describe how waste- or by-products from the industry can be used in different applications

6. describe environmental and geotechnical properties of sulphide soil

7. describe problems related to radon

8. describe legal handling of contaminated soil.

## Contents

- Engineering geology: Quaternary formations and characteristic soil profiles with different soil types.

- Remedial investigation: How to conduct monitoring of soil and water in a remedial investigation. Risk assessment.

- Soil chemistry: Dispersion of organic and inorganic pollutants in the ground. Properties of filtering and lining in the ground, and how different factors can influence these.

- Liner technique: Clays (different clay minerals), geosynthetic clay liners, geomembranes and liner design.

- Soil remediation: Case studies with contaminated soil and different remediation techniques.

- Waste- and by-products: Properties and applications for different waste- and by-products (ashes, tire chips, etc.)

- Radon: What does it mean with radon in a ground? How to do an investigation if radon is present in an old and new construction and how to avoid problems with radon.

- Laws: Legal handling of contaminated soil.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The teaching is given in form of lecturers, project work and laboratory work. The lectures are given in physical classrooms and lecture materials are published beforehand on the study plant form. Project work and laboratory work are performed in groups of max. 4 students. The project work is divided into two steps where risk assessment on a contaminated land is to be conducted and remedial method is to be proposed. Two laboratory activities are included in laboratory work where liner material will be examined and remediation techniques for diesel contaminated soil (lab 1) and water (lab 2) will be investigated. To practice written and presentation skills, both project work and laboratory work are presented in a written report. The project work is also presented orally.

The students are expected to attend all the lectures if possible, and are mandatorily required to conduct project work and laboratory work. Group meetings are expected among the students to practice collaboration and communication skills.

A guest lecture is included in the course where actual soil remediation projects are presented.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through written exam, project work and laboratory work. Project work and laboratory are presented in form of written report. Project work is also to be presented orally. All activities included in project work and laboratory work are compulsory to be completed. Written exam, project work and laboratory work must all be completed for a course grade. Grading scale is G/U 3 4 5 which is determined by the grade of written exam.

All intended learning outcomes are to be assessed through written exam. Intended learning outcome 1, 2 and 3 are also assessed through project work. Intended learning outcome 4 is also assessed by laboratory work.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course G7003B is equal to ABG107

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 3 | Mandatory | A07 |  |
| 0002 | Project work | U G# | 3 | Mandatory | A07 |  |
| 0003 | Laboratory work | U G# | 1.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31-13 and is valid from H-07.
