---
course_code: "Y0010B"
title: "Civil Engineering, Practical Studies"
credits: "15"
title_sv: "Bygg och anläggning VFU"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "UG"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=Y0010B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=Y0010B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/y00/y0010b-bygg-och-anlaggning-vfu"
---

# Civil Engineering, Practical Studies (Y0010B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and 75 hp initiated studies at the university diploma programme in Work Management in Civil Engineering

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course participants should be able to…

Knowledge and understanding

Describe the activities and the tasks performed at the workplace.

Describe how local work environment work should be conducted at the workplace.

Describe different gender equality perspectives in the workplace.

Competence and skills

Participate in the daily activities of the workplace and perform associated tasks.

Evaluate how local work environment work is conducted at the workplace.

Judgement and approach

Evaluate and describe the workplace from a gender equality perspective.

## Contents

The practical studies (VFU) is carried out at a company, municipality, authority, or similar workplace related to the education. The following course elements are included:

Search for an individual VFU place.

Plan VFU work.

Participate in the daily work of the workplace in a professional position.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of independent studies with the support of a supervisor / examiner from the university and an external supervisor at the workplace. The implementation is designed in connection with the planning of the practical studies.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is examined as follows:

Project plan.

Certificate of completed VFU.

Written report.

Grading takes place according to grade scale G U. All included examination parts must be completed for the final grade on the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course Y0010B is equal to Y0007B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Assignment report | UG | 6 | Mandatory | S27 |  |
| 0004 | Work placement | UG | 9 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-02-14
