---
course_code: "P0007B"
title: "Project management"
credits: "7.5"
title_sv: "Byggprojektledning"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0007B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0007B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p00/p0007b-byggprojektledning"
---

# Project management (P0007B)

## Main field of study

Architecture, ., Civil Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

Knowledge and understanding

After completing the course, the student should be able to draw from research and experience-based knowledge and applications in basic project management literature and: (1) identify and, with correct use of terminology elaborate on some concepts, models, methods and planning tools that are commonly used in project management; (2) describe some ways and principles for organizing, managing and leading projects including reflections regarding different construction project phases/conditions/limitations, impacts on construction project progress and results and, potentially subsequent knowledge/skills requirements for construction project managers/project employees; (3) describe key functions in projects based on some typical roles, tasks, areas of responsibility and relations.

Competence and skills

After completing the course, the student should be able to: (4) with basic skills and together with others in a project organization use such knowledge as specified in goals 1-3 to:

- plan, implement, follow up, and hand over a project work within specified limitations, as well as reflect on the significance of the selected applications for progress and results.

- in the very early phase of a construction project; contribute to the development of, and critical reflection on, goals and related data.

Judgement and approach

After completing the course, the student should be able to: (5) reflect based on basic project management literature and project management experiences on the student’s need for knowledge and competence development for roles as project manager/project employee.

## Contents

Basic project management concepts, the project-management “tool-box” and common project practices, with examples of use and applications in construction; focussing in particular on early phases and construction project management from a client perspective.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The teaching is in Swedish and consists of two main parts. During part 1, students independently develop project management knowledge and understanding with a focus on goals 1-3, supported by course literature, reference literature and lectures. In part 2, the students test, practice and reflect on the application of the course material in a project assignment. The assignment is carried out in groups and with the support of supervisors and peer-review assignments.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Two examining modules are included in the course, and all examination is in Swedish. Exam 0003 (U G #) is examined through a written individual test “dugga” (U G #) and through a written and oral “peer-review” (U G #). Both of these partial examinations must be approved for a passing (G #) module 0003. Exam 0004 (G U 3 4 5) is examined by a “project work”, and for assessment against grades 4 and 5 a written individual “reflection assignment” is also included. The project work is examined continuously during the course through oral and written reports on project progress as well as on project results. The credit system is described in detail in the study guide that is distributed at the start of the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course P0007B is equal to ABP117, P0010B, P0013B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Individual assignments | U G# | 3 | Mandatory | A07 |  |
| 0004 | Project work | GU345 | 4.5 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Department of Civil and Environmental Engineering 2010-03-10
