---
course_code: "Z7001B"
title: "Architectural acoustics"
credits: "7.5"
title_sv: "Rums- och byggnadsakustik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-11-02"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Teknisk akustik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=Z7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=Z7001B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/z70/z7001b-rums--och-byggnadsakustik"
---

# Architectural acoustics (Z7001B)

## Main field of study

Architecture

## Entry requirements

Acoustics corresponding to the course W0008B Building Physics

## Selection

The selection is based on 30-285 credits

## Course Aim

After the course the student should independently be able to;

- Plan rooms to have appropriate acoustic properties for the intended use of the room

- Evaluate rooms’ acoustic properties to assure correct acoustics

- Calculate/estimate sound insulation of walls

- Measure the sound insulation of walls and floors

- Use software to model and acoustically evaluate room in the design phase

- Dimension vibration insulation

- Work and solve technical problems in-group and present the results in written report

## Contents

The course deals with the following moments, including deeper relations to buildings:

- Fundamental acoustics

- Acoustic planning of residentials concerning indoor and outdoor environment

- Legislation and sound standards for housing

- Measurement techniques and methods regarding sound and vibration

- The physiology and psychology of hearing and hearing damages

- Sound mechanisms – physiological phenomena behind origination and propagation of sound

- Room acoustics – sound field and sound propagation in closed spaces (reverberation time, absorption, reflection, transmission etc.)

- Methods to calculate the sound insulation of walls and floors and building methods to achieve quite environments

•Vibration insulation – theory and calculation procedures to mitigate structural vibrations

- Room acoustic modeling – software to model sound propagation in rooms and/or to model sound insulation between rooms

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course content is presented and covered by lectures, demonstrations, problem solving. Laboratory experiments and project in computer modelling and solved in groups The project may also contain a couple of guest lectures.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Written exam. Written reports regarding laboratory experiments. Written report and/or oral presentation of the project task.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Writen exam | GU345 | 5 | Mandatory | S15 |  |
| 0005 | Laboratory work | UG | 1 | Mandatory | S27 |  |
| 0006 | Projekt work | UG | 1.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-11-02

## Syllabus established

by Eva Gunneriusson 2014-02-12
