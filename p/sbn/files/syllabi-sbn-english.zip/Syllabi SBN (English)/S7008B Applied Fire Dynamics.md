---
course_code: "S7008B"
title: "Applied Fire Dynamics"
credits: "7.5"
title_sv: "Tillämpad branddynamik"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Brandteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7008B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7008B&lasPeriod=214&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/s70/s7008b-tillampad-branddynamik"
---

# Applied Fire Dynamics (S7008B)

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course participants should be able to

- explain and solve problems related to fire behavior of furniture and fittings

- explain and solve problems related to fire testing methods and fire classification of products

- explain and compute exercise related to ignitability, flame spread, and energy release rate

- solve problems with the computer program FDS, Fire Dynamics Simulator

- explain and solve problems within the approval process and project management related to fire safety in buildings

## Contents

Introductory lectures about CFD, Computational Fluid Dynamics, and especially about the FDS-program, its applicability, and how to edit a FDS input file.Explanation of the current building codes and illustration of the fire safety requirements on new buildings. The concept and limitations of performance-based design with regard to fire safety of buildings is discussed and applied from the perspective of the authorities and from the perspective of the user. Fire properties of wood, various plastic materials, mineral wool etc., and their use as surface linings, insulation and other applications in buildings, are included.Fire properties for furniture and fittings is also part of the course, for example upholstery material. Thermal models for ignitability and flame spread is covered, as well as energy release rate and relative importance of parameters such as thermal inertia for the fire development. Also included in the course is smoke production including production of toxic gases. Fire parameters that are used to declare the fire properties of products are included, as well as these parameters’ use and relation to theory of fire dynamics. Finally, the basics of international standardization work in ISO, IMO, and CEN is presented.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

This course includes teaching and learning activities such as lectures, problem solving classes, computer laboration, group assignments, and consultation time with the teacher. During the lectures and problem solving classes in FDS the students shall work in groups and each group shall have access to a laptop computer. The course consists in four assignments: one in material properties, two in FDS, and one in fire safety design and documentation. Each assignment if carried out in groups and reported in a written report as well as in an oral presentation.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course is examined in the way that all four written reports should be approved by the teacher, and the teacher should have confirmed that the student has actively orally presented, and participated in discussions during other groups presentations, during the presentations of all four assignments. Grading of the course is G U. Presence if compulsory at all scheduled events and absence must be compensated by an oral examination in order to ensure that the student has studied what was covered during the missed teaching event.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course S7008B is equal to S7018B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment reports | U G# | 7.5 | Mandatory | S14 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2013-02-15
