---
course_code: "O7003K"
title: "Senior Design Project in Applied Geophysics"
credits: "30"
title_sv: "Projektkurs i tillämpad geofysik"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2018-06-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geofysik"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O7003K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O7003K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o70/o7003k-projektkurs-i-tillampad-geofysik"
---

# Senior Design Project in Applied Geophysics (O7003K)

## Entry requirements

Decided by the examiner depending on type of project.

## Selection

The selection is based on 30-285 credits

## Course Aim

The student shall independantly design, carry out and report a project within the subject.

## Contents

The project theme shall be chosen in cooperation with the examiner and be related to modern research and development.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The student will work independently with guidance.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Written report

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

Transition terms 2500

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Passed oral and written presentation | GU345 | 30 | Mandatory | A07 | Yes |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2018-06-13

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
