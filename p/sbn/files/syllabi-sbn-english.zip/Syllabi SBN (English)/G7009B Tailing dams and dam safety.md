---
course_code: "G7009B"
title: "Tailing dams and dam safety"
credits: "3"
title_sv: "Gruvdammar och dammsäkerhet"
valid: "Spring 2015 Sp 3 - Present"
decision_date: "2014-11-04"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Items/credits Number       Type                                                                 Credits    Grade  0001         Assignment report                                                    3          U G#"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7009B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7009B&lasPeriod=191&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7009b-gruvdammar-och-dammsakerhet"
---

# Tailing dams and dam safety (G7009B)

## Examiner

Sven Knutsson

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Overlap

The course G7009B is equal to ABG133

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Items/credits Number       Type                                                                 Credits    Grade

0001         Assignment report                                                    3          U G#

## Literature

*Literature. Valid from Autumn 2008 Sp 1*

## Last revised

by Eva Gunneriusson 2014-11-04

## Syllabus established

by Eva Gunneriusson 2014-11-04
