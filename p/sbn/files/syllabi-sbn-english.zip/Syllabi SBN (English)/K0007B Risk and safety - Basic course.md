---
course_code: "K0007B"
title: "Risk and safety - Basic course"
credits: "7.5"
title_sv: "Risk och säkerhet - Grundkurs"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2020-02-14"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0007B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0007B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k00/k0007b-risk-och-sakerhet---grundkurs"
---

# Risk and safety - Basic course (K0007B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

The aim of the course is to give an introduction to the area of Risk and Safety. The students shall become familiar with different methods to manage projects with risk in mind. After completing the course module on gender equality, the student should show an understanding of the national gender equality goals, regulations for gender equality in professional life and give examples of the prerequisite for gender equality in professional life.

## Contents

The course is divided into following areas:

- -     Introduction to the area Risk and Safety
- -     Principles of Risk Analysis with case studies and practical examples
- -     Principle of risk management
- -     Fire protection legislation
- -     Gender equality in the workplace

The course consists of lectures, study visits, project group and individual assignments.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The education consists of lectures, seminars, study visit, project work and quizzes. During lectures students will get familiar of different aspects of risk and related issues. Examples are taken from areas dealing with transports, building and construction, process industry, and municipal activities, such as fire fighters and rescue service. Students will practice to carry risk analysis and management as individual assignment and as group assignment. Students will be trained in writing report technics, oral presentation and peer-review.

The course module on gender equality consists of recorded lectures and literature.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

To pass the course following requires, 80% attendance on the course lectures, Project Work must be completed and approved. The project topic should be chosen within the course content. Complete all assignments provided in the course. The course module on gender equality is examined through quizzes.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K0007B is equal to ABKR01

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Project assignments and quizzes | U G# | 5 | Mandatory | A07 |  |
| 0006 | Lectures and study visit | U G# | 2.5 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-02-14

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
