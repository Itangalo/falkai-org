---
course_code: "KX002K"
title: "Chemistry G1, Highschool Supplementary Course"
credits: "7.5"
title_sv: "Kemi G1, gymnasiekomplettering"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "Pre-university level"
grade_scale: "GU345"
subject: "Kemi"
subject_group_scb: "Chemistry"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=KX002K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=KX002K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/kx0/kx002k-kemi-g1-gymnasiekomplettering"
---

# Chemistry G1, Highschool Supplementary Course (KX002K)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Course Aim

After completion of the course, the student should

- Have acquired knowledge and skills which basically corresponds to Kemi 1 for upper secondary school

- Be able to describe and explain basic concepts and theories

- Be able to balance chemical reactions and perform stoichiometric calculations

- Be able to connect properties of matter with different types of chemical bonding

- Have knowledge about applications and importance of chemistry in industry, technological development, everyday life, environment and health.

- Be able to perform, interpret and present experiments

## Contents

The course covers basic chemical concepts, atomic theory, periodic table, chemical bonding, aggregation forms, reaction formulas, stoichiometry, acids and bases, thermochemistry, redox, electrochemistry

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching takes place in the form of lessons and laboratory work in groups. The lessons go through relevant theoretical content with discussions around various questions and practical examples. The laboratory sessions provide opportunity for practical experience of the theory content. The results are reported in the form of written laboratory reports. Attendance at the laboratory sessions is compulsory.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Approved laboratory reports and approved written exam are necessary for passing the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course KX002K is equal to KGK036, KX001K

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

Code         Description                           Grade scale      Fup      Status               From        Title period

0001         Written exam                          GU345            3.2      Mandatory            S15

0002         Written exam                          GU345            3.1      Mandatory            S15

0005         Laboratory work II                    UG               0.6      Mandatory            S27

0006         Laboratory work I                     UG               0.6      Mandatory            S27

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2014-02-04
