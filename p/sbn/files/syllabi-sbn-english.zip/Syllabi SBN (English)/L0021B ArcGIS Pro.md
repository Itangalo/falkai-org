---
course_code: "L0021B"
title: "ArcGIS Pro"
credits: "7.5"
title_sv: "ArcGIS Pro"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Geografisk informationsteknologi"
subject_group_scb: "Geographic Information Technology and Surveying"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0021B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0021B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0021b-arcgis-pro"
---

# ArcGIS Pro (L0021B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

The aim of the course is to give the students ability, with geographical technology, to

- collect, store, analyse and visualize geographical data,

- be familiar with building geographical databases,

- plan and execute fundamental geographic analysis in the software ArcGIS Pro.

## Contents

Introduction to the subject field Geographical Information Systems (GIS)

-ArcGIS Pro Software Concepts and interface

-Practises, including: Layer management Database management Creating and editing data Processing data Workflows Analysis Designing maps

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. All the course material and software can be found on LTU’s Citrix portal. There you can also find more detailed descriptions of the course contents and its realization. There are no pre-recorded lectures, nor are there any mandatory gatherings. The book constitutes the course literature and should be followed according to its instructions.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course aim is examined through assignments that will be completed individually or in groups of two which will be examined throughout the course. Marking of the assignments will be made according to U/G marking scale. All assignments should be completed to receive a final mark. Assignments are available on LTU’s Citrix portal.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

Courses taken through the Internet requires access to some sort of broadband connection.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment reports | U G# | 7.5 | Mandatory | A20 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-02-14
