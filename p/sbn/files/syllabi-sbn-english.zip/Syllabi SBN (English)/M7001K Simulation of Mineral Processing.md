---
course_code: "M7001K"
title: "Simulation of Mineral Processing"
credits: "7.5"
title_sv: "Simulering av mineraltekniska processer"
valid: "Autumn 2026 Sp 1 - Present"
decision_date: "2026-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Mineralteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7001K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7001K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/m70/m7001k-simulering-av-mineraltekniska-processer"
---

# Simulation of Mineral Processing (M7001K)

## Main field of study

Chemical Engineering, Geosciences

## Entry requirements

90 ECTS in Chemical Engineering, including the Mechanical Process Technology course (M0001K), or equivalent. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

The course aims at acquiring the knowledge to conduct simpler computer-assisted simulations of processes for particulate material. After completing the course, participants should be able to:

- Identify situations when simulation techniques may provide a contribution to the understanding of the process,

- Establish the required input data for simulation of mineral processes,

- Construct and confine flowsheets for simulations,

- Report results from simulations,

- Judge if the simulation results are relevant,

- Interpret the result in process technology terms,

- Formulate hypothesis on changes to the process as a result of the simulation.

## Contents

The course covers

Dry processes:

- Models for comminution of hard, crystalline materials

- Models for screening

- Simulation of crusher circuit

Wet comminution:

- Models for comminution in mills with manufactured or autogenous grinding bodies

- Models for classification

- Simulation of grinding circuit

Separation by density

- Models for density separation with manufactured or autogenous media

- Simulation of wet gravity circuit

Separation by surface properties (flotation)

- Simple and advanced models for flotation

- Simulation of flotation circuit

Separation processes based on other physical characteristics

- Simple models for magnetic separation

- Models for thickeners and filters

- Simulation of soil remediation plant

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The teaching consists of lectures, reading notes, quizzes, exercises, assignments, and compulsory seminars.

Lectures are used to present and explain theoretical concepts. Reading notes, provided for each part of the course, summarize key material from the textbook, include references to the simulation program, and help students describe model structures and explain theoretical concepts. Quizzes allow students to test their factual knowledge. Exercises are designed to train students in modeling and simulation procedures.

The assignments, carried out in groups, involve conducting, evaluating, interpreting, and presenting simulation results. Each group must prepare a technically sound presentation of their work and defend it at a joint seminar. An opponent group will write a short evaluation of the presenting group’s seminar and provide an oral critique.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through assignments, quizzes, and seminars that are mandatory. Assignments, quizzes, seminars, and the opposition are each awarded points based on the attained level. Assignments and opposition reports must be delivered in time otherwise there will be a deduction of maximum achievable points. The total points production determines the grand grade of the course, and it is given on the scale 3 4 5.

- For grade 3, the student must be able to list and produce input data, conduct a simulation and present the results.

- For grade 4, the student must be able to evaluate whether the results are relevant, to interpret them in process technology terms and report the results.

- For grade 5, in addition to the above, the student must be able to formulate and motivate suggestions for changes to processes (model parameters) and to report and present the results.

Attendance at the first scheduled lecture and the seminars is mandatory.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course M7001K is equal to KGM005

## Remarks

Compulsory attendance at the first gathering.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Assignments | GU345 | 3.5 | Mandatory | A26 |  |
| 0003 | Seminars | GU345 | 3 | Mandatory | A26 |  |
| 0004 | Quizzes | GU345 | 1 | Mandatory | A26 |  |

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
