---
course_code: "G7002B"
title: "Senior Design Project in Soil Mechanics and Foundation Eng"
credits: "7.5"
title_sv: "Projektkurs i geoteknik, fördjupning"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2023-06-02"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7002B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7002b-projektkurs-i-geoteknik-fordjupning"
---

# Senior Design Project in Soil Mechanics and Foundation Eng (G7002B)

## Entry requirements

At least 60 hp within Civil Engineering, including the course G0003B Soil Mechanics or similar. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2. For exchange students, the examiner makes an individual examination of the qualification depending on the type of project.

## Selection

The selection is based on 30-285 credits

## Course Aim

To provide the students a possibility to deeper studies in a special subject.

## Contents

Outlines för every special case.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. Outlines för every special case.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Judgement of project and project report.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course G7002B is equal to ABG106

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment | U G# | 7.5 | Mandatory | A07 | Yes |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
