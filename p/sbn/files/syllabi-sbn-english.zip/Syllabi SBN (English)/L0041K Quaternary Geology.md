---
course_code: "L0041K"
title: "Quaternary Geology"
credits: "7.5"
title_sv: "Kvartärgeologi"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-01-11"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0041K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0041K&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0041k-kvartargeologi"
---

# Quaternary Geology (L0041K)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Chemical Principles (K0016K), Geology, basic course (O0035K)

## Selection

The selection is based on 1-165 credits.

## Course Aim

Knowledge and understanding

After completing the course participants should be able to:

- briefly describe the geological development during the Quaternary period

- describe and explain growth, mass balance and movement of glaciers

- describe the most important glacial environments, and explain the processes that control deposition of sediments and formation of landforms in these environments

- use vertical geological profiles through Quaternary deposits to describe the geological evolution in an area

Competence and skills

After completing the course participants should be able to:

- describe the Quaternary evolution in northern Sweden by applying basic interpretation of aerial photographs, and by interpreting a soil map

## Contents

This course covers the following topics:

Climate variations during the Quaternary. Glaciers and properties of glacial ice. Glacial erosion, transportation and deposition. Glacial landforms. Fluvial, marine and lacustrine sediments and landforms. Quaternary stratigraphy. Isostatic rebound. Quaternary deposits and landforms in Sweden. Carbon-14 dating. Interpretation of aerial photographs and soil maps.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. This course includes teaching and learning activities in the form of lectures, assignments, and one group assignment. Lectures cover basic theory that is applied in minor assignments during lessons. Basic theory is also applied in the group assignment. The assignments will result in a deeper understanding of the main elements of the course when students actively participate in the learning process. The group assignment will also provide training to work in a group and to write a scientific report. The course also contains a field excursion in the Luleå area.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The ability to describe and give accounts of the basic theory is examined in a written exam (grade 3, 4, 5). The ability to interpret aerial photographs and soil maps, to describe the Quaternary development in northern Sweden, and to write a short scientific report is examined in a mandatory group work by handing in a written report (grade U G). Mandatory excursion (grade U G). All exams included in the module need to be completed for a course grade.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course L0041K is equal to KGL004

## Remarks

The course is given at a basic level, and is included in the Candidate and Civil engineer programme Naturresursteknik. A study guide is available in the Canvas room for the course.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 3.7 | Mandatory | A08 |  |
| 0004 | Project work | UG | 3 | Mandatory | S27 |  |
| 0005 | Excursion | UG | 0.8 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-01-11

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2008-01-22.
