---
course_code: "L0022B"
title: "Introduction to Python with a focus on Geographic Information Systems (GIS)"
credits: "7.5"
title_sv: "Introduktion till Pyhton med inriktning mot Geografiska informationssystem (GIS)"
valid: "Autumn 2025 Sp 1 - Present"
decision_date: "2025-02-13"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Geografisk informationsteknologi"
subject_group_scb: "Geographic Information Technology and Surveying"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0022B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0022b-introduktion-till-python-med-inriktning-mot-geografiska-informationssystem-gis"
---

# Introduction to Python with a focus on Geographic Information Systems (GIS) (L0022B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

Upon completion of the course, students will be able to:

1. Understand how Python syntax and structures are applied for scripting and automating tasks in GIS environments.

2. Apply Python programming techniques to process and analyze both raster and vector data in GIS.

3. Analyze geographical data by writing algorithms to identify patterns, trends, and relationships in spatial datasets.

4. Evaluate the performance and efficiency of various algorithms in solving GIS-related problems.

5. Create custom scripts and algorithms to collect, store, analyze, and present geographic information in response to real-world GIS challenges.

## Contents

The course provides an introduction to basic Python programming, algorithm development, scripting, and other fundamental Python programming concepts related to GIS applications.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. All course materials and software are available through LTU’s Citrix portal, where detailed descriptions of course content and implementation are provided. There are no recorded lectures, nor are there any mandatory in-person sessions. Lectures are provided in text format.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course objectives are assessed through assignments completed individually or in pairs, and are evaluated throughout the course. Assignments are graded on a Pass/Fail (U/G) scale. All assignments must be completed for a final grade. Assignments are accessible via LTU’s Citrix portal.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment reports | U G# | 7.5 | Mandatory | A25 |  |

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
