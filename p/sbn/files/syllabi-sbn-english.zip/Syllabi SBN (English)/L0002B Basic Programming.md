---
course_code: "L0002B"
title: "Basic Programming"
credits: "7.5"
title_sv: "Introduktion till programmering och C#"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2023-02-13"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Geografisk informationsteknologi"
subject_group_scb: "Geographic Information Technology and Surveying"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0002B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0002b-introduktion-till-programmering-och-c"
---

# Basic Programming (L0002B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

After approved course the students shall know how to

- build algorithms for problem solving

- express these algorithms in some pseudo language or graphical formal way of expression.

- apply basics of programming in some representative programming language

- construct simpler, well documented applications.

- be familiar with some methods for integrating and managing maps in applications.

## Contents

- Introduction to programming

- Computer Hardware/Software

- Algorithms

- Program structure and our first program

- Variables and data types

- Input and output

- Arithmetic operations

- Assignment operations and Boolean expressions

- Control statements

- Conditional statements

- Repetition statements

- Classes and methods

- Passing arguments by value and by reference

- Variable scope and duration

- Implementation and debugging

- Arrays

- Strings and characters

- Basic GUI

- Managing maps with MapPoint, Only theoretically.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. All the course material can be found on LTU’s Citrix portal. There you can also find more detailed descriptions of the course contents and its realization. There are no pre-recorded lectures, nor are there any mandatory gatherings. The book constitutes the course literature and should be followed according to its instructions.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course is target examined through assignments that will be completed individually or in groups of two people who will be examined throughout the course. Marking of the assignments will be made according to U/G marking scale. All assignments should be completed to receive a final mark. Deliverables are available on LTU’s Citrix portal.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course L0002B is equal to ABL005, D0014E, D0009E, D0017D, D0028E, D0017E

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment | U G# | 7.5 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
