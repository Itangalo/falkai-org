---
course_code: "P7006K"
title: "High Temperature Materials"
credits: "7.5"
title_sv: "Högtemperaturmaterial"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2023-06-02"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Processmetallurgi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7006K&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p70/p7006k-hogtemperaturmaterial"
---

# High Temperature Materials (P7006K)

## Main field of study

Chemical Engineering

## Entry requirements

90 credits in Chemical Engineering. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, the student should be able to:

Knowledge and understanding

1 describe the thermodynamics, crystallography and kinetics of melts and high temperature materials.

2 explain the meaning of the term sintering.

3 describe the manufacturing methods of ceramics, their microstructure, technical applications and physical and mechanical properties.

Competence and skills

4 independently analyze and construct phase diagrams.

5 use thermodynamic calculation programs and models and predict thermodynamic events

6 use different types of material characterization equipment and analyze experimental data from these.

7 Demonstrate the ability to formulate and solve problems within set time frames.

8 Demonstrate the ability to orally and in writing evaluate, compile and present results from experimental experiments.

9 Identify, formulate and treat complex engineering questions

Judgement and approach

10 Assess, evaluate and compare different types of experimental data and theoretical information.

## Contents

The course consists of thermodynamics, crystallography, phase analysis and kinetics. Basic thermodynamics as well as the crystal structures of metals and oxides, amorphous structures, defects, diffusion processes and basic reaction kinetics. In addition, phase transformations, grain growth and solid phase reactions are treated. The concepts of sintering and methods for manufacturing high-temperature materials are also covered in the course. The course contains thermodynamic computer simulations and a shorter material characterization project.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course has both theoretical and practical elements consisting of lectures, exercises, computer labs, material characterization, metallurgical laboratory work and written and oral reporting.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Goals/ILOs are assessed through written exam, oral and written project presentation and written laboratory report/assignment

Exam asses ILOs 1-4,6,7,9

Project work+ laboratory work asses ILOs 4-10

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 5.3 | Mandatory | A07 |  |
| 0002 | Project work + Laboratory work | GU345 | 2.2 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02

## Syllabus established

by the Department of Chemical Engineering and Geosciences 2007-02-28
