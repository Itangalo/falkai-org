---
course_code: "K7029B"
title: "Design of Timber Structures 2, Extreme Conditions and Safety"
credits: "7.5"
title_sv: "Träkonstruktion 2, säkerhet vid extrem påverkan"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2026-02-13"
education_level: "Second cycle"
grade_scale: "U G VG"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7029B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7029B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7029b-trakonstruktion-2-sakerhet-vid-extrem-paverkan"
---

# Design of Timber Structures 2, Extreme Conditions and Safety (K7029B)

## Main field of study

.

## Entry requirements

At least 90 credits within the field Civil Engineering or corresponding, including the courses K7026B Design of Timber Structures 1 and K0019B Wood as a Construction Material or corresponding. In addition, English 6/level 2 and Swedish 3/level 3 are required.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, the student should be able to:

Knowledge and understanding

- Explain how external actions that may lead to structural collapse should be considered during the design process

- Describe different methods to prevent progressive collapse in timber structures

- Account for the stability sensitivity of timber structures

- Describe measures to prevent the spread of fire

Competence and skills

- Select appropriate measures to prevent progressive collapse in a timber structure

- Determine stability limits for interconnected structural systems

- Assess and communicate the consequences of extreme or unusual actions on a timber structure

Judgement and approach

- Evaluate the applicability of measures to prevent progressive collapse in timber structures

- Assess the reliability of different measures aimed at preventing structural collapse

## Contents

The course addresses how the integrity of large timber structures can be affected by various exceptional actions, and how disproportionate collapse can be prevented. The following aspects are covered:

- Causes of collapse in timber buildings

- Stability issues

- Measures to prevent progressive collapse in different types of structures

- Unforeseen external loads such as accidents and explosions

- Fire

- Dynamic actions such as wind, earthquakes, and explosion

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The course is offered as a distance course and is based on self-studies of literature and other material in accordance with a study guide, complemented by recorded lectures and live online sessions with the instructor. Skills and abilities are developed through practical exercises and an assignment carried out individually or in groups.

Learning progress is monitored during regular supervision sessions with the instructor.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Assessment is carried out continuously through both quizzes and a written assignment.

Students’ knowledge and skills are examined through a combination of theoretical and practical components.

Theoretical knowledge is assessed through several quizzes containing varied tasks that require a solid understanding and insight into the course content.

The practical ability to apply learned methods and theories is assessed through a written assignment, which may be completed individually or in groups.

The assignment includes both a written report and an oral presentation, in which students are also expected to reflect on their results and draw their own conclusions.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K7029B is equal to W7013T

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Assignment report | U G VG | 5 | Mandatory | S27 |  |
| 0003 | Quizzes | UG | 2.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13
