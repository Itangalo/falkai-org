---
course_code: "A7005B"
title: "Environmental Engineering Microbiology"
credits: "7.5"
title_sv: "Miljöteknisk mikrobiologi"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2022-11-03"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Miljöteknik"
subject_group_scb: "Environmental Care and Environmental Protection"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=A7005B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=A7005B&lasPeriod=214&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/a70/a7005b-miljoteknisk-mikrobiologi"
---

# Environmental Engineering Microbiology (A7005B)

## Main field of study

Natural Resources Engineering

## Entry requirements

Chemical Principles (K0016K) or a corresponding course.

## Selection

The selection is based on 30-285 credits

## Course Aim

The course aims to provide basic knowledge on generic microbiology and advanced knowledge on its environmental engineering applications, particularly within waste science and technology.

The goal of the course is that participants:

Should be able to apply:

- Basic natural science on the environmental engineering applications.

Should be able to perform:

- Simple microbiological investigations.

- Structure and content of a technical report, including formal correctness.

- Information retrieval from scientific databases.

- Basic environmental engineering calculations.

- Active team work, both as a member and leader.

- Critically review, design and develop unit processes for environmental engineering applications of microbiology.

Be able to describe and reflect on :

- How microorganisms affect and are affected by their environment.

- Microecological processes

-The function of application processes and the interdependence of substrates, microflora, process conditions and the process output.

- Generic microbiological concepts.

- Important microbiological processes in nature.

- Important environmental engineering applications of microbiology.

- Security rules of laboratory work.

## Contents

Unit operations of environmental engineering microbiology applications, e g waste treatment. The student assesses the processes in view of realistic problems with regard to the environment, character of process, microorganisms, process design and sizing. The potential of the processes are analyzed e g with regard to design criteria and environmental conditions. In support of the application oriented course parts a generic background in microbiology will be given. This part will focus on taxonomy, physiology, different types of metabolism, requirements for growth and control as well as micro ecology. Also basic laboratory techniques for the characterization of micro biota, will be introduced.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures, laboratory work, seminars, study visits and project assignment in group. The dominating part of the course is a problem oriented project assignment including laboratory work, individual specialization studies, oral and written presentation with opposition. The course starts with a lecture series that presents basic microbiology and environmental engineering microbiology applications. Students may be supplemented with more specialized information on demand as a support to the project work

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Written examination. Laboratory, study visits, project work with oral and written presentations and opposition are compulsory.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0006 | Written exam | GU345 | 4 | Mandatory | A10 |  |
| 0007 | Laboration and projectwork | U G# | 3.5 | Mandatory | A10 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-11-03

## Syllabus established

by Lars Bernspång 2010-03-01
