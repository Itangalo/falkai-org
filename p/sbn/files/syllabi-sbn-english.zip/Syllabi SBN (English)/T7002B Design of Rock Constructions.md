---
course_code: "T7002B"
title: "Design of Rock Constructions"
credits: "7.5"
title_sv: "Dimensionering av bergkonstruktioner"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7002B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7002b-dimensionering-av-bergkonstruktioner"
---

# Design of Rock Constructions (T7002B)

## Main field of study

., Civil Engineering

## Entry requirements

Basic rock mechanics, e.g. T0014B Fundamentals of Rock mechanics or T7001B Fundamentals of Rock Mechanics, alternatively Q0038B Rock Mechanics I together with Q0028B Rock Mechanics 2, or equivalent knowledge.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course participants should be able to

1. explain linear-elastic and plastic material models and apply them in analytical and numerical (stability) analyzes of constructions in rock

2. select appropriate input data for analytical and numerical (stability) analyzes of constructions in rock

3. be able to perform linear elastic and plastic numerical analysis and be able to evaluate and explain results obtained

4. for different geological conditions select and calculate the appropriate ground support for constructions in rock

5. describe dynamic behaviors of rock masses as well as describe measurement and observation programs for different types of rock constructions and situations

6. present analyzes and results in writing and discuss conclusions and the knowledge and arguments that forms its basis

## Contents

The main topics covered in the course are:

- Introduction – Course layout, repetition of relevant content from previous course(s) in rock mechanics

- Non-elastic behaviour – Plastic and brittle failure of rock, how to model the material behaviour in numerical analyses

- Numerical methods – A short introduction to the theoretical background to different numerical methods; the different types of available numerical codes; an overview of how to carry out numerical analyses; learn to use a numerical application, how to apply it to rock mechanical problems, how to evaluate and interpret the results, and how to present numerical analyses and its results in writing.

- Rock support and reinforcement – support and reinforcement principles, types and action of common support/reinforcement elements/systems and when to apply them, ground reaction and support reaction characteristics, rock reinforcement using rock mass classification.

- Dynamic processes – General principles, stress waves, wave reflections, failure by dynamic processes, i.e. blasting, seismicity in mining, i.e. rockbursts

- Measurements and monitoring – Instrumentation and monitoring of slopes and underground constructions

- Destressing – A method to reduce stresses in highly stresses rock

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

This course includes teaching and learning activities such as:

- Lectures - They are a mix of several teaching/learning activities: (i) the lecturer will shortly explain the main theoretical aspects related to the content of the course and (ii) all together solving and/or discussing typical rock mechanical problems, thereby providing you an opportunity to practice applying your theoretical knowledge as well as practicing discussing.

- Computer exercises - During these we work together in a computer room practicing different numerical applications.

- Assignments - You work together with other students applying your knowledge to solve different problems. You present your work in written reports. You practice problem solving, conducting analytical and numerical analysis, and explaining your work in writing.

- Outside of lectures - You are expected to prepare before each lecture by working through the recommended material, recommended exercises and online quizzes so that you are prepared to contribute and participate in discussions during the lectures and computer exercises.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through:

- Written tests - Consists of questions testing your theoretical knowledge and understanding of certain rock mechanics aspects related to the content of the course.

- Assignments - Consist of problems where you practice and apply your theoretical knowledge, understanding, and abilities as well as conducting analyses and explaining your results in writing.

- Written exam - You solve problems like those encountered during the course (in lectures and assignments) to test your individual knowledge, understanding, skill and abilities.

Intended learning outcomes 2-6 is assessed through a written exam. Grading scale G/U 3 4 5

Intended learning outcomes 1-5 is assessed through the written tests.

Intended learning outcomes 1-6 is assessed through the assignments. Grading G/U.

To be approved on the module required assignment, you must be approved on assignments as well as approved on written tests.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course T7002B is equal to ABM024

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 3 | Mandatory | A07 |  |
| 0003 | Required assignment | UG | 4.5 | Mandatory | S27 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
