---
course_code: "T7006K"
title: "Senior Design Project in Chemical Technology"
credits: "7.5"
title_sv: "Projektkurs i Kemisk teknologi"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2022-02-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Kemisk teknologi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7006K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7006k-projektkurs-i-kemisk-teknologi"
---

# Senior Design Project in Chemical Technology (T7006K)

## Main field of study

Chemical Engineering

## Entry requirements

At least 90 credits in Chemical Engineering. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2. For exchange students, the examiner makes an individual examination of the qualification depending on the type of project.

## Selection

The selection is based on 30-285 credits

## Course Aim

The overall goal of the project course is that the student should be able to deal with important scientific issues in chemical separation engineering and catalysis areas.

On completion of the course, the student should be able to:

- Formulate a relevant problem for investigation within the subject area.

- Plan a project work in an efficient way.

- Design and carry out a project within the subject.

- Solve problems independently in the project

- Evaluate the results using the theoretical knowledge they learned.

- Write a scientific report, give an oral presentation and defend the conclusions.

## Contents

The project theme shall be chosen in cooperation with the examiner and be related to modern research and development.

Some advanced characterisation instruments, like SEM, BET and separation equipment or catalytic setup will be used.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The student will work independently with guidance.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Written report and oral presentation.

In the report and presentation, the student should show the ability to:

- Collect critical information relevant to the problem formulated.

- Describe the project in a scientific manner including the project plan, design and implementation of the project as well as the results and conclusions.

- Use the theoretical knowledge they learned to discuss the results obtained.

- Give an oral presentation to present their own work.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Passed oral and written presentation | GU345 | 7.5 | Mandatory | A07 | Yes |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-05-28.
