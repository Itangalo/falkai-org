---
course_code: "S7018B"
title: "Applied Fire Engineering"
credits: "7.5"
title_sv: "Tillämpad brandteknik"
valid: "Spring 2025 Sp 3 - Present"
decision_date: "2024-09-19"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Brandteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7018B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7018B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/s70/s7018b-tillampad-brandteknik"
---

# Applied Fire Engineering (S7018B)

## Entry requirements

S0003B Fire Dynamics I, S7002B Fire Dynamics II and K0017B Applied Risk Management or corresponding.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course students should be able to:

Knowledge and Understanding

1. Explain basic principles of performance-based fire safety design.

2. Explain strategies for performance-based fire safety design.

3. Explain the legal framework for performance-based fire safety design.

Competence and Skill

4. Solve performance-based fire safety design challenges using analytical and numerical tools.

Judgment and Approach

5. Judge performance-based fire safety designs.

6. Explain the strategy for evaluating performance-based challenges.

## Contents

Different areas of interest for performance-based fire safety design including, but not limited to:

- Classification according to different fire classes,

- ASET-RSET,

- Smokefilling,

- Risk analysis,

- Etc.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The students participate in lectures where backgrounds and theories to the course content are derived, presented, and exemplified.

Theoretical principles and calculation methods are applied by students in three settings:

1. Individually, through practical exercises conducted in classroom sessions.

2. Individually or in small groups through project works.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. This course is examined by few different forms of assignments: written reports, calculation/design assignments, oral presentations, quizzes.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course S7018B is equal to S7008B

## Remarks

This course corresponds to parts of S7008B. The course cannot be included in the degree together with this course.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignments | U G# | 7.5 | Mandatory | S25 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-09-19

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-19
