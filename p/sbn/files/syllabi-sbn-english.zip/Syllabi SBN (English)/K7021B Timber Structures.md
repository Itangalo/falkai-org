---
course_code: "K7021B"
title: "Timber Structures"
credits: "7.5"
title_sv: "Träkonstruktioner"
valid: "Spring 2026 Sp 3 - Autumn 2026 Sp 2"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Konstruktionsteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7021B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7021B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7021b-trakonstruktioner"
---

# Timber Structures (K7021B)

## Main field of study

Civil Engineering, .

## Entry requirements

At least 90 credits completed courses where 30 credits of courses in building materials, structural engineering, structural design and structural mechanics should be included, for instance K0002B Building materials, B0002B Structural Engineering, K0013B Structural Design and B7004B Structural mechanics I. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course students should be able to:

Knowledge and Understanding:

1. Describe the properties and characteristics of structural timber, including common engineered wood products.

2. Explain the strengths and weaknesses of various wood-based materials, considering their structural applications and performance.

3. Explain the mode of action of typical construction solutions for timber-based industrial and multi-storey buildings.

Competence and Skills:

4. Apply relevant Eurocode design regulations to perform structural calculations for different timber members under static loads, encompassing compression, tension, bending, and combinations of these forces. Address instability issues for these load modes.

5. Apply appropriate regulations to select and design timber connections, considering both design and execution aspects.

Judgment and Approach:

6. Identify and resolve structural and technical challenges specific to timber buildings, including issues arising during the assembly phase.

7. Create well-structured technical reports and documentation, facilitating comprehension by technically qualified individuals, ensuring consistency in work understanding and conclusions.

## Contents

During this course students learn about:

- Structural timber and most common timber engineered materials, their properties and applications.

- General technical challenges in timber structures related to fire, moisture and acoustics

- ULS and SLS

- Timber members in compression, tension, bending, shear and under combination of these loads/actions.

- Connections in timber structures

- Local and global stability issues, stabilising methods

- Systems in timber för multi-storey buildings

- Systems in timber for industrial buildings

- Timber bridges

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

This course includes lectures where the theory and background are explained and exemplified by the teacher. One of the lectures is given by the guest lecturer sharing an expert experience of working with timber structures. During seminars students practice themselves solving design problems as well as get supervised by the teacher if needed in the project work. The project of and industrial building is carried out by students individually or in small groups.

During the course students will be offered to attend the study trip to take a closer look at some real-life examples of timber structures and/or some timber related production facilities.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The outcome of the course is assessed through a project assignment that will be evaluated in parts or as a whole. To additionally evaluate the theoretical understanding, the students will complete a mandatory quiz.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project assignment | GU345 | 6.5 | Mandatory | A24 |  |
| 0002 | Quiz | U G# | 1 | Mandatory | A24 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14
