---
course_code: "V7013B"
title: "Resource-oriented Water and Sanitation Systems"
credits: "7.5"
title_sv: "Resurseffektiva vatten- och avloppssystem"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2022-01-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "VA-teknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V7013B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V7013B&lasPeriod=220&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/v70/v7013b-resurseffektiva-vatten--och-avloppssystem"
---

# Resource-oriented Water and Sanitation Systems (V7013B)

## Entry requirements

V0016B Urban Water Systems or corresponding.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course participants should be able to

- explain the composition of different wastewater flow-streams and their associated resources (nutrients, water, energy, organic material) and make simple mass balances for these resources,

- describe principles, technical solutions and critical factors (e.g. risks) for recovery and reuse of resources in wastewater flow-streams,

- describe pros and cons with different systems for wastewater management nationally and internationally, including today’s system,

- design and optimise system components for efficient wastewater management and treatment and for source separation for maximum resource recovery,

- design, carry out and present laboratory experiments related to wastewater treatment,

- describe and design solutions for rainwater harvesting and for reuse of stormwater and reclaimed water for decreased pressure on drinking water systems, and to

- describe existing legal framework in relation to source separating wastewater systems.

## Contents

This course will give a broad overview of resource-oriented water and sanitation systems, which are important ingredients in a future, sustainable society. The course covers important resources, such as nutrients, organic matter, heat, water and energy, all of which are contained in household wastewater and need to be recycled to a larger extent than today in a sustainable future. The course covers source-separating wastewater systems, where nutrient-rich streams such as blackwater or urine, are diverted for separate management from the greywater, which enables a more efficient resource management. In this course, the resources, including the resource water, will be in focus throughout the course. The course will include, among other things: (i) principles for collection, treatment and reuse, (ii) design and optimization of system components, (iii) pros and cons with different system solutions, including consideration of system size, (iv) existing legal framework. The relevance of source-separating wastewater systems in an international perspective will also be highlighted.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. An overview over the subject and details in relation to dimensioning of system components will be covered in lectures. A literature assignment will be handed out early on in the course, which will allow for a deepened understanding of a few treatment technologies. This assignment will result in a written report and an oral presentation. To enhance the understanding of the course content’s relevance a case study will be introduced a few weeks into the course, in which groups of students will motivate and suggest a water and sanitation system solution with resource efficient system components for the case study. The results will be presented in a report and orally. To gain practical understanding of the course content groups of students will design, build and assess a prototype for greywater treatment. The results will be presented in a written report and orally. A board game focusing on the implementation of source-separating wastewater systems will be played and followed by an individual reflection. Theoretical and design (dimensioning etc.) aspects are examined in a written exam.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course is assessed through a literature assignment, a laboratory task, a case study, an individual reflection and a written exam (see table below). Active participation at presentations of the literature assignment, the case study and the laboratory task are compulsory. Failure to meet the mandatory requirements listed means the student will have to wait for the following year to fulfil the course requirements.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course V7013B is equal to V7012B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Literature assignment | GU345 | 1 | Mandatory | A20 |  |
| 0002 | Laboratory task | GU345 | 1.8 | Mandatory | A20 |  |
| 0003 | Case study | GU345 | 1.7 | Mandatory | A20 |  |
| 0006 | Individual reflection | U G# | 0.5 | Mandatory | A20 |  |
| 0007 | Written exam | GU345 | 2.5 | Mandatory | A20 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-01-11

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-02-14
