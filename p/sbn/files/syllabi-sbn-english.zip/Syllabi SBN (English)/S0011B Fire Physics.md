---
course_code: "S0011B"
title: "Fire Physics"
credits: "7.5"
title_sv: "Brandfysik"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Brandteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S0011B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S0011B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/s00/s0011b-brandfysik"
---

# Fire Physics (S0011B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and M0055M Multivariable Calculus or corresponding course

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course participants should be able to

- explain and compute exercises for the electromagnetic interaction between fires and its surroundings

- explain and compute exercises for condensed matter physics properties relevant in fire situations, such as expansion coefficient, heat conductivity and heat capacity

- explain and compute exercises for how soot and liquid sprays interact with fires

- explain and compute exercises for fluid mechanical phenomena relevant for fires

## Contents

The course covers theory of electromagnetic spectra, spectrally resolved emissivity/absorptivity, Kirchoff’s law, Beer-Lamberts law and heating of semi-transparent materials, heat transfer, expansion coefficient, heat conductivity, heat capacity, thermal properties of soot, fluid dynamics, droplet and spray physics, interaction between electromagnetic radiation and sprays

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

This course includes lectures, problem solving classes, quizzes and partial exams.

Documents are communicated via Canvas.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through a final written exam with grading U 3 4 5. Quizzes and partial exams are offered during the course and passed quizzes and partial exams results in points awarded that are included in the result for the final written exam. All three modes of examination: final written exam, quizzes, and partial exams, each cover all parts of the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 7.5 | Mandatory | A20 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-02-14
