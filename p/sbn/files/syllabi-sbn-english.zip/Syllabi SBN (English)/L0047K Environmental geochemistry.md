---
course_code: "L0047K"
title: "Environmental geochemistry"
credits: "7.5"
title_sv: "Miljögeokemi"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0047K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0047K&lasPeriod=222&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0047k-miljogeokemi"
---

# Environmental geochemistry (L0047K)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Chemical Principles (K0016K), Geology, basic course (O0035K)

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course participants should be able to

Knowledge and understanding

1. Explain the general geochemical principles regulating the distribution and geochemistry of the elements in minerals and water

2. Explain geochemical cycles on the Earths surface

Competence and skills

3. Interpret the biogeochemical processes which influence the concentrations of the major elements in groundwater and surface water and

4. Balance important geochemical weathering reactions

5. Apply geochemical processes on field cases

6. Discuss how carbon dioxide and oxygen in the atmosphere have been regulated during geological time

7. Summarize relevant scientific articles in an abstract

Judgement and approach

8. On scientific basis reflect how man-kind influences the carbon dioxide concentrations on short and long time scales in the atmosphere

## Contents

The content of the course includes 1) basic explanations of geochemical concepts to understand natural processes occurring on the earth surface, 2) tools to identify and compare natural concentrations and anthropogenic pollutions, and 3) the basic geochemistry which is affecting climate change. General geochemical concepts such as pH and redox potential are explained, and attributed to the mobility of elements between different reservoirs.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The students reflect on adequate background knowledge learned from previous courses by taking a quiz in the beginning of the course. During the course, students will actively work in groups to discuss and summarize geochemical information from given chapters of the course literature. The students will collaborate and solve problems by geochemical data interpretations, calculations, balancing of weathering reaction formulas, and by visualizing and presenting geochemical cycles.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The intended learning outcomes (ILO’s) of the course are assessed by three different assessments:

1. An individual assignment assess the ILO 7 (Grade G/U)

2. A project assignment assess ILO 2 (Grade G/U)

3. All the remaining ILO’s are assessed by an individual written exam in the end of the course, graded U 3 4 5.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Written exam | GU345 | 6 | Mandatory | A13 |  |
| 0003 | Assignment report | U G# | 0.5 | Mandatory | A13 |  |
| 0004 | Project Assignment | U G# | 1 | Mandatory | A13 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2013-02-06
