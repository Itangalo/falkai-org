---
course_code: "S7021B"
title: "Hydrogen Jet Flames and Hydrogen Explosions"
credits: "1.5"
title_sv: "Vätgasjetflammor och vätgasexplosioner"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2026-02-13"
education_level: "Second cycle"
grade_scale: "UG"
subject: "Brandteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7021B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7021B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/s70/s7021b-vatgasjetflammor-och-vatgasexplosioner"
---

# Hydrogen Jet Flames and Hydrogen Explosions (S7021B)

## Entry requirements

180 credits in engineering/natural sciences. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2 or equivalent real competence obtained through practical experience. Read more about how to apply for real competence via this link: https://www.ltu.se/en/student-web/your-studies/prior-learning.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course with a passing grade, the student shall be able to

1) Unignited hydrogen releases

- Distinguish between expanded and under-expanded hydrogen jets.

- Recognize features like Mach disks and shock structures in high-pressure releases.

- Explain how hydrogen plumes disperse and form flammable clouds depending on conditions.

- Assess the safety implications of different release scenarios.

2) Ignition of hydrogen mixtures

- Define and use key ignition-related terms for hydrogen.

- Understand why hydrogen-air mixtures are so easy to ignite.

- Explain various mechanisms that can cause spontaneous ignition of hydrogen releases

- Apply this knowledge to safety scenarios.

3) Deflagration and detonation

- Differentiate between deflagration and detonation.

- Explain the concept of vented detonations/deflagrations and associated risks.

- Illustrate the Deflagration-to-Detonation Transition (DDT) process step-by-step.

- Summarize key safety implications of deflagrations, detonations, and DDT in hydrogen systems.

4) Jet flames

- Describe the structure and characteristics of hydrogen jet flames.

- Distinguish between momentum-dominated and buoyancy-dominated regimes using the Froude number.

- Apply empirical correlations to estimate flame length and hazard distances.

- Explain the blow-off phenomenon and factors affecting flame stability.

- Identify key safety measures and design principles for preventing and mitigating jet fire risks.

## Contents

The course covers the following topics:

1) Unignited hydrogen releases.

a) Overexpanded and underexpanded jets.

2) Ignition of hydrogen mixtures

a) Piloted ignition and spontaneous ignition

3) Deflagration and detonation

a) Vented and unvented deflagrations

b) Vented and unvented detonation

c) DDT (Deflagration-to-Detonation Transition)

4) Jet flames

a) Froude-number based correlations

b) Blow-off-phenomenon (flame extinction phenomenon)

c) Jet flame characteristics

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course is delivered online and is self-paced. Teaching and learning are supported through structured online materials, including pre-recorded lecture videos that students are required to watch and study independently. Students complete calculation assignments, compulsory quizzes, and a final report to demonstrate their understanding of the course content. Each section includes a discussion component where students reflect on what they have learned and engage in dialogue with other participants.In addition, students are required to attend three compulsory online seminars.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

All learning outcomes (1.5 credits) are assessed through the student’s attendance at three compulsory online meetings and by demonstrating active participation and sufficient knowledge during these meetings, as evaluated by the teacher using the grading scale U (Fail) / G (Pass).

To pass the course, the student must also write a report that is peer-reviewed by other students and subsequently revised before final approval by the teacher. In addition, the student must pass four compulsory quizzes and one calculation assignment.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Essay | UG | 0 | Mandatory | S27 |  |
| 0006 | Calculation assignments | UG | 0 | Mandatory | S27 |  |
| 0007 | Online meetings | UG | 1.5 | Mandatory | S27 |  |
| 0008 | Quizzes | UG | 0 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students

applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13
