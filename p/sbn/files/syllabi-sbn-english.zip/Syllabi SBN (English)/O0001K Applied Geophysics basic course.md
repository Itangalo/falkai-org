---
course_code: "O0001K"
title: "Applied Geophysics, basic course"
credits: "7.5"
title_sv: "Tillämpad geofysik, grundkurs"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Geofysik"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0001K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0001K&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o00/o0001k-tillampad-geofysik-grundkurs"
---

# Applied Geophysics, basic course (O0001K)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Geology, basic course (O0035K) or corresponding.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completed course, the student is expected to be able to:

- explain the concepts of geophysical models, geophysical data and anomalies
- give a quantitative account on petrophysical properties of common rock types and mineralizations
- explain the concept of equivalence by use of standard statistical tools
- describe qualitatively the Earth magnetic field
- describe qualitatively the Earth gravity field and the geoid
- explain the basic principles (physics, measuring techniques and interpretation) for the geophysical methods that are included in the course
- describe particle movements for seismic waves
- derive formulas for reflection and refraction seismic travel times for simple two layer Earth models and identify and interpret arrival time data in a seismogram
- derive formulas for reflection of radar waves for simple two layer Earth models and identify and interpret arrival time data in a radargram

## Contents

Seismology-seismic profiling: The different types of seismic waves. The correlation between elastic properties of a material and P-, S- wave velocities. Reflection and refraction. Interpretation of seismic reflection and refraction data. Examples with application of refraction and reflections seismics.

The magnetic field of the Earth – magnetometry: The Earth magnetic field. Magnetic properties of rocks and unconsolidated sediments. Measuring techniques and data processing. Exploration for mineral resources.

The gravity field of the Earth – gravimetry: Geodesy with emphasis on the gravity field of the Earth. Density of rocks and unconsolidated sediments. Corrections to gravity data and the calculation of Bouguer anomalies. Regional/residual anomaly separation.

Electric and electromagnetic methods: Electric conductivity of rocks and unconsolidated sediments. Dielectric constants of rocks and unconsolidated sediments. Electric methods based on natural and artificial currents. Electric sounding and mapping. Examples in mineral prospecting, environmental studies, prospecting for and planning of water resources, pollution of ground water. Electromagnetic fields. Depth of penetration. Electromagnetic methods with examples of application in mineral exploration and environmental studies.

Ground Penetrating Radar and borehole radar with examples in environmental studies.

Borehole methods and logging: acoustic/sonic log; calliper log; density log; gamma log, induction/conductivity log, neutron log, resistivity log, SP-log (self-potential); temperature log; IP log (induced polarization) and magnetic log. Examples from logging in hard rock and sediments.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching will be as lectures, laboratory and field training. Participation in laboratory and field training is compulsory. The lectures will be focused on basic theory and applications. The laboratory and field training will be directed on laboratory and field instrumental training, field measurements and data processing.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course is assessed through written examination with differentiated grades is organized after the study period and includes both an account of the theoretical parts of the course and problem solving. Grading is done according to grading scale G U 3 4 5. The field exercise is examined through a report according to the grading scale GU. The report shall include a review of measurement methodology and interpretation of data. All examinations must be completed for the final grade of the course. Field practice is mandatory.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course O0001K is equal to KGG001

## Remarks

O0001K is equivalent to KGG001 and cannot be combined

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 6 | Mandatory | A07 |  |
| 0003 | Laboratory report | UG | 1.5 | Mandatory | S27 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
