---
course_code: "Y0003B"
title: "Basic surveying"
credits: "7.5"
title_sv: "Byggmätning 1"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "U G VG *"
subject: "Geografisk informationsteknologi"
subject_group_scb: "Geographic Information Technology and Surveying"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=Y0003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=Y0003B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/y00/y0003b-byggmatning-1"
---

# Basic surveying (Y0003B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Y0008B Tools for engeneering calculations and reporting

## Selection

The selection is based on 1-165 credits.

## Course Aim

Kursen motsvarar O0002K –The course aims to develop basic knowledge of, and practical skills in, detailed measurement (measurement in general, installation in particular) in connection with the construction of houses and facilities. After completing the course participants should be able to…

Knowledge and understanding

Describe the basics of producing release data and practical release with GPS.

Know and understand the meaning of different coordinate systems, GPS systems and machine control.

Read lists of quantities and technical descriptions used in construction and civil engineering.

Competence and skills

Manage total station, GNSS equipment as well as balancing instruments and plant lasers

Apply standard software and transfer results between instruments and computers.

Perform simpler release and measurement.

Read drawings and carry out reference line laying for houses.

Byggmätning.

## Contents

Instrument theory (GNSS, total station, as well as balancing instruments and plant lasers).

Software (Geo, Topocad, etc.).

Plant measurement

House release

Drawing reading for road, house and land

Construction documents, quantity list, technical description and AMA

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures, laboratory work, arithmetic exercises, individual work, group work, field exercises.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is examined through design assignments and a written test.

Grading takes place according to grade scale G U VG. All included examination parts must be completed for the final grade on the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course Y0003B is equal to O0002K

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Written test | U G VG * | 4 | Mandatory | A08 |  |
| 0004 | Assignment report | U G# | 3.5 | Mandatory | A08 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2008-01-22 and is valid from H08.
