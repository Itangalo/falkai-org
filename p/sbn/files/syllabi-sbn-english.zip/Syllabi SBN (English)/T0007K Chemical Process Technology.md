---
course_code: "T0007K"
title: "Chemical Process Technology"
credits: "7.5"
title_sv: "Kemisk processteknik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-06-15"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Kemiteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0007K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t00/t0007k-kemisk-processteknik"
---

# Chemical Process Technology (T0007K)

## Main field of study

Chemical Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Basic courses in Physical chemistry, Organic chemistry, Inorganic chemistry and Water Chemistry or corresponding courses.

Good knowledge in English, equivalent to English B/6.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completed course, the student shall be able to:

- From a theoretical and practical perspective describe and explain the most common chemical and biochemical processes for industrial manufacturing of chemicals, fuels and products.

- Describe the concepts adsorption and catalysis.

- Describe why adsorbents, catalysts or enzymes are necessary in many of the processes and on a basic level, be able to describe some adsorbents and heterogeneous catalysts.

- Understand what the necessary process conditions are for effective production and be able to describe these on a basic level.

- Describe the most common processes for purification of gas streams in chemical industry.

- Prepare fuels in laboratory scale.

- Present orally and in written form preparation of fuels in laboratory scale.

- Identify and describe some environmental harmful processes and how to minimize the effect on the environment.

## Contents

The following topics are discussed in the course:

- Introduction to Chemical Engineering

- Adsorption

- Heterogeneous and enzyme catalysis

- How fossil fuels, chemicals and products are produced

- How renewable fuels, chemicals and products are produced

- Purification of gas streams

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course is realized through lectures and practical work. The practical work is in the form of project work where the students work in groups and the work is presented both orally and in written form.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Examination by written individual exam with grades according to U (Failed), 3, 4 and 5. To pass the laboratory project, the oral and written presentation has to be passed. The grades are failed or passed.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course T0007K is equal to T0005K

## Remarks

Compulsory attendance at the project work and the oral presentation of the work. The course is given at basic level and is included in the MSc programme in Sustainable process and chemical engineering. A study guide for the course is found in Canvas.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 5.5 | Mandatory | S22 |  |
| 0003 | Project work | UG | 2 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-06-15

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17
