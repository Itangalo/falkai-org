---
course_code: "C7001B"
title: "Traffic in the city"
credits: "7.5"
title_sv: "Trafik för en attraktiv stad"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Trafikteknik"
subject_group_scb: "Civil and Environmental Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=C7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=C7001B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/c70/c7001b-trafik-for-en-attraktiv-stad"
---

# Traffic in the city (C7001B)

## Main field of study

Architecture

## Entry requirements

Basic knowledge of urban planning (F0002B Urban Design) or equivalent, and report writing and oral presentation (V0015B Sustainable Building) or equivalent.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course participant should

Knowledge and understanding

- have knowledge about

    - basic traffic engineering concepts

    - the basics for dimensioning traffic systems for different types of traffic

    - traffic strategies for urban areas

Competence and Skills

- be able to

    - implement, apply and evaluate traffic strategy for urban areas

    - collaborate in groups with different compositions and present their results orally and in writing to colleagues

Judgement and approach
- have an understanding of holistic thinking about traffic technology in community building

## Contents

Work with traffic strategy for the urban area with the support of the handbook TRAST. Systematic literature survey based on scientific sources. Socio-economic calculations and capacity and accessibility at intersections. The course deals mainly with urban traffic; traffic outside the urban area is discussed briefly. The course covers:

- The city's character
- Travel and transport, where and why people travel
- Safety, availability and security
- Pedestrian traffic, cycle traffic, moped traffic
- Public transport
- Interchanges, railway stations
- Vehicular traffic

Freight traffic and emergency traffic are dealt with in this course briefly, as part of vehicular traffic. The course begins with a theoretical work. Individual study questions used to quickly get into the literature. This is followed by project work and laboratory work on partly socio-economic calculations and partly capacity and accessibility at intersections. This is followed by field work and analysis, as well as individual literature studies. This work results in an individual written report to be presented and discussed.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The course includes lectures, seminars, laboratory work and field exercises / inventory. The course begins with lectures and seminars. The course trains oral / written presentation, project work, group work / collaboration, in work with open issues. The purpose of the project assignment is to give students the opportunity to work with traffic strategy for an urban area.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is examined with 80% participation in lectures and participation in oral presentations / seminars, participation in field exercises / inventory

The learning objectives connected to:

Knowledge and understanding are examined through individual written project assignments.

Competence and skills are examined through written and oral group work.

Judgment and approach is examined through individual written project assignments with differentiated grades.

Mandatory attendance at lessons, oral presentations / seminars and field exercises / inventory.

All included examination parts must be completed for the final grade on the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Oral and written report on project work | GU345 | 1.5 | Mandatory | A07 |  |
| 0006 | Project work, part 1 | UG | 2 | Mandatory | S27 |  |
| 0007 | Lectures | UG | 1 | Mandatory | S27 |  |
| 0008 | Field work | UG | 1 | Mandatory | S27 |  |
| 0009 | Project work, part 2 | UG | 2 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
