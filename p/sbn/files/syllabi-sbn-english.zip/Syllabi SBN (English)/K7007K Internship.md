---
course_code: "K7007K"
title: "Internship"
credits: "30"
title_sv: "Ingenjörspraktik"
valid: "Autumn 2025 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2025-02-13"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Kemiteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7007K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7007k-ingenjorspraktik"
---

# Internship (K7007K)

## Entry requirements

Three years of studies at the Master Programme in Sustainable Process and Chemical Engineering

## Selection

The selection is based on 30-285 credits

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K7007K is equal to K7005K

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Start of Internship | U G# | 1 | Mandatory | A22 |  |
| 0004 | Approved Report | U G# | 24 | Mandatory | A22 |  |
| 0005 | Oral presentation of internship | U G# | 5 | Mandatory | A22 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11
