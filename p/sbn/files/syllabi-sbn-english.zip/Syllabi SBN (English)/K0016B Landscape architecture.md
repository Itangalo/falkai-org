---
course_code: "K0016B"
title: "Landscape architecture"
credits: "7.5"
title_sv: "Markprojektering"
valid: "Spring 2026 Sp 3 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Konstruktionsteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0016B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k00/k0016b-markprojektering"
---

# Landscape architecture (K0016B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Swedish upper secondary school courses Mathematics 2a or 2b or 2c. Or: Mathematics level 2a or level 2b or level 2c.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

The course will provide knowledge of the planning process and the geometric design of roads, railways and water and sewerage, electricity, fiber and other paved infrastructure. The concepts are built up by the regulations that the Swedish Transport Administration, municipalities and others uses. After completing the course participants should be able to…

Knowledge and understanding

Interpret and describe the planning process for road and railway construction with detailed documents.

Interpret and describe the planning process for the construction of pipelines with detailed documents.

Competence and skills

Apply geometric design in plane, profile and section.

Calculate line elements for road and railway lines.

## Contents

Geometric design in plane, profile and section.

The planning process for ground design.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures and design assignments.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is examined through design assignments and a written test.

Grading takes place according to grade scale G U. All included examination parts must be completed for the final grade on the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project work | U G# | 5 | Mandatory | A19 |  |
| 0002 | Test | U G# | 2.5 | Mandatory | A19 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-02-14
