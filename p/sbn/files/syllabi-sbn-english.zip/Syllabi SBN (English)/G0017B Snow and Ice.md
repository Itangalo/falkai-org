---
course_code: "G0017B"
title: "Snow and Ice"
credits: "7.5"
title_sv: "Snö och is"
valid: "Spring 2023 Sp 3 - Present"
decision_date: "2022-06-15"
education_level: "First cycle"
grade_scale: "U G VG"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0017B&lasPeriod=210&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g00/g0017b-sno-och-is"
---

# Snow and Ice (G0017B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Swedish upper secondary school course English 6.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Examiner

Nina Lintzén

## Course Aim

Knowledge and understanding

After completing the course, the students should be able to explain:

- The basics of snow formation and ice growth, and how snow and ice are changed

- Classification methods for snow and ice

- Subject areas and techniques where snow and ice are utilized

- How avalanches are triggered and describe avalanche safety

- Snow accumulation and melting, and how pollutions in urban snow is handeled

Competence and skills

The students should be able to describe:

- How snow, ice and cold climate affect the society

- How snow and ice can be advantageously used as materials

- How cold climate affects humans physically

- How to build a bivouac or safely spend a night outdoors in the winter

Judgement and approach

The students should be able to apply:

- Work in groups and practical work in cold climate

## Contents

This course covers basic knowledge about snow, ice and cold climate and their impact on society and the individual. Winter-related phenomena affect how we build and plan our society and our everyday lives. Snow, ice, and cold climate entails large societal costs but also great recreational opportunities for individuals as well as economic potential for actors in the winter business industry, e.g., winter tourism. Snow and ice are complex materials that can be beneficially used in cold climates. The course snow and ice deals with the basics of snow and ice mechanics, snow formation, classification methods for snow, avalanche knowledge, techniques for utilizing snow and ice and working in cold climate. This knowledge is put in a societal and individual perspective. After the course, you will have useful knowledge for work within winter tourism, construction, and civil society-related areas. During the project work you can immerse yourself in relevant specific areas such as snow and ice mechanics, frost engineering, winter tourism, leadership, etc.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. Teaching is conducted in the form of lectures, project work in groups, study visits and a compulsory field exercise where a fee is added which includes travel, accommodation, and meals.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course is assessed through submission of reports, assignments, and oral presentations. Participation in the field exercise and associated field work and assignments are compulsory.

## Overlap

The course G0017B is equal to G0008B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignments | U G VG | 4.5 | Mandatory | S23 |  |
| 0002 | Project work | U G VG | 3 | Mandatory | S23 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Literature

*Literature. Valid from Spring 2023 Sp 3* All literature will be available on the learning platform Canvas upon course start. You will find the learning platform via My LTU.

[1] LTU Ice Handbook for Engineers, Version 1.2, Lennart Fransson [2] The International Classification for Seasonal Snow on the ground, IACS 2009, Fierz et.al. [3] Slope Preparation and Grooming, 2019, Wolfsperger et.al. Excerpts from books and compendiums.

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-06-15
