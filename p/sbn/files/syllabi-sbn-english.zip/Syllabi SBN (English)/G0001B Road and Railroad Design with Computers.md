---
course_code: "G0001B"
title: "Road and Railroad Design with Computers"
credits: "7.5"
title_sv: "Väg och järnvägsprojektering med datorstöd"
valid: "Autumn 2015 Sp 1 - Spring 2019 Sp 3"
decision_date: "2015-06-11"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Items/credits Number        Type                                                              Credits      Grade  0001          Project work                                                      6            U G#  0002          Required assignment                                               1.5          U G#"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0001B&lasPeriod=193&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g00/g0001b-vag-och-jarnvagsprojektering-med-datorstod"
---

# Road and Railroad Design with Computers (G0001B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Examiner

Tommy Edeskär

## Course Aim

The course will give you knowledge of the Swedish system of planning roads and railroads.

You are learned geometrical design of roads in a design project using Novapoint.

## Contents

Novapoint is a model based road, highway and street design software package including intersection design. The Highway design software package includes sight distance analysis, multiple lanes and grad separated intersections. The Road design software and street design software include dynamic vehicle turning analysis and at grade intersections including automatic roundabout design. The program has complete and integrated functions for design, quantity calculations, drawings, reports and 3D visualisation. Alignment design, highway design, road design, street design, intersection design, drawing production and 3D presentation are the main components of Novapoint Road Professional.The highway design software, the road design software and the street design software support a large range of international design standards and export and import formats. The road, highway and street design model is integrated with the other Novapoint modules and allows the use user to create complete design models that can be presented in Virtual Reality or exported to construction equipment.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. Teaching consists of lessons, educational visits and a design problem that will be carried out with computer aid.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Some continuous examination. There will be some written tests during the course. The project work will be graded with pass (or fail).

## Overlap

The course G0001B is equal to ABG023

## Remarks

Basic knowledge of AutoCAD is positiv. The course can be studied in English if the student have a basic knowledge in Swedish.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Items/credits Number        Type                                                              Credits      Grade

0001          Project work                                                      6            U G#

0002          Required assignment                                               1.5          U G#

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Literature

*Literature. Valid from Autumn 2011 Sp 1* Chosen in cooperation with the examiner.

## Last revised

by Eva Gunneriusson 2015-06-11

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
