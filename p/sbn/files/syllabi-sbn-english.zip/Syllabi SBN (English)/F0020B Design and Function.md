---
course_code: "F0020B"
title: "Design and Function"
credits: "7.5"
title_sv: "Gestaltning och funktion"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2022-02-11"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F0020B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F0020B&lasPeriod=223&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f00/f0020b-gestaltning-och-funktion"
---

# Design and Function (F0020B)

## Main field of study

Architecture

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and F0007B Engineering Architecture and D0054A Sketching and Drawing or corresponding courses.

## Selection

The selection is based on 1-165 credits.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course F0020B is equal to D0013A

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project work | GU345 | 6 | Mandatory | S21 |  |
| 0002 | Seminars | U G# | 1.5 | Mandatory | S21 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-02-14
