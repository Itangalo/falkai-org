---
course_code: "M7003K"
title: "Mineral Processing"
credits: "7.5"
title_sv: "Mineralteknik"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2022-06-15"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Mineralteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7003K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7003K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/m70/m7003k-mineralteknik"
---

# Mineral Processing (M7003K)

## Main field of study

Chemical Engineering, Geosciences

## Entry requirements

90 credits in Chemical Engineering, including the course M0001K Mechanical ProcessTechnology.

## Selection

The selection is based on 30-285 credits

## Course Aim

The course objective is to provide a possibility to understand mineral processes for ores, industrial minerals, recycling products and mineral fuels (coal and peat). After completion the student should be able to:
- Calculate technical-economic conditions for winning of mineral resources,
- Describe and explain commonly occurring processes for mineral beneficiation,
- Analyse reasons for selection of processes based on raw material properties,
- Generalise the knowledge of process conditions to suggest process selections for hypothetical raw materials.

## Contents

Processing of ores.
- Magnetite and hematite ores. Processing of steel alloying ores. Theory of flotation. Autogenous grinding. Copper ores, lead and zinc ores and complex sulphide ores. Precious metal ores. * Computer laboratory class: Mass balancing. * Assignments: Product balance. Limiting grades and selectivity. Flotation. Mass and water balance.

Particle technology. * Comminution of minerals. Reactions with liquids and gases. Dissolution. Adsorption. Precipitation. Rheologi of suspensions and particulate matter. Porosity, pore size distribution. Shear strength of particulate matter. Mechanical properties of mineral products. Handling of bulk materials. Ultra-fine grinding.

Industrial minerals and fuels. * Aggregates for roads and concrete. Lime, cement and other binders. Masonry. Light weight concrete, aerated concrete, glass, insulators and other construction materials. Ceramics. Refractories. Pigments and fillers. Coal processing.

Environmental issues. * Handling of solid waste materials from mineral processing plants. Process water.

Recycling. * Uses of mineral processing methods in the recycling of industrial and consumer products. Selected recycling processes.

Management and mineral economy. * Current issues. * Assignments: Revenues. Cost analysis, Technical -economical calculations.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The teaching comprises lectures, assignments, computer laboratory class, lessons, and industrial field trips. Participation is compulsory with the exception of the lectures. The lectures should provide the possibility for the students to be able to describe and explain the operating principles of the processes and to explain theoretical concepts. The assignments, which are introduced during lessons, train the student to independently do calculations and technical compilations. The computer laboratory class is done in groups. The students are trained to compile input data for, evaluate and report on computer-assisted material balances. The field trips provide the possibility for the students to learn to describe industrial process technology.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. After the first quarter, a written exam that is, and an oral examination after the course. The written exam has to be passed before the student is admitted to the oral examination. The theoretical understanding of the field of study is checked by written and oral exams, graded 3 4 5. For grade 3, the student must be able to describe and explain what is included in the field of study, and do routine calculations. For grade 4, the student must be able to analyse reasons for process selections based on the properties of the raw material. For grade 5, the student must be able to apply the acquired knowledge to partly new theoretical and practical problems.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids

not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course M7003K is equal to KGM003

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam Q1 | GU345 | 2.4 | Mandatory | A07 |  |
| 0002 | Oral exam, Q2 | GU345 | 3 | Mandatory | A07 |  |
| 0003 | Laboratory class and assignments | U G# | 1.5 | Mandatory | A07 |  |
| 0004 | Field trip | U G# | 0.6 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-06-15

## Syllabus established

by the Department of Chemical Engineering and Geosciences 2007-02-28
