---
course_code: "T7001B"
title: "Fundamentals of Rock Mechanics"
credits: "7.5"
title_sv: "Bergmekanikens grunder"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7001B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7001b-bergmekanikens-grunder"
---

# Fundamentals of Rock Mechanics (T7001B)

## Main field of study

Civil Engineering

## Entry requirements

Good knowledge in solid mechanics. Good knowledge in geology is desirable.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course participants should be able to

1. carry out field experiments with proven methods and with analytical, empirical and numerical methods evaluate rock and joint parameters as well as the quality of the rock mass

2. identify structurally controlled failures forms in rock slopes and underground constructions in rock with the help of spherical projection and engineering geological descriptions of the rock mass, and where possible be able to calculate the safety against failures

3. calculate and evaluate the stress state of underground constructions in rock using analytical, empirical and numerical methods and propose optimal geometry and orientation of underground constructions in rock

4. identify possible failure mechanisms and based on that select and apply related failure criterion to analytically, empirically and numerically analyze and evaluate the stability of underground constructions in rock

5. calculate and evaluate the deformation and strain state of underground constructions in rock with analytical, empirical and numerical methods

6. identify fracture forms for loaded bedrock based on simplified geological descriptions, and where possible be able to calculate the safety against crime

7. present and discuss in writing their analyzes, models, results and conclusions

After completing the course module on gender equality, the student should show an

8. understanding of the national gender equality goals, regulations for gender equality in professional life and give examples of the prerequisite for gender equality in professional life

## Contents

The main topics covered in the course are:

- Introduction - Course design, study guide, schedule, introduction to the subject rock mechanics, etc.

- The material rock - Pre-investigation, classification, geological structures in rock and their significance from a rock mechanics perspective. Mapping of joints. Rock mass classification methods. hemispherical projection.

- Rock stress – primary stresses, secondary stresses (stresses around underground openings), absolute and effective stresses, shallow and deep-seated excavations, Mohr’s stress circles, stress measurements.

- Deformation and failure of rock - Constitutive laws, failure mechanisms and failure criteria, experimental methods to determine deformation and strength parameters, Mohr’s stress circles,

- Analytical analysis - Deformations and stresses around excavations, Analytical, empirical and numerical methods are covered, Failure of underground excavations, Failure mechanisms and failure criteria, Overstressed rock.

- Rock slope stability - hemispherical projection methods, theories for plane, wedge, circular and toppling failure of slopes, effects of groundwater and drainage, design criteria for slopes, remedial measures.

- Gender equality - The Swedish national gender equality goals, reforms that have contributed to increased gender equality, Central concepts used in gender equality work and for development of gender equality knowledge, Introduction to gender mainstreaming in the technical field, Introduction to resources for gender mainstreaming in technical projects.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

This course includes teaching and learning activities such as:

- Lectures - They are a mix of several teaching/learning activities: (i) short theory review where the lecturer explains the most important theoretical aspects related to the course content and (ii) together solve and/or discuss typical rock mechanical problems and questions which gives you the opportunity to work in different ways with several aspects around empirical and analytical stability analyzes of different underground constructions in rock from a practical and theoretical point of view and train calculation procedures for problems related to these.

- Computer exercises - During these we work in computer rooms where we practice on various numerical applications and how they can be used to analyze joint data, stresses, deformation, and the stability of underground structures in rock.

- Field exercise - Here you train in performing and evaluating joint and rock properties in the field as well as presenting the conducted work and results in writing.

- Assignments - You work together with other students and use your knowledge to solve various problems. You present your work in written reports. You train to use and apply empirical, analytical, and numerical analyzes to motivate and suggest how an underground construction in rock should be made stable.

- Between lecture - You are expected to prepare for each lecture by working through the recommended material, recommended exercises and study questions so that you are ready to contribute and participate in the learning activities (problem solving, discussion, etc.) during the lectures, computer exercises, as well as the field and laboratory exercises.

- The course module on gender equality consists of recorded lectures and literature.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through:

- Written tests - Consists of questions testing your theoretical knowledge and understanding of certain rock mechanics aspects related to the content of the course.

- Assignments - Consist of problems where you practice and apply your theoretical knowledge, understanding, and abilities as well as conducting analyses and explaining your results in writing.

- Field exercise - Through the exercise in the field and the submission of a written solution.

- Written exam - You solve problems like those encountered during the course (in lectures and assignments) to test your individual knowledge, understanding, skill and abilities. You are allowed to use the course compendium during the written exam.

- Quiz – to assess your knowledge on gender equality.

Intended learning outcomes 1-7 is assessed through a written exam. Grading scale G/U 3 4 5

Intended learning outcomes 1 and 7 is assessed through field exercise. Included in required assignment with the grading scale G U.

Intended learning outcomes 1-7 is assessed through written tests and the assignments. Included in required assignment with the grading scale G U.

Intended learning outcomes 8 is assessed trough a quiz. Included in required assignment with the grading scale G U.

To be approved on the module required assignment, you must be approved on assignments, laboratory work and field exercises as well as approved on written tests and the quiz.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course T7001B is equal to ABM023

1000

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 3 | Mandatory | A07 |  |
| 0002 | Required assignment | U G# | 4.5 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2006-02-13 and is valid from H- 06.
