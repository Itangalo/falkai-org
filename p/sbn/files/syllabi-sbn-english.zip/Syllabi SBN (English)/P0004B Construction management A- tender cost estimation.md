---
course_code: "P0004B"
title: "Construction management A- tender cost estimation"
credits: "7.5"
title_sv: "Byggstyrning A- Anbudskalkylering"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2023-06-02"
education_level: "First cycle"
grade_scale: "UG"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0004B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p00/p0004b-byggstyrning-a--anbudskalkylering"
---

# Construction management A- tender cost estimation (P0004B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

The main aim of this course is to give basic knowledge in planning and cost estimation of a building project. It provides also knowledge of methods and thinking in this area.

## Contents

- To appoint the scope of a building project - Planning and control of a building project in order to do cost estimation
- Resource planning - Tender cost estimation

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. Teaching will take the form of lectures and work with an assignment report (training in group work and searching of information).

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Approved assignment of written report and oral presentation.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course P0004B is equal to ABP114

## Remarks

Due to similar content, the course cannot be included in a degree together with P0001B or other courses with similar content.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0006 | Project work | UG | 6 | Mandatory | S27 |  |
| 0007 | Short written exam | UG | 1.5 | Mandatory | S27 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02

## Syllabus established

by Department of Civil and Environmental Engineering 2007-01-31
