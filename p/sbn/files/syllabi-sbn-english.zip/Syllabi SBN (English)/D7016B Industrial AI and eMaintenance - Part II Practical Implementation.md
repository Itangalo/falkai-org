---
course_code: "D7016B"
title: "Industrial AI and eMaintenance - Part II: Practical Implementation"
credits: "7.5"
title_sv: "Industriell AI och eUnderhåll - Del II: Praktisk implementering"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2022-02-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7016B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7016b-industriell-ai-och-eunderhall---del-ii-praktisk-implementering"
---

# Industrial AI and eMaintenance - Part II: Practical Implementation (D7016B)

## Main field of study

Maintenance Engineering

## Entry requirements

The student should have knowledge about basic programming skills, databases and cloud computing services, equivalent to D7015B Industrial AI and eMAintenance I. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After the completion of this course student should be able to apply the terms eMaintenance and Industrial AI in industrial contexts. The student should be able to identify as well as apply suitable advanced data analytics techniques related to operation and maintenance processes in industrial contexts.

## Contents

- Implementing the concept of eMaintenance in pratice

- Implementing the concept of Industrial AI

- Implementing related digital and AI technologies

- Developing software

- Applying software engineering

- Implementing AI for maintenance analytics

- Developing information logistics

- Experimenting with distributed computing, cloud/edge

- implementing cybersecurity in eMaintenance solutions

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching includes lectures and project assignments, including implementations. The lectures can be a combination of online, self-study, and/or classroom interaction. The project assignments will be a combination of mandatory and optional tasks such as developing solution (software and/or hardware) and practical report writing.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Course objectives related to both theoretical understanding and practical skills are examined with assignments. The assignments consist of demonstrations and written reports. The students are expected to complete all assignments with a passing grade to pass the course with grade 3. Each assignment will have additional tasks which provides the student with the opportunity to score grade 4 and 5.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment reports | GU345 | 7.5 | Mandatory | A22 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11
