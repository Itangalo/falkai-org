---
course_code: "D7008B"
title: "Condition Monitoring and Condition Based Maintenance"
credits: "7.5"
title_sv: "Tillståndskontroll och tillståndsbaserat underhåll"
valid: "Autumn 2017 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2017-02-10"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Items/credits Number        Type                                                              Credits      Grade  0002          Compulsory group work                                             3.5          U G#  0003          Assignments                                                       4            GU345"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7008B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7008B&lasPeriod=209&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7008b-tillstandskontroll-och-tillstandsbaserat-underhall"
---

# Condition Monitoring and Condition Based Maintenance (D7008B)

## Entry requirements

At least 60 ECTS in one of the following areas: Maintenance Engineering, Energy Engineering, Mechanical Engineering, Materials Science, Civil Engineering or equivalent, and a minimum of 15 ECTS in mathematics.

## Selection

The selection is based on 30-285 credits

## Examiner

Matti Rantatalo

## Course Aim

The aim of the course is to develop skills and capabilities for advanced condition monitoring techniques in order to collect information used for maintenance decision.

## Contents

- Standards maintenance and condition monitoring
- Maintenance strategy and Condition based maintenance
- Inspection and condition monitoring
- Sensor and measurement technology
- Data acquisition and analysis
- Feature extraction and time, frequency and envelope analysis
- Diagnostics and prognostics
- Maintenance decision and scheduling

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The course includes lectures and laboratory work dealing with theory and methods.Knowledge from the course is applied to real industrial problems. The students should demonstrate independent literature studies and oral and written presentation of assignments.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

To obtain a passing grade in the course must the assignments and laboratory work be completed with a passing grade.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Items/credits Number        Type                                                              Credits      Grade

0002          Compulsory group work                                             3.5          U G#

0003          Assignments                                                       4            GU345

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Literature

*Literature. Valid from Autumn 2016 Sp 1* Litterature will be given before course start

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2017-02-10

## Syllabus established

by Eva Gunneriusson 2016-01-19
