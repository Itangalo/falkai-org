---
course_code: "F7017B"
title: "Urban Spaces"
credits: "7.5"
title_sv: "Stadsmiljö"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2022-02-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7017B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f70/f7017b-stadsmiljo"
---

# Urban Spaces (F7017B)

## Main field of study

Architecture

## Entry requirements

F0002B Urban Design or corresponding course

## Selection

The selection is based on 30-285 credits

## Course Aim

The course aims for the students to use their knowledge from previous courses (urban theory, urban design, urban morphology, planning methods etc.) and combine them to develop an urban development project from vision to concrete proposals and make a plan for implementation.

After completing the course, participants should be able to:

Knowledge and understanding

- Explain different urban planning theories and propose appropriate analysis methods for delivering urban development projects.

Competence and skills

- Analyse complex urban environments and asses their potential for developments.

- Develop an urban design proposal.

- Identify determining factors and stakeholders for delivering urban development projects.

- Develop a delivery strategy for an urban design proposal.

- Independently search for and select the appropriate academic literature supporting the urban development proposal.

- Present the urban design proposal and delivery strategy orally and through text and illustrations.

Judgement and approach

- Critically reflect on the theory and methods used in a large-scale urban regeneration project.

## Contents

The course covers analysis of a neighbourhood, development proposal including vision and delivery strategy for the area.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. This course includes teaching and learning activities such as lectures, literature seminars, project work, and supervision.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course aims are examined by seminars and a project work. To pass the seminars (U/G) active participation is required as well as a written reflection. To pass the project work active participation is required and a pass for the oral, written and visual presentations. The project work is graded by G/U 3 4 5.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Projectwork | GU345 | 6 | Mandatory | A16 |  |
| 0003 | Seminars | U G# | 1.5 | Mandatory | A16 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

by Eva Gunneriusson 2016-01-19
