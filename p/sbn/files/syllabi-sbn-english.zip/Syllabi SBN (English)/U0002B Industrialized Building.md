---
course_code: "U0002B"
title: "Industrialized Building"
credits: "7.5"
title_sv: "Industrialiserat byggande"
valid: "Autumn 2019 Sp 1 - Present"
decision_date: "2019-06-19"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=U0002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=U0002B&lasPeriod=200&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/u00/u0002b-industrialiserat-byggande"
---

# Industrialized Building (U0002B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Examiner

Lars Stehn

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project Assignment | U G# | 4.5 | Mandatory | A19 |  |
| 0002 | Individual Assignment | U G# | 3 | Mandatory | A19 |  |

## Literature

*Literature. Valid from Autumn 2019 Sp 1*

## Syllabus established

by Eva Gunneriusson 2019-06-19
