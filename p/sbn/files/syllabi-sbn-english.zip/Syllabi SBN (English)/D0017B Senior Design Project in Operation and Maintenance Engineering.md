---
course_code: "D0017B"
title: "Senior Design Project in Operation and Maintenance Engineering"
credits: "15"
title_sv: "Projektkurs i drift och underhållsteknik"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2019-01-11"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0017B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0017b-projektkurs-i-drift-och-underhallsteknik"
---

# Senior Design Project in Operation and Maintenance Engineering (D0017B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and At least 60 points in approved base and core courses from the Bachelor programme in Maintenance Engineering

## Selection

The selection is based on 1-165 credits.

## Course Aim

The goal of the course is for the student to develop their ability to apply a holistic view on the present and future maintenance situation of an organization. After passing the course the student shall be able to:

- With support from relevant theory, problematize a maintenance problem applying a holistic view on an organization
- Analyse the need for internal and external information necessary in order to develop proposals for problem solving
- Carry out analysis on and present consequences of developed proposals for problem solving
- Design, organise and control a development process aiming at solving maintenance problems
- Perform oral and written reports on analysis and proposals to problem solving, with a holistic view on an organisation

## Contents

In a project team, students will work in an integrative way and with a holistic view on a business organization; apply knowledge and abilities developed in previous courses (see prerequisites) in maintenance engineering.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

Seminars and supervision. The course contains project work in contact with business sector. Compulsory attendance can be required.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The written project report examines student’s abilities in problematizing, applying relevant theories, analysing the need for internal and external information, carrying out analysis on and present consequences of maintenance proposals. The student’s ability of designing, organising and controlling a development process aiming at solving maintenance problems is examined by problem specification report, project plan and weekly project reports. Oral presentation of project work and oral presentation assignment examine the ability to present analyses and proposed problem solutions and further the ability to review and reflect on other student’s analyses, problem solutions and predicted consequences..

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignments | U G# | 4 | Mandatory | S16 |  |
| 0002 | Project report | GU345 | 11 | Mandatory | S16 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-01-11

## Syllabus established

by Eva Gunneriusson 2015-02-11
