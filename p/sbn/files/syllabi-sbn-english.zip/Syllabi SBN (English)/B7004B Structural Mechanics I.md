---
course_code: "B7004B"
title: "Structural Mechanics I"
credits: "7.5"
title_sv: "Byggnadsmekanik I"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Konstruktionsteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B7004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B7004B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/b70/b7004b-byggnadsmekanik-i"
---

# Structural Mechanics I (B7004B)

## Main field of study

., Civil Engineering

## Entry requirements

A basic course in strength of materials, like B0002B Structural engineering

## Selection

The selection is based on 30-285 credits

## Course Aim

The aim of the course is that the student should be able to

- explain the difference between statically determinate and statically indeterminate structures

- calculate section forces (normal forces, shear forces and bending moments) in statically indeterminate 2- dimensional trusses and frames

- calculate deformations (displacements and rotations) in statically indeterminate 2-dimensional trusses and frames

- apply and determine influence lines to calculate sections forces by live loads on 1-dimensional statically determinate and statically indeterminate structures

- calculate sections forces and stresses by torsion of elements with circular cross section and by skew bending

- determine principle moments of inertia

- plan and execute calculation tasks in group, process results and present them in writing (calculation report)

## Contents

Section forces and deformations in statically indeterminate 2-dimensional trusses and frames with

- Energy methods:

    - Castigliano’s theorem

    - Principle of least work

    - Principle of virtual work

- Displacement method

- Force method

Sections forces by live loads on 1-dimensional statically determinate and statically indeterminate structures with

- application of known influence lines

- determination of new influence lines with general principles for one or several concentrated loads and for distributed loads

Sections forces and stresses by torsion of statically determinate and statically indeterminate elements with circular cross sections

Principle moments of inertia for symmetrical and for unsymmetrical cross sections

Stresses by skew bending

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

Students take part in lectures where backgrounds and theories to the course content are derived, presented and exemplified.

The students practice the calculation methodology of the course content

- individually on practice sessions in the classroom and in the computer room for simpler structures (a few elements)

- in groups for larger structures, partly in a design task where a truss is constructed and calculated, partly in two project tasks where two different frames are analysed with computer programs

The students practice the ability to plan, carry out and report calculation tasks in groups in one design task and in two project tasks.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Background and theories are examined with a written part-time exam (“dugga”). Calculation methodology for simpler supporting structures (a few elements) is examined with a written final exam. The results from the two exams are summarized. Grading scale: U, 3, 4, 5.

Calculation methodology for larger structures is examined through written calculation reports for the design task and the project tasks. For passing the course, approved calculation reports are required.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course B7004B is equal to B0004B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 6 | Mandatory | S11 |  |
| 0004 | Calculation tasks | UG | 1.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Lars Bernspång 2010-03-01
