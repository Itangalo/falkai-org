---
course_code: "M7007K"
title: "Process mineralogy"
credits: "7.5"
title_sv: "Processmineralogi"
valid: "Spring 2019 Sp 4 - Autumn 2022 Sp 2"
decision_date: "2019-01-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Mineralteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7007K&lasPeriod=209&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/m70/m7007k-processmineralogi"
---

# Process mineralogy (M7007K)

## Entry requirements

90 credits in Chemical Engineering, including the course M0001K Mechanical ProcessTechnology.

## Selection

The selection is based on 30-285 credits

## Examiner

Yousef Ghorbani

## Course Aim

The student gets the possibility to develop skills in process mineralogy. After the course students are expected to be able to:
- Describe the principles behind process mineralogy and the quantitative analytical methods that are used,
- Apply in practice, different research and analytical methods of importance for process mineralogy. e.g., optical microscopy, XRD, SEM, liberation analysis
- Evaluate, analyse and interpret the process mineralogical data in a quantitative way
- Formulate a process mineralogical troubleshooting procedure for different kind of process related questions

## Contents

The course gives an introduction to the mineralogy of the most common ore types in Sweden and its influence on their processing. Important analytical methods are presented, how the analyses are done in practice, how data is processed and how the results are interpreted. It consists of the following parts:
- Process mineralogical analyses and research methods: optical microscopy, XRD, SEM, WDS,
- Process mineralogical calculations: elements to minerals conversions, distribution of elements between minerals, distribution of minerals between size fractions, sample density, composition of mineral fractions,
- Processing of particles; the most important process stages,
- Characterisation methods for particles: particle size, particle size distribution, mineral liberation
- Process mineralogy of the most important ore types in Sweden.
- Exercises of analysis methods, calculations and how results are interpreted; write laboratory and exercise reports
- Project: students must write project report and giving a presentation

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The instruction consists of lectures, PC lessons, assignments, compulsory laboratory classes, and compulsory seminars.
- The lectures are used to give the students the possibility to plan and conduct process mineralogy investigations, and to explain theoretical concepts.
- PC-lessons and assignments are used to train calculation procedures and techniques,
- Laboratory classes concern analytical methods, process mineralogy calculations, and interpretation of results,
- The project is used to (in groups) describe, analyse, evaluate, interpret, report and present the result of a process mineralogy investigation. It is reported at two seminars, the first to describe for the other groups the material and the intended work. The second seminar is used for reporting of the work done, and there is a prepared opponent group. The opponent group have written a short assessment of the responding group’s report and must during the seminar orally criticise the report. Laboratory and project reports should be technically, mineralogical and grammatically correct.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Laboratory classes, process mineralogy investigation and the seminars are compulsory. Laboratory reports, project including seminars, the investigation and the opposition are each awarded points based on the attained level. Assignments and reports must be delivered in time or there will be an automatic deduction of points. The total points production determines the grand grade of the course, and it is given on the scale U 3 4 5. For grade 3, the student must be able to describe procedures for, and to conduct, routine process mineralogy analysis. For grade 4, the student must be able to evaluate and interpret process mineralogy by different analytical techniques and to report the results. For grade 5, the student must be able to apply the acquired skills to a new process mineralogy material, interpret, report and present the results and to defend the conclusions.

## Remarks

The first lecture is compulsory for all students. Permission to be absent is given by the teacher responsible for the course. Course is on LMS in the course room.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Laboratory work | GU345 | 3.5 | Mandatory | S13 |  |
| 0004 | Project | GU345 | 4 | Mandatory | A14 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Literature

*Literature. Valid from Spring 2013 Sp 3* Compendium provided by the teacher.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-01-11

## Syllabus established

by Eva Gunneriusson 2012-03-14
