---
course_code: "K7020B"
title: "Steel Structures"
credits: "7.5"
title_sv: "Stålkonstruktioner"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Konstruktionsteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7020B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7020B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7020b-stalkonstruktioner"
---

# Steel Structures (K7020B)

## Main field of study

., Civil Engineering

## Entry requirements

At least 90 credits completed courses where 30 credits of courses in building materials, structural engineering, structural design and structural mechanics should be included, for instance K0002B Building Materials, B0002B Structural Engineering, K0013B Structural Design and B7004B Structural Mechanics I. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course students should be able to:

Knowledge and Understanding

1. Explain the theoretical foundations and factors contributing to local buckling and lateral-torsional buckling in steel girders.

2. Explain the concept of flexural buckling in steel columns, including its causes and implications.

Competence and Skill

3. Demonstrate the ability to use both elastic and plastic theories to design steel girders, considering relevant design codes and safety factors.

4. Skilfully incorporate several types of buckling (local, lateral-torsional, flexural) into the design process of steel girders and columns, ensuring structural stability.

5. Design and detail effective welded and bolted connections in steel structures, considering load transfer and material properties.

Judgment and Approach

6. Assess and identify potential failure modes in experimental setups, demonstrating the ability to determine the maximum load-bearing capacity of steel structures.

7. Utilize clear and concise communication skills to present results and design solutions both orally and in written reports, ensuring the effective transfer of technical information.

## Contents

Theory and design rules for stability issues such as:

- Local flange buckling

- Shear buckling of web plates

- Flexural buckling of columns

- Torsional buckling of columns

- Lateral-torsional buckling of steel girders

Fatigue of steel structures

- Background and design rules

Welded connections

- Background and design rules

Bolted connections

- Background and design rules

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The students participate in lectures where backgrounds and theories to the course content are derived, presented, and exemplified.

Theoretical principles and calculation methods are applied by students in three settings:

1. Individually, through practical exercises conducted in classroom sessions.

2. Individually or in small groups through a project work.

3. Collaboratively in groups, as they prepare, execute, and analyse laboratory.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. This course is examined by few different forms of assignments: laboration, written reports, calculation/design assignments, oral presentations, quizzes.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignments | GU345 | 7.5 | Mandatory | S25 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14
