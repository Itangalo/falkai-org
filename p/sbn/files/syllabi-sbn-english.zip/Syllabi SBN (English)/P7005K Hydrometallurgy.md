---
course_code: "P7005K"
title: "Hydrometallurgy"
credits: "7.5"
title_sv: "Hydrometallurgi"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2023-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Processmetallurgi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7005K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7005K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p70/p7005k-hydrometallurgi"
---

# Hydrometallurgy (P7005K)

## Main field of study

Chemical Engineering

## Entry requirements

90 credits in Chemical Engineering, including the course K0011K Inorganic Chemistry.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course the student shall be able to;

1. understand and be able to use hydrometallurgical phase diagrams.

2. describe how leaching mechanisms and how kinetics are influenced by factors as temperature, particle size, stirring, etc.

3. describe the hydrometallurgical unit operations and methodology and equipment used for treatment of different raw materials.

4. account for the most common hydrometallurgical processes and the chemical principles for these.

5. conduct, evaluate and report experimental hydrometallurgical work.

6. identify, formulate and treat complex engineering questions.

## Contents

- Introduction: Comparison of pyrometallurgical and hydrometallurgical process technology. Overview of hydrometallurgical unit operations and processes.

- Hydrometallurgical phase diagrams: Solubility and Pourbaix diagrams.

- Leaching: Theory, kinetics, reagents, methods and materials.

- Separation and solution purification: Chemical precipitation, cementation, crystallisation, ion-exchange and solvent extraction.

- Metal recovery: Electrolytic processes (electrorefining, electrowinning, smelt electrolysis) and gas reduction.

- Hydrometallurgical processes: Examples of hydrometallurgical applications with environmental considerations.

- Project including laboratory exercises: Leaching and electrolysis

- PC exercise: Construction of Pourbaix diagrams with FactSage software

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The course consists of lectures, project including laboratory exercises, four individual assignments and a study visit

The lectures and assignments give the students possibilities to understand chemistry and technology of the hydrometallurgical unit operations and understand the implications of different process options on economy and environment.

Laboratory exercises are performed in a group of normally two students. The students are trained in planning, cooperation, evaluation and writing reports. Study visit gives the students insight and feeling for full-scale processes.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Intended learning outcome is assessed through oral exam, written report on the project including laboratory work and written assignments.

An oral exam with grades U, 3, 4 and 5 assess the theoretical understanding for learning outcomes 1-4.

The written project report includes laboratory excercises with grades U and G assess the learning outcomes 2, 4 and 5.

Written assignments with grades U and G assess the learning outcomes 1-4 and 6.

Project with laboratory exercises, assignments and the study visit are compulsory.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0006 | Oral exam | GU345 | 3 | Mandatory | A07 |  |
| 0007 | Four assignments, hand-in | UG | 2 | Mandatory | S27 |  |
| 0008 | Project | UG | 2.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
