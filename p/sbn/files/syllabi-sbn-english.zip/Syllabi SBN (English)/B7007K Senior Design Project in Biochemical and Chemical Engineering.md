---
course_code: "B7007K"
title: "Senior Design Project in Biochemical and Chemical Engineering"
credits: "15"
title_sv: "Projektkurs i Biokemisk och kemisk processteknik"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2023-06-02"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Kemiteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B7007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B7007K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/b70/b7007k-projektkurs-i-biokemisk-och-kemisk-processteknik"
---

# Senior Design Project in Biochemical and Chemical Engineering (B7007K)

## Entry requirements

At least 90 credits in Chemical Engineering. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2. For exchange students, the examiner makes an individual examination of the qualification depending on the type of project.

## Selection

The selection is based on 30-285 credits

## Course Aim

The student shall independently design, carry out and report a project within the subject of Biochemical Process Engineering.

Upon completion of the course the student will be able to:

- Formulate a relevant problem for investigation within the subject of Biochemical Process Engineering.

- Apply your theoretical knowledge that you acquired during your studies to a research project in an independent and systematic way.

- Choose and justify the study research methods.

- Effectively plan and implement a project work within the chosen research topic.

- Solve problems independently in the project.

- Locate and critically review scientific information relevant to the project.

- Evaluate your results by using the theoretical knowledge you learned.

- Write a scientific report, give an oral presentation and defend the conclusions.

## Contents

The project topic is related to the current research frontiers of the biochemical process engineering and will be defined in cooperation with the examiner. Example of topics (but not limited) are the use of microorganisms (such as microalgae, bacteria, yeast and fungi) and enzymes for the production of high-added value products (bioenergy, chemicals, materials, etc) from renewable resources (such as biomass, organic wastes and CO2).

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The student will work independently under the guidance of a teacher that will be assigned based on the chosen research topic. Students will be given access to relevant laboratory facilities of biochemical process engineering, including analytical instrumentation. Prior to use of scientific and analytical equipment, appropriate training and safety instructions will be given. Students will have regular communication with the teacher to ensure that they receive appropriate support and monitor the progress of the project.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The learning objectives are examined through a written report and an oral presentation with grades according to G, U, 3, 4 and 5. Practical application of the learning outcomes is examined via the project work.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Passed oral and written presentation | GU345 | 15 | Mandatory | A21 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17
