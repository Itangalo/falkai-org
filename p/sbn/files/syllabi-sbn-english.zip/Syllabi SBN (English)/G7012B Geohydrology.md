---
course_code: "G7012B"
title: "Geohydrology"
credits: "7.5"
title_sv: "Geohydrologi"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Hydrologi"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7012B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7012b-geohydrologi"
---

# Geohydrology (G7012B)

## Main field of study

Geosciences

## Entry requirements

90 credits in Geoscience, including the courses O0035K Geology, basic course and L0039K/V0017B Natural Water Transport Processes or similar courses or V0014B Hydraulics and Geology or similar course

## Selection

The selection is based on 30-285 credits

## Course Aim

After passing the course, the student should be able to:

- calculate groundwater level, flow rate and direction in an area using soil properties and water level pipes (piezometers)

- determine the hydraulic parameters that characterize an aquifer using measurement data from performed pumping tests

- design drainage, damming structures and barriers for e.g. construction work using hydraulic parameters

- calculate leakage through dams, dikes, dams, etc., by geometric and numerical iteration

- design pumping and observation wells

- describe the laws that control the water flow in the unsaturated zone

- describe methods used to prevent salt water penetration, pollution transport in groundwater and leakage from waste storage

After the course, the future civil engineer should be able to work for a consulting company or in industry as an administrator with a hydrogeological survey.

## Contents

This course provides the student with knowledge of groundwater theory that can be applied in areas such as drainage, drinking water supply, construction, foundation, dam safety, soil remediation, etc.

The course deals with:

- Groundwater availability in different types of bedrock and soil layers.

- Relationship between precipitation and sustainable groundwater abstraction.

- Estimation of transmissivity using horizontal flow nets.

- Calculation of two-dimensional stationary flow using vertical flow nets.

- Pumping tests: Test pumping in wells for determining aquifer characteristics and assessment of possible withdrawal, groundwater lowering, etc.

- Well hydraulics in open and closed aquifers. Theis, Thiems and Cooper-Jacobs methods.

- Interference effects between several wells. Method of mirror wells to describe sources and sinks.

- Saltwater intrusion.

- Unsaturated flow: Unsaturated hydraulic conductivity, pF curves, tensiometers, total potential, determination of unsaturated water content.

- Landfill hydrology: Use of water balance equations to minimize leachate formation. Measurement and calculation methods for water balance parameters in a landfill.

- Construction of pumping and observation wells

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures, written and oral presentation of theoretical assignment, discussion and oral presentation in two problem solving workshops, and two computer labs, in which Geostudio SEEP / W and Modflow are demonstrated.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is examined in several parts:

1. The course includes two student-led problem-solving workshops, where the topics of the course are discussed. All problems that are reviewed aim to prepare the students for the final written exam. Mandatory attendance and participation are required for a passing grade.

2. Two computer labs are conducted during the course, where the simulation programs Geostudio SEEP / W and Modflow are demonstrated. The data labs have a mandatory attendance and mandatory submission of the correct solution is required for a passing grade.

3. A written report on any subject in geohydrology must be submitted and presented orally at the closing seminar. Mandatory attendance and participation are required for a passing grade.

4. Written examination completes the course and is graded according to the scale U 3 4 5.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids

not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course G7012B is equal to L7019K

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 5 | Mandatory | S16 |  |
| 0004 | Written assignment | UG | 1.5 | Mandatory | S27 |  |
| 0005 | Computer laboratory work | UG | 1 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2015-05-19
