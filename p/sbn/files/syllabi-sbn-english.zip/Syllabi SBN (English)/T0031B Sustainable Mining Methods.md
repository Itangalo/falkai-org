---
course_code: "T0031B"
title: "Sustainable Mining Methods"
credits: "7.5"
title_sv: "Hållbara brytningsmetoder"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2025-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0031B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0031B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t00/t0031b-hallbara-brytningsmetoder"
---

# Sustainable Mining Methods (T0031B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and L0049K Sustainable Resource Engineering 1. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course, the student should be able to:

Knowledge and understanding

1. Understand mining methods and sustainability.

2. Describe current mining methods (main ones).

Competence and skills

3. Identify how sustainability principles be applied in each mining method.

4. Demonstrate how sustainability principles be applied in each mining method.

## Contents

The course covers the existing mining methods and sustainability principles, and how the principles can be applied in each method.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. Group assignments combined with lectures and study visits.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Goals/ILO:s are assessed through written assignments and a written final exam as follows:

Group assignments assess ILO 1, 2, 3, 4.

Final exam assesses ILO 1 and 3.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4.5 | Mandatory | S26 |  |
| 0003 | Assignments | UG | 3 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
