---
course_code: "D7001B"
title: "Mine Automation"
credits: "7.5"
title_sv: "Gruvautomation"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7001B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7001b-gruvautomation"
---

# Mine Automation (D7001B)

## Main field of study

Civil Engineering, Maintenance Engineering

## Entry requirements

T0013B Rock Engineering and Rock Mechanics or corresponding course. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

The aim of the course is to provide knowledge about different aspects of automation in the mining and underground construction industry, and the latest development in the field. After the completion of the course the students should:

- know how to consider human factors in automation

- understand how operational data from mining equipment can be used in the mining process

- have knowledge of automation of mining equipment

- have competence to perform reliability analysis of automated systems

- know how AI concept can be used in mining automation

- have knowledge of indoor and outdoor navigation systems in mines

## Contents

The course addresses

- Surface and underground mine automation

- Automation of drilling and drill rigs

- Automation of underground loading and transportation systems

- Automation in tunnelling projects

- Automation of surface mining

- Reliability of automation systems and units

- Human factor-related problems

- Data communication and modern computerised control systems

- Data formats and IREDES

- AGV technology, navigation and GNSS (satellite navigation)

- AI in mine automation

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course is based on lectures and project assignments.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Written exam with differentiated grades and assignments during the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course D7001B is equal to ABD014

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4.5 | Mandatory | A07 |  |
| 0003 | Assignment reports | U G# | 3 | Inactive | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
