---
course_code: "G0005B"
title: "Solar Heating Systems"
credits: "7.5"
title_sv: "Solvärmesystem"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0005B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0005B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g00/g0005b-solvarmesystem"
---

# Solar Heating Systems (G0005B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Upper secondary school courses English 6, Physics 2, Chemistry 1, Mathematics 4 or Mathematics E. Or: English level 2, Physics level 2, Chemistry level 1, Mathematics Further level 2 or Mathematics E.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

After completing the course, the student will be able to

- dimension a solar collector system for residential use through both manual calculations and computer simulations,

- make estimations of solar radiation at any place in the world with the help of statistical cloud models,

- describe and evaluate different types of solar heating systems

- analyze the performance of a solar PV system for residential use.

## Contents

This course provides theoretical and practical knowledge of how solar energy can be used for heat and electricity production on a small and large scale.

Specifically, the course covers:

- The potential of the sun: International overview of the use of solar energy.

- Solar energy: The annual variations of solar radiation. Calculation of solar radiation against a surface. How geography, topography and the location of the solar panels / solar cells affect the efficiency of the system.

- Solar heating systems: Description of small and large-scale solar heating systems, components of a solar heating system, examples of existing solar heating systems.

- Solar collector theory: Different types of solar collectors and their uses.

- Solar cell theory: Description of the solar cell, construction efficiency and economy.

- Dimensioning: Dimensioning of solar heating systems for different purposes (Aids: Excel or similar).

- System simulation: Dimensioning of a solar heating system using the computer program Polysun.

- Mandatory study visit to a solar heating system.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The teaching consists of lectures and project work in groups of 1-3 students. The project consists of designing and simulating the performance of a solar heating system for a house/facility of the student’s own choosing. Each lecture is meant to take students to the next level in their solar heating project work. In the final phase of the course, a computer laboratory and a compulsory study visit to a solar heating system are performed. The course does not contain oral presentations.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The assessment of the course aims is based on the result of the project work result, which is divided into three subprojects with an accompanying theoretical quiz. The subprojects are evenly distributed throughout the course and contain the following:

Part 1: calculation of how the angle of incidence and intensity of solar radiation varies with time, location, and cloudiness.

Part 2: Theory, design, and dimensioning of solar collectors.

Part 3: Estimation of a villa's heating and hot water needs and dimensioning of the solar heating system (through own calculations and through computer simulations). Economic analysis of the system. One compulsory study visit to a solar heating facility.

A prerequisite for a passing grade is that group work is submitted within set deadlines. The combined assessment of project work and quizzes gives the final grade according to U(failed) 3 4 5.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course G0005B is equal to E0002B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0004 | Assignment report | GU345 | 6.5 | Mandatory | A15 |  |
| 0006 | Required assignment | UG | 1 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Eva Gunneriusson 2015-02-12
