---
course_code: "D7021B"
title: "Reliability and Maintenance Engineering"
credits: "7.5"
title_sv: "Driftsäkerhet och underhållsteknik"
valid: "Autumn 2025 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2025-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7021B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7021B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7021b-driftsakerhet-och-underhallsteknik"
---

# Reliability and Maintenance Engineering (D7021B)

## Main field of study

Civil Engineering, Maintenance Engineering

## Entry requirements

90 ECTS in engineering subjects. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 30-285 credits

## Course Aim

This course is designed to provide students with fundamental principles and underlying concepts of maintenance engineering, allowing them to analyze system reliability, assess risk of failures and develop effective maintenance strategies to enhance operational efficiency, safety, and cost-effectiveness. The course emphasizes the application of reliability and maintenance engineering in industry, including areas such as mining and civil engineering. Upon successful completion of the course, students should demonstrate the following Intended Learning Outcomes (ILOs):

Knowledge and Understanding 1. Explain Reliability, Availability, Maintainability, and Safety (RAMS) principles and evaluate their interrelationships and applications in assessing RAMS performance of a system. 2. Explain the underlying concepts, applicability, and effectiveness of different maintenance strategies. 3. Demonstrate a general understanding of maintenance engineering principles and their application to real-world industrial challenges

Competence and Skills 4. Perform basic reliability analysis and apply basic system reliability models 5. Demonstrate the ability to utilize risk evaluation techniques 6. Use maintenance methodology to identify applicable and effective maintenance strategies

## Contents

- Maintenance and life cycle management
- Fundamentals of RAMS (Reliability, Availability, Maintainability and Safety)
- System performance assessment
- Basic reliability life data analysis and system reliability analysis
- Maintenance strategies, applicability and effectiveness criteria
- Reliability-centered maintenance (RCM)
- Risk analysis in engineering, including methods such as Failure Modes and Effects Analysis (FMEA), Fault Tree Analysis (FTA), Event Tree Analysis (ETA), and Hazard and Operability Study (HAZOP)
- Maintenance modeling and optimization
- Human factor in maintenance engineering

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

Lectures will present the core concepts with examples, using slides and board. The lectures will be supported by group assignments, to reinforce the understanding of each topic. Students are required to interact to solve problems, apply, explain, analyze, or identify aspects of the subjects presented. The students will also work on a number of extended group project and individual exercises and assignment to strengthen their learning of each topic. In case of group work, the students are required to submit a report supported by a group presentation, to get comments for improvement from the participants and the instructor. Individual assignments will be reviewed by the teachers to provide the students constructive comments and guidance.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course assessment includes two mandatory components: a written exam and assignment reports. The written exam assesses students’ comprehensive understanding of the core course content related to the ILOs. The exam, graded on a U, 3, 4, 5 scale, is worth 5 credits. In addition, students must complete and pass their assignment, graded on a U, G scale, contribute 2.5 credits to the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 5 | Mandatory | A25 |  |
| 0002 | Assignments | U G# | 2.5 | Mandatory | A25 |  |

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
