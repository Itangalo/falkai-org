---
course_code: "P0005B"
title: "Construction management B- Construction Planning"
credits: "7.5"
title_sv: "Byggstyrning B- Produktionsplanering"
valid: "Spring 2022 Sp 3 - Spring 2023 Sp 4"
decision_date: "2021-04-20"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0005B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0005B&lasPeriod=206&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p00/p0005b-byggstyrning-b--produktionsplanering"
---

# Construction management B- Construction Planning (P0005B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Construction management A- tender cost estimation

## Selection

The selection is based on 1-165 credits.

## Examiner

Johan Larsson

## Course Aim

The main aim of this course is to give basic knowledge in construction planning of a building project. It provides also knowledge of methods and thinking in this area.

## Contents

This course covers:

- Planning and control of a building project in a production phase

- Logistic planning of the work space

- Quality- and environmental planning, plans for control

- Planning of the organisation

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. Teaching will take the form of lectures and work with an assignment report (training in group work and searching of information).

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Approved assignment of written report and oral presentation, and also written exam.

## Overlap

The course P0005B is equal to ABP115

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Project work | U G# | 6 | Mandatory | A07 |  |
| 0004 | Short written exam | U G# | 1.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Literature

*Literature. Valid from Spring 2022 Sp 3* Recommended:
- Mats Persson (upplaga 1:2) Planering och beredning av bygg- och anläggningsprojekt. Studentlitteratur Lund. ISBN978-91-44-05773-6
- Sveriges byggindustrier (2013). Byggarbetsplatsens teknikhandbok. ISSN: 1652-6384.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-04-20

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
