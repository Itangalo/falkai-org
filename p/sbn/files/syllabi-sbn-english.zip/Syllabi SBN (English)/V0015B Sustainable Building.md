---
course_code: "V0015B"
title: "Sustainable Building"
credits: "7.5"
title_sv: "Hållbart byggande"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0015B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/v00/v0015b-hallbart-byggande"
---

# Sustainable Building (V0015B)

## Main field of study

Architecture, Civil Engineering, .

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Knowledge of construction and building materials etc. V0011B, F0007B and K0002B.

## Selection

The selection is based on 1-165 credits.

## Course Aim

When you have taken this course you should be able to:

Knowledge and understanding

1. explain the concept “Sustainable development” at a national and global level; the origin of the concept, how it has developed and the definitions and of today.

2. explain the structures and functions of the ecosystems which contribute with resources and be able to relate these to the building.

3. explain and compare reasons that threaten a sustainable development of society. Be able to give examples and explain effects of non-sustainable activities and relate these to building.

4. explain what economical, juridical, political and sector specific steering tools and system analyses that are available and relate these to sustainable development and sustainable building.

5. describe energy, material and waste flows in society and give examples concerning handling of materials and recycling possibilities in construction. 6. give examples in which way urban areas can be planned, designed and be built to achieve sustainable development to decrease the environmental pressure on nature and culture environments and improve the social conditions.

Competence and skills 7. write and review scientific manuscripts and argue with scientific references.

Judgement and approach 8. give examples of and reflect about an engineer’s professional role and responsibility to achieve a sustainable development of society. 9. discuss and reflect on and critically remain to sustainable development in relation to planning, building and construction in relation to working environment and with a system perspective.

## Contents

In this course, the concept sustainable development will be dealt with from ecological, economic and social perspectives and relate this to building of society and construction. Threats towards sustainable development will also be dealt with. Flows of materials and waste in society and recycling possibilities in construction is also included in the course as well as steering tools to promote a sustainable development. Within the course frame, focus is also on scientific writing, and argumentation with scientific references as well as how citations should be made in scientific texts. Working environmental aspects in relation to the building sector are also included in the course.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course consists of lectures, a project task and mandatory seminar series. Theoretical parts will be dealt with at lectures. The aim of the project task is to give the students a possibility of working more practically with the concept sustainability development and relate the concept to building of society and construction. The project work results in an article of scientific format and is presented in small groups. By the seminars and the reflection task, the students are given opportunity to reflect more about sustainable development, how the concept has developed during the years as well as about their own role and responsibility as a future professional engineer about a sustainable development in the building sector.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course aims 1-6 are examined with written exam (#0005). The course aims 8 and 9 are examined by active participation at the seminars (#0007) and with an individual written reflection (#0008). The course aims 3, 4, 6, 7 and 9 are examined by a project task (#0006). To pass the project task pass is needed for a written article, an individual written opposition as well as active participation at the oral presentation.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course V0015B is equal to L0010N

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Written exam | GU345 | 4.5 | Mandatory | A09 |  |
| 0006 | Project task | GU345 | 2.5 | Mandatory | A09 |  |
| 0007 | Seminar | U G# | 0.3 | Inactive | A09 |  |
| 0008 | Assignment | U G# | 0.2 | Inactive | A09 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13

## Syllabus established

by Department of Civil and Environmental Engineering 2009-01-20
