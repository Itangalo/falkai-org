---
course_code: "A7001B"
title: "Landfill Technology"
credits: "7.5"
title_sv: "Upplagsteknik"
valid: "Autumn 2024 Sp 1 - Autumn 2025 Sp 2"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Miljöteknik"
subject_group_scb: "Environmental Care and Environmental Protection"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=A7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=A7001B&lasPeriod=221&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/a70/a7001b-upplagsteknik"
---

# Landfill Technology (A7001B)

## Main field of study

Natural Resources Engineering, Civil Engineering

## Entry requirements

At least 90 hp in Chemical Engineering, Geoscience or Natural Resource Engineering. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 30-285 credits

## Course Aim

The aim of the course is to provide a basic understanding of the design, construction, function and role of landfills in society, as well as to impart practical skills in the area required for further work, e.g. as a consultant, in industry, at private or municipal waste companies or at municipal environmental offices.

After passing the course, the student should be able to:

- Apply scientific principles and methods in landfill technology.

- Calculate the consequences of important processes in and around landfills, such as leachate formation or gas formation potential by applying chemical and physical principles.

- Explain safety rules in the environmental laboratory and perform practical laboratory tasks.

- Work in groups, both as a group member and as a project manager.

- Evaluate results and present them both in writing (technical report) and orally (presentation).

The student should be able to describe and discuss:

- The role of landfills in waste management systems.

- The design and construction of landfills.

- Conversion processes in landfills.

- Methods for management and treatment of landfill gas and leachate

- The interaction of landfills and their environments

The student must be able to account for:

- The legal framework and regulations that govern landfilling

- The more important chemical and biological processes that affect landfills
- Methods for waste characterization

## Contents

The course deals with the role and function of landfills in the waste management system, landfill siting, construction, operation and completion. Both technical aspects and current legislation in the area are covered. Factors that affect the location and establishment of new landfills are discussed, such as geological and hydrological conditions, as well as properties of the waste that control the conversion processes that lead to the generation of emissions, such as leachability and biodegrade-bility. Landfill gas and leachate are examples of material flows that must be controlled and treated. For example, we will calculate how much gas can be expected to be formed in a landfill and discuss how it can be treated and used. Landfill closure, final coverage and after-care are discussed from both a technical point of view and with regard to the long-term sustainability of the deposit.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

Teaching takes place in the form of lectures, seminars, a study visit, laboratory work, individual work and project work in groups. Each student explores and presents orally about landfilling in their home municipality or their home country. The main topics of the area are introduced in a series of lectures and subsequently discussed in-depth in seminars where also relevant calculations are practiced. Early in the course, a project work is initiated in groups of 3-5 students related to current research in landfill technology. The project work contains two parts - a literature study and an experimental part with laboratory work. In addition to writing a report, each group presents its project twice - the planning and the laboratory methods at the beginning and the results and evalua-tion at the end of the course. Opposition to another group's report and oral presentation are also included in the project work. Great focus is placed on the evaluation of the results, cooperation in the group and between the groups.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is examined as follows:

The learning objectives regarding knowledge about landfilling, scientific principles and methods in landfill technology, including calculations, are examined through a written individual examination. Grading according to grade scale G U 3 4 5. To pass the course, the student must also complete the project work (in groups) with an approved report, two presentations and opposition, participate in the study visit and orally present a self-selected landfill to the class. All examination parts must be completed for the final grade on the course

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a

conflict.

## Overlap

The course A7001B is equal to ABA003

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0009 | Project work | U G# | 3 | Mandatory | A07 |  |
| 0010 | Landfill presentation and excursion | U G# | 1 | Mandatory | A07 |  |
| 0011 | Written exam | GU345 | 3.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Department of Civil and Environmental Engineering 2009-03-10
