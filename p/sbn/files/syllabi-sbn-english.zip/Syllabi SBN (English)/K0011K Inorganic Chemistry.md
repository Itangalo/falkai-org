---
course_code: "K0011K"
title: "Inorganic Chemistry"
credits: "7.5"
title_sv: "Oorganisk kemi"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Kemi"
subject_group_scb: "Chemistry"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0011K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0011K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k00/k0011k-oorganisk-kemi"
---

# Inorganic Chemistry (K0011K)

## Main field of study

Chemical Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Chemical Principles (K0016K)

## Selection

The selection is based on 1-165 credits.

## Course Aim

After taking the course, you shall be able to - apply the connections and theories that explain the composition and characteristics of various substances. - explain the fundamental causes to hydrolysis and acid-base strengths of various substances and ions. - explain and apply the thermodynamics for dissolution and precipitation. - conclude the speciation of various substances by the use of equilibrium diagrams. - describe and apply some basic theories within coordination chemistry. - use the chemical nomenclature for inorganic substances and ions, including some common exceptions. - explain the causes of corrosion and suggest and explain the appropriate actions available to prevent corrosion. - describe various differences and similarities among the elements. - describe the characteristics and in some cases the preparation of more important substances.In addition, you should have gained increased knowledge of the practical applications that exist of inorganic chemistry, globally as well in Sweden.

## Contents

Reactions in solutions : Ion potential – hydrolysis/hydration. Acid and base definitions. Theoretical aspects on acid- and base strength, both in aquatic and other solvents. Thermodynamic, equilibrium chemical and reaction kinetic aspects on solubility. The chelate effect.

Corrosion: Electrochemical and chemical corrosion. Catodic protection. Passivation, inhibition, immunity.

Coordination compounds : Ligand fields, molecular orbitals. Catalysis. Bioinorganic coordination compounds.

Descriptive chemistry with reference to the periodic table

Laboratory exercises : Composed of applications of Reactions in solutions.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of lectures and laboratory exercises. The first lecture is compulsory as well as the laboratory exercises.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Graded exam. Passed assignments, lab. exercises and reports.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K0011K is equal to KGK025

## Remarks

Syllabus can be downloaded from the course room on Fronter.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0006 | Written exam: Reactions in solutions | GU345 | 3 | Mandatory | A07 |  |
| 0007 | Written exam: Coordination compounds | GU345 | 2 | Mandatory | A07 |  |
| 0010 | Descriptive chemistry | UG | 1 | Mandatory | S27 |  |
| 0011 | Laboratory work | UG | 1.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
