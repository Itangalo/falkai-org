---
course_code: "D0010B"
title: "Maintenance Strategy"
credits: "7.5"
title_sv: "Underhållsstrategi"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0010B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0010B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0010b-underhallsstrategi"
---

# Maintenance Strategy (D0010B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on 1-165 credits.

## Course Aim

The aim of the course is to provide students with knowledge of how maintenance strategies can be applied to achieve production goals and put these in relation to overall business goals. After passing the course, the student should demonstrate proficiency in developing a maintenance strategy for an industrial system by developing maintenance plans for included units.

## Contents

The course deals with:

- Maintenance process in an industrial organization

- System and flow mapping of industrial systems

- The plant's life cycle costs

- Maintenance goals in relation to company goals

- Methods and principles for preventive maintenance

- Reliability Centered Maintenance (RCM)

- Methods for developing a maintenance strategy

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. Teaching consists of seminars and assignments. It is expected that students are prepared for the seminars by going through the prescribed material. Active participation in seminars is expected. Assignments are conducted individually and in groups. Mandatory attendance at oral presentation of assignment.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course objectives are assessed through written exam, assignments, reflection and understanding of assigned material during seminars, project report and oral presentation of the project work.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Seminar/Assignments | GU345 | 7.5 | Mandatory | A21 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2014-02-13
