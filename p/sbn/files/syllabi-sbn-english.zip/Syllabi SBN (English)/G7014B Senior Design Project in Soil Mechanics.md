---
course_code: "G7014B"
title: "Senior Design Project in Soil Mechanics"
credits: "30"
title_sv: "Projektkurs i geoteknik"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2023-02-13"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7014B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7014b-projektkurs-i-geoteknik"
---

# Senior Design Project in Soil Mechanics (G7014B)

## Entry requirements

At least 90 hp within Civil Engineering, including the course G7008B Soil Mechanic, Advanced Course or similar. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2. For exchange students, the examiner makes an individual examination of the qualification depending on the type of project.

## Selection

The selection is based on 30-285 credits

## Course Aim

The overall goal of the course is that the student practices, develops and is able to apply theory and methods to solve challenges relevant to a profession as Master of Science in Civil Engineering within the field of Geotechnical Engineering.

This means that on completion of the course the student is able to:
- Formulate a relevant problem for investigation from a chosen subject within the subject area Soil Mechanics.
- Apply knowledge and proficiency that has been acquired during the period of study to a complex development project or a smaller research project in an independent and systematic manner.
- Choose and justify the study method for an investigation.
- Analyse and defend the problem formulated with respect to science and engineering.
- Locate and critically review information and summarise this in a scientific manner.
- Plan, structure and execute a project within research, development or investigation.
- Judge the scientific and practical relevance of the results obtained.
- Work to a timetable.
- Express themselves well in writing in a verbally and scientifically correct manner.
- Create and execute a presentation of the results of the project, defending the conclusions.
- Critically review the work of others in a constructive and scientific manner.

## Contents

The project theme shall be chosen in cooperation with the examiner and be related to research or engineering development in a field related to geotechnical engineering.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The student will work independently with guidance.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Written presentation of individual work. In the report, the student shows the ability to:
- Justify the chosen problem of study
- Select and justify the study methods
- Collect information relevant to the problem formulation with an explicit connection to the chosen theory/method
- Present in writing the information collected in a relevant manner
- Analyse and defend the formulated problem from the chosen theory and methods
- Critically review the relevance of the results obtained from a scientific and engineering point of view
- Express themselves in writing in a correct linguistic and scientific manner.
- Oral presentation of own work

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The department provides active supervision from the start of the project. The project is performed individually; only in exceptional cases may at most two students carry out the project together. In cases in which the project is carried out by two students, this shall be clearly visible in the scope and depth of the report.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Approved oral and written presentation | U G# | 30 | Mandatory | A19 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural

Resources Engineering 2019-02-14
