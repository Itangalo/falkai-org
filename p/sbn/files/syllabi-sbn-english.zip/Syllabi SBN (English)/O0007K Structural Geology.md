---
course_code: "O0007K"
title: "Structural Geology"
credits: "7.5"
title_sv: "Strukturgeologi"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2023-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0007K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o00/o0007k-strukturgeologi"
---

# Structural Geology (O0007K)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and O0035K Geology, basic course or corresponding.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The goals of the course is that the student through studies on deformation mechanisms and structural analysis of deformed rocks 1) will be able to identify the more common geological structures, 2) explain their formation, 3) visualize structural geological data through stereographic projection, and 4) be aware of different types of bias in geological map material and in broad terms be able to plan bedrock geological mapping.

The student will through this course gain a base for different types of practical work in geology, mining, mineral exploration and engineering geology.

The student will know how to collect and process data and to present these both in written (report) and oral form (presentation).

## Contents

During the course the following structural geological parts will be addressed: plate tectonics, stress and strain, secondary structures in the bedrock such as deformation zones and folding, kinematic indicators, measuring geological structures in the field, bedrock mapping and different applications of structural geology in society. The course deals with structural geology on micro- to regional scale. The course contains plotting and modelling of structural geological data in 2D/3D software.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The lectures will deal with basic theory and different applications of structural geology. The lessons deal with how to solve structural geological problems through stereographic projection, geological maps and profiles. Fieldwork and an excursion is part of the course.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Goal 1 and 2 are examined through a written exam with differentiated grades (3.5 credit) that covers the lectures and course literature.

Goal 3 is examined through a practical exercise (1.5 credit) that uses structural geological measurements collected during the excursion and an associated classroom exercise where data is plotted and interpreted.

Goal 4 is examined as a project (2.5 credit) where the students do fieldwork, bedrock mapping. Coupled to the fieldwork, the students write a report and present the results in class.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course O0007K is equal to KGO003

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0004 | Written exam | GU345 | 3.5 | Mandatory | A07 |  |
| 0005 | Project work | U G# | 2.5 | Mandatory | A07 |  |
| 0006 | Exercise | U G# | 1.5 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
