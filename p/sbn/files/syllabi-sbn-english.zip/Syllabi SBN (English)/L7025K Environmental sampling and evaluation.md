---
course_code: "L7025K"
title: "Environmental sampling and evaluation"
credits: "7.5"
title_sv: "Miljöprovtagning och utvärdering"
valid: "Autumn 2014 Sp 1 - Present"
decision_date: "2014-02-11"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Miljöteknik"
subject_group_scb: "Environmental Care and Enivronmental Protection"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Items/credits Number        Type                                                              Credits      Grade  0001          Short written exam                                                2.5          U G#  0002          Assignment reports                                                2.5          U G#  0003          Project work                                                      2.5          U G#"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7025K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7025K&lasPeriod=188&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l70/l7025k-miljoprovtagning-och-utvardering"
---

# Environmental sampling and evaluation (L7025K)

## Entry requirements

90 credits in Geoscience or Chemical Engineering.

## Selection

The selection is based on 30-285 credits

## Examiner

Christian Maurice

## Course Aim

The overall aim of the course is to:
- Be able to reflect over how sampling strategy, sample handling and analytical techniques can influence the information obtained from an environmental monitoring program

Important learning objectives are:
- Be able to apply the most relevant sampling and analytical techniques for different types of environmental samples (soil, sediment, water)
- Be able to describe the most common analytical methods for environmental samples
- Be able to apply relevant statistical treatments on data sets Important learning objectives are:
- Be able to apply the most relevant sampling and analytical techniques used in the industry and by consultants for different types of environmental samples (soil, sediment, water)
- Be able to describe the most common analytical methods for environmental samples
- Be able to apply relevant statistical treatments on data sets * Be able to plan, budget, perform, and report a common recipient control program

## Contents

- Common sampling and analytical methods in environmental monitoring programs
- Statistical analysis and calculations used in environmental monitoring programs
- Field exercises and demonstrations
- Lab exercises and demonstrations
- Environmental quality and legislation
- Study visit
- Project work in group
- Individual assignment

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. Lectures, field exercises and demonstrations, study visit, lab exercises and demonstrations, project work. The first lecture is compulsory. During the course, examples taken from real projects are used to illustrate which types of tasks the future engineers will work with.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Passed individual assignment report and completed project work, short written exam on the theoretical parts of the course.

## Overlap

The course L7025K is equal to L7026K

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Items/credits Number        Type                                                              Credits      Grade

0001          Short written exam                                                2.5          U G#

0002          Assignment reports                                                2.5          U G#

0003          Project work                                                      2.5          U G#

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Literature

*Literature. Valid from Autumn 2013 Sp 1*
- Lakes and Watercourses, Report 5050, Swedish EPA
- Hand-outs and reports from Naturvårdsverket (available on-line)

## Last revised

by Eva Gunneriusson 2014-02-11

## Syllabus established

by Eva Gunneriusson 2012-03-14
