---
course_code: "D0023B"
title: "IoT-Enabled Condition Monitoring and Maintenance Technologies"
credits: "7.5"
title_sv: "IoT-baserad tillståndsövervakning och underhållsteknologier"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0023B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0023B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0023b-iot-baserad-tillstandsovervakning-och-underhallsteknologier"
---

# IoT-Enabled Condition Monitoring and Maintenance Technologies (D0023B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and M0048M Linear Algebra and Calculus or equivalent course. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course, participants should be able to:

Knowledge and Understanding:

1. Demonstrate basic knowledge of the Internet of Things (IoT) and its implementation.

2. Demonstrate basic knowledge of concepts in Python programming, including syntax, data types, and data structures.

3. Explain how the Internet of Things (IoT) and condition monitoring can be used to support maintenance decisionmaking.

Competence and Skills:

4. Carry out measurements using sensors, microcontrollers, DSP platforms or similar systems for the acquisition of signals and measurement data.

5. Program simple applications for data acquisition, signal processing, and communication between devices within the Internet of Things (IoT).

6. Analyse signals and measurement data using basic signal processing techniques.

7. Independently and in groups, plan and carry out condition monitoring using connected measurement systems, cloud services, and applications.

## Contents

This course covers:

- Basic concepts of condition monitoring and condition-based maintenance.

- The Internet of Things (IoT), measurement technology, microcontrollers, sensors, and cloud services.

- Programming for data acquisition, signal processing, and communication within IoT systems.

- Signal analysis, trend analysis, thresholding, and machine learning.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course consists of three parts. The first part is theoretical, with lectures on condition monitoring, the Internet of Things, programming, signal analysis, and maintenance technologies. The second part consists of laboratory exercises related to sensors, measurement systems, and the Internet of Things. In the third part, a project is carried out that includes planning and performing condition monitoring using the Internet of Things.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

To obtain a passing grade in the course, all assignments, laboratory work, and the project must be completed and approved.

- The assignments assess knowledge and understanding related to learning outcomes (1–3) and the ability to analyse measurement data as described in learning outcome 6.

- The laboratory work evaluates the skills and competencies described in outcomes 4 and 5. The laboratories are carried out in groups and are assessed through lab reports and oral presentations.

- The project assesses the ability to independently plan and carry out condition monitoring according to outcome 7. The project is presented both orally and in writing.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignments | GU345 | 4 | Mandatory | A26 |  |
| 0002 | Laboratory work | U G# | 1.5 | Inactive | A26 |  |
| 0003 | Project work | U G# | 2 | Inactive | A26 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13
