---
course_code: "U0006B"
title: "Condition Based Maintenance"
credits: "7.5"
title_sv: "Tillståndsbaserat underhåll"
valid: "Autumn 2019 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2019-09-04"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=U0006B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=U0006B&lasPeriod=208&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/u00/u0006b-tillstandsbaserat-underhall"
---

# Condition Based Maintenance (U0006B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Examiner

Matti Rantatalo

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment reports | GU345 | 4 | Mandatory | A19 |  |
| 0002 | Laboratory work | U G# | 3.5 | Mandatory | A19 |  |

## Literature

*Literature. Valid from Autumn 2019 Sp 1*

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-09-04
