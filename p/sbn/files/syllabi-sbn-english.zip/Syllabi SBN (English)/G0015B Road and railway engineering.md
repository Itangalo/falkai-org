---
course_code: "G0015B"
title: "Road and railway engineering"
credits: "7.5"
title_sv: "Väg- och järnvägsbyggnad"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0015B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g00/g0015b-vag--och-jarnvagsbyggnad"
---

# Road and railway engineering (G0015B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

The aim of the course is to give students basic knowledge in the construction and design of roads and railways, and the performance and distresses during the service time. The course is based on the Swedish framework for road and railway construction but the theory and design approaches are globally applicable.

After the course the student shall be able to:

Describe:

The role of road and railway infrastructure in the society

How the society plan and realize investments and maintenance in road and railway engineering

Geotechnical survey’s for road and railway projects

Contract forms

Account for:

Laboratory investigation methods for bound and unbound materials

Degradation mechanisms for road and railways

Condition monitoring and rating of roads

Analytical and empirical design methods for roads

General design principles in railways

Operation and maintenance planning

Frost in the ground, frost heave, frost thawing

Explain:

Structural design of flexible and rigid pavements

Structural design of ballasted tracks

Apply:

Basic frost depth analysis

Evaluate results from ballast testing

Basic design of road and railway superstructures

The Swedish safety guidelines for work within road traffic environments.

The course also has as a goal to practice the general skills written and oral presentation.

## Contents

The course covers design, construction and basic operation and maintenance on road and railways. Design and material requirements in this course are based on Swedish guidelines and European standards. The course extensively covers geotechnical requirements, alignment, supportive structures and the realization of construction projects processes. The focus in the course is on superstructure design and material requirements.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The course contains lectures. In the course, three assignments are included that deal with: Frozen ground engineering, Particle size distribution curves and Road design. The assignments are solved in groups of normally three students. The assignments are corrected by the teacher and the student groups get feedback on their work. The course also contains a compulsory computer exercise (workshop) about railway engineering. A larger seminar assignment is included in the course where each group choose a topic relevant to the course to study closer, writes a paper about the subject and present the paper orally at a seminar in the end of the course. In the seminar assignment the general skills written and oral presentation are practiced. Each group will also act as opponent on another groups work. All seminar assignments are corrected by teachers and the student groups obtain feedback. The course contains two part exams that are done individually. The first exam deals with road engineering and the second exam deals with railway engineering.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. All learning outcomes in the course that have to do with road engineering are assessed in the exam about road engineering. All learning outcomes in the course that have to do with railway engineering are assessed in the exam about railway engineering. The assignments and the computer exercise assess the “apply” learning outcomes of the course on a deeper level. By the seminar assignment the general skills written and oral presentation are practiced. The teacher will give feedback on the presentation technique at the oral presentations. Both the modules Exams and Assignments/reports are graded according to the grading scale GU345. All exams included in the modules need to be completed for a course grade. The course grade is a weighted average of the performance on Exams and Assignments/reports with the grading scale GU345.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Test | GU345 | 3 | Mandatory | S16 |  |
| 0002 | Assignments and computer laboratory work | GU345 | 4.5 | Mandatory | S16 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2015-05-19
