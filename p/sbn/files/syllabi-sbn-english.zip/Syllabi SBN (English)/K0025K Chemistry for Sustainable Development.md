---
course_code: "K0025K"
title: "Chemistry for Sustainable Development"
credits: "7.5"
title_sv: "Kemi för hållbar utveckling"
valid: "Spring 2026 Sp 3 - Autumn 2026 Sp 2"
decision_date: "2024-02-14"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Kemi"
subject_group_scb: "Chemistry"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0025K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0025K&lasPeriod=222&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k00/k0025k-kemi-for-hallbar-utveckling"
---

# Chemistry for Sustainable Development (K0025K)

## Main field of study

Natural Resources Engineering, Chemical Engineering, Energy Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Upper secondary school courses Chemistry 1, Mathematics 3c or Mathematics D. Or: Chemistry level 1, Mathematics Further level 1c.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K0025K is equal to K0016K

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam part 1 | GU345 | 1.5 | Mandatory | A20 |  |
| 0002 | Written exam part 2 | GU345 | 2 | Mandatory | A20 |  |
| 0003 | Written exam part 3 | GU345 | 1.5 | Mandatory | A20 |  |
| 0004 | Written exam part 4 | GU345 | 1.5 | Mandatory | A20 |  |
| 0006 | Chemistry for Sustainable Development | U G# | 1 | Mandatory | A20 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-02-14
