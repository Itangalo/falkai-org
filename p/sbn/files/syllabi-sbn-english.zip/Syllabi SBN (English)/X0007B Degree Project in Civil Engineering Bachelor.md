---
course_code: "X0007B"
title: "Degree Project in Civil Engineering, Bachelor"
credits: "15"
title_sv: "Examensarbete i Väg- och vattenbyggnad, kandidat"
valid: "Autumn 2013 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2013-06-13"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Items/credits No items/credits available"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X0007B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X0007B&lasPeriod=218&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/x00/x0007b-examensarbete-i-vag--och-vattenbyggnad-kandidat"
---

# Degree Project in Civil Engineering, Bachelor (X0007B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course students will be able to:
- show deepened ability to independently plan and carry out a more extensive project.
- apply the knowledge and skills acquired during his/her studies.
- independently analyze and reflect on the subjects problem areas.
- present the results in a technical-scientific report and orally in Swedish or English.

## Contents

Final project should be completed during the last year of the programme on a subject matter that is relevant to the area of specialization. Those who do the final project on a topic outside the specialized area must first appeal to the department.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. For the final exam project the student shall, alone or together with another student, focus on a given task. This final project should be characteristic of a simple research project or a more advanced investigational project. The student will work independently with guidance. The final report will be given both written and orally. Time limit for final exam work: students who begin exam work and do not finish within 15 months cannot request allowance to complete that project. The department that is responsible for the examination and supervision has no obligation to complete supervision of an exam work that goes beyond the 15 month time limit.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. In order to pass exam work the student is required to complete his or her own project and in addition;
- present work in a written report
- present work in a seminar at the department
- attend at least two other student presentations

## Remarks

In the case that the exam is carried out for an external assigner, the exam should also, apart from exceptional case, be approved by the external assigner before it can finally be approved.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Items/credits No items/credits available

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Eva Gunneriusson, Assistant Director of Undergraduate Studies at the Department of Civil, Environmental and Natural Resources Engineering 2013-06-13
