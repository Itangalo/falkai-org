---
course_code: "P7014B"
title: "Construction Supply Chain Management"
credits: "7.5"
title_sv: "Bygglogistik"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2020-11-06"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7014B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p70/p7014b-bygglogistik"
---

# Construction Supply Chain Management (P7014B)

## Main field of study

., Civil Engineering

## Entry requirements

At least 90 credits in Civil Engineering or Architectural Engineering. The course P0007B Project Management or equivalent must be included.

## Selection

The selection is based on 30-285 credits

## Course Aim

The aim of the course is to give the students a basic understanding of concepts and methods in construction supply chain management. Intended Learning Outcomes After a passed course the student shall be able to:
- define and apply basic concepts, models, tools and methods to observe, describe and analyze site and construction supply chain management
- define and apply the concepts of construction supply chain planning, supply chain coordination, supply chain integration and supply chain management given basic conditions.
- independently plan, develop and suggest implementation of construction supply chain design in a construction setting including services, subcontracting, deliveries of materials and other resources within given conditions
- reflect on the strategic meaning of supply chain management activities within construction and on its effect on sustainability, social responsibility, health and safety and risk management
- define, describe and reflect on future challenges and trends related to the construction supply chain management

## Contents

The course consists of theories in construction supply chain management related to methods, processes, production systems, concepts and flows of trades, information, material, and cash. Areas that are covered are supply chain design and supply chain planning, supply chain coordination, supply chain integration and management of the supply chain within the construction context.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

Students obtain the theoretical material from the course literature with the support of lectures. The application of theory is practiced, tested and reflected upon in assignments where students work both in groups and individually. The groups present their findings and discuss their choices for the assignment at seminars.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Basic understanding of the theoretical content is assessed through individual assignments. Deeper knowledge and practical skills are assessed collectively through a written and an oral presentation of assignments.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment report | GU345 | 3 | Mandatory | S20 |  |
| 0002 | Group work | U G# | 4.5 | Mandatory | S20 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-11-06

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-06-14
