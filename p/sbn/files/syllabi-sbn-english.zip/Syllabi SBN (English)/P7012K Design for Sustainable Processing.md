---
course_code: "P7012K"
title: "Design for Sustainable Processing"
credits: "3"
title_sv: "Design för hållbar processteknik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2026-02-13"
education_level: "Second cycle"
grade_scale: "UG"
subject: "Processmetallurgi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7012K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7012K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p70/p7012k-design-for-hallbar-processteknik"
---

# Design for Sustainable Processing (P7012K)

## Entry requirements

180 credits in engineering/natural sciences. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2 or equivalent real competence obtained through practical experience. Read more about how to apply for real competence via this link: https://www.ltu.se/en/student-web/your-studies/prior-learning

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, the student should be able to:

1. Know the concept of sustainable development

2. Know some of the most common techniques used in recycling processes for metal recycling

3. Understand the connection between process choice and material composition

4. Be aware of how residual products are generated in high-temperature metallurgical processes and have knowledge of possible areas of use

5. Know the limitations for recycling different types of metal-containing scrap and the use of metal-containing residual products

6. Know how the design of a product affects the recycling of the end-of-life product

## Contents

The course covers the recycling of metals from post-consumer scrap and metallurgical residues.

Metallurgical smelting processes for recycling metals are reviewed, with a focus on the recycling of copper from electronic scrap and steel from end-of-life vehicles. The formation of residues in high-temperature processes will be reviewed, as well as different options for recycling and/or use in different applications, including use as construction materials. The course will provide insight into the connection between material composition and recycling possibilities through a project assignment and seminar. The course includes quizzes for each sub-area with a followup webinar to provide knowledge about different processes for recycling and which residues are generated.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The course, which is given on distance, has a time plan but offers individual flexibility through access to recorded lectures, quizzes and individual assignments in the digital course room.

Webinars are held to support learning and enable students to discuss the course's recorded lectures. During the seminar, students will present and reflect on assignments that are completed individually.

Reporting is done both in writing and orally.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Quizzes, webinars, project assignments and seminars are mandatory. Project assignments are presented in writing and orally during seminar and are assessed with pass (G), fail (U) and participation.

Objectives 1, 2, 4 and 5 are examined through quizzes and follow-up webinars.

Objectives 3 and 6 are examined through presentation at seminar and written report

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The course P7012K is partly equal to P7009K.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Quizzes & webinars | UG | 1.5 | Mandatory | S27 |  |
| 0004 | Project assignment & seminar | UG | 1.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13
