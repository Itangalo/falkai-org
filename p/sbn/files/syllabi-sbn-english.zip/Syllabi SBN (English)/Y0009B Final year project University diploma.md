---
course_code: "Y0009B"
title: "Final year project, University diploma"
credits: "7.5"
title_sv: "Examensarbete, Samhällsbyggnad"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2026-06-17"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=Y0009B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=Y0009B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/y00/y0009b-examensarbete-samhallsbyggnad"
---

# Final year project, University diploma (Y0009B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and At least 90 credits completed courses as required for the degree.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course participants should be able to…

Knowledge and understanding

Show general subject knowledge within the main area of education.

Demonstrate knowledge of the scientific basis of the main area.

Demonstrate knowledge and understanding of some applicable methods in the main area of education.

Competence and skills

Search and gather relevant information in a problem statement.

Critically interpret relevant information to formulate answers to well-defined questions.

Demonstrate such skills as are required to work independently with certain tasks in the area to which the education relates.

Write a report of the type simpler research report or investigation report.

Analyze and draw conclusions from survey results.

Judgement and approach

Demonstrate knowledge of and have the prerequisites to handle ethical issues within the main area of the education.

## Contents

In the degree project, the student must plan and solve a self-chosen task within the field of study and report the results. The degree project must have the character of a simpler research project or advanced investigative project.

The content of the course is designed together with the student when the choice of degree project has been made.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching consists of independent studies with the support of a supervisor / examiner from the university and an external supervisor at the workplace. The implementation is designed in connection with the planning of the degree project.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is examined through a written report/degree project.

Grading takes place according to grade scale G U.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course Y0009B is equal to Y0011B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written report | U G# | 7.5 | Mandatory | A09 | Yes |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students

applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-06-17

## Syllabus established

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2009-01-20 att gälla från H09.
