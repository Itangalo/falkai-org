---
course_code: "V7015B"
title: "Senior Design Project in Urban Water Engineering"
credits: "7.5"
title_sv: "Projektkurs i VA-teknik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "UG"
subject: "VA-teknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V7015B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/v70/v7015b-projektkurs-i-va-teknik"
---

# Senior Design Project in Urban Water Engineering (V7015B)

## Main field of study

.

## Entry requirements

At least 60 credits in environmental-, civil-, or natural resources engineering. Basic courses in urban water engineering, e.g., V0016B Urban Water Systems. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2. For exchange students, the examiner makes an individual examination of the qualification depending on the type of project.

## Selection

The selection is based on 30-285 credits

## Course Aim

After the course the student should be able to:

- independently describe a specific topic within urban water engineering,

- frame a specific topic related to urban water engineering,

- independently work with question within the topic urban water engineering that are not well documented or described in literature,

- write a scientific report,

- give an oral presentation.

## Contents

The course focuses on a relevant theme and questions within urban water engineering. The course content is decided in each case and should include complexity to a certain degree.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course is carried out as an individual project in which the student is working independently with the study. The topic is clearly related to urban water engineering and could be chosen by the student or suggested by the supervisor. The student shall contact the course examiner before the start of the course to assess fulfillment of the entry requirements and to identify a suitable project. The study should not only be a literature study. A scientific report should be written, and oral presentation given.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course aims are examined by a written report and an oral presentation.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Project report | UG | 6.5 | Mandatory | S27 |  |
| 0004 | Oral presentation | UG | 1 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02
