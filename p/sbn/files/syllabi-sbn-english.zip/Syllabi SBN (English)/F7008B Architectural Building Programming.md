---
course_code: "F7008B"
title: "Architectural Building Programming"
credits: "7.5"
title_sv: "Arkitektoniskt byggnadsprogram"
valid: "Autumn 2025 Sp 1 - Present"
decision_date: "2025-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7008B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7008B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f70/f7008b-arkitektoniskt-byggnadsprogram"
---

# Architectural Building Programming (F7008B)

## Main field of study

Architecture

## Selection

The selection is based on 30-285 credits

## Course Aim

The goal of this course is for the students to understand design-oriented tasks to manage and discuss complex concepts used in the early stages of the building design-to-construction process, along with comprehending the architect's creative work. In this course, students will acquire:

Knowledge and understanding of:

- Processes and methods for analyzing the client's and society's needs and requirements for further development. (Module 0008)
- Proposing an architecture project considering societal, user, and climate-impacting aspects (Modules 0006, 0008)
- Challenges and opportunities in building design and construction. (Module 0008)

Skills and ability to:

- Analyze the site's opportunities based on user and business needs. (Module 0008)
- Develop and design an architectural solution for a given architectural program up to 2500 sqm of total built area. (Modules 0006, 0008)
- Develop a system document for a building (drawings, renders, and area takeoffs). (module 0008).
- Perform daylight calculations (Module 0006).
- Use CAD as tool for producing building drawings and 3D models (Module 0008).

## Contents

The course deals with the problem of designing mixed-use buildings (residential plus an alternative use) and creates the basis for F7007B. The course applies the aggregated content of previous courses in terms of CAD-BIM skills, knowledge in building construction, building materials, regulations and representation techniques in a realistic scenario.

The project work pertains to complex buildings containing several functions that provide different requirements for building design.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course consists of lectures, workshops, and iterative design work running throughout the entire course. Tutored design studio sessions, along with related tasks and seminars (oral and written), conform the course’s structure. Assignment are submitted via drawings, 3D models, sketches, posters and oral presentations performed mostly as groupwork.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Written and oral presentation in groups and individually during submission seminars and ongoing at design studios.

Code 0006. Individual assessment is based on individual tasks, quizzes, and workgroup performance. Grading scale G/U 3/4/5.

Code 0008. Group assessment is based on workgroup results, presentations, and compliance with task requirements. Building design (drawings, written reports, renderings). Grading scale G/U 3/4/5.

A minimum attendance of 80% for ordinary sessions (design studios and lectures) is required. Attendance is compulsory at seminars and presentation sessions.

The work must have achieved the required quality requirements no later than one week after the current academic period. Any remaining elements can be completed when the course opens again.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0009 | Individual assignments | GU345 | 3 | Mandatory | A24 |  |
| 0010 | Project work, group | GU345 | 4.5 | Mandatory | A24 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Eva Gunneriusson 2012-03-14
