---
course_code: "L7026K"
title: "Sampling and Evaluation of Environmental Data"
credits: "7.5"
title_sv: "Provtagning och utvärdering vid miljökontroll"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2023-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Miljöteknik"
subject_group_scb: "Environmental Care and Environmental Protection"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7026K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7026K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l70/l7026k-provtagning-och-utvardering-vid-miljokontroll"
---

# Sampling and Evaluation of Environmental Data (L7026K)

## Main field of study

Natural Resources Engineering, Geosciences

## Entry requirements

90 credits in Geoscience or Chemical Engineering.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, the student should be able to

Knowledge and understanding

1. Explain how geochemical and physical properties of environmental problems should be considered during sample planning, and demonstrate       where to find relevant background information

2. show an understanding of set gender equality goals, regulations for gender equality in professional life and give examples of the prerequisite for   gender equality in professional life.

Competence and skills

3. apply sampling and analytical techniques of environmental samples (soil, sediment, water)

4. use relevant computer programs and apply relevant statistical treatments on data sets

5. plan, budget, perform, report and present a monitoring program

Judgement and approach

6. Critically reflect and discuss how sampling strategy, sample handling and analytical techniques can influence the information and errors obtained      from an environmental monitoring program

## Contents

The course is divided into four blocks. The first block focuses on environmental quality standards, legislation, environmental problems and the sampling procedures for surface water, groundwater, soil and sediments. The second block includes in-situ measurements, theory of laboratory tests and visits to laboratories to see analytical techniques. The third block focuses on geochemical data interpretation and visualization by using and statistical- and data treatment programs. The fourth block deals with gender equality.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. In the course, students develop their ability to plan work independently by taking pre-recorded lessons with basic information and study questions based on the recordings and course literature. By working actively in groups at seminars, students develop the ability to collaborate and solve geochemical problems, but also to identify relevant background information and visualize results for the other groups in the course. Through field exercises and study visits, students work with potentially upcoming tasks in work life and gain a holistic understanding of sampling and evaluation of environmental data. Throughout the course, students work on a project assignment where they use the information from the course to develop a monitoring program based on real cases.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The intended learning outcomes (ILO’s) of the course are assessed by four different assessments:

1. The ILO’s 1, 3, 4 and 6 are assessed through an oral exam (Grading G/U 3 4 5)

2. The ILO’s 2 and 4 are assessed by individual assignments (Grading G/U 3 4 5)

3. A written group report of a project assignment (grading G/U) and an individual presentation of the report (Grading G/U 3 4 5) assess the ILO 5.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course L7026K is equal to L7025K

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Group Work | U G# | 2.5 | Mandatory | A18 |  |
| 0004 | Individual seminar | GU345 | 1.5 | Mandatory | A18 |  |
| 0005 | Individual exam | GU345 | 3.3 | Mandatory | A18 |  |
| 0006 | Individual assignments | GU345 | 0.2 | Mandatory | A18 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2018-02-13
