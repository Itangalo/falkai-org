---
course_code: "D7022B"
title: "Predictive Analytics and Condition Based Maintenance"
credits: "7.5"
title_sv: "Prediktiv analys och tillståndsbaserat underhåll"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2025-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7022B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7022b-prediktiv-analys-och-tillstandsbaserat-underhall"
---

# Predictive Analytics and Condition Based Maintenance (D7022B)

## Entry requirements

At least 90 credits and D7007B Maintenance technology or equivalent. Good knowledge of English, equivalent to English 6.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, participants should be able to:

Knowledge and Understanding:

1. Explain concepts and methods of condition monitoring, condition based maintenance and predictive maintenance.

2. Demonstrate a basic understanding of data acquisition methods, signal processing, and feature extraction techniques for condition monitoring.

3. Explain how modelling and simulation using software tools can support condition based maintenance.

4. Describe prediction modelling techniques and machine learning approaches for prognostics and maintenance decision-making.

Competence and Skills:

5. Analyse time-series data using signal processing techniques and predictive analytics to assess and forecast asset condition.

6. Implement diagnostics and prognostics with machine learning, using data from sensors and monitoring systems.

7. Perform maintenance planning and scheduling considering assets availability, risks and life cycle cost.

## Contents

This course covers:

- Condition-Based Maintenance and Predictive Maintenance

- Sensor Technology and Data Acquisition

- Feature Extraction and Signal Processing Techniques

- Machine Learning and Predictive Analytics for Maintenance

- Diagnostics and Prognostics.

- Decision Support for Maintenance Planning and Scheduling

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course includes lectures and laboratory work to provide both theoretical knowledge and practical skills. Lectures will cover theoretical concepts of condition-based maintenance, data analytics techniques, and modelling approaches for predictive maintenance and maintenance decision-making. Laboratory work will provide hands-on experience with sensor data collection, signal processing, and implementation of diagnostic and prognostic using analytics software.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

To obtain a passing grade in the course must the assignments and laboratory work be completed with a passing grade.

- Assignments assess knowledge and understanding related to learning outcomes 1-4 along with competence in maintenance planning and scheduling related to learning outcome 7.

- Laboratory work and reports evaluate the practical competence and skills described in learning outcomes 5-6. Lab sessions will be conducted in groups, with lab reports to evaluate both the group's and the individuals' competence and skills.

- Peer Review between groups is included to allow students to evaluate each other’s contributions and reflect on their own understanding.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignments | GU345 | 4 | Mandatory | A25 |  |
| 0003 | Laboratory work | UG | 3.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
