---
course_code: "D0019B"
title: "Human Factors for Safety in the Work Environment"
credits: "7.5"
title_sv: "Mänskliga faktorer för säkerhet i arbetsmiljön"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2022-02-10"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0019B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0019B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0019b-manskliga-faktorer-for-sakerhet-i-arbetsmiljon"
---

# Human Factors for Safety in the Work Environment (D0019B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Upper secondary school courses English 6, Physics 2, Chemistry 1, Mathematics 3c or Mathematics D. Or: English level 2, Physics level 2, Chemistry level 1, Mathematics Further level 1c .

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

Knowledge and understanding

After completing the course, the student should be able to show knowledge and understanding:

- For how theories and methods in psychosocial work environment can be applied

Competence and Skills

After completing the course, the student should be able to:

- Understand how people's performance in the workplace is affected by ergonomic factors

- Gather information about a problem concerning people in the work environment and apply relevant methods

- Evaluate and critically review information collected from studies

- Critically discuss psychosocial work environment

- Identify, describe, and solve problems related to the work environment

- Present and discuss orally and in writing

Judgement and approach

After completing the course, the student should be able to show the ability to:

- Make assessments of the work environment with regard to psychosocial and ergonomic aspects

- Show insight into the human role in the work environment from a sustainable perspective

## Contents

Basic principles for ergonomics, safety and working environment. Ergonomic factors and their impact on the physical and psychosocial work environment. The course deals with how the interaction between people and the work environment can be understood and developed from a psychosocial perspective, and how people are affected by the work environment. More specifically, the course touches on how human information processing, perception, attention, memory, thinking, decision-making and stress levels affect the interaction between people and the work environment. The course also touches on current technological development in society from a sustainable perspective for people and society. The course introduces several different methods for analyzing the work environment (eg PEAR model) as well as methods for examining human abilities and limitations at work (eg FAIR model).

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The teaching is based on seminars with oral and written presentation. In order to achieve the course's goals regarding knowledge and understanding, the student should independently study the specified course literature and other literature provided during the course, and take part in seminars and exercises.

In order to achieve the course's goals regarding skill and ability, the student should participate actively during seminars and in written and oral presentations. Seminars train the ability to collect and evaluate information by using different methods and theories. Through presentations and discussion, the ability to identify, describe, solve and critically examine problems and phenomena related to the interaction between people and the work environment is also trained. In order to achieve the course's goals regarding judgment and attitudes, the student should actively participate in seminars, discussions, and presentations and actively study the course literature. The ability to see psychosocial challenges in the work environment from a sustainable perspective is trained through discussions and reflection.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Knowledge and understanding are examined mainly through seminars and assignments. Skills and abilities as well as judgment and attitudes are examined through project assignments and oral and written presentation. Oral presentation takes place through presentations and discussions. Written reporting takes place via assignments, project assignments and reflections. All included examination parts must be completed for the final grade in the course (7.5 credits, grade scale: G 3 4 5).

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0004 | Project assignment, presentations and assignments | GU345 | 7.5 | Mandatory | A17 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-10

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2017-02-08
