---
course_code: "L7027K"
title: "Hydrogeochemistry"
credits: "7.5"
title_sv: "Hydrogeokemi"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7027K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7027K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l70/l7027k-hydrogeokemi"
---

# Hydrogeochemistry (L7027K)

## Entry requirements

At least 90 ECTS in the areas of geoscience, geology, natural resources technology, mining technology, or constructions technology. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course participants should be able to:

Knowledge and understanding

1. Describe how catchment hydrology and the physical properties of soils and rocks affect groundwater formation and flow.

2. Explain how natural geochemical processes in soils and rocks as well as pollution can affect groundwater quality.

3. Explain how climate change can affect groundwater levels and quality.

Competence and skills

4. Access groundwater data from open databases and use oxygen and hydrogen isotopes and geochemical software to interpret this groundwater data.

5. Write a scientific report and present geochemical data.

Judgement and approach

6. Use hydrogeochemical principles in working towards a sustainable use of groundwater resources in a changing climate.

## Contents

The course covers basic concepts related to soils/rocks, hydrology/groundwater, and geochemistry. These basic concepts are then used to interpret groundwater data and to judge potential effects of climate change on groundwater quality.

The section on soils and rocks covers formation and distribution of Quaternary sediments, physical and chemical properties of soils such as porosity, permeability, capillarity, and cation exchange capacity. Groundwater occurrence in rocks.

The section on hydrology and groundwater covers basic catchment hydrology, groundwater formation, and groundwater flow in aquifers. Groundwater–surface water interactions with applications in groundwater reservoirs. Demonstration of groundwater sampling and sampling equipment.

The section on geochemistry covers interactions between soils, rocks, and groundwater, and how these interactions affect groundwater quality. Groundwater pollution and pollution transport in groundwaters. Oxygen and hydrogen isotopes are used as a tool to trace groundwater origin. Software such as ioGAS and QGIS are used to interpret groundwater data.

Potential effects on groundwater levels and quality in a changing climate are discussed in relation to real cases.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. Basic theory on the physical and chemical properties of soils and rocks, catchment hydrology, and groundwater characteristics is presented during lectures. Three mandatory exercises based on data from relevant field sites provide a deeper understanding of the basic theory related to hydrological and geochemical aspects. Hydrological and geochemical aspects are integrated in a mandatory project assignment providing training in collaboration, scientific writing, and data presentation. Visit to a relevant field site (waterworks or other).

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The goals and intended learning outcomes of the course are assessed by:

1. An individual, short written exam (G U 3 4 5) to assess ILO’s 1, 2, and 3.

2. Three exercises (U G#) to assess ILO’s 4 and 5.

3. A written report (U G#) to assess ILO’s 5 and 6.

All exams included in the module need to be completed for a course grade.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Test | GU345 | 3 | Mandatory | S25 |  |
| 0004 | Project assignment | UG | 1.5 | Mandatory | S27 |  |
| 0005 | Exercises | UG | 3 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14
