---
course_code: "O7002K"
title: "Senior Design Project in Applied Geophysics"
credits: "15"
title_sv: "Projektkurs i tillämpad geofysik"
valid: "Autumn 2011 Sp 2 - Present"
decision_date: "2011-10-05"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geofysik"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Items/credits Number       Type                                                            Credits      Grade  0001         Passed oral and written presentation                            15           GU345"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O7002K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O7002K&lasPeriod=166&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o70/o7002k-projektkurs-i-tillampad-geofysik"
---

# Senior Design Project in Applied Geophysics (O7002K)

## Entry requirements

Decided by the examiner depending on type of project.

## Selection

The selection is based on 30-285 credits

## Examiner

Sten-Åke Elming

## Course Aim

The student shall independantly design, carry out and report a project within the subject.

## Contents

The project theme shall be chosen in cooperation with the examiner and be related to modern research and development.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The student will work independently with guidance.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Written report

Transition terms 2500

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Items/credits Number       Type                                                            Credits      Grade

0001         Passed oral and written presentation                            15           GU345

## Literature

*Literature. Valid from Autumn 2007 Sp 1* Depends on the project choosen, and will therefor be decided later.

## Last revised

by Eva Gunneriusson 2011-10-05

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
