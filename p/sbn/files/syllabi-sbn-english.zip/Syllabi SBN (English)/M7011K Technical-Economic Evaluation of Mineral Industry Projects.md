---
course_code: "M7011K"
title: "Technical-Economic Evaluation of Mineral Industry Projects"
credits: "7.5"
title_sv: "Teknisk-ekonomisk bedömning av mineralindustriprojekt"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2023-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Mineralteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7011K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7011K&lasPeriod=213&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/m70/m7011k-teknisk-ekonomisk-bedomning-av-mineralindustriprojekt"
---

# Technical-Economic Evaluation of Mineral Industry Projects (M7011K)

## Entry requirements

60 ECTS in geoscience, mining engineering, process engineering or equivalent areas or equivalent knowledge from practical experiences (at least 5 years). Substantiated with certificates from employers. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 30-285 credits

## Course Aim

The course aims to create knowledge of investment analysis options for technically feasible and economic mineral extraction and of understanding of market mechanisms for minerals and metals. After completing the course, the student shall be able to:

- Know and explain the market mechanisms and global supply chains for minerals and metals

- Establish parts of the technical and economic documentation for a feasibility study

- Describe and explain different methods used for investment analysis and risk analysis of mineral industry projects

- Perform a simplier project analysis and evaluation

## Contents

This course covers:

Mineral and metal markets

- Mineral Supply and Demand

- Stakeholders

- Commodity prices and pricing institutions

- Global supply chains and trends in the minerals industries

Project analysis - Extraction of mineral resources

- Feasibility studies at different development stages

- CAPEX and OPEX for mining, mineral processing and remediation

- Production planning and material flows

Investment analysis

- Methods for investment calculation

- Uncertainties and risk analysis

- Case study

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The teaching consists of lectures that are combined with assignments and a small project.

Lectures will give the students an understanding of the mechanisms of mineral and metal markets and the opportunity to examine the development of mining projects from a technical-economic perspective.

The assignments and the project will train the student to independently work with and deepen selected sub-areas.

Seminars are devoted to in the group describing, analyzing, interpreting and presenting a complex topic in the thematic field.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Assignments as well as seminars and projects are mandatory. Assignments and project are assessed with grades in these parts. The seminars are graded passed/not passed. The total score production gives the total grade for the course, which is given at a grade scale of 3 4 5.

Mandatory attendance at the first lecture. Permission to be absent is given by the teacher responsible for the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignments | GU345 | 3 | Mandatory | A23 |  |
| 0002 | Seminars | U G# | 2 | Mandatory | A23 |  |
| 0003 | Project | GU345 | 2.5 | Mandatory | A23 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13
