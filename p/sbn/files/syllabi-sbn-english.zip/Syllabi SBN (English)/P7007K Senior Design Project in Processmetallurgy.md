---
course_code: "P7007K"
title: "Senior Design Project in Processmetallurgy"
credits: "7.5"
title_sv: "Projektkurs i Processmetallurgi"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2022-02-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Processmetallurgi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7007K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p70/p7007k-projektkurs-i-processmetallurgi"
---

# Senior Design Project in Processmetallurgy (P7007K)

## Main field of study

Chemical Engineering

## Entry requirements

At least 90 credits in Chemical Engineering, including the course P0006K High Temperature Processes or similair. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2. For exchange students, the examiner makes an individual examination of the qualification depending on the type of project.

## Selection

The selection is based on 30-285 credits

## Course Aim

The aim of the course is that students independently shall plan and conduct an experimental project related to up todate research and technical development. After completing the course the student shall be able to independently plan and carry out a project. The student shall be able to evaluate results and summarise the work in a written and oral presentation.

## Contents

The content of the course is decided in consultation with examinator and shall be related to up to-date research and development.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. Independent projectwork with support from examinator and/or other supervisor appointed by the examinator. The project course can be given in Swedish or English. The project course shall give the student knowledge of different laboratory equipment that are available at the division of process Metallurgy. The student will be trained to use equipment in laboratory scale, plan and carry out project and in oral and written presentation.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Approved oral and written presentation.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

Can be given in Swedish or English.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project report | GU345 | 7.5 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
