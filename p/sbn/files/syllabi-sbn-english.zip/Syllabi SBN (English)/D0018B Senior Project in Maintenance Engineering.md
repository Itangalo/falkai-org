---
course_code: "D0018B"
title: "Senior Project in Maintenance Engineering"
credits: "15"
title_sv: "Projektkurs i underhållsteknik"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2017-02-10"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0018B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0018B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0018b-projektkurs-i-underhallsteknik"
---

# Senior Project in Maintenance Engineering (D0018B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and At least 60 Hp or corresponding within the subject Maintenance Engineering and proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course, the student should independently design, carry out and report a project within the subject.

## Contents

The project theme shall be chosen in cooperation with the examiner or designated supervisor and be relevant to a profession as Bachelor of Science in Engineering within the area of Maintenance Engineering.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The student independently plans and executes the degree project with guidance.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The examination of the course is specified, by the examiner, in a detailed course description at the course occasion and can consist of
- written report
- oral presentation of own work
- public discussion of the work of others
- seminars

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids

not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The department provides active supervision for a period of one term from the start of the project.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project work | U G# | 15 | Mandatory | S17 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2017-02-10

## Syllabus established

by Eva Gunneriusson 2016-06-13
