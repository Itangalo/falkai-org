---
course_code: "G7013B"
title: "Natural Energy Sources"
credits: "7.5"
title_sv: "Naturvärme"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7013B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7013B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7013b-naturvarme"
---

# Natural Energy Sources (G7013B)

## Entry requirements

F0032T Thermodynamics and Heat Transfer or corresponding course.

## Selection

The selection is based on 30-285 credits

## Course Aim

After passing the course, the student should be able to:

- Describe different techniques for extracting or storing geoenergy for heating purposes

- estimate the profitability of different geoenergy plants

- estimate the maximum theoretical solar radiation, and evaluate different types of solar heating systems

- perform simple design calculations of a geothermal heating systems
- perform a feasibility study of a geoenergy or solar project, and report results in a written report and oral presentation

## Contents

This course covers basic knowledge of solar collectors, geoenergy systems and thermal energy storage. Within these areas, technology, dimensioning, and costs are addressed. Topics include:

- Heat transfer and heat transport: Physical description of conduction, radiation and convection. Heat storage capacity of different materials.

- Solar energy: Active and passive solar energy, solar irradiation on inclined surface.

- Solar thermal applications, calculation examples of flat plate solar collectors, different types of solar collectors

- Geoenergy: Natural heat sources in air, soil and water, overview of heat pumps.

- Snow storage

- Recharging of heat sources.

- Thermal energy storage: Current research. Different techniques. Storage of heat / cold. Short and long term storage. Economy. Calculation examples stock size, energy losses etc.

- Project work: Design of energy storage systems. Definition and division of projects. Choice of system. Collection of technical data and cost data. Optimization of thermal energy storage systems. Reporting.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The teaching consists of lectures and exercises. The main part of the course consists of a project work, sometimes commissioned by the industry or university. Data labs with the EarthEnergyDesigner (EED) and Polysun softwares are required. The programs are later available as aids in the project work. The project work is documented in writing and presented at a joint seminar.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course is assessed based on the quality of the project report, and oral presentation. Completed reports from computer labs on Polysun and EED are required for a completed course. The course grades are given according to the scale U 3 4 5.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course G7013B is equal to E7002B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assigment report | GU345 | 5.5 | Mandatory | A16 |  |
| 0002 | Oral Presentation | U G# | 1 | Mandatory | A16 |  |
| 0003 | Required Assignments | U G# | 1 | Mandatory | A16 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2016-02-10
