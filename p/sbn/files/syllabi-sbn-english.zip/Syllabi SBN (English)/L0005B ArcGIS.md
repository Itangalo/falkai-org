---
course_code: "L0005B"
title: "ArcGIS"
credits: "7.5"
title_sv: "ArcGIS"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2022-02-11"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Geografisk informationsteknologi"
subject_group_scb: "Geographic Information Technology and Surveying"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0005B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0005B&lasPeriod=219&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0005b-arcgis"
---

# ArcGIS (L0005B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

After approved course the students shall know how to

- collect, store, analyse and visualize geographical data.

- build small geographical databases and design small geographical information systems (GIS) with basic functionality.

- build small applications

- document their work according to established methodology.

## Contents

- Introduction to the subject field Geographical Information Systems (GIS)

- Traditional GIS-software: ArcGIS

Concepts

Construction

- Practises, including:

Layers management

Database management

Creating and displaying data

Designing maps

Analyzing data

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. All the course material can be found on LTU’s Citrix portal. There you can also find more detailed descriptions of the course contents and its realization. There are no pre-recorded lectures, nor are there any mandatory gatherings. The book constitutes the course literature and should be followed according to its instructions.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course is target examined through assignments that will be completed individually or in groups of two people who will be examined throughout the course. Marking of the assignments will be made according to U/G marking scale. All assignments should be completed to receive a final mark. Deliverables are available on LTU’s Citrix portal.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course L0005B is equal to ABL013

## Remarks

A course that is completed online demands that the student has access to some form of broadband connection.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment | U G# | 7.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural

Resources Engineering 2022-02-11

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
