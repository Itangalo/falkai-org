---
course_code: "O7028K"
title: "Geodata - from analysis to model"
credits: "7.5"
title_sv: "Geodata - från analys till modell"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Malmgeologi"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O7028K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O7028K&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o70/o7028k-geodata---fran-analys-till-modell"
---

# Geodata - from analysis to model (O7028K)

## Entry requirements

At least 90 credits completed courses where at least 60 credits in the area of nature resource technology, geology or geoscience. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

Upon completion of the course the student should be able to:

- demonstrate an understanding of different types of geodata and critically analyze their characteristics (Learning Outcome 1),
- evaluate different data acquisition methods and apply quality assessment techniques to ensure data reliability (Learning Outcome 2),
- utilize online geodatabases for geoscience data analysis and interpretation (Learning Outcome 3),
- demonstrate the ability to critically analyze and select appropriate data transformation methods and advanced techniques, such as machine learning and geostatistical methods, for solving geoscientific problems (Learning Outcome 4),
- critically assess geoscientific models from micro- to regional scale, evaluate their underlying assumptions, and apply modeling techniques to extract information from complex geoscience data (Learning Outcome 5),
- demonstrate a basic understanding regarding the application of artificial intelligence in geoscience (Learning Outcome 6), and
- independently perform data processing, validation, and modelling based on real-world data (Learning Outcome 7).

## Contents

The course deals with strategies for acquiring, storing and processing geoscientific data, with the aim of creating a deeper understanding of the flow of data in mining and exploration projects and specific challenges that arise when handling large and complex data sets. Topics covered include:

Introduction to Geoscience Data Analysis • Data Acquisition and Quality Assessment • Data Storage, Management and Validation • Data Processing Techniques • Modeling • Artificial Intelligence

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

This course includes lectures, practical exercises and a project work. Lectures and practical exercises are organized in an alternating order where theoretical principles are covered in the lectures and the learned skills are then applied in the related practical exercises.

The practical exercises are performed to improve collaboration and enhance problem solving skills. The project work is devoted to describe, analyze, interpret and present a complex topic in the field of geodata analysis and modeling.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through practical exercises, project work and an examination. Practical exercises are only graded as passed – not passed. The project report and examination are given with differentiated grades.

The intended learning outcomes of the course are assessed by three different assessments: 1. All learning outcomes except learning outcome 7 are assessed through an examination (Grading scale: 5 4 3 U) 2. Learning outcomes 2, 3, 4 and 5 are assessed by practical exercises (Grading scale: G#/U) 3. Learning outcome 7 is assessed through the project work (Grading scale: 5 4 3 U)

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Exam | GU345 | 3 | Mandatory | S25 |  |
| 0002 | Project work | GU345 | 3.5 | Mandatory | S25 |  |
| 0004 | Exercises | UG | 1 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14
