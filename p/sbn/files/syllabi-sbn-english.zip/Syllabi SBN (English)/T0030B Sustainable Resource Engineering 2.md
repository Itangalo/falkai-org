---
course_code: "T0030B"
title: "Sustainable Resource Engineering 2"
credits: "15"
title_sv: "Hållbar mineralutvinning 2"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-13"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0030B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0030B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t00/t0030b-hallbar-mineralutvinning-2"
---

# Sustainable Resource Engineering 2 (T0030B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and L0049K Sustainable Resource Engineering 1. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The course provides advanced knowledge of the mineral and metal value chain, how the different parts of the value chain are connected and the relation to the surrounding society and environment. After completing the course, the student should be able to:

Knowledge and understanding 1. Understand the use of advanced technologies in resource engineering that can assist mineral and metal extraction process to become more sustainable in the future.

Competence and skills 2. Demonstrate the ability to search for and gather scientific information about the advanced technologies used in resource engineering.

Judgement and approach 3. Be able to make proper technical assessments based on scientific principles.

## Contents

The course is a project course that provides advanced knowledge of the mineral and the metal value chain. The course consists of different parts along the value chain in project form, both independent work and group work. The course consists of both practical and theoretical elements and of importance is oral and written presentation.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. Project work in groups and independently combined with lectures, study visits, and workshops.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Goals/ILOs are assessed through written report as well as presentations/discussions during workshops.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project work 1, including oral presentation and report | U G# | 3.7 | Inactive | A25 |  |
| 0002 | Project work 2, including oral presentation and report | U G# | 3.8 | Inactive | A25 |  |
| 0003 | Project work 3, including oral presentation and report | U G# | 3.8 | Inactive | A25 |  |
| 0004 | Project work 4, including oral presentation and report | U G# | 3.7 | Inactive | A25 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
