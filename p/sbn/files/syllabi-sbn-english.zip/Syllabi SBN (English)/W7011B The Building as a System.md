---
course_code: "W7011B"
title: "The Building as a System"
credits: "7.5"
title_sv: "Byggnaden som system"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2023-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=W7011B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=W7011B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/w70/w7011b-byggnaden-som-system"
---

# The Building as a System (W7011B)

## Main field of study

Architecture

## Entry requirements

- Knowledge of project work and project management corresponding to, for example, the course P0007B Project management
- Knowledge in building technology corresponding to, for example, the course W7007B Building technology
- Knowledge in structural design theory corresponding to, for example, the course K7012B Structural design
- Knowledge in room and building acoustics equivalent to, for example, the course Z7001B Architectural acoustics
- Knowledge in life cycle analyses corresponding to, for example, the course W7008B Environmentally-efficient construction

## Selection

The selection is based on 30-285 credits

## Course Aim

The purpose of the course is for you to develop understanding and abilities to propose and evaluate renovation measures for a building as a system in a given context, where the building is considered as a technical and architectural whole.

Knowledge and understanding

After completing the course, you should be able to:

- describe the renovation process, its stages and conditions

- describe and discuss how a building's design, construction and technical systems affect its function and performance

- relate investigation projects in renovation to relevant research and development work

Competence and skills

After completing the course, you should be able to:

- plan and actively contribute to investigation projects in renovation by:

- propose a set of suitable renovation measures to improve a building's function and performance based on prevailing conditions
- investigate and assess how proposed renovation measures affect the building as a system, considering some selected technical and architectural aspects, from a life-cycle perspective
- explain and justify the assessments and considerations that form the basis of proposed renovation measures

- compile, report and discuss implementation and results of investigation projects in a structured way, both in writing and orally

Judgement and approach

After completing the course, you should be able to:

- reflect on the consequences of proposed building renovation based on a holistic view of the building as a system

- reflect on social, economic, environmental and work environment consequences of proposed building renovation

## Contents

In the course, you apply and deepen knowledge and skills in project management and building design that you have acquired in previous courses in the program. The application and deepening take place in the field of building renovation. The course deals with concepts, processes, prerequisites, solutions and methods for renovation based on a holistic view of the building as a system. In addition, the course deals with challenges and limitations that prevail when working with existing buildings. The course includes, and places particular emphasis on, application of the course material in an investigation project on possible renovation measures for a real-life existing building.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

In the course, you carry out a qualified investigation in the form of a project work in a group. The work is supported by lectures, tutorials and dialogues during presentations. The investigation project includes three stages that build on each other: Planning, Inventory and Investigation. In addition, you carry out an individual review of another investigation project and a reflection on your group’s investigation project.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Five examination modules (Test 0001, 0002, 0003, 0004 and 0005) are included in the course, all of which must be completed for the final grade in the course.

The learning objectives relating to knowledge and understanding are examined through Tests 0002, 0003 and 0005. The learning objectives relating to skills and abilities are examined through Exams 0001, 0002, 0003, 0004 and 0005. The learning objectives relating to judgement and approach are examined through Exam 0005.

Test 0001 (Planning; G U) is examined through a project planning written in group. Test 0002 (Inventory; G U) is examined through an oral group presentation. Test 0003 (G U) is examined through a combination of a written report and an oral presentation in a group. Test 0004 (G U) is examined through a written individual assignment. Sample 0005 (U 3 4 5) is examined through a written individual assignment and an oral reflection.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course W7011B is equal to W7009B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Planning | U G# | 0.5 | Mandatory | A23 |  |
| 0002 | Inventory | U G# | 1.5 | Mandatory | A23 |  |
| 0003 | Investigation | U G# | 3 | Mandatory | A23 |  |
| 0004 | Examination | U G# | 0.5 | Mandatory | A23 |  |
| 0005 | Reflection | GU345 | 2 | Mandatory | A23 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13
