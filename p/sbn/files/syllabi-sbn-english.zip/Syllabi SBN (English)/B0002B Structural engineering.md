---
course_code: "B0002B"
title: "Structural engineering"
credits: "7.5"
title_sv: "Konstruktionsteknik"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Konstruktionsteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B0002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B0002B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/b00/b0002b-konstruktionsteknik"
---

# Structural engineering (B0002B)

## Main field of study

Architecture, ., Civil Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and M0047M Differential Calculus and M0048M Linear Algebra and Calculus and F0004T Physics 1 or corresponding courses.

## Selection

The selection is based on 1-165 credits.

## Course Aim

To attain basic ability to do calculations related to strength of materials and beam theory.

## Contents

Basics of strength of materials: Stresses, strains and their relations and transformations Bars: Stresses, strains and deformations Beams: Moments, shear forces and stresses from bending. Introduction to deformations, stability and design

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. There will be lectures, exercises and demonstrations. Demonstrations are compulsory.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Written exam with graded marks (U, 3, 4, 5) Presence at demonstrations and passed reports on demonstrations.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course B0002B is equal to ABB025

## Remarks

null replaces the earlier courses ABB017 and ABK117.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 6 | Mandatory | A07 |  |
| 0002 | Laboratory work | U G# | 1.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
