---
course_code: "T7025B"
title: "Project Course in Rock and Soil"
credits: "7.5"
title_sv: "Projektkurs i Jord och Berg"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7025B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7025B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7025b-projektkurs-i-jord-och-berg"
---

# Project Course in Rock and Soil (T7025B)

## Main field of study

Civil Engineering

## Entry requirements

- The courses T7002B Design of Rock Constructions, T7008B Open Pit and Underground Mining, and G7006B Foundation Engineering

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course participants should be able to

1. have insight into current research and development work within the specific niche of your project,

2. be able to plan and adequately implement qualified tasks within given timeframes, thereby contributing to the development of knowledge and evaluating the conducted work,

3. in international contexts, be able to explain and discuss your conclusions and the knowledge and arguments that underlies them

## Contents

The main topics covered in the course are:

- Introduction - Overview of the course, description of available projects.

- Project planning - Overview of how to plan projects.

- Written presentation - Overview of how to present work in a scientific way.

- Oral presentation - Overview of how to orally present work.

Exact content is designed in dialogue with the examiner or appointed supervisor. The projects will be connected to the subjects Rock Mechanics, Rock Engineering or Geotechnics

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

This course includes teaching and learning activities such as:

- Lecture - There the lecturer explains the most important theoretical aspects related to the course content, which you later apply in the different parts of your project work.

- Project work – Here you implement and apply your knowledge and skills acquired so far in your education and in this course for planning and implementation of an advanced project in Rock Mechanics, Rock Engineering or Geotechnics. You must also reflect on the solution and the alternatives that were available during the work. During the work, you document your work and have a dialogue with your supervisor (from the university and/or industry). The project work consists of three parts:

    - Method - The part includes planning and implementation of the project and associated methods.

    - Scientific article (essay) - The part includes writing a conference paper in English that describes the project in a scientific way. The paper must be of a high standard, supported by references and implemented so clearly that a person who is not familiar with the project will be able to take part in and continue working on the information produced.

    - Oral presentation - This part includes planning and performing an oral presentation of the project.

- Reflection - For each of the three parts, you should give feedback on other student's work and reflect on your own performance.

- Supervision - You work together with your supervisor (from the university and/or industry). You make the arrangement for this together with your supervisor.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through:

- Method – Hand-in of the project planning and a report on work performed. The student must also provide feedback on another student's work and reflect on their own work. Assesses intended learning outcome 1 and 2.

- Essay – Hand-in of a conference paper where the project is reported in a scientific way. The student must also provide feedback on another student's essay and reflect on their own essay. Assesses intended learning outcome 3.

- Oral presentation – Perform an oral presentation of the project. The student must also provide feedback on another student's oral presentation and reflect on their own oral presentation. Assesses intended learning outcome 3.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Method | GU345 | 4 | Mandatory | A19 |  |
| 0002 | Essay | GU345 | 2.5 | Mandatory | A19 |  |
| 0003 | Oral presentation | GU345 | 1 | Mandatory | A19 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-02-14
