---
course_code: "X7010B"
title: "Degree project in Civil Engineering, specialization Structural Engineering, Master of Science in Engineering"
credits: "30"
title_sv: "Examensarbete i Väg- och vattenbyggnad, inriktning Konstruktion, civilingenjör"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "UG"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Science in Engineering 30 cr                                                            Sp 3            17"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X7010B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X7010B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/x70/x7010b-examensarbete-i-vag--och-vattenbyggnad-inriktning-konstruktion-civilingenjor"
---

# Degree project in Civil Engineering, specialization Structural Engineering, Master of Science in Engineering (X7010B)

## Main field of study

Civil Engineering

## Entry requirements

At least 240 credits completed courses as required for the degree. A maximum of two 7.5 credits courses (or one 15 credits course) may be unfinished from base and core courses. Of the completed courses at least 30 credits shall be of advanced level. In addition to the above, the examiner decides whether the proposed degree project is within the subject area and student has the depth of knowledge required.

## Selection

The selection is based on 30-285 credits

## Course Aim

The overall goal of the course is that the student practices, develops and is able to apply theory and methods to solve unstructured problems relevant to a profession as Master of Science in Civil Engineering within the field Structural Engineering.

This means that on completion of the course the student is able to:
- Formulate a relevant problem for investigation from a chosen subject within the subject area Structural Engineering.
- Apply knowledge and proficiency that has been acquired during the period of study to a complex development project or a smaller research project in an independent and systematic manner.
- Choose and justify the study method for an investigation.
- Analyse and defend the problem formulated in a correct manner with respect to science and engineering, without complete information.
- Locate and critically review information and summarise this in a scientific manner.
- Plan, structure and execute a project within research, development or investigation.
- Judge the scientific and practical relevance of the results obtained.
- Work to a timetable.
- Express themselves well in writing in a verbally and scientifically correct manner.
- Create and execute a presentation of the results of the project, defending the conclusions.
- Critically review the work of others in a constructive and scientific manner.

## Contents

The content of the degree project is designed in collaboration with the supervisor. The degree project always contains a theoretical foundation in the form of a literature survey that highlights the area of technology and the methodology, summarised in a scientific manner.

## Realization

Science in Engineering 30 cr                                                            Sp 3           17

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The student independently plans and executes the degree project; the supervisor is available for assistance. A timetable for the entire project is included in the degree project, which is continuously reviewed.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.
- Written presentation of individual work. In the report the student shows the ability to:
    - Justify the chosen problem of study
    - Select and justify the study methods
    - Collect information relevant to the problem formulation with an explicit connection to the chosen theory/method
    - Present in writing the information collected in a relevant manner
    - Analyse and defend the formulated problem from the chosen theory and methods
    - Critically review the relevance of the results obtained from a scientific and engineering point of view
    - Express themselves in writing in a correct linguistic and scientific manner.
- Oral presentation of own work
- Public discussion of the work of others
- Attendance at presentations of the degree project work of others

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The department provides active supervision for a period of two terms from the start of the project. The degree project is performed individually; only in exceptional cases may at most two students carry out the degree project together. In cases in which the degree project is carried out by two students, this shall be clearly visible in the scope and depth of the report.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Science in Engineering 30 cr                                                            Sp 3            17

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Oral presentation | UG | 0 | Mandatory | S27 |  |
| 0006 | Start of degree project | UG | 0 | Mandatory | S27 |  |
| 0007 | Approved report | UG | 30 | Mandatory | S27 | Yes |
| 0008 | Public discussion of others degree project | UG | 0 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2013-02-07
