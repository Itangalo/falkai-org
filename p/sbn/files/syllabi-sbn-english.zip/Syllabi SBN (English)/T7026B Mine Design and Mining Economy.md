---
course_code: "T7026B"
title: "Mine Design and Mining Economy"
credits: "7.5"
title_sv: "Gruvdesign och brytningsekonomi"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2021-11-02"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7026B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7026B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7026b-gruvdesign-och-brytningsekonomi"
---

# Mine Design and Mining Economy (T7026B)

## Main field of study

Civil Engineering, .

## Entry requirements

At least 90 credits in Civil Engineering - Soil and Rock Engineering. Course T0013B Rock Engineering and Rock Mechanics or equivalent knowledge must be included within these credits

## Selection

The selection is based on 30-285 credits

## Course Aim

The course goal is that the students should be able to apply and implement the theoretical foundations as well as the tools and methods used for mine design and mine planning.

The ILO of this course are as follows:

1. Describe the overall timeline of a mining project. This is assessed by quiz.

2. Apply and implement technical and theoretical issues regarding mine design, production planning and mining economy. This is assessed by assignment 1 and 2.

3. Apply the state of the art software for mine design and production planning. This is assessed by assignment 1 and 2.

4. Evaluate the risk of a mining project. This is assessed by quiz.

## Contents

- Theory of mine design, mine planning, mine feasibility study and mine economics.

- Mine planning and production planning, through computer-based planning tools, for underground and open pit operations.

- Risk analysis of mining projects: basic theory, risk identification and assessment.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. Lectures and exercises, computer-based exercises, assignments and a mine study visit. All activities are mandatory.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Quiz on mining economics and mine design & mine planning, to assess ILO 1 and 4.

Assignment 1: computer-based mine design and mine planning, to assess ILO 2 and 3.

Assignment 2: Production planning project, to assess ILO 2 and 3.

Students must do all assessments in order to pass the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The course is based on T7011B and T7013B.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Quiz | GU345 | 2 | Mandatory | S20 |  |
| 0002 | Assignment 1 | GU345 | 1 | Mandatory | S20 |  |
| 0003 | Assignment 2 | GU345 | 4.5 | Mandatory | S20 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural

Resources Engineering 2021-11-02

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-06-14
