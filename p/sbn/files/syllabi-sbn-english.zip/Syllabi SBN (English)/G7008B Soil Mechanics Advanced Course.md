---
course_code: "G7008B"
title: "Soil Mechanics, Advanced Course"
credits: "7.5"
title_sv: "Geoteknik fk"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geoteknik"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7008B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7008B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/g70/g7008b-geoteknik-fk"
---

# Soil Mechanics, Advanced Course (G7008B)

## Main field of study

., Civil Engineering

## Entry requirements

Basic course in soil mechanics including soil physics and basic soil behavior. Stress-strain relationships in soils. Mean stresses and deviatoric stresses. Effective stress concept and consolidation theory. Bearing capacity. Classical consolidation theory and settlement calculation. Earth pressure against retaining walls. Slope stability with cylindrical slip surface. Common laboratory methods.

## Selection

The selection is based on 30-285 credits

## Course Aim

To provide a deeper understanding of some areas of soil mechanics and foundation engineering and to introduce the student to ongoing research in some areas of soil mechanics. The students shall also see the application of the basic geotechnical concepts independent of specific tasks.

Further, the intention is to train the students to read complex comprehensive scientific literature.

## Contents

Soil Dynamics and Geotechnical Earthquake Engineering (30%) Principles of soil dynamics based on mass oscillator, wave propagation and equivalent elastic soil behaviour, Introduction into the basics of geotechnical earthquake engineering, vibration and vibration protection, liquefaction. Rehabilitation measures.

Strength and deformation properties of soils-constitutive modelling (30%). Laboratory and field methods for determination of strength and deformation properties of soils. Behaviour of soils under compression and shear. Reversible and irreversible deformation. The concepts of contractance, dilatancy and critical state. Laboratory test with performance of a triaxial test on a soil sample for termination of its strength and deformation properties. Theories for the constitutive modelling of soils, especially the flow theory of plasticity. Example from Cam Clay model (critical state theory). Computer laboratory with the application of a constitutive driver for the simulation of a triaxial test.

Slope stability and landslides (30%). Different slide mechanisms. Classical methods of slope stability analysis with emphasis on drained analysis (coanalysis).Computer laboration with the drained analysis of a slope, comparison of different theories. Numerical methods of slope stability analysis. Geotechnical investigations inslide potential areas. Computer simulations with a commercial finite element software.

Case Histories (appr. 10%) Some lectures given by experts and or practising engineers with focus on projects or special construction techniques in geotechnical engineering.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. Teaching is given in classes, including problem-solving and informal discussions. Laboratory work. Assignments solved by the students. Reading, summarising and presenting a complex comprehensive research paper (Rankine lectures).

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Examination based upon written summary and the oral presentation of the research paper, fulfilled assignments and laboratory reports.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course G7008B is equal to ABG112, ABG105

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Seminar essay | U G# | 3.8 | Mandatory | A07 |  |
| 0002 | Project work | U G# | 3.7 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural

Resources Engineering 2021-02-17

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2007-01-31 and is valid from H07.
