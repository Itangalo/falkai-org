---
course_code: "K7026B"
title: "Design of Timber Structures 1"
credits: "7.5"
title_sv: "Träkonstruktion 1"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2026-02-13"
education_level: "Second cycle"
grade_scale: "U G VG"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7026B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7026B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7026b-trakonstruktion-1"
---

# Design of Timber Structures 1 (K7026B)

## Main field of study

.

## Entry requirements

At least 90 credits within the field Civil Engineering or corresponding. Basic knowledge in structural engineering, mechanics or solid mechanics with a content similar to one of the following three courses; B0002B Structural engineering, K0013B Structural Design or M0032T Mechanics and strength of materials or corresponding. In addition, English 6/level 2 and Swedish 3/level 3 are required.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, the student should be able to:

Knowledge and understanding

- Account for how the properties of timber differ from those of other construction materials in structural applications

- Describe various failure modes in timber joints and their underlying causes

- Explain in which scenarios actions perpendicular to the grain direction may occur in timber structures

- Explain the reasoning behind the formulas and design rules in the Eurocode

Competence and skills

- Design timber structures in accordance with the Eurocode

- Design joint solutions in timber structures

- Calculate stresses and deformations in structural timber elements

Judgement and approach

- Assess the strengths, weaknesses, and applicability of calculation methods

- Evaluate the reliability of calculated results

## Contents

The course covers the following:

- Design of timber structures and structural elements in accordance with the Eurocode

- Design of connections in timber structures in accordance with the Eurocode and guidelines for glued timber products

- Calculation of stresses and deformations in glulam beams and cross-laminated timber (CLT)

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The course is offered as a distance course and is based on self-studies of literature and other distributed material according to a study guide, complemented by recorded lectures and live online sessions with the instructor. Skills and abilities are developed through practical exercises.

Student learning is continuously monitored through supervision meetings, during which students are expected to have prepared material in accordance with the instructions provided in the study guide

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Assessment is carried out continuously through mandatory written assignments. The course concludes with an individual oral examination.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K7026B is equal to W7017T

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written assignments | U G VG | 5 | Mandatory | A26 |  |
| 0002 | Oral examination | U G# | 2.5 | Inactive | A26 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Director of Undergraduate Studies Michael Försth, Department of Civil, Environmental and Natural Resources Engineering 2026-02-13
