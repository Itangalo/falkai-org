---
course_code: "O0038K"
title: "Economic Geology"
credits: "7.5"
title_sv: "Ekonomisk geologi"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2025-04-16"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Malmgeologi"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0038K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0038K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o00/o0038k-ekonomisk-geologi"
---

# Economic Geology (O0038K)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and O0035K Geology, basic course and O0036K Mineralogy or corresponding.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After the course, the student should be able to: 1) account for the most important ore forming processes in time and space, 2) account for the nature and formation conditions of the main ore types and industry mineral deposits, 3) have knowledge about the most important ore regions in Sweden, 4) apply geological methods for documentation and core logging.

## Contents

Classification of ore types. Ore forming processes. Character and geological environment of the main ore types and their relation to plate tectonics. Industrial minerals, their occurrence, formation conditions and use. Aggregates, natural stone and energy raw materials of geological origin. Core logging methods. Sweden's most important ore districts and mineral deposits.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching includes lectures where basic theory is presented and explained and includes ore forming processes, the character and origin of the major ore types, industrial minerals, aggregates, dimension stone and energy raw materials. Practical exercises are linked to the lectures and focus on the student's skills in describing, interpreting and explaining the character of ores and industrial mineral deposits. Swedish ore districts and mineral deposits are presented in lectures and through the student's own project work with oral presentation, and there is training in drill core mapping.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Graded written examination and approved exercises and oral presentation of project work.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not

previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0012 | Written exam | GU345 | 5.5 | Mandatory | A09 |  |
| 0014 | Project work | UG | 1 | Mandatory | S27 |  |
| 0015 | Project work | UG | 1 | Mandatory | S27 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-04-16

## Syllabus established

by Department of Chemical Engineering and Geosciences 2009-02-19
