---
course_code: "D7009B"
title: "Senior Design Project in Maintenance Engineering"
credits: "30"
title_sv: "Projektkurs i underhållsteknik"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2016-06-13"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7009B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7009B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7009b-projektkurs-i-underhallsteknik"
---

# Senior Design Project in Maintenance Engineering (D7009B)

## Entry requirements

At least 120 Hp or corresponding within the subject Maintenance Engineering

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, the student should design, carry out and report a project within the subject and learn to work independently in research-linked projects.

## Contents

The content of the project is designed in collaboration with the examiner or designated supervisor. The project always contains a theoretical foundation in the form of a literature survey that highlights the area of technology and the methodology, summarised in a scientific manner.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The student independently plans and executes the degree project with guidance.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The examination of the course is specified, by the examiner, in a detailed course description at the course occasion and can consist of

- written report

- oral presentation of own work

- public discussion of the work of others

- seminars

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The department provides active supervision for a period of two terms from the start of the project.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Project work | U G# | 30 | Mandatory | S17 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Syllabus established

by Eva Gunneriusson 2016-06-13
