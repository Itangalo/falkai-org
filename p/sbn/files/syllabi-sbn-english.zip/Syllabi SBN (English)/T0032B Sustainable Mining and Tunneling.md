---
course_code: "T0032B"
title: "Sustainable Mining and Tunneling"
credits: "7.5"
title_sv: "Hållbar gruvdrift och tunnelbyggande"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2025-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0032B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0032B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t00/t0032b-hallbar-gruvdrift-och-tunnelbyggande"
---

# Sustainable Mining and Tunneling (T0032B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and T0013B Rock Engineering and Rock Mechanics or corresponding course. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course the successful student shall:

Knowledge and understanding

1. Applying different excavation methods with its applicability to underground construction and tunnelling and its effect on the environment.

2. Applying and understand processes for underground construction, from design to usage.

3. Understand perspectives of sustainable: environment, economy, socially and UN global sustainable goals.

Competence and skills

4. Show skills to orally and written describe and discuss conclusions and arguments which is the basics for the learning.

5. Show skills in collaborating in groups med different composition.

Judgement and approach

6. Describe possibilities and limitations with mining and tunnelling including its role in the society.

7. Identify needs for further knowledge and continuously develop the competence.

## Contents

This course covers environmental aspects and sustainability with mining and tunnelling- we will work rock but depending on usage, different problems will arise. The basis are UN 17 global sustainability goals which are coupled to different learning activities such as lectures, group work and guest lectures. The students will analyse the goals with respect to the machinery, excavation methods, waste handling, ground water affects and effects on the surrounding, nitrogen emissions, what a environmental risk assessment is and what does the legislations tell us.

The course has the following content:

Introduction to UN:s 17 global sustainable goals coupled to tunnelling and mining.

Introduction to mining methods – Why is ore mined? What needs to be known of the deposit, risc associated to the deposit, how does Swedish mining industry look like, Swedens role in raw material supply.

Introduction to tunnel- and underground construction – methods for tunnelling, types of machinery, machines for different methods and rock types.

Perspectives of sustainability

Which processes are needed and laws applied for starting a mine or building a tunnel?

How to design a mine under round? What is needed and required? What to think of?

How to design a tunnel in an urban environment? How is the surroundings affected and how to choose methods that has minimal impact on the environment.

Study visit

- A study visit in on going construction underground.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The learning activities are:
- Lectures – Different types learning activities where each lesson is introduced with theory statement where the lecturer describes the most important aspects related to the course content. And together solve/discuss typical problems or questions encountered with the topic. It can be either pre-recorded theory chapters or lessons with theory sessions with interactive activities.

- Between lectures- it is expected that the students is well prepared for every lesson by working with given material (exercises discussed in previous lessons or handed out). This is expected so that the students can participate and contribute in the learning activities (problem solving, discussions etc) during the lessons.

- Project tasks – you will work alone and in groups with other students and use your skills to study problems and questions. You will present your work in a written report and orally including reflect on other students work. Based on a method of excavation for a mine or a tunnel suggestions on improvement based of at least three of UN:s goals for sustainability. The improvement should be in such nature that it can be implemented with today’s technique and knowledge.

- Study visit – A study visit in ongoing construction underground and gather information to be presented written or orally explanation of the visit

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is examined in the following way:

- Project task – Group- hand ins of reports where the participants explains the task and how they planned and executed the work- The students should give feedback on other students group tasks. Examines the goals 1, 2, 3, 4, 5, 6 and 7

- Oral presentation – Conduct a oral presentation coupled to the project tasks. The students shall also give feedback on other students presentations and reflect on their own. Examines goal 2.

- Study visit – Compulsory attendance at visit and hand in of written or oral explanation. Part of examinations goal 1 and 2.

- Oral exam/Quiz – Examines goal 1,2 and 3

All modules of examinations must be passed to receive a final grade of the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0004 | Oral exam - quiz | GU345 | 3 | Mandatory | S26 |  |
| 0005 | Required assignment - group | UG | 3.5 | Mandatory | S27 |  |
| 0006 | Study visit | UG | 0.5 | Mandatory | S27 |  |
| 0007 | Oral presentation | UG | 0.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
