---
course_code: "C0022B"
title: "Society's planning for hazards"
credits: "7.5"
title_sv: "Samhällets planering för risker och kriser"
valid: "Spring 2015 Sp 3 - Autumn 2017 Sp 2"
decision_date: "2014-05-28"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Items/credits No items/credits available"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=C0022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=C0022B&lasPeriod=187&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/c00/c0022b-samhallets-planering-for-risker-och-kriser"
---

# Society's planning for hazards (C0022B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and 30 credits in technology

## Selection

The selection is based on 1-165 credits.

## Examiner

Glenn Berggård

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Overlap

The course C0022B is equal to C0023B, C0024B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Items/credits No items/credits available

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Literature

*Literature. Valid from Spring 2015 Sp 3* Boverket och Räddningsverket (2006) Säkerhetshöjande åtgärder i detaljplaner. Karlskrona och Karlstad: Boverket och Statens räddningsverk, 2006 Krisberedskapsmyndigheten (2008) Klarar vi krisen? Samhällets krisberedskapsförmåga 2007. KBM:s temaserie 2008:2 Räddningsverket (2004) Riskhantering i Översiktsplaner. Karlstad: Statens räddningsverk, 2001 Myndigheten för samhällsskydd och beredskap (2012) Olycksrisker och MKB. Att integrera risk- och säkerhetsfrågor i MKB-processen Myndigheten för samhällsskydd och beredskap (2011) Vägledning för risk- och sårbarhetsanalyser.

## Syllabus established

by Eva Gunneriusson, Assistant Director of Undergraduate Studies at the Department of Civil, Environmental and Natural Resources Engineering 2014-05-28
