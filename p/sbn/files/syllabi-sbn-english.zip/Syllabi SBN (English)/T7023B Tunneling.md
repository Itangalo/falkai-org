---
course_code: "T7023B"
title: "Tunneling"
credits: "7.5"
title_sv: "Tunnelprojektering"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7023B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7023B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7023b-tunnelprojektering"
---

# Tunneling (T7023B)

## Main field of study

Civil Engineering, .

## Entry requirements

Basic knowledge regarding the rock Engineering unit operations, rock blasting and mining engineering in Sweden corresponding to T0013B, basic rock mechanics corresponding to T0014B and soil mechanics corresponding to G0003B.

## Selection

The selection is based on 30-285 credits

## Course Aim

Tunneling in hard rock involves environmental consideration with design of tunnels including rockmechanics, excavation methods with emphasis on blasting, reinforcement, hydrogeology and grouting. The aim of the course is to guide the students to develop their knowledge in application of design of tunnels.

Knowledge and understanding

For a pass on the course, the successful student should be able to:

1. Apply Swedish design standards for a tunnel project.

2. Describe different stages in the design of a tunnel.

3. Propose appropriate measures related to technology, economy and organization for the efficiency of tunnel construction.

Competence and skills

For a pass on the course, students shall be a able to:

1. Without complete information in an engineering and scientific way, analyze and answer the formulated problem.

2. Describe the basis for an engineering geological forecast

3. Carry out calculation, account and argue for appropriate content in an initial and continued pre-investigation.

4. Describe different tunneling methods as well as motivate and explain the choice of these.

5. Analyze, compare and motivate, from a rock engineering perspective, when a tunnel option is more advantageous to use than other suggested alternatives.

6. Present current research and underground projects in Sweden and abroad and explain current principles and working methods used in tunnel design.

Judgement and approach

For a pass on the course, students shall demonstrate the ability to

1. Carry out literature study and critically review information and summarize it in a scientific manner.

2. Understand societal aspects that affect tunneling.

## Contents

The following topics will be covered:

- General introduction of tunnelling

- The legislation of a tunnel project

- The design of reinforcement and mechanics of a shallow located tunnel

- Hydrogeology of rock

- The design of grouting

- Design of blasting with respects to environmental considerations (vibrations)

- Carry out a field study using water-loss measurements

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. This course includes lectures, self-study, weekly assignments as well one project assignment in groups. The project assignment is presented orally. The project assignment is focused of one drill-and blast process of the student´s choice and should incorporate the weekly assignments and written in the form of AMA-code.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through three different tasks:

- Approved project assignments comprising the weekly assignments and a final project report with oral presenation (4HP).

- Attended the field study (1HP)

- A written exam, Quiz, (2.5HP)

According to intended learning outcomes, ILOs of Knowledge and understanding point 1, 2 and 3 are directly linked to the points under Competence and skills and are assessed through weekly assignments and graded with the scale of G/U 3 4 5, where grade 3 is passed. The same points are graded with distinction of the project members using a quiz graded in the same way.

The ILOs 1 in Judgement and approach is assessed in the literature survey which is incorporated in the project assignment.

The ILOs 2 in Judgement and approach is assessed in project work

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course T7023B is equal to T7021B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Project work | GU345 | 4 | Mandatory | S18 |  |
| 0004 | Quiz/Written exam | GU345 | 2.5 | Mandatory | S18 |  |
| 0005 | Compulsory field study | UG | 1 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2017-06-16
