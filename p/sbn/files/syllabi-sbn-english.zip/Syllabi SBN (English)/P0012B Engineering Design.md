---
course_code: "P0012B"
title: "Engineering Design"
credits: "7.5"
title_sv: "Projektering"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2025-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Byggproduktion"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0012B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p00/p0012b-projektering"
---

# Engineering Design (P0012B)

## Main field of study

.

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Swedish upper secondary school courses Physics 2, Chemistry 1, Mathematics 4 or Mathematics E. Or: Physics level 2, Chemistry level 1, Mathematics Further level 2 or Mathematics E.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

The overall goal after passing the course is for the student to have a basic understanding of the design process, methods and technical knowledge of various deliverables from the design within the civil engineering process.

Knowledge and understanding

1. The student must acquire knowledge of various planning processes within the civil engineering sector and obtain an understanding of various supporting methods including its activities, actors and the responsibilities of various roles.

2. The student must build a theoretical base within industry standards for construction documents, systematic construction and building information modeling (BIM).

Skills and Abilities

The student must:

3. Be able to work individually as well as in a group.

4. Read and process and use instructions in English and Swedish.

5. Apply simpler project planning including activity and processes.

6. Apply CAD tools in real civil engineering project at basic level.

7. Present information sets, drawings and digital models (BIM.

Valuing ability and reflections

8. Analyze and relate acquired knowledge to industry-specific challenges

## Contents

This course provides general knowledge of design processes in civil engineering, with a more in-depth focus on methods and execution of deliveries. Project planning is a central sub-process within civil engineering in which one plans, designs and determines the design of buildings and infrastructures. Both planning and carrying out the design is the part of the construction process where the architect's intentions are realized and described so that the building/infrastructure can be erected by one or more contractors. The course primarily describes the design process based on both the construction of buildings, structures as well as infrastructure, between which there are both similarities and differences. The design process for both buildings and infrastructure is divided into several phases with an increased level of detail the closer you get to the production process.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The learning activities consist of lectures, project work, seminars, reflection tasks and written quizzes. The activities contain both individual and group project work for the various parts. Project work is mainly carried out when applying CAD tools, while the individual elements relate in different ways to planning through both practical and theoretical elements. Theoretical knowledge is mainly acquired through lectures and course literature, while the practical aspects also include seminars and laboratories.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

For theory and application, process and technology, the elements are examined in the grading scale U, 3, 4, 5, where level 3 is assessed on the basis that the student has acquired the majority of the skills practiced within the course on the project The student must have acquired the majority of the skills practiced within the course on the project. The student must

understand what the assigned task entails and be able to apply it against the requirements set in the instruction.

For assessment level 4, the student must also clearly demonstrate abilities in the application and

independently solve problems along the steps. For assessment level 5, the student must in addition to previous criteria develop, analyze and present their results in a deeper and more complete way.

Examination through dust and submissions for theory and application process and technology.

The course is examined in several different ways to suit the different goals. The learning objectives that relate to understanding of the theoretically acquired knowledge (learning objectives 1 and 2) are examined based on these, grading takes place according to the grading scale U 3 4 5. Learning objectives 3,5 and 7 are examined by completing written reports and exercises, grading takes place according to the grading scale U 3 4 5, respectively U G#. Learning objective 6, which is about learning to apply information management with BIM, is examined via a submission task, grading takes place according to the grading scale U 3 4 5. Learning objectives 8 and 9, which is about applying industry-specific applications for construction documents and technical descriptions, is examined in seminar form, grading takes place according to rating scale U G#.

In order to achieve a passing grade (3) on the course, G# is required on all included examinations. In order to achieve higher grades (4 and 5), not only approved submissions are required, but higher grades on the examinations that have a grading scale of U 3 4 5.

The course includes mandatory attendance on campus at seminars, external lectures (linked to reflections) and written assignments.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Theory and application process and technology | GU345 | 4.5 | Mandatory | A25 |  |
| 0002 | Understanding and reflection deliveries, standards and regulations | U G# | 3 | Inactive | A25 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
