---
course_code: "F7007B"
title: "Architectural Building Planning"
credits: "7.5"
title_sv: "Arkitektonisk byggnadsprojektering"
valid: "Autumn 2025 Sp 1 - Present"
decision_date: "2025-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7007B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7007B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f70/f7007b-arkitektonisk-byggnadsprojektering"
---

# Architectural Building Planning (F7007B)

## Main field of study

Architecture

## Entry requirements

P0007B Byggprojektledning and F0012B Conceptual Design or corresponding courses.

## Selection

The selection is based on 30-285 credits

## Course Aim

The goal of the course is to understand, manage, and discuss complex concepts used in the design stage of the building process, as well as to be able to design a building considering regulatory requirements and to understand the importance of building details in a holistic way.

Provide Knowledge about:

- The design process in the implementation stage (modules 0004, 0005).
- How regulatory requirements, technology, and economy influence the architect's creative work (modules 0004, 0005).

Understanding of:

- Factors that influence technical decisions in construction
- How CAD is used as design tool

After completion of the course, students should have acquired the skills and ability to:

- (ILO 01): Use building information Modeling (BM) or CAD for drafting and producing building documentation.
- (ILO 02): Adjust a building design for a construction permit, based on a previous building program.
- (ILO 03): Construction permit: Develop solutions that meet the regulatory requirements set during the building permit stage and prepare drawings for a building permit.
- (ILO 04): Construction drawings: Create technical drawings in the form of a detailed floor plan and a wall section for coordination with stakeholders and contractors.
- (ILO 05):Construction drawings: Create technical drawings of fixed furniture with technical specifications.

## Contents

The course applies the aggregated content of the previous courses undertaken by the students, into a design project in the implementation stage. The project work pertains to complex buildings containing several functions that provide different requirements for building design.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course consists of lectures, workshops, and seminars (oral and written). Assignments are submitted via drawings and oral presentations performed mostly as groupwork.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Written and oral presentations happen as group and individual project work during workshops and final reporting.

80% attendance at lectures and practice sessions with supervision and mandatory attendance at seminars and presentations of project work. The learning objectives are examined in applicable parts both in Building Permit Documents and in Construction Documents.

The work must have achieved the required quality requirements no later than one week after the current academic period. Any remaining elements can be completed when the course opens again.

Written and oral presentation in groups and individually during submission seminars and ongoing at design studios.

Code 0004: Group assessment is based on group work results, presentations, and compliance with assignment requirements. Building Permit Document and Construction Document. Floor plans and building details based on a previous building program. Grade scale: G/U 3/4/5. (ILO 01, 02, 03, 04)

Code 0005: Individual assessment is based on individual tasks, quizzes, and group work performance. Grade scale: G/U 3/4/5. (ILO 03, 04, 05)

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0004 | Construction document with financials | GU345 | 4 | Mandatory | A13 |  |
| 0005 | Construction document | GU345 | 3.5 | Mandatory | A13 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Eva Gunneriusson 2012-03-14
