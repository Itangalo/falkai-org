---
course_code: "K7015B"
title: "Steel and Timber Structures"
credits: "7.5"
title_sv: "Stål- och träkonstruktioner"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2022-11-03"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Konstruktionsteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7015B&lasPeriod=215&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7015b-stal--och-trakonstruktioner"
---

# Steel and Timber Structures (K7015B)

## Main field of study

., Civil Engineering

## Entry requirements

Knowledge about
- building materials corresponding to K0002B Buildning Materials
- strength of materials and solid mechanics and structural mechanics correspondning to B0002B Structural
Engineering and B7004B Structural Mechanics I.
- structural design corresponding to K0013B Structural Design, W7006B/K7012B Structural Design or S0007B Fire Exposed Structural Elements.

## Selection

The selection is based on 30-285 credits

## Course Aim

After the course, the students should be able to

- describe and explain the function and behaviour of steel and timber structures under load

- narrate and describe the background to current regulations for design and execution of steel and timber structures

- apply and chose relevant parts in current regulations for design and execution of steel and timber structures

- plan and perform calculation tasks individually and laboratory tasks in groups and present results and analyses in writing in a structured way so     that a that a technically qualified person can follow the work and reach the same conclusions

## Contents

The course deals with

- operation of steel and timber structures under load

- design of steel and timber structures according to current regulation with regard to local buckling (steel), buckling, lateral torsional buckling, flexural buckling and joints

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The course is conducted in the form of lectures, arithmetic exercises and laboratory work. At lectures, backgrounds and theories of function and mode of action under load are derived,        presented and exemplified under load Application of current regulations and calculation methodology is practiced individually
- on calculation exercises in classrooms
- in computer room using calculation computer software
- in assignments Methods of action under load are tested in laboratories. The ability to plan, carry out and report on group work is practiced in laboratory tasks.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Backgrounds, theories and calculation methodology are examined with a written final exam with differentiated grades. Rating scale: U, 3, 4, 5. Calculation methodology and ability to plan and perform calculation task individually are examined through a written calculation report. Rating scale: U, G. The ability to plan and perform laboratory tasks in groups, process data and present results is examined through written laboratory reports. Rating scale U, G All included examination parts must be completed for the final grade on the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 4 | Mandatory | A19 |  |
| 0002 | Assignment reports | U G# | 2 | Mandatory | A19 |  |
| 0003 | Laboratory work | U G# | 1.5 | Mandatory | A19 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-11-03

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-02-14
