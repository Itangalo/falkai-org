---
course_code: "T7020B"
title: "Applied Rock Mechanics"
credits: "7.5"
title_sv: "Tillämpad bergmekanik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-06-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Berg- och mineralteknik"
subject_group_scb: "Mining and Mineral Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7020B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7020B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7020b-tillampad-bergmekanik"
---

# Applied Rock Mechanics (T7020B)

## Main field of study

Civil Engineering, .

## Entry requirements

T0013B Rock Engineering and Rock Mechanics and T0014B Fundamentals of Rock Mechanics or T7001B Fundamentals of Rock Mechanics, and T7002B Design of Rock Constructions or equivalent knowledge. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

This course will enhance the students’ knowledge and skills as well as judgement in the area of rock mechanics and will help the students to solve practical rock mechanics problems in connection to civil and mining engineering projects.

Knowledge and understanding

After completing the course, the student should be able to

1. design rock beams, pillars, stopes, shafts and backfill,

2. analyse mining-induced subsidence and seismicity, and

3. select and apply the available engineering methods and tools in applied rock mechanics.

Competence and skills

After finishing the course, the student should be able to

4. formulate and carry out appropriate analysis for the given assignments and a project task, and

5. explain principle, mechanism and difficulties on the dimensioning, construction, and control of underground constructions in an engineering way orally, in writing and graphically.

Judgement and approach

After completing the course, the student should be able to

6. assess quality of own work and work by others, and

7. defend their work in connection to a field work or a project task.

## Contents

This course covers

- Beam theory

- Pillar design

- Design of open rooms and stopes

- Shaft design and construction

- Backfill design

- Numerical modelling

- Subsidence prediction

- Mining induced seismicity

- Field visit or project work

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

This course includes teaching and learning activities such as

- Lectures

- Self-studies

- Assignments

- Written tests

- Field visit or project work

- Technical report and oral presentation

The topics in this course are presented in the form of in-class lectures by several lecturers. Theoretical skills are trained through calculations and analyses in class, self-studies and after-class assignments. The understanding of the topics will be assessed through written tests. Focus on a specific engineering problem is made through group field visit and/or project work. The results of the project work are compiled in a written report and need be commented by peer reviewers. The work will be presented orally in the classroom during a seminar and the students need defend their work in group.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through written tests, written technical report and oral exam with differentiated grades (5.0 HP) and required assignments (2.5 HP) during the course.

- Intended learning outcomes 1, 2, 4, 5 and 6 are assessed through required assignments graded with G/U, i.e. Pass (G) or Fail (U).

- Intended learning outcomes 1, 2 and 5 are further assessed through written tests.

- Intended learning outcomes 3-7 are evaluated through written technical report and oral exam.

All exams including the written tests, written technical report and oral exam need to be completed for a course grade. The grades for the written tests, written technical report and oral exam are awarded according to a graded scale of U, G, 3, 4 and 5, i.e. Fail (U), Pass (3), Pass without distinction (4), and Pass with distinction (5).

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0005 | Written tests, project work assignment, oral exam | GU345 | 5 | Mandatory | A08 |  |
| 0006 | Required assignment | UG | 2.5 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-06-14

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2006-02-20 and is valid from H06.
