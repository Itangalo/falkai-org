---
course_code: "K0015B"
title: "Tools for Engineering Calculations and Reporting"
credits: "15"
title_sv: "Verktyg för byggkalkyler och rapporter"
valid: "Spring 2026 Sp 3 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0015B&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k00/k0015b-verktyg-for-byggkalkyler-och-rapporter"
---

# Tools for Engineering Calculations and Reporting (K0015B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Swedish upper secondary school courses Mathematics 2a or 2b or 2c. Or: Mathematics level 2a or level 2b or level 2c.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

After completing the course participants should be able to…

Knowledge and understanding

Interpret and explain basic mathematical concepts and methods.

Distinguish and design different kinds of technical texts.

Express yourself appropriately in speech and writing.

Interpret and present data in diagrams.

Competence and skills

Perform and report mathematical calculations.

Perform and present simple calculations in different tools.

Write and design technical reports.

Present results and facts orally and in writing.

Judgement and approach

Evaluate and apply an ethical approach in solving various tasks.

## Contents

The course deals with three parts: mathematics, data and communication.

Mathematics

Numerical calculations

Equations and differences

Coordinates and systems of equations

Formula treatment

Geometry

Trigonometry

Linear and non-linear equations

Exponential and logarithm functions

Statistics

Data

Calculation tool

Data processing

Chart

Communication

Oral communication

Written communication

Technical reports

Argumentation and presentation techniques

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The teaching consists of lectures, laboratory work, arithmetic exercises, individual work, group work, oral/written presentation, peer response.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is examined as follows:

Mathematics

Four written tests.

Data

Assignments.

Communication

Writing.

Oral presentations.

Technical report.

Grading takes place according to grade scale G U. All included examination parts must be completed for the final grade on the course.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course K0015B is equal to Y0008B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Data | U G# | 0.9 | Mandatory | A19 |  |
| 0002 | Communication | U G# | 3.7 | Mandatory | A19 |  |
| 0003 | Mathematics 1 | U G# | 3.3 | Mandatory | A19 |  |
| 0004 | Mathematics 2 | U G# | 3.3 | Mandatory | A19 |  |
| 0005 | Mathematics 3 | U G# | 1.9 | Mandatory | A19 |  |
| 0006 | Mathematics 4 | U G# | 1.9 | Mandatory | A19 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-02-14
