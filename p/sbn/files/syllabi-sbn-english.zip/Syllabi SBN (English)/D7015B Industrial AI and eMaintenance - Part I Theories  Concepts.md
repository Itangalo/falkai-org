---
course_code: "D7015B"
title: "Industrial AI and eMaintenance - Part I: Theories & Concepts"
credits: "7.5"
title_sv: "Industriell AI och eUnderhåll - Del I: Teorier & koncept"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2025-04-16"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7015B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7015b-industriell-ai-och-eunderhall---del-i-teorier--koncept"
---

# Industrial AI and eMaintenance - Part I: Theories & Concepts (D7015B)

## Entry requirements

A least 60 ECTS in engineering subjects. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After the completion of this course student should be able to describe the terms eMaintenance and Industrial AI. The student should be able to analyse the advanced data analytics techniques related to operation and maintenance processes in industrial contexts. The student should also be able to apply some of these techniques in this context.

## Contents

- Understanding the concept of eMaintenance
- Understanding the concept of Industrial AI
- Overview of related digital and AI technologies
- Software development
- Software engineering
- AI for maintenance analytics
- Information logistics
- Distributed computing, cloud/edge
- Overview of cybersecurity in eMaintenance solutions

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The teaching includes lectures and assignments, including laboratory work. The lectures can be a combination of online, self-study, and/or classroom interaction. The assignments will be a combination of mandatory and optional tasks such as developing solution (software and/or hardware) and practical report writing.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The course objectives are assessed through assignments.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be

assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment report | GU345 | 7.5 | Mandatory | S22 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-04-16

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-06-14
