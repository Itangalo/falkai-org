---
course_code: "B7003K"
title: "Bioprocess Engineering"
credits: "7.5"
title_sv: "Bioprocessteknik"
valid: "Autumn 2025 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2025-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Kemisk apparatteknik"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B7003K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B7003K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/b70/b7003k-bioprocessteknik"
---

# Bioprocess Engineering (B7003K)

## Main field of study

Chemical Engineering

## Entry requirements

Basic principles of physics and chemistry. Mathematics through differentil equations. Transport processes, Unit operation. Corresponding to the courses K0016K Chemical principles, B0007K Organic Chemistry and Biochemistry, B0003K Transport Processes, B0004K Unit Operations and F0004T Fysik 1.

## Selection

The selection is based on 30-285 credits

## Course Aim

The course will give the students an introduction to industrial bio-engineering and also give skills in the use of microorganisms in bio-engineering production systems. After completion of the course students will be able to:

1. describe theoretical concepts within bioprocess engineering.

2. describe and clarify enzymes' basic functions and their significance in biochemical processes.

3. describe central metabolic reaction pathways and in addition explain the cells energy turnover.

4. describe which factors direct microbial cell growth and product structure and in addition complete equations for this.

5. describe bioreactors mathematically.

6. manage and design bioreactors.

7. describe and explain various processes for product extraction and cleaning.

8. describe normal existing large scale bioprocesses.

9. carry out, evaluate and record experimental bio-engineering work

## Contents

The course consists primarily of the following topics:

- Industrial microbiology

- Microbial metabolism

- Enzyme catalysis and kinetics

- Fermentation operation

- Design and control of bioreactors

- Processes for product extraction

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course consists of lectures, tutorials and laboratories. In the lectures the theory regarding the chosen modules will be discussed. During the tutorials, example problems will be solved and the concepts discussed in the theory section will be illustrated. The laboratories illustrate key elements from the lectures and will give students practical experience in fermentation operation.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Assessment is done by a final exam and laboratory reports.

Intended learning outcomes 1-8 are assessed through the written exam (Grading scale G U 3 4 5).

Intended learning outcomes 6 and 9 are assessed through the laboratory reports (Grading scale U G).

All exams included in the module need to be completed for a course grade

Laboratory exercises include compulsory participation.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The course B7003K is equal to KGB008.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 6 | Mandatory | A07 |  |
| 0003 | Laboratory reports (experimental) | U G# | 1.5 | Mandatory | A07 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
