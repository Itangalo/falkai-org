---
course_code: "V0014B"
title: "Hydraulics and geology"
credits: "7.5"
title_sv: "Hydraulik och geologi"
valid: "Autumn 2024 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2024-02-14"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0014B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/v00/v0014b-hydraulik-och-geologi"
---

# Hydraulics and geology (V0014B)

## Main field of study

Civil Engineering, .

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Basic knowledge in mathematics and physics.

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course, participants should be able to…

1. Solve basic problems based on the fundamental laws of hydraulics (e.g. calculate hydrostatic pressure, water levels, velocities and flows)

2. Identify different flow conditions and perform calculations regarding the transition from one condition to another.

3. Identify the calculation procedure for basic problems of open channel hydraulics and solve them.

4. Describe the basics of weathering and erosion and the basics of processes generating magmatic, sedimentary and metamorphic rocks and basic principles for plate tectonics.

5. Describe basic processes generating geological structures.

6. Identify the most common minerals, rocks and soil types and describe their properties and how they have been formed.

7. Describe the most important glacial environments and the geological formations which they can result in.

8. Describe the basics of the occurrence of geological resources in Sweden.

9. Interpret a soil map.

## Contents

The course consists of two parts, aiming to provide basic knowledge in hydraulics with a focus on open channel flow, and geology. The hydraulics part covers hydrostatic pressure, fundamental equations – continuity, momentum and energy equation, and open channel flow, including different flow conditions and transitions between them. Teaching regarding hydraulics may take place in English.

The geology-part covers the geology of earth, crust and plate tectonics, rock forming processes, methods to identify minerals and rocks, quaternary geology, soil types and their formations and properties, and interpretation of soil maps.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

Lectures and literature study provide the basic theoretical knowledge in hydraulics. Lectures are combined with calculation exercises. Furthermore, calculation exercises are solved independently, and a calculation assignment must be fulfilled in groups. This assignment is connected to the laboratory task (No. 0005). The participation in the laboratory task is mandatory as it is a part of examination. The calculation exercise is assessed orally and a report about the laboratory task must be submitted.

Lectures, exercises and literature study provide basic knowledge about the geology of earth, minerals and rocks and Quaternary geology. In practical exercises students learn to identify different minerals and rocks, and the interpretation of soil maps. The participation in the task for interpretation of a soil map is mandatory as it is a part of examination.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. To pass the course all examination items must be passed, and the laboratory session must be attended. The final grade is calculated as a weighted grade of examination items no. 0006 and 0008. The learning outcomes 1-3 are assessed in a written exam (item no. 0006, marked according to grading scale), and a laboratory work connected with a calculation assignment and laboratory report (item no. 0005, marked as pass/fail). Participation in the lab is mandatory. If a student does not attend the laboratory session, this item can be taken in another academic year, if sufficient places are available. The learning outcomes 4-8 are assessed by a written test (item no. 0008, marked according to grading scale), learning outcome 6 by a practical test for identification of minerals and rocks (item no. 0007, marked as pass/fail), and learning outcome 9 by a map exercise (item no. 0003, marked as pass/fail).

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course V0014B is equal to V0021B, V0017B

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Map exercise | U G# | 0.1 | Mandatory | A09 |  |
| 0005 | Laboratory work | U G# | 0.6 | Mandatory | A09 |  |
| 0006 | Written exam | GU345 | 3.2 | Mandatory | A09 |  |
| 0007 | Practical test | U G# | 1 | Mandatory | A09 |  |
| 0008 | Short written exam | GU345 | 2.6 | Mandatory | A09 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

The plan is established by the Department of Civil and Environmental Engineering 2009-01-20 and is valid from H09.
