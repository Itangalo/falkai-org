---
course_code: "M7006K"
title: "Geometallurgy"
credits: "7.5"
title_sv: "Geometallurgi"
valid: "Autumn 2011 Sp 2 - Present"
decision_date: "2011-10-05"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Processmetallurgi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering  Items/credits Number       Type                                                             Credits      Grade  0001         Laboratory work and practical exercise                           5            U G#  0002         Seminars                                                         2.5          U G#"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7006K&lasPeriod=175&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/m70/m7006k-geometallurgi"
---

# Geometallurgy (M7006K)

## Examiner

Jan Rosenkranz

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

Items/credits Number       Type                                                             Credits      Grade

0001         Laboratory work and practical exercise                           5            U G#

0002         Seminars                                                         2.5          U G#

## Literature

*Literature. Valid from Spring 2011 Sp 3*

## Last revised

by Eva Gunneriusson 2011-10-05

## Syllabus established

by Eva Gunneriusson 2011-04-19
