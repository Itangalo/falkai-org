---
course_code: "T7009K"
title: "Advanced Chemical Reaction Engineering"
credits: "7.5"
title_sv: "Avancerad kemisk reaktionsteknik"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2019-11-05"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Kemisk teknologi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7009K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7009K&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/t70/t7009k-avancerad-kemisk-reaktionsteknik"
---

# Advanced Chemical Reaction Engineering (T7009K)

## Entry requirements

90hp in Chemical Engineering and the course T0006K Fundamentals of Chemical Reaction Engineering.

## Selection

The selection is based on 30-285 credits

## Course Aim

At the completion of the course, you should be able to:
- have gained a more profound knowledge of chemical reaction engineering to enable the student to choose and dimension reactors and geometrical size of catalyst particles for use in chemical processes. Further, the students should have acquired the theoretical background for determining the operational mode and optimization of these processes.
- give an account of the processes limiting the reaction rate and also describe how the influence of the limiting process can be minimized.
- give an account of the different kinetic regimes occurring in multiphase reactors and be able to choose a suitable rector based on information about the kinetic regime.
- mathematically model and solve advanced problems in reaction engineering comprising, e.g. reactions with coupled heat- and mass transfer and non-ideal reactors.

## Contents

Non-ideal reactors, coupling of reaction kinetics with physical transport processes with a focus on systems with heterogeneous catalysts, mass transfer and reaction kinetics in multiphase systems and bio reactors.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The teaching-learning activities are comprised of lectures, tutorial sessions and a project work. The most important parts of the theory of reaction engineering are presented in the lectures. In the tutorial sessions, example problems are solved by the teacher. Compulsory assignments are solved in smaller groups, aiming at getting the students to practise in mathematical modelling of reactors/reactor systems, analysing the models and to develop oral presentation skills. The project work comprising modelling of reactors where the reaction is coupled to mass transfer, is aiming to make the students face problems with uncertain data, which is often the case in industry, and to develop written presentation skills as the project work should be presented as a technical report. The first lecture is compulsory.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. The examination comprises completed assignment problems, project report and a written exam. The grades pass or fail are given for the assignments and project report, these parts of the course are examined continuously during the course. For the written exam, the grades are U (Failed), 3, 4 and 5. Students who have failed the exam on five occasions will not be allowed further resits.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course T7009K is equal to T7002K

## Remarks

Advanced level, the course is compulsory for students on the specialization in Chemical and biochemical engineering on the Masters programme in Chemical engineering design and for students on the Masters programme in chemical and biochemical engineering.

Study guidance is available on Canvas in the corresponding room.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written Exam | GU345 | 3 | Mandatory | A17 |  |
| 0002 | Assignments | U G# | 3 | Mandatory | A17 |  |
| 0003 | Project work | U G# | 1.5 | Mandatory | A17 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-11-05

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2017-02-13
