---
course_code: "K7019B"
title: "Building Materials Influence on Indoor Environment: Perception and Reality"
credits: "7.5"
title_sv: "Byggmaterialens påverkan på inomhusmiljön: Uppfattning och verklighet"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2022-02-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7019B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7019B&lasPeriod=214&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/k70/k7019b-byggmaterialens-paverkan-pa-inomhusmiljon-uppfattning-och-verklighet"
---

# Building Materials Influence on Indoor Environment: Perception and Reality (K7019B)

## Main field of study

Civil Engineering

## Entry requirements

In order to meet the general entry requirement for the course, the student must have accomplished 120 ECTS of university studies in civil engineering, architecture, material science or similar. Moreover, this course requires the completeion of a introductory building materials course like building material K0002B or equivalent. Knowledge in English, equivalent to English B/6.

## Selection

The selection is based on 30-285 credits

## Course Aim

The objective of the course is for the student to develop knowledge of building materials influence on indoor air quality.

After passing the course, the student should be able to: 1. Demonstrate mastery of concepts and techniques on building materials influence on indoor air climate. 2. Evaluate possible impact of chosen building materials on the indoor air quality. 3. Reflect on indoor air problems originating from building materials and give possible solution to problems. 4. Demonstrate awareness of potential risks with different building materials. 5. Demonstrate a deeper understanding of building materials impact on human health. 6. Explain how perception of healthiness of building materials is formed and influenced.

## Contents

Due to its holistic approach this courses encompasses many areas of building materials, indoor air climate and health. The course explains the importance of the indoor climate as an essential part of the comfort and quality of living. Various factors determining the indoor climate are heavily influenced by the material selection. Indoor air climate and emissions originating from the building material itself like VOCs and radon are covered in this course as well as impact of wrong use of building materials leading to, e.g. mold. This course will cover several topics related to indoor air climate, ensuring that the students learns about potential risks and how to minimize problems. Students will also learn about perception of building materials as healthy/unhealthy.

Topics covered a.o. are:

- Building materials and humidity

- Mold

- Radiation and Radon

- Hazardous building materials (asbestos)

- Passive houses

- Perception of different building materials as healthy

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

Teaching consists of lectures given by several persons. Lectures focus on the theoretical background of the subject area. Practical skills are trained through calculations / exercises in the classroom and in laboratory tasks. The work in the laboratory is performed in groups and results from the laboratories are documented in lab rapports by the groups. Laboratory work and exercises are linked to the lectures and will take place in parallel to the lectures. Study visits are carried out if possible to see practical applications in the industry. Document management takes place in the learning platform Canvas.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. During the course the students will work on short written assignments, which will be U/G. Instead of a final exam the student will submit a longer written project assignment which is graded U/3/4/5/. Through this method, all learning outcomes can be covered. Please note that all written assignments can be done in Swedish or English.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Short individual assignments | U G# | 4 | Mandatory | S23 |  |
| 0002 | Written Project assignment | GU345 | 2 | Mandatory | S23 |  |
| 0003 | Laboratory work and site visit | U G# | 1.5 | Mandatory | S23 |  |

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11
