---
course_code: "X7004B"
title: "Degree project in Fire Engineering, Master of Science in Engineering"
credits: "30"
title_sv: "Examensarbete i Brandteknik, civilingenjör"
valid: "Autumn 2021 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Väg- och vattenbyggnad"
subject_group_scb: "Civil Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X7004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X7004B&lasPeriod=222&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/x70/x7004b-examensarbete-i-brandteknik-civilingenjor"
---

# Degree project in Fire Engineering, Master of Science in Engineering (X7004B)

## Entry requirements

At least 240 credits completed courses as required for the degree. A maximum of 15 credits completed courses may be remaining from base and core courses. Of the completed courses at least 30 credits shall be of advanced level. In addition to the above, the examiner decides whether the proposed degree project is within the subject area and student has the depth of knowledge required

## Selection

The selection is based on 30-285 credits

## Course Aim

The overall goal of the course is that the student practices, develops and is able to apply theory and methods to solve unstructured problems relevant to a profession as Master of Science in Fire Engineering.

This means that on completion of the course the student is able to:
- Formulate a relevant problem for investigation from a chosen subject within the subject area Fire Engineering.
- Apply knowledge and proficiency that has been acquired during the period of study to a complex development project or a smaller research project in an independent and systematic manner.
- Choose and justify the study method for an investigation.
- Analyse and defend the problem formulated in a correct manner with respect to science and engineering, without complete information.
- Locate and critically review information and summarise this in a scientific manner.
- Plan, structure and execute a project within research, development or investigation.
- Judge the scientific and practical relevance of the results obtained.
- Work to a timetable.
- Express themselves well in writing in a verbally and scientifically correct manner.
- Create and execute a presentation of the results of the project, defending the conclusions.
- Critically review the work of others in a constructive and scientific manner.

## Contents

The content of the degree project is designed in collaboration with the supervisor. The degree project always contains a theoretical foundation in the form of a literature survey that highlights the area of technology and the methodology, summarised in a scientific manner.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The student independently plans and executes the degree project; the supervisor is available for assistance. A timetable for the entire project is included in the degree project, which is continuously reviewed.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.
- Written presentation of individual work. In the report the student shows the ability to:
    - Justify the chosen problem of study
    - Select and justify the study methods
    - Collect information relevant to the problem formulation with an explicit connection to the chosen theory/method
    - Present in writing the information collected in a relevant manner
    - Analyse and defend the formulated problem from the chosen theory and methods
    - Critically review the relevance of the results obtained from a scientific and engineering point of view
    - Express themselves in writing in a correct linguistic and scientific manner.
- Oral presentation of own work
- Public discussion of the work of others
- Attendance at presentations of the degree project work of others.

## Remarks

The department provides active supervision for a period of two terms from the start of the project. The degree project is performed individually; only in exceptional cases may at most two students carry out the degree project together. In cases in which the degree project is carried out by two students, this shall be clearly visible in the scope and depth of the report.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Start of degree project | U G# | 0 | Mandatory | A13 |  |
| 0002 | Public discussion of others degree project | U G# | 0 | Mandatory | A13 |  |
| 0003 | Oral presentation | U G# | 0 | Mandatory | A13 |  |
| 0004 | Approved report | U G# | 30 | Mandatory | A13 | Yes |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2013-02-06
