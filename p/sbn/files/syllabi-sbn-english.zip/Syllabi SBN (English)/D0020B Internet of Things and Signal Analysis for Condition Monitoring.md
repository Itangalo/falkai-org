---
course_code: "D0020B"
title: "Internet of Things and Signal Analysis for Condition Monitoring"
credits: "7.5"
title_sv: "Sakernas internet och signalanalys för tillståndsövervakning"
valid: "Autumn 2023 Sp 1 - Autumn 2025 Sp 2"
decision_date: "2023-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0020B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0020B&lasPeriod=220&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0020b-sakernas-internet-och-signalanalys-for-tillstandsovervakning"
---

# Internet of Things and Signal Analysis for Condition Monitoring (D0020B)

## Main field of study

Maintenance Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Linear Algebra and Calculus (M0048M) or equivalent course and documented skills in English language equivalent of English 6.

## Selection

The selection is based on 1-165 credits.

## Course Aim

The purpose of the course is to develop knowledge and skills in measurement technology, the Internet of Things, and signal analysis in order to independently perform condition monitoring.

Knowledge and understanding After completing the course, the student should:
- have basic knowledge of the Internet of Things and its implementation
- show understanding of how the Internet of Things can be used for condition monitoring and maintenance decision support

Competence and skills After completing the course, the student should have the ability to:
- apply basic methods in signal analysis
- calculate and describe features in time and frequency domain
- independently and in group implement condition monitoring using connected devices, cloud services and applications
- identify knowledge gaps and bridging these gaps by gaining new knowledge

## Contents

- Basic concepts of condition monitoring and condition-based maintenance

- The Internet of Things, measurement technology, microcontroller, sensors, and cloud services

- Signal analysis in time and frequency domain (for both continuous and discrete signals)

- Time series analysis and prediction

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The course consists of three parts. The first part is theoretical with lectures and lessons on condition monitoring, the Internet of Things and signal analysis. The second part consists of laboratories and exercises about the Internet of Things. In the third part, you carry out project work where you plan and carry out condition monitoring using the Internet of Things. Supervision is offered to support the project work.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Three examination modules are included in the course: assignments, laboratory work and project work.

The assignments examine knowledge and understanding of condition monitoring and how the Internet of Things can be applied for condition monitoring as well as competences in signal analysis.

The laboratories examine knowledge and implementation of the Internet of Things as well as conducting condition monitoring using connected devices.

The project work examines the ability to independently plan and implement condition monitoring with connected devices, cloud services and applications as well identifying and closing knowledge gaps.

In order to obtain a passing grade in the course, the assignments, project, and laboratory work must be completed with a passing grade. The project work is presented both orally and in writing.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignments | GU345 | 4 | Mandatory | A18 |  |
| 0002 | Project work | U G# | 2 | Mandatory | A18 |  |
| 0003 | Laboratory work | U G# | 1.5 | Mandatory | A18 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2018-02-13
