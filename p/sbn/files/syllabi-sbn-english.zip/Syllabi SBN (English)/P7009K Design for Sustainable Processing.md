---
course_code: "P7009K"
title: "Design for Sustainable Processing"
credits: "7.5"
title_sv: "Designer för hållbar processteknik"
valid: "Autumn 2023 Sp 1 - Autumn 2025 Sp 2"
decision_date: "2022-06-15"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Processmetallurgi"
subject_group_scb: "Chemical Engineering"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7009K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7009K&lasPeriod=214&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/p70/p7009k-designer-for-hallbar-processteknik"
---

# Design for Sustainable Processing (P7009K)

## Main field of study

Chemical Engineering

## Entry requirements

90 credits in Chemical Engineering, including the courses P0006K (P0001K) High Temperature Processes and M0001K Mechanical ProcessTechnology. Good knowledge in English, equivalent to English B/6.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, the student shall be able to:

1. describe the concept of sustainable development.

2. describe the most usual methods to analyse how the choice of material or process influence environmental impact.

3. describe and understand the techniques usually used in recycling.

4. describe the residues formed in high-temperature processes, how they are formed and possible uses.

5. describe the important limitations of recycling.

6. describe a few examples of coupled material cycles and understand how this influences the possibilities for sustainable processing.

7. understand that and to some extent why the design of a product influences possibilities for recycling.

Sustainable Development

8. give an account of and critically relate to the concept of sustainable development at the national and global level; how it has arisen, evolved, its various contemporary definitions, manifestations and ethical starting points.

9. explain and compare the causes of the threats to sustainable development and indicate, explain and analyse the effects that the threats to sustainable development give/will have.

10. give examples of the role and responsibility of the engineer for sustainable development in his professional practice.

## Contents

The course will give the student a knowledge of common methods for evaluating environmental impact, primarily LCI/LCA and how the choice of materials and the choice process technology affect sustainability in material production. Metallurgical process technology and physical separation methods that are especially used in recycling processes will be reviewed. Several recycling processes including melting electronic scrap, recycling of lead-acid batteries, flotation of pressure odours and energy and chemical production from residues from the paper industry will be highlighted. The generation of residues and their recycling is an important part of the course. Within the framework of the course, a shorter project assignment will also be carried out where the student will have the opportunity to reflect on how the design of a product affects opportunities for future recycling. A study visit will link theory from lectures and project work with practical applications in the industry.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The course has both theoretical and practical elements in the form of lectures, exercises, demonstrations, project work, seminars and study visits. Reporting is done both in writing and orally.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Assignments, the project, seminars and study trips are compulsory. Assignments, seminars, the project and the opposition are each awarded points based on the attained level. Assignments and reports must be delivered in time or there will be an automatic deduction of points. The total points production determines the grand grade of the course, and it is given on a scale of 3 4 5.

Assignments and project assignments examine ILOs 1-7.

Seminars examine ILOs 8-10.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Overlap

The course P7009K is equal to P0002K

## Remarks

Compulsory attendance at the first lecture, study trips and seminars.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment reports | GU345 | 2.5 | Mandatory | S13 |  |
| 0002 | Project | GU345 | 4.5 | Mandatory | S13 |  |
| 0003 | Study trip | U G# | 0.5 | Mandatory | S13 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-06-15

## Syllabus established

by Eva Gunneriusson 2012-03-14
