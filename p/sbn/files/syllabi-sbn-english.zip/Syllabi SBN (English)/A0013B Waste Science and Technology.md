---
course_code: "A0013B"
title: "Waste Science and Technology"
credits: "7.5"
title_sv: "Avfallsteknik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2022-11-07"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Miljöteknik"
subject_group_scb: "Environmental Care and Environmental Protection"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=A0013B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=A0013B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/a00/a0013b-avfallsteknik"
---

# Waste Science and Technology (A0013B)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Swedish upper secondary school courses Physics 1b1 or 1a, Mathematics 2a or 2b or 2c. Or: Physics level 1a1 or level 1b, Mathematics level 2a or level 2b or level 2c.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

After completing the course the student should have gained knowledge about waste management systems, waste characteristics, waste characterization and treatment, and be able to discuss strategies for sustainable waste management.

After completing the course, participants should be able to fulfil the Intended Learning Outcomes (ILO’s):

- Describe the waste management structure and function in our society.

- Describe typical properties of representative municipal and industrial waste in our society.

- Understand the basic physical, chemical and biological principles behind typical waste treatments.

- Describe methods for mechanical, biological and thermal treatment of waste.

- Describe and motivate the construction and function of landfills.

- Explain and compare technical solutions that contributes to a sustainable waste management.

- Describe waste characterization methods

## Contents

This course covers the following topics:

- Waste streams in society and sustainable waste management. Under this topic, statistics about waste generation, waste treatment and a historical perspective of waste in Sweden are described and the information is contextualized with international statistics. Flowcharts as a tool to describe waste streams in our society are overviewed. The function and use of waste management, environmental sustainability of waste management, circular economy of waste, who is responsible for waste management in our society and legal framework, waste hierarchy and the environmental impacts of waste management from a system perspective, are overviewed.

- Mechanical, biological and thermal waste treatment as well as final disposal at landfills are the four basic waste treatments that the course covers. The concepts that are overviewed for each treatment in an introductory level are:

- goals and function of each treatment.

- characteristics of wastes suitable for each treatment and waste characterization.

- strategies to decide when to use the respective treatment

- basic physical, chemical and biological principles behind the technology on which the treatment is based on

- description of the available technologies

- The environmental impact of each treatment.

- Household waste. Different collection systems and how these systems are applied in Sweden, recycling of paper, plastic, metals and glass in Sweden and energy recovery from combustible waste are overviewed.

- Municipal and industrial wastes. Here, examples of important wastes are presented in order to provide specific knowledge about these wastes and link them to the topics presented previously in the course. Wastes that could be presented in this section are for example mining waste, construction waste, industrial waste in general and hazardous waste.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The topic is presented in the form of lectures. Moreover, a seminar projects allows a group of students to select a topic and gain specific knowledge on this subject by performing a literature review, written and oral presentations and group discussions. Practical skills are trained through laboratory exercise dealing with the goals and content of the course as well as a study visit. All documentation is made available through CANVAS web tool, which it is also used as a communication, and pedagogic tool in the course.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through a written exam, which evaluates all ILO’s previously described. Grade Scale: 5 4 3 U

To pass the course the students are required to be approved on the laboratory training and study visit as well as approve on the seminar task. The laboratory training are assessed by assistance to the laboratory exercise and a written report. The study visit is assessed by assistance to the study visit and the completion of a reflective document about the visit. Finally, the seminar task is assessed by written report, oral presentation and active participation in the discussion with other groups.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Exam | GU345 | 3 | Mandatory | S12 |  |
| 0004 | Seminartask | UG | 2.3 | Mandatory | S27 |  |
| 0005 | Laboratory and field trips | UG | 2.2 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-11-07

## Syllabus established

by Department of Civil, Environmental and Natural Resources Engineering 2011-02-07
