---
course_code: "D7020B"
title: "Intelligent Asset Management"
credits: "7.5"
title_sv: "Intelligent asset management"
valid: "Autumn 2025 Sp 1 - Present"
decision_date: "2025-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7020B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7020B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7020b-intelligent-asset-management"
---

# Intelligent Asset Management (D7020B)

## Entry requirements

90 ECTS in engineering subjects. Good knowledge in English, equivalent to English 6.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, participants should be able to:

Knowledge and Understanding:

1. Understand key concepts of maintenance and its role in intelligent asset management.

2. Describe the core principles of asset management and how it is supporting asset performance and lifecycle management.

3. Demonstrate knowledge of software engineering essential for developing asset management solutions.

Competence and Skills:

4. Apply software engineering techniques to implement AI-based solutions for asset management.

5. Demonstrate analytical skills to address complex industrial challenges through data-driven decision-making.

Judgment and Approach:

6. Evaluate real-world case studies to determine effective practices and strategic approaches in intelligent asset management.

## Contents

This course covers:

- The fundamentals of asset management

- Asset management in maintenance

- Asset performance and lifecycle management

- Tools for asset management - analytics, AI, digitalisation

- Software engineering and software development

- Case studies and practical applications in industrial domains

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course combines online and in-person sessions in a hybrid format. Delivery methods include lectures, assignments, labs, and real-world case study analyses.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

This course includes formative assessments (for learning) and summative assessments (of learning). Summative assessments, in the form of assignments and reports, examine the intended learning outcomes, while formative assessments (in-class discussions, reflections, quizzes, group work, feedback) support learning. All assignments will be processed during the course with feedback from teachers and/or peers.

To pass the course, 5 assignments must be completed. To pass each of the assignments, the solution must first be demonstrated to the Teacher Assistant allocated to the assignment. The demonstration should be preferably performed during the solving session or the wrap up session allocated for the assignment. After the demonstration is evaluated as satisfactory, the files must be submitted through Canvas. The Teacher Assistant will revise the submitted files and mark the assignment as passed or require a revision. The assignments will determine the grade (3,4,5). All the assignments carry equal weight.

The overall grade will be the mean grade of all these 5 assignments.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment reports | GU345 | 7.5 | Mandatory | A25 |  |

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
