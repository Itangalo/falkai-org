---
course_code: "L0050K"
title: "Geochemistry"
credits: "7.5"
title_sv: "Geokemi"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2025-02-13"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0050K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0050K&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l00/l0050k-geokemi"
---

# Geochemistry (L0050K)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language + Upper secondary school courses English 6, Physics 2, Chemistry 1, Mathematics 4 or Mathematics E. Or: English level 2, Physics level 2, Chemistry level 1, Mathematics Further level 2 or Mathematics E.

## Selection

The selection is based on final school grades or Swedish Scholastic Aptitude Test.

## Course Aim

The course provides a geochemical toolbox (basic principles and techniques) which can be used to understand mechanisms that control large geoscientific systems, such as lithosphere, hydrosphere, and atmosphere. The students will learn about the origin and abundance of elements, their occurrence, and the forms in which they exist in Earths main geochemical reservoirs and their use in society. The course will create a broad geochemical fundament that can be used in a future geoscientific career in academia and industry (e.g., environmental consultants or mining-related careers).

After completing the course, the participants should be able to

Knowledge and understanding

1. Explain interaction between Earths’ compartments and element mobility.

2. Describe stable, radiogenic and radioactive isotope systems and their applications.

3. Apply geochemical principles that regulate the element abundance in the lithosphere, hydrosphere and atmosphere.

Competence and skills

4. Demonstrate the ability to search, compile and critically interpret relevant literature and information, as well as implement constructive criticism for advancing competencies, such as writing and presenting.

5. Discuss how concentrations of metals and nutrients are influenced in freshwaters and soil/sediments, by identifying and explaining geochemical principles.

6. Present and summarize scientific research in written and oral form.

Judgement and approach

7. Perform basic qualitative and quantitative interpretations and data visualization of field data with relevant software.

8. Show insights into the geochemical toolbox and how it will set the fundament for many processes being discussed in the later part of the bachelor program, e.g., Sustainable Mining Methods and Extractive metallurgy.

## Contents

- Origin of elements and nucleosynthesis [Big Bang]

#understand how elements are formed

- Chemical composition and differentiation of solar system, planets and moons

#understand basic chemical distribution in universe, solar system, and planets

- Gases in the Earth system, ideal gases, gas law [stoichiometry and mole concepts; molarity; concentrations]

#understand different states of material: gases; apply stoichiometry, unit conversion, quantity skills

- Acid-bases, principles, pH buffer in natural waters

#understand the role of water dissociation and know what distinguishes weak from strong acid/bases. Explain what a buffer is, know natural buffers on Earth. Get familiar to pH diagrams.

- The carbon cycle. Carbonate system in freshwater and oceans. What controls the global carbon cylcle?

#understand and apply the carbonic system with respect to buffer capacity and the relationship to pH in natural waters.

- Redox geochemistry in geological systems (principles of coupled reduction-oxidation reactions). The electron tower and energetics of redox reactions. Redox ladder [balancing important geochemical redox reactions]

#understand the mechanisms behind redox reactions [know how to balance redox reactions]. Understand chemical equilibrium, acid/base behavior and redox chemistry relate to each other.

- Geochronological principles using radiogenic isotopes, the epsilon notation (half-life, decay constants, age determination)

# understand and apply dating concepts for different isotope systems.

- Stable isotope systems, the delta notation and fractionation equations

#understand isotope notation and fractionation, equilibrium fractionation, unidirectional reactions.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course consists of lectures where basic theory is presented and explained. Theoretical knowledge translates into practical applications and increased understanding through assignments exercises, group discussions, problem-based seminars, and oral and written presentation.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

This course is graded (U, G, 3, 4, 5) individually. The final grade is based on homework assignments (4 assignments, 1.5hp), one individually midterm exam (1.5hp), a written geochemical data evaluation with ioGAS report (2.0hp) and a final exam (2.5hp).

The course is assessed through four modules, all modules need to be completed for a course grade.

Module 1: Homework assignment

Assesses ILO 1, 2, 3, 4, 6

During this assignment, the students will answer one question related to the course content. The student is supposed to spend 1.5 to 3 hours on these questions by researching, sorting their thoughts and writing 250 to 400 words. In total, there will be 4 essay assignments, weighted 5% each. The students can show and improve their ability to summarize scientific concepts in written form.

Module 2: Oral mid-term exam

Assesses ILO 1,2,5

The midterm exam will allow the student to solidify their understanding. They have the possibility to study strategically and develop a deep understanding of half the material covered in the course, which will be the fundament for the residual course.

Module 3: Data report and presentation

Assesses ILO 5,6,7,8

Group module. Each group will get a data set, which they are supposed to evaluate and interpret with relevant software. The software can be used to verify and visualize the data. The students will then write a report together clearly marking which part was written by whom. This assignment aims to deepen the gained expertise from the homework assignments to write a concise research report in form of a scientific publication and present it in front of an audience.

Module 4: Written exam

Assesses ILO 1-8

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Midterm exam | GU345 | 1.5 | Mandatory | A25 |  |
| 0003 | Written report and presentation | GU345 | 2 | Mandatory | A25 |  |
| 0004 | Written exam | GU345 | 2.5 | Mandatory | A25 |  |
| 0001 | Homework assignments | U G# | 1.5 | Inactive | A25 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
