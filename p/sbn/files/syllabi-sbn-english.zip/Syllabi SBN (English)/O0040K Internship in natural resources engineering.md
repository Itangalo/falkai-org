---
course_code: "O0040K"
title: "Internship in natural resources engineering"
credits: "15"
title_sv: "Praktik inom naturresursteknik"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "First cycle"
grade_scale: "UG"
subject: "Naturresursteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0040K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0040K&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o00/o0040k-praktik-inom-naturresursteknik"
---

# Internship in natural resources engineering (O0040K)

## Main field of study

Natural Resources Engineering

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and 60 ECTS credits in geosciences

## Selection

The selection is based on 1-165 credits.

## Course Aim

After completing the course participants should be able to:

-write an application and CV and apply for an internship with relevance to the ongoing education (Learning objective 1).

-independently plan and carry out projects under supervision (Learning objective 2).

-apply theoretical knowledge and skills practically (Learning objective 3).

-analyze and reflect on engineering problems and on their future professional role (Learning objective 4).

## Contents

This course covers a subject matter that is relevant to the area of specialization through internship. Those who do the internship on a topic outside the specialized area must first appeal to the department.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

This course includes teaching and learning activities through internship, where the student shall, alone or together with another student, focus on one or more given tasks. The internship work should have the character of simpler research or investigational work. The student works independently with guidance. The experiences are reported in writing and orally.

Time limit for internship: students who begin a project and do not finish within 15 months cannot request allowance to complete the course.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course is assessed through approval of the internship, completion of the internship, written and oral presentation.

Learning objective 1: assessed by approval of the internship.

Learning objective 2-4: assessed by a written report and oral presentation where all students are expected to attend and learn from others experiences. The language can be Swedish or English.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0004 | Approved work placement | UG | 14 | Mandatory | S27 |  |
| 0005 | Oral and written report | UG | 1 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2012-03-14
