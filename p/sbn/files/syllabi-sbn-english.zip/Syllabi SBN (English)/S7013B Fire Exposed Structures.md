---
course_code: "S7013B"
title: "Fire Exposed Structures"
credits: "15"
title_sv: "Brandutsatta konstruktioner"
valid: "Autumn 2023 Sp 2 - Present"
decision_date: "2023-06-02"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Brandteknik"
subject_group_scb: "Building Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7013B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7013B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/s70/s7013b-brandutsatta-konstruktioner"
---

# Fire Exposed Structures (S7013B)

## Entry requirements

S0006B Analysis and design of fire loading in buildings and S0003B Fire dynamics I, and one of the courses S0007B Fire Exposed Structural Elements, S0004B Construction and fire resistance, S0010B Structural Design and Fire, or K0013B Structural Design, or equivalent knowledge.

## Selection

The selection is based on 30-285 credits

## Course Aim

Knowledge and understanding After completing the course, the student should be able to:
- Define a general design process for fire exposed load-bearing structures.
- Define the scientific foundations and proven experience for FEM (Finite Element Method), in particular applied to calculations of the load-bearing capacity of fire-exposed structures, as well as define the most important current research and development areas for FEM within this field.

Skills and abilities After completing the course, the student should be able to show the ability to:
- Compute the temperature development in room fires with simple hand calculation methods.
- Solve problems for the temperature development in room fires with CFD (Computational Fluid Dynamics).
- Compute temperature development in structures exposed to fire with simple hand calculation tools.
- Solve problems for the temperature development in structures exposed to fire with FEM.
- Compute the load-bearing capacity for structures at elevated temperatures with simple hand calculation tools.
- Solve problems for the load-bearing capacity for structures at elevated temperatures with FEM.
- Solve design problems for load-bearing capacity for structures exposed to fire by critically and systematically integrate knowledge, also with limited available information.
- Plan, perform, analyze and interpret complex design calculations for load-bearing capacity of fire exposed structures, as well as clearly and scientifically present the results.
- Show ability for teamwork and in writing and orally in dialogue with different groups clearly present and discuss the conclusions on the design of fire exposed structures with respect to load-bearing capacity, as well as presenting and discussing the knowledge and arguments behind the design.

Judgement and attitude After completing the course, the student should be able to:
- Judge different models and working processes for design of fire-exposed structures with respect to load-bearing capacity, as well as show insight about the responsibility of the engineer to choose and account for parameters in such a way that the results are used correctly.
- Show ability to identify her/his own need for further knowledge in design of fire-exposed structures and for continuous competence development.

## Contents

- Repetition of the basics in heat transfer and statics with applications within fire technology
- Design process for fire-exposed load-bearing structures
- Simple hand calculation tools for temperature development in rooms fires
- CFD for calculating temperature development in room fires
- Simple hand calculation tools for heat transfer from fires to structures
- FEM for calculating heat transfer from fire to structures
- Simple hand calculation tools for load-bearing capacity at elevated temperatures
- FEM for calculating load-bearing capacity at elevated temperatures

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The teaching is based on self-studies, lectures, tutorials, consultations, individual quizzes, individual assignments, project assignment that is performed in groups with oral and written presentation, and individual reflection assignment.

In order to achieve the course’s goals regarding knowledge and understanding, the student should independently study the specified course literature and participate at the lectures.

In order to achieve the course’s goals regarding skills and abilities, the student should also participate at the tutorials, do the individual quizzes and assignments, actively participate in the project assignment including written and oral presentation, as well as actively participate in the consultations. In order to achieve the course’s goals regarding judgement and attitude, the student should also participate in discussions on the course contents at lectures and tutorials, as well as do the reflection assignment.

The students are expected to have their own computers.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

In order to pass the course the quizzes must be passed and all assignments, the written and oral presentation of the group assignment, as well as the reflection assignment must be approved by the teacher. The grading scale is U G.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

Transition terms The course cannot be counted in a diploma together with any of the courses S7005B Temperature analysis of structures, S7012B Collapse mechanisms of fire exposed structures, S7006B Fire exposed structures.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Assignments | U G# | 15 | Mandatory | A22 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-02-14
