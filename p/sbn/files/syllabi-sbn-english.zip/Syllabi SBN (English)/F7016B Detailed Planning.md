---
course_code: "F7016B"
title: "Detailed Planning"
credits: "7.5"
title_sv: "Detaljplanering"
valid: "Spring 2027 Sp 3 - Present"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7016B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f70/f7016b-detaljplanering"
---

# Detailed Planning (F7016B)

## Main field of study

Architecture

## Entry requirements

Knowledge of spatial planning especially at the detailed/block level eg F0002B Urban Design or equivalent.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course the student should be able to produce a complicated detail plan with the appropriate documents and have knowledge of all stages of the detailed planning process, along with the plan implementation steps.

Knowledge and understanding

Detailed plans in relation to other levels of planning, detailed planning as regulatory instruments, all stages of detailed planning process and along with the plan implementation steps. Collaborate with other experts, consultation with Plan Manager / City Architect, other municipal departments, government agencies and the public.

Competence and skills

Produce a complicated detail plan with the appropriate parts according to the current legislation. Implement all stages and documents of detailed planning process; formal detailed plan with regulation, illustration, design specification, implementation description and the consultation report.

Judgement and approach

Detailed planning in relation to other planning levels. The opportunities and limitations of detailed planning.

## Contents

Planning and Building Act, the purpose of detailed planning, its possibilities and limitations of the content and its legal effect, the planning processes. Plan map, planning regulations, plan description, and plan presentation. Impact assessments and methods for them. Consultation with experts and stakeholders. Real estate law implementation agents, concepts within the planned economy, compensation rules.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course includes lectures, field trips, exercises, individual project and construction work and seminars according to detailed schedule.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Passing the course requires participation in field trips, compulsory participation in seminars, passing the project assignment and the construction assignment.

Intended learning outcome Knowledge and understanding are examined through a Project assignment (U G #). Judgement and approach are examined through participation in study visits, seminars (U G #)

The learning objective Competence and skills are examined through a Construction assignment (G U 3 4 5).

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0003 | Construction Work | GU345 | 6 | Mandatory | A15 |  |
| 0006 | Study Visit, Seminars | UG | 0.5 | Mandatory | S27 |  |
| 0007 | Project Work | UG | 1 | Mandatory | S27 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural

Resources Engineering 2021-02-17

## Syllabus established

by Eva Gunneriusson 2015-02-09
