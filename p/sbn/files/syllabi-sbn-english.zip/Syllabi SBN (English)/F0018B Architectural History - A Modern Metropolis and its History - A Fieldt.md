---
course_code: "F0018B"
title: "Architectural History - A Modern Metropolis and its History - A Fieldtrip to Paris"
credits: "7.5"
title_sv: "Arkitekturhistoria - En modern metropol och dess historia - en exkursion till Paris"
valid: "Spring 2024 Sp 3 - Autumn 2026 Sp 2"
decision_date: "2023-06-02"
education_level: "First cycle"
grade_scale: "U G#"
subject: "Arkitektur"
subject_group_scb: "Architecture"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F0018B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F0018B&lasPeriod=214&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/f00/f0018b-arkitekturhistoria---en-modern-metropol-och-dess-historia---en-exkursion-till-paris"
---

# Architectural History - A Modern Metropolis and its History - A Fieldtrip to Paris (F0018B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and F0008B History of Architecture

## Selection

The selection is based on 1-165 credits.

## Course Aim

Knowledge and understanding

After completing the course students should be able to:

- Based on examples, give a general description of Paris, both as a living reference in architectural history and as a modern metropolitan environment.

Competence and skills

After completing the course students should be able to:

- Present in oral and written form a place or a building to potential colleagues, partners and / or clients.

Judgement and approach

After completing the course students should be able to:

- Describe their experience of the study trip as a tool for acquiring practical related knowledge and inspiration for their own tasks.

## Contents

The course consists of a series of lectures on the history and significance of the study trip, as well as the history of architecture and urban planning, with special emphasis on the city of Paris. At the same time, each course participant prepares a report on a place, a building or an urban environment through literature studies. The preparation of these is designed in collaboration with the teacher with the aim of a joint travel guide. During up to five days in Paris, the course participants present the presentations they prepared, the content and verbal performance of which are discussed and criticized by the teachers and the group jointly.

## Realization

cr                                                                                       3                 02

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website. The teaching consists of preparatory seminars and activities at LTU and teacher-led seminars at selected objects in Paris. The students produce jointly a travel guidebook under the guidance of the teacher. The travel and all expenses are paid for by the participants themselves.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

An active participation to the course seminars and activities is fundamental for the course.

To pass the course an approved written and oral presentation as well as an active participation throughout the study trip is required.

In module 0002, learning objectives 1 and 2 are examined through an oral presentation on site (grading scale: U G #)

In module 0003, learning objective 1 is examined through active participation in seminars and online assignments (grading scale: U G #)

In module 0004, learning objectives 2 and 3 are examined through a written assignment (grading scale: U G #)

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

Due to similar content, the course cannot be included in a degree together with F0016B och F0017B or other courses with similar content.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Travel and oral presentation | U G# | 4 | Mandatory | S20 |  |
| 0003 | Seminars | U G# | 0.5 | Mandatory | S20 |  |
| 0004 | Written assignment | U G# | 3 | Mandatory | S20 |  |
| cr |  |  |  | 3 | 02 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2023-06-02

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2019-02-14
