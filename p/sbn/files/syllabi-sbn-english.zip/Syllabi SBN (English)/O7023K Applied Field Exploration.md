---
course_code: "O7023K"
title: "Applied Field Exploration"
credits: "3"
title_sv: "Tillämpad fältprospektering"
valid: "Autumn 2026 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2021-02-17"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Malmgeologi"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O7023K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O7023K&lasPeriod=224&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/o70/o7023k-tillampad-faltprospektering"
---

# Applied Field Exploration (O7023K)

## Entry requirements

90 credits in Geoscience.

Proficiency in English equivalent to Swedish upper secondary course English 6/level 2

## Selection

The selection is based on 30-285 credits

## Course Aim

The course concerns different aspects of field exploration methodologies and when passed the student is expected to have:

-knowledge about different field methods and their use during an exploration program.

-knowledge about drilling and sampling methods.

-knowledge about different methods for field mapping.

-ability to synthesize different types of geological and geophysical data for target selection.

## Contents

Geological, geophysical and geochemical exploration methods in VMS exploration. Practical field mapping exercises in structural geology, stratigraphy, hydrothermal alteration. Practical geophysical surveying using UAV technology. GIS-based data synthesis for exploration target selection. Drill core logging and assaying.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. Online exercises, lectures, practicals in the field. Project work.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Written presentation of project work.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Remarks

The course is given as a summer course at an advanced level.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0002 | Project work | GU345 | 1.8 | Mandatory | S21 |  |
| 0001 | Excercises | U G# | 1.2 | Inactive | S21 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2021-02-17

## Syllabus established

by Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-10-13
