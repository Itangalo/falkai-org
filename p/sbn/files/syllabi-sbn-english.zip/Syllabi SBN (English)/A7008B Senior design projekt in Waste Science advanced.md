---
course_code: "A7008B"
title: "Senior design projekt in Waste Science, advanced"
credits: "15"
title_sv: "Projekt i Avfallsteknik, fördjupning"
valid: "Autumn 2023 Sp 1 - Present"
decision_date: "2016-01-22"
education_level: "Second cycle"
grade_scale: "U G#"
subject: "Miljöteknik"
subject_group_scb: "Environmental Care and Environmental Protection"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=A7008B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=A7008B&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/a70/a7008b-projekt-i-avfallsteknik-fordjupning"
---

# Senior design projekt in Waste Science, advanced (A7008B)

## Main field of study

Natural Resources Engineering

## Entry requirements

Determined by the examiner.

## Selection

The selection is based on 30-285 credits

## Course Aim

After the course the student should

- Have a thorough knowledge in waste technology

- Be able to make a relevant selection of literature, conduct literature review and draw conclusions

- Be able to plan, implement and evaluate experimental work

- Independently plan, carry out and present a project

## Contents

Specialization in waste science and technology through literature, experimental work, evaluation of results and reporting.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

Project planning, experimental work in the lab and/or field. Independent work. Oral and written presentation.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

Oral and written presentation.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Passed oral and written presentation | U G# | 15 | Mandatory | A11 |  |

## Last revised

by Eva Gunneriusson 2016-01-22

## Syllabus established

by Department of Civil, Environmental and Natural Resources Engineering 2011-02-08
