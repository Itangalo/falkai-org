---
course_code: "L7021K"
title: "Freshwater Geochemistry"
credits: "7.5"
title_sv: "Sötvattengeokemi"
valid: "Spring 2026 Sp 3 - Autumn 2026 Sp 2"
decision_date: "2024-02-14"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7021K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7021K&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l70/l7021k-sotvattengeokemi"
---

# Freshwater Geochemistry (L7021K)

## Main field of study

Chemical Engineering, Civil Engineering, Geosciences

## Entry requirements

90 credits in Geosciences or equivalent. The course L0047K Environmental Geochemistry or equivalent must be included. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, the participants should be able

Knowledge and understanding 1. Understand general geochemical principles that regulate the abundance and geochemical character of elements in freshwater and soil/sediments.

Competence and skills 2. Interpret and explain the biogeochemical processes that influence the concentrations of metals and nutrient elements in freshwaters and soil/sediments. 3. Identify and explain geochemical principles using geochemical data sets. 4. Understand and summarize scientific research in written and oral form.

Judgement and approach 5. Perform basic qualitative and quantitative interpretations of field data with relevant software, and construct box models based on these interpretations.

## Contents

This course is an extension of Environmental Geochemistry (L0047K), which explains basic geochemical concepts.

Freshwater geochemistry covers the element cycling and mobility from the sediment/soil towards the groundwater, along stream- and river water into the open sea. It covers the importance of basic parameters such as pH, redox, and alkalinity and their impact on the distribution of major, minor, and trace elements in natural waters. The course also discuss the use of stable isotope systems as an important and reliable tool to shed light on geochemical processes and pathways. Geochemical data and data analysis software (e.g., ioGASTM) will be used to deepen the understanding of geochemical processes.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. All course materials can be found in its canvas room. The canvas room consists of different modules, structuring the course into pre-knowledge, lectures and exercises, and assignments. The course is given as a series of lectures and exercises. The lectures will introduce the students to fundamental geochemical knowledge, which will be deepened during a series of relevant exercises. The exercises provide training in deepening the knowledge of the geochemical principles. The assignments provide the opportunity to interpret and explain geochemical field data, with the aim of giving a deeper understanding of the theoretical parts of the course. The assignments can be of individual or group character, which will help the students to develop their independence but also teach them flexibility during collaboration.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

The course-intended learning outcomes and goals are assessed by

1. Written, individual exam, graded (G U 3 4 5) to assess ILO 1, 2, and 5. A minimum score of 60% is required to pass the final exam.

2. Literature assignment, with written and oral presentation (G U) to assess ILO 4.

3. Hand-in assignment based on geochemical data and their visualization (G U) to assess ILO 3 and 4.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0011 | Written exam | GU345 | 4.5 | Mandatory | A07 |  |
| 0012 | Literature exercise | U G# | 1.5 | Mandatory | A07 |  |
| 0014 | Hand-in assignment | U G# | 1.5 | Mandatory | A07 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2024-02-14

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
