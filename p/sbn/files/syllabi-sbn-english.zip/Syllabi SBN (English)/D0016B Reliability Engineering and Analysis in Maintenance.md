---
course_code: "D0016B"
title: "Reliability Engineering and Analysis in Maintenance"
credits: "7.5"
title_sv: "Tillförlitlighetsanalys i underhåll"
valid: "Autumn 2023 Sp 1 - Autumn 2026 Sp 2"
decision_date: "2020-02-14"
education_level: "First cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0016B&lasPeriod=225&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d00/d0016b-tillforlitlighetsanalys-i-underhall"
---

# Reliability Engineering and Analysis in Maintenance (D0016B)

## Entry requirements

In order to meet the general entry requirements for first cycle studies you must have successfully completed upper secondary education and documented skills in English language and Basic knowledge in mathematical statistics e.g course S0001M Mathematical statistics

## Selection

The selection is based on 1-165 credits.

## Course Aim

This course will provide basic knowledge on Reliability Engineering. After the course, the participant will be able to:

- Articulate fundamental concepts, characters, and their relationships on reliability engineering;
- Discuss and apply various types of reliability models for analyzing failure data;
- Understand and discuss various system configuration and calculate their reliability;
- Understand the mechanism of Weibull plot;
- Discuss various reliability related standards
- Apply Software tools for reliability analysis.
- Analyse and evaluate the benefits and challenges of computer software tools for reliability analysis.

## Contents

The contents include:

- fundamental concepts, characters, and their relationships on reliability engineering, including reliability function (MTTF, MTBF, MTTR, MTTF, etc), failure function, probability density function, failure rate/hazard rate, cumulative hazard function, residual life;
- various types of reliability models, including Exponential distribution, Weibull distribution, Lognormal distribution, etc;
- different system configuration, including Series configuration, Parallel configuration, k-out-of-n configuration, Standby configuration
- mechanism of Weibull plot;
- Reliability standards;
- Software Tools for Reliability Analysis.

## Realization

Each course occasion´s language and form is stated and appear on the course page on Luleå University of Technology's website.

The course is given on campus with the opportunity to participate remotely. Mandatory attendance at presentation of assignments and at study visits.

The course contains theoretical modules and seminars that deal with theory and methods. The course also includes project work, which is conducted in collaboration with industry.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. Written examination and approved assignments and project work.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Written exam | GU345 | 3.5 | Mandatory | A15 |  |
| 0004 | Project work | U G# | 2 | Mandatory | A15 |  |
| 0005 | Assignment report | U G# | 2 | Mandatory | A15 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2020-02-14

## Syllabus established

by Eva Gunneriusson 2015-02-09
