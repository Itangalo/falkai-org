---
course_code: "D7023B"
title: "Intelligent Asset Management and Industrial AI"
credits: "3"
title_sv: "Intelligent asset management och industriell AI"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2025-02-13"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Underhållsteknik"
subject_group_scb: "Other Subjects within Technology"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7023B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7023B&lasPeriod=227&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/d70/d7023b-intelligent-asset-management-och-industriell-ai"
---

# Intelligent Asset Management and Industrial AI (D7023B)

## Entry requirements

Courses of at least 90 ECTS in engineering subjects or equivalent real competence gained through practical experience. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2. Read more about how to apply for prior learning via this link: https://www.ltu.se/en/student-web/your-studies/prior-learning

## Selection

The selection is based on 30-285 credits

## Course Aim

After completing the course, participants should be able to:

- describe the terms eMaintenance and Industrial AI

- understanding the fundamentals of asset management and maintenance

- analyse the advanced data analytics techniques related to operation and maintenance processes in industrial contexts

- demonstrate AI and digitalisation in industrial contexts

## Contents

This course covers:

- Understanding the concepts of eMaintenance and Industrial AI

- Understanding the fundamentals of asset management and maintenance

- Industrial AI for asset management and maintenance

- Case studies and practical applications in industrial domains

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website. The course combines online and in-person sessions in a hybrid format. Delivery methods include lectures, assignments, labs, and real-world case study analyses.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided.

This course includes formative assessments (for learning) and summative assessments (of learning). Summative assessments, in the form of assignments and reports, examine the intended learning outcomes, while formative assessments (in-class discussions, reflections, quizzes, group work, feedback) support learning. All assignments will be processed during the course with feedback from teachers and/or peers.

To pass the course, 3 assignments must be completed. To pass each of the assignments, the solution must first be demonstrated to the Teacher Assistant allocated to the assignment. The demonstration should be preferably performed during the solving session or the wrap up session allocated for the assignment. After the demonstration is evaluated as satisfactory, the files must be submitted through Canvas. The Teacher Assistant will revise the submitted files and mark the assignment as passed or require a revision. The assignments will determine the grade (3,4,5). All the assignments carry equal weight.

The overall grade will be the mean grade of all these 3 assignments.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Assignment reports | GU345 | 3 | Mandatory | S26 |  |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13

## Syllabus established

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2025-02-13
