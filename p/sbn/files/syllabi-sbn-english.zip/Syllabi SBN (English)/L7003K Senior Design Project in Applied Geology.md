---
course_code: "L7003K"
title: "Senior Design Project in Applied Geology"
credits: "15"
title_sv: "Projektkurs i tillämpad geologi"
valid: "Spring 2026 Sp 3 - Present"
decision_date: "2022-02-11"
education_level: "Second cycle"
grade_scale: "GU345"
subject: "Geovetenskap"
subject_group_scb: "Earth Science and Physical Geography"
course_offered_by: "Department of Civil, Environmental and Natural Resources Engineering"
syllabus_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7003K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7003K&lasPeriod=226&locale=en"
course_page_url: "https://www.ltu.se/utbildning/kurs/l70/l7003k-projektkurs-i-tillampad-geologi"
---

# Senior Design Project in Applied Geology (L7003K)

## Entry requirements

90hp in natural resources engineering or equivalent, of which 30 credits environmental geochemistry or equivalent. Proficiency in English equivalent to Swedish upper secondary course English 6/level 2.

## Selection

The selection is based on 30-285 credits

## Course Aim

The student should independently design, implement and report on a project in the subject of geochemistry.

This means that the student after completing the course should:

- be able to formulate a relevant purpose based on a given problem in geochemistry

- seek and critically examine information, summarize and structure it in a scientific way.

plan, structure and implement a scientific project within given time frames.

- demonstrate the ability to describe and refer to relevant research and development work within the specific project

assess the scientific and practical relevance of the results obtained.

- be able to structure, analyze, interpret, and visualize geochemical data

- assess the scientific and practical relevance of the results obtained.

- express the work well in written and oral scientific correct way.

- conduct an oral presentation of the project's results, argue and defend the achieved conclusions for relevant stakeholders.

## Contents

Content is designed in dialogue with the examiner and supervisor, and if relevant stakeholders. The projects are in the subject of geochemistry

The course covers the following areas:

Introduction of the course objectives, description of available project and stakeholder and oral and written requirements.

Planning project, defining goals, formulating activities and time schedule

Project implementation, which can include laboratory work, field work or work with existing data and use of available tools for interpretation, modeling. and visualization of geochemical data.

Written presentation of work in a scientific way

Oral presentation of work to relevant stakeholders in a scientific way.

## Realization

Each course occasion's language and form are stated and appear on the course page on Luleå University of Technology's website.

The student works independently under supervision of planning of laboratory work, analytical studies, and field work together with supervisor and stakeholders involved in the project. Regular meetings with supervisor take place throughout the project period. Project implementation includes laboratory or fieldwork as well as searching for and summarizing scientifically relevant references and using available tools for interpretation, modeling. and visualization of geochemical data. Oral and written presentation for relevant stakeholders and the research group within Applied Geochemistry. Oral and written presentation includes relevant references, and scientific interpretation and description of geochemical data.

## Examination

If there is a decision on special educational support, in accordance with the Guideline Student's rights and obligations at Luleå University of Technology, an adapted or alternative form of examination can be provided. All goals are examined and assessed in the written presentation and in the oral presentation.

## Unauthorized aids during exams and assessments

If a student, by using unauthorized aids, tries to mislead during an exam or when a study performance is to be assessed, disciplinary measures may be taken. The term “unauthorized aids” refers to aids that the teacher has not previously specified as permissible aids and that may assist in solving the examination task. This means that all aids not specified as permissible are prohibited. The Swedish version has interpretative precedence in the event of a conflict.

## Course offered by

Department of Civil, Environmental and Natural Resources Engineering

## Modules

| Code | Description | Grade scale | Cr | Status | From | Title |
|---|---|---|---|---|---|---|
| 0001 | Passed oral and written presentation | GU345 | 15 | Mandatory | A07 | Yes |

## Study guidance

Study guidance for the course is to be found in our learning platform Canvas before the course starts. Students applying for single subject courses get more information in the Welcome letter. You will find the learning platform via My LTU.

## Last revised

by Assistant Director of Undergraduate Studies Eva Gunneriusson, Department of Civil, Environmental and Natural Resources Engineering 2022-02-11

## Syllabus established

Course plan approved by the Department of Chemical Engineering and Geosciences 2007-02-28.
