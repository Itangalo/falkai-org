---
kurskod: "X7014K"
titel: "Examensarbete i Arktiska mineralresurser, inriktning Mineralresurshantering, master"
hp: "30"
titel_en: "Degree project in Arctic Mineral Resources, specialization Mineral Resource Management, master"
giltig: "Vår 2024 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2023-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A2E"
betygsskala: "U G#"
amne: "Mineralteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X7014K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X7014K&lasPeriod=222&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/x70/x7014k-examensarbete-i-arktiska-mineralresurser-inriktning-mineralresurshantering-master"
---

# Examensarbete i Arktiska mineralresurser, inriktning Mineralresurshantering, master (X7014K)

## Behörighet

Minst 60 hp avklarade kurser av examensfordringarna. Utsedd examinator avgör om studenten har den fördjupning som krävs för det föreslagna examensarbetet.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens övergripande mål är att studenten skall öva, utveckla och visa färdigheter i att på ett korrekt sätt tillämpa teori och metod för att lösa ostrukturerade problem inom huvudområdet Arktiska mineralresurser.

Detta innebär att studenten efter kursen ska kunna:

- Formulera en relevant problemställning utifrån ett valt ämne inom huvudområdet Arktiska mineralresurser/Mineralresurshantering?.

- Tillämpa kunskaper och färdigheter som har förvärvats under studietiden för ett komplext utvecklings- eller mindre forskningsprojekt på ett självständigt och systematiskt sätt.

- Välja och motivera metod för studien med tydlig förståelse för valens inverkan på studiens resultat

- Utan fullständig information på ett vetenskapligt korrekt sätt analysera och besvara formulerad problemställning.

- Finna och kritiskt värdera information och sammanfatta denna på ett vetenskapligt sätt.

- Planera, strukturera och genomföra ett forsknings- eller utvecklingsarbete.

- Bedöma den vetenskapliga relevansen av erhållna resultat

- Arbeta efter tidplan.

- Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt.

- Utforma och genomföra en presentation där arbetets resultat och slutsatser redovisas och försvaras.

- Kritiskt granska andra studier på ett konstruktivt och vetenskapligt sätt.

## Kursinnehåll

30 hp                                                                                 Lp3

Innehållet i examensarbetet utformas i dialog med handledare. Examensarbetet innehåller alltid en teoretisk uppbyggnad i form av en litteraturstudie som belyser teknikområde och metodik, sammanfattad på ett vetenskapligt sätt.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten genomför och planerar självständigt examensarbetet med handledare som stöd. I examensarbetet ingår att göra en tidplan för hela projektet som kontinuerligt följs upp.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

- Skriftlig presentation av eget arbete.

I rapporten skall studenten visa förmåga att:

    - Motivera den valda problemställningen

    - Välja och motivera metod för studien med tydlig förståelse för valens inverkan på studiens resultat

    - Med tydlig koppling till vald teori/metod samla in information relevant för problemformuleringen

    - På ett relevant sätt skriftligt presentera den insamlade informationen

    - Utifrån vald teori/metod på ett korrekt sätt analysera och besvara formulerad problemställning

    - Med ett kritiskt förhållningssätt bedöma den vetenskapliga relevansen av erhållna resultat

    - Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt.

- Muntlig presentation av eget arbete

- Opponering på annans arbete

- Närvara vid presentationer av andra examensarbeten.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Institutionen tillhandahåller aktiv handledning under två terminer från kursstart.

Examensarbetet utförs företrädesvis enskilt och endast i undantagsfall med maximalt två deltagande studenter.

30 hp                                                                                 Lp3

I de fall där examensarbetet utförs av två studenter skall detta synas i rapportens omfång och djup.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Start av examensarbete | U G# | 0 | Obligatorisk | V24 |  |
| 0002 | Opponering av annat examensarbete | U G# | 0 | Obligatorisk | V24 |  |
| 0003 | Muntlig presentation | U G# | 0 | Obligatorisk | V24 |  |
| 0004 | Godkänd rapport | U G# | 30 | Obligatorisk | V24 | Ja |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13
