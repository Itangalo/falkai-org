---
kurskod: "S7015B"
titel: "Brandmodellering"
hp: "7,5"
titel_en: "Fire Modeling"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7015B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s70/s7015b-brandmodellering"
---

# Brandmodellering (S7015B)

## Behörighet

S0006B Brandtekniska beräkningar, samt något av alternativen S0003B Branddynamik I och S7002B Branddynamik II eller S7014B Branddynamik

Motsvarande kurser ger också behörighet.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kunskap och förståelse

För godkänd kurs skall studenten kunna:

- återge den vetenskapliga grunden och beprövade erfarenheten för CFD-beräkningar (Computational Fluid Dynamics), speciellt tillämpat på brandtekniska problem, samt återge de viktigaste aktuella forsknings- och utvecklingsområdena inom CFD för brandmodellering

- återge generell arbetsprocess för CFD och brandmodellering

Färdighet och förmåga

För godkänd kurs skall studenten kunna:

- räkna typtal för turbulenta flöden

- förklara, lösa problem och värdera frågeställningar och lösningsmetoder för förbränning, flamspridning samt termo- och fluiddynamik tillämpat på bränder

- förklara olika numeriska metoder

- lösa brandtekniska problem med CFD genom att kritiskt och systematiskt integrera kunskap för att simulera och utvärdera skeenden, även med begränsad information,

- kunna planera, genomföra, analysera och tolka komplexa brandmodelleringar samt överskådligt och vetenskapligt presentera resultat från dessa

- visa förmåga till lagarbete och skriftligt i dialog med olika grupper klart redogöra för och diskutera sina slutsatser från brandmodellering och den kunskap och de argument som ligger till grund för dessa.

Värderingsförmåga och förhållningssätt

För godkänd kurs skall studenten:

- kunna värdera olika modeller och arbetsprocesser för CFD-modellering tillämpat på olika brandscenarier samt visa insikt i ingenjörens ansvar att välja och redovisa parametrar så att resultaten används korrekt

- visa förmåga att identifiera sitt behov av ytterligare kunskap inom brandmodellering och att fortlöpande utveckla sin kompetens

## Kursinnehåll

Kursen behandlar

- Introduktion till CFD
- Arbetsprocessen för CFD
- Fluiddynamik och styrande ekvationer
- Längd- och tidskalor vid bränder
- Turbulenta flöden: Introduktion till turbulens.Längd- och tidskalor. Large Eddy Simulation, Reynolds Averaged Navier-Stokes samt Direct Numerical Simulation
- Förbränning och värmeöverföring
- Numeriska metoder:Styrande ekvationer. Diskretisering. Interpolation och felfortplantning. Meshningtekniker. Randvillkor
- Simulering av strålning
- Flamspridning
- Olika beräkningsprogram
- Validering och kritisk granskning av CFD

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen är baserad på självstudier, föreläsningar, quizzar, duggor, två projektuppgifter med muntlig och skriftlig redovisning, samt reflexionsuppgift.

För att nå kursens mål rörande kunskap och förståelse bör studenten ta del av föreläsningar och självständigt studera angiven kurslitteratur.

För att nå kursens mål rörande färdighet och förmåga bör studenten dessutom genomföra de individuella quizzarna och duggorna, medverka aktivt vid arbetet med samt den skriftliga och muntliga redovisningen av de två projektuppgifterna som genomförs i grupp, samt aktivt delta vid de konsultationer som ges för dessa projektuppgifter.

För att nå kursens mål rörande värderingsförmåga och förhållningssätt bör studenten dessutom delta i diskussioner om kursinnehållet vid föreläsningar, grupparbeten samt genomföra reflexionsuppgiften.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. För att bli godkänd på kursen krävs godkänt resultat på alla duggor, projektuppgifter samt reflexionsuppgiften. Betyget, med betygsskala U 3 4 5, bestäms från ett viktat medelvärde från resultaten på duggorna, projektuppgifterna och reflexionsuppgiften.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Duggor | GU345 | 4,5 | Obligatorisk | V23 |  |
| 0002 | Inlämningsuppgifter | GU345 | 3 | Obligatorisk | V23 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11
