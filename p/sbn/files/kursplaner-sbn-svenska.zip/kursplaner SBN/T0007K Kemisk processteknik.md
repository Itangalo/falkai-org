---
kurskod: "T0007K"
titel: "Kemisk processteknik"
hp: "7,5"
titel_en: "Chemical Process Technology"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-06-15"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Kemiteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0007K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t00/t0007k-kemisk-processteknik"
---

# Kemisk processteknik (T0007K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Grundläggande behörighet samt Kurserna K0010K(Fysikalisk kemi), K0011K(Oorganisk kemi), B0007K(Organisk kemi och biokemi), K0006K(Vattenkemi) eller motsvarande.

Goda kunskaper i engelska, motsvarande Engelska B/6.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter fullgjord kurs skall studenten kunna:

- Ur ett teoretiskt och praktiskt perspektiv beskriva och förklara de vanligaste kemiska och biokemiska processerna för industriell tillverkning av kemikalier, bränslen och produkter.

- Beskriva begreppen adsorption och katalys.

- Beskriva varför många av processerna kräver adsorbenter, katalysatorer eller enzymer och kunna beskriva några vanliga adsorbenter och fastfaskatalysatorer översiktligt.

- Förstå vilka driftsbetingelser som krävs för en effektiv produktion och kunna beskriva dessa översiktligt.

- Beskriva de vanligaste processerna för att rena strömmar av gas i kemisk industri.

- Tillverka bränslen i labbskala.

- Muntligen och skriftligen presentera tillverkning av bränslen i labb-skala.

- Identifiera och beskriva miljöpåverkande processer samt hur miljöpåverkan kan minimeras.

## Kursinnehåll

Denna kurs behandlar följande områden:

- Introduktion till kemiteknik

- Adsorption

- Heterogenfaskatalys och enymkatalys

- Hur fossila bränslen, kemikalier och produkter tillverkas

- Hur förnyelsebara bränslen, kemikalier och produkter tillverkas

- Rening av gasströmmar

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen genomförs genom föreläsningar och praktiska moment. Det praktiska momentet sker i form av projektarbete där studenterna arbetar i grupper och redovisas både skriftligt och muntligt.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examinationen genom individuell skriftlig tentamen med betyg enligt U (underkänd), 3, 4,5. För godkänt projektarbete krävs godkänd skriftlig och muntlig presentation av projektet med betygsskalan icke godkändgodkänd.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen T0007K motsvarar kursen T0005K

## Övrigt

Obligatorisk närvaro vid projektarbetet och vid muntlig redovisning av detta. Kursen ges på grundläggande nivå och ingår i civilingenjörsprogrammet Hållbar process- och kemiteknik. Studiehandledning återfinns i Canvas.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Skriftlig tentamen | GU345 | 5,5 | Obligatorisk | V22 |  |
| 0003 | Projektarbete | UG | 2 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-06-15

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17
