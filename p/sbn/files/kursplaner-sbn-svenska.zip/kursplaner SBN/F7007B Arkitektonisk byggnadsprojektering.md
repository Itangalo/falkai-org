---
kurskod: "F7007B"
titel: "Arkitektonisk byggnadsprojektering"
hp: "7,5"
titel_en: "Architectural Building Planning"
giltig: "Höst 2025 Lp 1 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7007B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7007B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/f70/f7007b-arkitektonisk-byggnadsprojektering"
---

# Arkitektonisk byggnadsprojektering (F7007B)

## Ingår i huvudområde

Arkitektur

## Behörighet

90 hp kurser inom teknik/naturvetenskap varav kurserna P0007B Byggprojektledning och F0012B Konceptuell design eller motsvarande kurser

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Målet med kursen är att kunna förstå, hantera och diskutera komplexa begrepp som används i byggnadsprocessens projekteringsskede samt kunna gestalta en byggnad med hänsyn till myndighetskrav och förstå detaljens betydelse för helheten. I denna kurs kommer studenterna att förvärva:

Kunskap och förståelse för

- Projekteringsprocessen i genomförandeskede (Moduler 0004,0005)

- Hur myndighetskrav, teknik och ekonomi påverkar arkitektens gestaltande arbete (Moduler 0004,0005)

- Faktorer som påverkar tekniska beslut i byggkonstruktion (Moduler 0004,0005)

- Hur CAD används som projekteringsverktyg (Moduler 0004,0005)

Färdigheter och förmåga att

- Justera byggnadsdesignen för ett bygglov, baserat på tidigare byggnadsprogram (Modul 0004)

- Bygglovshandling: Framställa lösningar som uppfyller krav från myndigheter under bygglovsskedet och utarbeta ritningar för bygglov. (Modul 0004)

- Bygghandling: Skapa tekniska ritninga för samordning med olika aktörer i byggprocessen. (Moduler 0004,0005)

- Bygghandling: Utarbeta tekniska ritningar av fasta möbler med tekniska specifikationer. (Modul 0005 )

## Kursinnehåll

Kursen tillämpar den genomgångna utbildningens samlade innehåll i ett projekteringsprojekt i genomförandeskede. Projektarbetet avser komplexa byggnader innehållande flera funktioner som ger olika krav på byggnadens utformning.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen består av föreläsningar, workshops och seminarier (muntliga och skriftliga). Uppgifter lämnas in via ritningar och muntliga presentationer som mestadels utförs i grupparbete.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Skriftlig och muntlig presentation av gruppens och individuellt projektarbete vid övningspass och slutredovisning.

Närvaro 80 % vid föreläsningar och övningspass med handledning och obligatorisk närvaro vid seminarier och redovisningar av projektarbete. Lärandemålen examineras i tillämpliga delar dels i Bygglovhandlingar samt dels i Bygghandlingar.

Arbetet ska ha uppnått ställda kvalitetskrav senast inom en vecka efter innevarande läsperiod. Eventuella kvarstående moment kan avslutas vid påföljande kurstillfälle.

Skriftlig och muntlig presentation i grupp och individuellt under inlämningsseminarier och löpande på designstudior.

Kod 0004: Gruppbedömning baseras på arbetsgruppsresultat, presentationer och efterlevnad av uppgiftskrav. Bygglovshandling och Bygghandling. Planlösningar och byggnadsdetaljer baserade på ett tidigare byggprogram. Betygsskala G/U 3/4/5.

Kod 0005: Individuell bedömning baseras på individuella uppgifter, frågesporter och arbetsgruppsprestationer. Betygsskala G/U 3/4/5.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0004 | Bygglovshandling med ekonomistyrning | GU345 | 4 | Obligatorisk | H13 |  |
| 0005 | Bygghandling | GU345 | 3,5 | Obligatorisk | H13 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Eva Gunneriusson 2012-03-14
