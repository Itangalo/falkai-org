---
kurskod: "P7005K"
titel: "Hydrometallurgi"
hp: "7,5"
titel_en: "Hydrometallurgy"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2023-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Processmetallurgi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7005K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7005K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p70/p7005k-hydrometallurgi"
---

# Hydrometallurgi (P7005K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

90hp inom kemiteknik. Kursen K0011K Oorganisk kemi ska ingå

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter avslutad kurs skall studenten kunna;

1. förstå samt använda sig av hydrometallurgiska fasdiagram.

2. redogöra för hur lakningsmekanismer och hur kinetiken påverkas av faktorer som temperatur, partikelstorlek, omrörning, etc.

3. redogöra för de hydrometallurgiska enhetsoperationerna samt metodik och apparatur som används vid behandling av olika råmaterial.

4. beskriva de vanligaste hydrometallurgiska processerna och de kemiska principerna bakom dessa.

5. genomföra, utvärdera och redovisa experimentellt hydrometallurgiskt arbete

6. identifiera, formulera och hantera komplexa frågeställningar

## Kursinnehåll

- Introduktion: Jämförelse mellan hydro- och pyrometallurgisk processteknik. Översikt av hydrometallurgiska enhetsoperationer och processer.

- Hydrometallurgiska fasdiagram: Löslighets- och Pourbaixdiagram

- Lakning: Teori, kinetik, reagens, metoder och lakningsobjekt

- Separation och lösningsrening: Kemisk fällning, cementering, kristallisation, jonbyte och vätskeextraktion.

- Metallutvinning: Teknisk elektrokemi, smältelektrolys, elektroraffinering, elektrovinning och gasreduktion.

- Hydrometallurgiska processer: Genomgång av hydrometallurgiska tillämpningar och miljöaspekter.

- projekt som innehåller laborationer: Lakning och elektrolys

- Datorlab: Konstruktion av Pourbaix diagram med programvaran FactSage.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av lektioner, projekt som omfattar laborationer, fyra individuella inlämningsuppgifter och en studieresa.

Lektionerna och inlämningsuppgifterna ger studenterna möjlighet att förstå kemin och tekniken i de hydrometallurgiska enhetsoperationerna samt att förstå hur val framställningsteknik påverkar ekonomi och miljö.

Laborationerna utförs i grupper om normalt 2 personer. Studenterna tränar planering, samarbete, utvärdering och försöksrapportering.

Studieresan ger studenterna ökad förståelse och känsla för fullskaliga processer.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursens mål examineras genom muntlig examen, skriftlig rapport avseende projekt som omfattar även laborationer och skriftliga inlämningsuppgifter.

Muntlig tentamen med betygen U 3 4 5 bedömer delmålen 1-4.

Skriftlig projektrapport inkluderand laborationer med betygen U och G examinerar delmålen 2, 4 and 5.

Skriftliga inlämningsuppgifter med betygen U och G examinerar delmålen 1-4 och 6.

Projekt inkluderande laborationer, inlämningsuppgifter och studieresa är obligatoriska.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0006 | Muntlig tentamen | GU345 | 3 | Obligatorisk | H07 |  |
| 0007 | Fyra inlämningsuppgifter | UG | 2 | Obligatorisk | V27 |  |
| 0008 | Projekt | UG | 2,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
