---
kurskod: "L0048K"
titel: "Klimatförändringar, principer och processer"
hp: "7,5"
titel_en: "Climate Change, Principles and Processes"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0048K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0048K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0048k-klimatforandringar-principer-och-processer"
---

# Klimatförändringar, principer och processer (L0048K)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet samt K0016K Kemiska principer eller motsvarande.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter avslutad kurs ska studenten kunna

Kunskap och föreståelse

- Översiktligt förklara uppkomst och utveckling av jordens atmosfär samt diskutera dess betydelse för jordens klimat (Lärandemål 1)

- Översiktligt förklara grundläggande havsdynamik och klimatrelaterade processer i hav samt diskutera deras betydelse för jordens klimat (Lärandemål 2)

- Ge exempel på och förklara hur miljöarkiv kan användas för att ge kunskap om jordens historiska klimat (Lärandemål 3)

Färdighet och förmåga

- Beräkna och bedöma naturlig och antropogen påverkan på atmosfären och jordens klimat med enkla modeller (Lärandemål 4)

- Utifrån en vetenskaplig grund sammanställa och presentera hur några av de processer som styr jordens klimat påverkar varandra (Lärandemål 5)

Värderingsförmåga och förhållningssätt

- Utifrån en vetenskaplig grund reflektera över hur antropogena processer påverkar klimatet

(Lärandemål 6)

## Kursinnehåll

Kursen ger en grundläggande introduktion till jordens klimatsystem med fokus på atmosfären och hav. Den innehåller grundläggande kunskap om klimatförändringar och exempel på vad som kan göras för att ändra den pågående utvecklingen. Kursen tar upp geokemiska och fysikaliska begrepp och information om processer som krävs för att förstå förändringar i jordens sfärer. Metoder för att förstå historiskt klimat och information om hur modeller används för att förutsäga framtida klimat behandlas. Exempel på hur ett förändrat klimat påverkar ekosystem ges från olika miljöer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar samt obligatoriska inlämningsuppgifter, muntliga presentationer och projektarbete i grupp med individuell examination där studenterna förväntas delta aktivt.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt

- Skriftlig rapport och muntlig presentation av projektarbete (U/G)

- Inlämningsuppgifter och muntliga uppgifter (3 4 5)

Lärandemål 1-4 och 6 bedöms genom inlämningsuppgifter och muntliga uppgifter.

Lärandemål 5 bedöms genom en skriftlig rapport och muntlig presentation av projektarbete.

Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Uppgifter | GU345 | 4,5 | Obligatorisk | H22 |  |
| 0004 | Projektarbete | U G# | 3 | Inaktiv | H22 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11
