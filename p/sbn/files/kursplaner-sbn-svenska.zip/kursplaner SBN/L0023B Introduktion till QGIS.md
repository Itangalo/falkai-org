---
kurskod: "L0023B"
titel: "Introduktion till QGIS"
hp: "7,5"
titel_en: "Introduction to QGIS"
giltig: "Höst 2025 Lp 1 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Geografisk informationsteknologi"
amnesgrupp_scb: "Geografisk informationsteknik och lantmäteri"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0023B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0023B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0023b-introduktion-till-qgis"
---

# Introduktion till QGIS (L0023B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kursen introducerar studenterna grunderna i geografiska informationssystem (GIS) och utrustar dem med praktiska färdigheter i QGIS. Med hjälp av kurerade handledningar kommer studenterna självständigt att navigera, analysera och visualisera rumsliga data i QGIS.

Efter avslutad kurs kommer studenterna att kunna:

- Navigera i QGIS-programvaran: Uppvisa effektiv navigering i QGIS-gränssnittet, inklusive anpassning av arbetsytan och användning av verktyg.

- Tillämpa koordinatsystem: Välja och tillämpa lämpliga koordinatsystem och projektioner för rumsliga datamängder.

- Manipulera rumsliga data: Importera, organisera och hantera rumsliga data i vektor- och rasterformat för att bygga upp geografiska databaser.

- Skapa visualiseringar: Designa och skapa kartor av professionell kvalitet med effektiv symbolik och etikettering.

- Designa enklare applikationer: Slutför självständiga projekt med hjälp av QGIS-verktyg för att ta itu med specifika frågor. Dokumentera arbetet enligt vedertagen metodik.

## Kursinnehåll

Grundläggande-intermediär GIS-drift: introduktion till ämnet Geografiska informationssystem (GIS)

- Koncept, struktur och funktion

- OpenStreetMap-data och QGIS-programvara

Praktiska övningar inkluderar:

- Arbeta med attribut

- Tabellhantering och databashantering

- Bearbetning

- Skapa och redigera data

- Kartografi

- Analys

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Detaljerade beskrivningar av kursens innehåll och kursmaterial finns under LTU:s lärplattform Canvas och universitetets egen dokumentmapp. Det finns inga inspelade föreläsningar och inte heller några obligatoriska sammankomster. Litteraturboken och webbkurserna innehåller läromedlet och ska följas enligt deras anvisningar. Uppgifterna hittar du under LTU:s lärplattform Canvas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursens mål examineras med uppgifter som görs individuellt eller i grupper om två personer och som examineras under kursens gång. Betygssättning av uppgifter sker enligt en betygsskala U/G. Alla uppgifter måste vara slutförda för slutbetyget.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Kurs som ska följas via Internet kräver att studenten har tillgång till någon form av bredbandsuppkoppling.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G# | 7,5 | Obligatorisk | H25 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
