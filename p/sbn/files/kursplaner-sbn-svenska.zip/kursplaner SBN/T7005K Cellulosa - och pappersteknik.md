---
kurskod: "T7005K"
titel: "Cellulosa - och pappersteknik"
hp: "7,5"
titel_en: "Cellulose and Paper Technology"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2023-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Kemisk teknologi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7005K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7005K&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7005k-cellulosa---och-pappersteknik"
---

# Cellulosa - och pappersteknik (T7005K)

## Behörighet

90hp inom kemiteknik. Kurserna K0011K Oorganisk kemi samt B0007K Organisk kemi och biokemi ska ingå.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kunskap och förståelse

1. beskriva vedens uppbyggnad

2. redogöra för och förklara sulfatprocessen samt mekanisk massa för framställning av pappersmassa

3. förklara och beskriva tekniker för blekning av pappersmassa

4. förklara och beskriva tekniker för framställning av papper

5. redogöra för de vanligaste metoder för att karaktärisering av massa

6. redogöra samband mellan fiberegenskaper och pappersegenskaper

7. redogöra för hantering och användning av returfiber

8. redogöra för vikten av kemikalieåtervinning i ett massabruk

Färdighet och förmåga

9. visa förmåga att utifrån komplexa frågeställningar kunna formulera, planera och utföra relevanta experimentella försök inom uppsatta tidsramar

10. visa förmåga att muntligt och skriftligt utvärdera, sammanställa och presentera experimentella försök.

11. visa förmåga att kunna bedöma, värdera och jämföra olika sorters experimentellt data samt teoretisk information.

## Kursinnehåll

Kursen behandlar följande område:

-Råvaror för massaframställning

-Trä- och fiberhantering

-Processer för framställning av kemisk och mekanisk massa

-Kemikalieåtervinning i ett massa- och pappersbruk

-Blekning av pappersmassa

-Pappersproduktion

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar som kommer att täcka teorin för kursens lärandemål. I kursen ingår även laborationer för att erbjuda studenterna möjlighet att tillämpa relevanta processer och tekniker inom massa- och pappersindustrin. Laborationerna omfattar även träning i projektplanering, samarbete samt skriftlig och muntlig presentation.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Lärandemålen examineras genom en skriftlig individuell tentamen. Betygssättning sker enligt betygsskala G U 3 4 5. Praktisk tillämpning av lärandemålen examineras via laborationer som utförs i samarbete med andra studenter på kursen. För godkänd laboration krävs en godkänd skriftlig rapport, där betygsskalan godkänd-icke godkänd används. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen. Laborationer och skriftlig rapport måste utföras och lämnas in inom kursens tidsram, i annat fall kommer inlämnat material att granskas och bedömas vid nästa kurstillfälle.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen T7005K motsvarar kursen KGT005

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 6 | Obligatorisk | H07 |  |
| 0003 | Laboration | UG | 1,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
