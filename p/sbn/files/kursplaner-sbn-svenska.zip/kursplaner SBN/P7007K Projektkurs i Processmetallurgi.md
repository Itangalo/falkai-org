---
kurskod: "P7007K"
titel: "Projektkurs i Processmetallurgi"
hp: "7,5"
titel_en: "Senior Design Project in Processmetallurgy"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Processmetallurgi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7007K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p70/p7007k-projektkurs-i-processmetallurgi"
---

# Projektkurs i Processmetallurgi (P7007K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Minst 90hp inom Kemiteknik varav kursen P0006K Högtemperaturprocesser eller motsvarande ska ingå. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2. För utbytesstudenter gäller att examinator gör individuell prövning av behörigheten beroende på typ av projekt.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Syftet är att studenten självständigt skall utforma och genomföra ett experimentellt projekt med anknytning till aktuell forskning och teknikutveckling. Vid kursens slut ska studenten självständigt kunna planera och utföra ett projekt. Studenten ska kunna utvärdera resultat och sammanfatta arbetet i en skriftlig och muntlig redovisning.

## Kursinnehåll

Innehållet bestäms i samråd med examinator och skall anknyta till aktuell forskning och teknikutveckling.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Självständigt projektarbete med stöd av examinator eller en handledare som utsetts av examinator. Projektet genomförs på svenska eller engelska. Projektkursen ska ge studenten kunskap om olika utrustning för genomförande av försök i laboratorieskala som finns vid avdelning för Processmetallurgi. Studenten tränas i att använda utrustning i laboratorieskala och analysinstrument, utforma och genomföra projekt samt muntlig och skriftlig redovisning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Godkänd muntlig och skriftlig rapportering.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation

ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Kan ges på svenska eller engelska

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektrapport | GU345 | 7,5 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
