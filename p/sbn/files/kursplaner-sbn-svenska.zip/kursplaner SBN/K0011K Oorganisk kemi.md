---
kurskod: "K0011K"
titel: "Oorganisk kemi"
hp: "7,5"
titel_en: "Inorganic Chemistry"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Kemi"
amnesgrupp_scb: "Kemi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0011K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0011K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0011k-oorganisk-kemi"
---

# Oorganisk kemi (K0011K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Grundläggande behörighet samt K0016K Kemiska principer eller motsvarande kurs.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter genomgången kurs skall deltagarna kunna

- tillämpa de samband och teorier som förklarar olika ämnens uppbyggnad och egenskaper.

- förklara orsakerna till egenskaper som hydrolys och syrabasstyrka hos olika ämnen och joner.

- förklara och tillämpa de termodynamiska förutsättningarna för upplösning och utfällning.

- avgöra speciationen hos olika ämnen mha jämviktsdiagram.

- beskriva och tillämpa grundläggande teorier inom koordinationskemi

- de namngivningsregler och viktigare undantag som används för formelskrivning och namngivning av föreningar och joner.

- förklara orsakerna till korrosion och kunna förklara och föreslå de lämpliga åtgärder som kan vidtas för att förhindra korrosion.

- Tillämpa i kursen diskuterade modeller för koordinationsföreningar, för att förklara koordinationsföreningarnas uppbyggnad, egenskaper och användning.

- Beskriva olika koordinationsföreningars uppbyggnad och namngivning med hjälp av tillämpbar nomenklatur

- beskriva olika likheter och skillnader hos grundämnena

- beskriva viktigare ämnens egenskaper och i vissa fall framställning

Vidare ska du ha erhållit en ökad kunskap om de praktiska tillämpningar som finns inom den oorganiska kemin, såväl globalt som inom landet.

## Kursinnehåll

Reaktioner i lösning:

Jonpotential - hydrolys/hydratisering.

Olika typer av syra/basbegrepp inklusive HSAB. Teoretiska aspekter på syra- och basstyrka i akvatiska och andra lösningsmedel.

Termodynamiska, jämviktskemiska och reaktionskinetiska aspekter på löslighet. Kelateffekten.

Korrosion: Elektrokemisk och kemisk korrosion. Katodiskt skydd. Passivering, inhibering, immunitet.

Laborationer

Laborationer omfattande reaktioner i lösning inklusive korrosion.

Koordinationsföreningar:

Kristall- och ligandfältsteori. Molekylorbitalteori med fokus på koordinationsföreningar.

Katalys. Biooorganiska koordinationsföreningar

Deskriptiv kemi

Avsnittet utgår från periodiska systemet och omfattar systematik, egenskaper, framställning och användning.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av lektioner, obligatoriska laborationer samt eget arbete med inlämningsuppgifter. Vid frånvaro första lektionen, meddela kursansvarig för att underlätta fortsatt planering av kursen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Skriftliga tentamen omfattande kursens mål, exklusive avsnittet Deskriptiv kemi (dvs. olika ämnens egenskaper, framställning och användning)

Prov nr 0006 examinerar punkterna 1-7 i målbeskrivningen

Prov nr 0007 examinerar punkterna 8-9 i målbeskrivningen

Godkända inlämningsuppgifter för avsnittet deskriptiv kemi, vilket omfattar de två sista punkterna i målen samt den sista raden.

Godkända laborationer och rapporter omfattande målen

- tillämpning av samband och teorier som förklarar olika ämnens uppbyggnad och egenskaper

- förklara orsakerna till korrosion och kunna förklara och föreslå de lämpliga åtgärder som kan vidtas för att förhindra korrosion.

Studenten ansvarar själv för att en aktiv dialog hålls med labbhandledaren i syfte att uppnå godkänt betyg inom fastställd tidsram.

Laborationer och rapporter som inte uppnått ställda kvalitetskrav inom en vecka efter innevarande läsperiods slut innebär betyget underkänt för laborationsmomentet. Laborationen i sin helhet får då utföras vid ett kommande kurstillfälle, under förutsättningen att lediga platser finns tillgängliga.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0011K motsvarar kursen KGK025

## Övrigt

Studiehandledningen finns upplagd i kursens rum på Fronter.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0006 | Tentamen: Reaktioner i lösning | GU345 | 3 | Obligatorisk | H07 |  |
| 0007 | Tentamen: Koordinationsföreningar | GU345 | 2 | Obligatorisk | H07 |  |
| 0010 | Deskriptiv kemi | UG | 1 | Obligatorisk | V27 |  |
| 0011 | Laborationer | UG | 1,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-

02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
