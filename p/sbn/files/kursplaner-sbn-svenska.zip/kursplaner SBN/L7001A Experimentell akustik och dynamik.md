---
kurskod: "L7001A"
titel: "Experimentell akustik och dynamik"
hp: "7,5"
titel_en: "Experimental Acoustics and Dynamics"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Teknisk akustik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7001A"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7001A&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l70/l7001a-experimentell-akustik-och-dynamik"
---

# Experimentell akustik och dynamik (L7001A)

## Behörighet

Kunskaper om akustik motsvarande Ljud och vibrationer (L0008A), Rums- och byggnadsakustik (L0009A), Maskindynamik (M0015T) eller Fordonsdynamik (M0019T).

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter avklarad kurs ska studenten behärska:

- experimentella modalanalysmetoder för bestämning av dynamiska parametrar hos vibrerande strukturer

- experimentella metoder för ljudintensitetsmätning

- grundläggande principer och beräkningar inom statistisk energianalys

- att självständigt planera och genomföra experimentella försök samt att redovisa resultaten i tekniska rapporter.

## Kursinnehåll

Avancerad mätteknik och signalbehandling med bl.a. Fourieranalys, koherens- och frekvensresponsfunktion.

Grundläggande statistisk energianalys.

Experimentell modalanalys och operativa svängningsformer.

Ljudintensitet för mätning av ljudeffekt och strålningskaraktäristik

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisning bestående av lektioner och demonstrationer som omfattar teorigenomgångar samt behandling av tillämpade problem. Laborationer och ett projektarbete som ägnas åt att dels översiktligt och praktiskt illustrera teorin, dels åt att lösa något mer övergripande problem av experimentell natur.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Skriftlig tentamen, skriftlig redovisning av laborationer. Skriftlig och muntlig redovisning av projektarbete.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen L7001A motsvarar kursen ARF105

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 4,5 | Obligatorisk | H07 |  |
| 0002 | Lab, inlämningsuppgift,projektarbete | GU345 | 3 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen har fastställts av Institutionen för arbetsvetenskap 2007-02-28
