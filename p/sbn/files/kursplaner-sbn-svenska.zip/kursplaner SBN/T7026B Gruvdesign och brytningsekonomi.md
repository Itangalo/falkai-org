---
kurskod: "T7026B"
titel: "Gruvdesign och brytningsekonomi"
hp: "7,5"
titel_en: "Mine Design and Mining Economy"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-11-02"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7026B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7026B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7026b-gruvdesign-och-brytningsekonomi"
---

# Gruvdesign och brytningsekonomi (T7026B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Minst 90hp inom kurser inom väg och vattenbyggnad. Kursen T0013B Berganläggningsteknik eller motsvarande ska ingå.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens mål är att studenterna ska kunna tillämpa och implementera de teoretiska grunderna samt de verktyg och metoder som används för gruvdesign och gruvplanering.

Kursmålen är följande:

1. Beskriva den övergripande tidslinjen för ett gruvprojekt. Det mål examineras i quiz.

2. Tillämpa och implementera tekniska och teoretiska faktorer gällande gruvdesign, produktionsplanering och brytningsekonomi. Detta mål examineras i inlämningsuppgift 1 och 2.

3. Tillämpa mjukvara för gruvdesign och produktionsplanering. Detta mål examineras i inlämningsuppgift 1 och 2.

4. Utvärdera risker förknippade med gruvprojekt. Detta mål examineras i quiz.

## Kursinnehåll

- Teori för gruvdesign, gruvplanering, förprojektstudier, och brytningsekonomi

- Datorstödd gruvplanering och produktionsplanering för underjordsgruvor samt dagbrott.

- Riskanalys av gruvprojekt: teori, riskidentifiering och riskbedömning

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Föreläsningar och övningar, övningar i mjukvara för gruvdesign och gruvplanering, inlämningsuppgifter och gruvstudiebesök. Samtliga uppgifter är obligatoriska.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Quiz gällande brytningsekonomi och gruvdesign -och planering, att examinerar kursmål 1 och 4.

Inlämningsuppgift 1: datorstödd gruvdesign och gruvplanering, att examinerar kursmål 2 och 3.

Inlämningsuppgift 2: Produktionsplanering projekt, att examinera kursmål 2 och 3.

Studenten måste genomföra alla examinationer att erhålla godkänt i kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Kursen baseras på T7001B samt T7013B.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Quiz | GU345 | 2 | Obligatorisk | V20 |  |
| 0002 | Inlämningsuppgift 1 | GU345 | 1 | Obligatorisk | V20 |  |
| 0003 | Inlämningsuppgift 2 | GU345 | 4,5 | Obligatorisk | V20 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-11-02

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institut 2019-06-14
