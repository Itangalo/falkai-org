---
kurskod: "T7025B"
titel: "Projektkurs i Jord och Berg"
hp: "7,5"
titel_en: "Project Course in Rock and Soil"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7025B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7025B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7025b-projektkurs-i-jord-och-berg"
---

# Projektkurs i Jord och Berg (T7025B)

## Ingår i huvudområde

Väg- och vattenbyggnad

## Behörighet

- Kurserna T7002B Dimensionering av bergkonstruktioner, T7008B Brytningsmetoder och G7006B Grundläggningsteknik

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten:
- ha insikt i aktuellt forsknings- och utvecklingsarbete inom den specifika nischen för sitt projekt,
- kunna planera och med adekvata metoder genomföra kvalificerade uppgifter inom givna tidsramar och därigenom bidra till kunskapsutvecklingen samt att utvärdera detta arbete,
- i internationella sammanhang muntligt och skriftligt klart redogöra för och diskutera sina slutsatser och den kunskap och de argument som ligger till grund för dessa

## Kursinnehåll

Kursen omfattar följande områden:

- Inledning - Genomgång av kursen, beskrivning av tillgängliga projekt.

- Projektplanering - Genomgång av hur man planerar projekt.

- Skriftlig presentation - Genomgång av hur man presenterar arbete på ett vetenskapligt sätt.

- Muntlig presentation - Genomgång av hur man muntligt presenterar arbete.

Exakt innehåll utformas i dialog med examinator eller utsedd handledare. Projekten kommer att vara inom ämnena Bergmekanik, Bergteknik eller Geoteknik

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av:

- Lektioner - Där förklarar föreläsaren de viktigaste teoretiska aspekterna relaterade till kursens innehåll vilket du senare applicera i de olika delarna av ditt projektarbete.

- Projektarbete - Genomförs som en tillämpning av de kunskaper du tillägnat dig inom utbildningen samt i denna kurs för planering och genomförande av ett avancerat utredningsuppdrag inom Bergmekanik, Bergteknik eller Geoteknik. Du skall också reflektera kring lösningen och de alternativ som stått till buds under arbetet. Under arbetets gång dokumenterar du ditt arbete samt har en dialog med din handledare (frånuniversitetet och/eller industrin). Projektarbetet består av tre delar:

    - Metod - I momentet ingår planering och genomförande av projektet och därtill hörande metoder.

    - Vetenskaplig artikel (uppsats) - I momentet ingår att skriva en konferensartikel på engelska som redogör för projektet på ett vetenskapligt sätt. Artikeln skall hålla hög klass, understödjas av referenser och genomföras så tydligt att en person som inte är insatt i projektet sedan tidigare skall kunna ta del av och arbeta vidare på de uppgifter som tagits fram.

    - Muntlig presentation - I momentet ingår att planera och genomföra en muntlig presentation av projektet.

- Reflektion - För var och en av de tre delarna ska du gå återkoppling annan students arbete samt reflektera kring din egen prestation.

- Handledning – Du arbetar tillsammans med din handledare. Upplägget för detta gör du tillsammans med din handledare.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:

- Metod - Inlämnat projektplanering samt redogörelse för utfört arbete. Studenten ska även ge återkoppling på annan students arbete samt reflektera kring sitt eget arbete. Examinerar mål 1 och 2.

- Uppsats - inlämning av konferensartikel där projektet redogörs på ett vetenskapligt sätt. Studenten ska även ge återkoppling på annan students konferensartikel samt reflektera kring sin egen konferensartikel. Examinerar mål 3.

- Muntlig presentation - Genomföra en muntlig presentation av projektet. Studenten ska även ge återkoppling på annan students muntliga presentation samt reflektera kring sin egen muntliga presentation. Examinerar mål 3.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Metod | GU345 | 4 | Obligatorisk | H19 |  |
| 0002 | Uppsats | GU345 | 2,5 | Obligatorisk | H19 |  |
| 0003 | Muntlig presentation | GU345 | 1 | Obligatorisk | H19 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-02-14
