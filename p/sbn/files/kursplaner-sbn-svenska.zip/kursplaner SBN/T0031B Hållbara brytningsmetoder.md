---
kurskod: "T0031B"
titel: "Hållbara brytningsmetoder"
hp: "7,5"
titel_en: "Sustainable Mining Methods"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0031B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0031B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t00/t0031b-hallbara-brytningsmetoder"
---

# Hållbara brytningsmetoder (T0031B)

## Behörighet

Grundläggande behörighet samt L0049K Hållbar mineralutvinning 1. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter genomgången kurs ska studenten kunna:

Kunskap och förståelse

1. Förstå brytningsmetoder och hållbarhet.

2. Beskriva nuvarande brytningsmetoder (de viktigaste).

Kompetens och färdigheter

3. Identifiera hur hållbarhetsprinciper tillämpas i varje brytningsmetod.

4. Demonstrera hur hållbarhetsprinciper tillämpas i varje brytningsmetod.

## Kursinnehåll

Kursen behandlar befintliga brytningsmetoder och hållbarhetsprinciper, och hur principerna kan tillämpas i respektive metod.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Gruppuppgifter kombinerat med föreläsningar och studiebesök.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Lärandemål bedöms genom skriftliga inlämningsuppgifter och en skriftlig tentamen enligt följande:

Gruppuppgifter bedömer lärandemål 1, 2, 3, 4.

Skriftlig tentamen bedömer lärandemål 1 och 3.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 4,5 | Obligatorisk | V26 |  |
| 0003 | Uppgifter | UG | 3 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
