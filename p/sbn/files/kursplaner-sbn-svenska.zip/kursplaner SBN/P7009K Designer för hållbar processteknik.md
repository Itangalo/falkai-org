---
kurskod: "P7009K"
titel: "Designer för hållbar processteknik"
hp: "7,5"
titel_en: "Design for Sustainable Processing"
giltig: "Höst 2023 Lp 1 - Höst 2025 Lp 2"
beslutsdatum: "2022-06-15"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Processmetallurgi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7009K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7009K&lasPeriod=214&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p70/p7009k-designer-for-hallbar-processteknik"
---

# Designer för hållbar processteknik (P7009K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

90hp inom kemiteknik. Kurserna P0006K (P0001K) Högtemperaturprocesser samt M0001K Fysikaliska separationsmetoder ska ingå. Goda kunskaper i engelska, motsvarande Engelska B/6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter fullgjord kurs skall studenten kunna;

1. känna till och kunna redogöra för begreppet hållbar utveckling.

2. beskriva några av de vanligaste metoderna för att analysera hur ett materialval eller processval påverkar miljöpåverkan.

3. beskriva och förklara vanligt förekommande tekniker som används i återvinningsprocesser.

4. beskriva vilka restprodukter som bildas vid högtemperaturprocesser, hur de bildas samt möjliga användningsområden.

5. beskriva några av de viktigaste begränsningarna för möjligheter till återvinning.

6 beskriva några exempel på kopplade materialcykler och inse hur detta påverkar möjligheterna till hållbar processteknik.

7 förstå att och till del varför, design av en produkt påverkar möjligheter till återvinning.

Hållbar utveckling

8. redogöra för och kritiskt förhålla sig till begreppet hållbar utveckling på nationell och global nivå; hur det uppstått, utvecklats över tiden, des olika nutida definitioner, yttringar och etiska utgångspunkter.

9. förklara och jämföra orsaker till hoten mot en hållbar utveckling samt ange, förklara och analysera de effekter som hoten för en hållbar utveckling ger/kommer att ge. 10. ge exempel på ingenjörens roll och ansvar för en hållbar utveckling i sin professionsutövning.

## Kursinnehåll

Kursen kommer ge studenten en kännedom om vanliga metoder för att värdera miljöpåverkan, främst LCI/LCA samt hur val av material och val av processteknik påverkar hållbarhet vid materialframställning. Metallurgisk processteknik och fysikaliska separationsmetoder som särskilt används inom återvinningsprocesser kommer gås igenom. Ett antal återvinningsprocesser däribland smältning av elektronikskrot, återvinning av blybatterier, flotation av trycksvärta samt energi- och kemikalieproduktion ur restprodukter från pappersindustrin kommer belysas. Generering av restprodukter och deras återvinning är en viktig del av kursen. Inom ramen för kursen kommer även en kortare projektuppgift att genomföras där studenten får möjligheten att reflektera över hur designen på en produkt påverkar möjligheter för framtida återvinning. Ett studiebesök kommer länkar samman teori från föreläsningar och projektarbete med praktiska tillämpningar i industrin.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen har både teoretiska och praktiska inslag i form av föreläsningar, övningar, demonstrationer, projektarbete, seminarium samt studiebesök. Rapportering sker såväl skriftligt som muntligt.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Inlämningsuppgifter, projektuppgift, seminarier och studiebesök är obligatoriska. Inlämningsuppgifter, seminarier, projekt och opponering bedöms med poäng inom dessa delar. Uppgifter och rapporter skall inlämnas inom föreskriven tid i annat fall sker avtrappning av max uppnåbara poäng på momentet. Den totala poängproduktionen ger totalbetyget för kursen, som ges med graderade betyg i skala 3 4 5.

Inlämningsuppgifter och projektuppgifterna examinerar delmål 1-7.

Seminarier examinerar delmål 8-10.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen P7009K motsvarar kursen P0002K

## Övrigt

Obligatorisk närvaro vid första lektionstillfället, studiebesök samt seminarier.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 2,5 | Obligatorisk | V13 |  |
| 0002 | Projekt | GU345 | 4,5 | Obligatorisk | V13 |  |
| 0003 | Studieresa | U G# | 0,5 | Obligatorisk | V13 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-06-15

## Kursplanen fastställd

av Eva Gunneriusson 2012-03-14
