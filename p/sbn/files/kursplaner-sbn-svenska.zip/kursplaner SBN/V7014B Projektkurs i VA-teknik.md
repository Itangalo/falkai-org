---
kurskod: "V7014B"
titel: "Projektkurs i VA-teknik"
hp: "30"
titel_en: "Senior Design project in Sanitary Engineering"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "UG"
amne: "VA-teknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V7014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V7014B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/v70/v7014b-projektkurs-i-va-teknik"
---

# Projektkurs i VA-teknik (V7014B)

## Behörighet

Kurser inom teknikområdet teknik/samhällsbyggnad/naturresurser motsvarande minst 200 hp samt minst 15 hp i ämnet VA-teknik eller motsvarande. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens övergripande mål är att studenten skall öva, utveckla och visa färdigheter i att tillämpa teori och metod för att lösa ostrukturerade problem med relevans för en yrkesverksamhet som civilingenjör inom området vatten och avloppsteknik.

Detta innebär att studenten efter kursen ska kunna:

- Formulera en relevant problemställning utifrån ett valt ämne inom ämnesområdet VA-teknik.

- Tillämpa kunskaper och färdigheter som har förvärvats under studietiden i ett komplext utrednings-, utvecklings- eller mindre forskningsprojekt på ett självständigt och systematiskt sätt.

- Välja och motivera metod för studien.

- Utan fullständig information på ett ingenjörsmässigt och vetenskapligt sätt analysera och besvara formulerad problemställning.

- Finna och kritiskt värdera information och sammanfatta denna på ett vetenskapligt sätt.

- Planera, strukturera och genomföra ett forsknings-, utvecklings- eller utredningsarbete.

- Bedöma den vetenskapliga och praktiska relevansen av erhållna resultat

- Arbeta efter tidplan.

- Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt

- Utforma och genomföra en presentation där arbetets resultat och slutsatser redovisas och försvaras.

- Kritiskt granska andra studier på ett konstruktivt och vetenskapligt sätt.

## Kursinnehåll

Innehållet i projektarbetet utformas i dialog med handledare. Examensarbetet innehåller alltid en teoretisk uppbyggnad i form av en litteraturstudie som belyser teknikområde och metodik, sammanfattad på ett vetenskapligt sätt.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen genomförs som ett individuellt arbete där studenten arbetar självständigt med att lösa ett problem inom VAteknik som antingen är självvalt eller valt tillsammans med handledaren. Studenten ska kontakta kursexaminator i god tid före kursstart för bedömning av förkunskapskrav och för att komma fram till lämpligt projekt. Problemet är av sådan art att en direkt lösning inte finns tillgänglig i litteraturen. Inom ramen för kursen ska en rapport med vetenskapligt upplägg skrivas och en muntlig presentation ges.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.
- Skriftlig presentation av eget arbete.

I rapporten skall studenten visa förmåga att:

- Motivera den valda problemställningen

- Välja och motivera metod för studien

- Med tydlig koppling till vald teori/metod samla in information relevant för problemformuleringen

- På ett relevant sätt skriftligt presentera den insamlade informationen

- Utifrån vald teori/metod på ett korrekt sätt analysera och besvara formulerad problemställning

- Med ett kritiskt förhållningssätt bedöma den ingenjörsmässiga och vetenskapliga relevansen av erhållna resultat

- Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt

- Muntlig presentation och försvar av eget arbete

- Opponering på annans arbete

- Närvara vid presentationer av andra projektarbeten

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Institutionen tillhandahåller aktiv handledning under två terminer från kursstart.

Examensarbetet utförs företrädesvis enskilt och endast i undantagsfall med maximalt två deltagande studenter.

I de fall där examensarbetet utförs av två studenter skall detta synas i rapportens omfång och djup.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Godkänd opposition samt muntlig och skriftlig presentation | UG | 30 | Obligatorisk | V27 |  |
| 0004 | Påbörjat projektarbete | UG | 0 | Obligatorisk | V27 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-06-14
