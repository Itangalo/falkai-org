---
kurskod: "T7004K"
titel: "Industriell katalys"
hp: "7,5"
titel_en: "Industrial Catalysis"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2018-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Kemisk teknologi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7004K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7004K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7004k-industriell-katalys"
---

# Industriell katalys (T7004K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Grundläggande behörighet. Kunskaper i fysikalisk kemi, oorganisk kemi, organisk kemi, jämviktskemi samt kemisk teknologi.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Studenten skall efter avslutad kurs: - Kunna förklara betydelsen av katalysatorer i industriella processer - Känna till och kunna förklara grundläggande begrepp inom katalys så som adsorption och desorption, adsorptionsisotermer, ytarea, porositet, dispertionsgrad, reaktionsmekanism, kinetik och zeoliter. - Kunna beskriva de vanligaste metoderna för karakterisering av katalysatorer - Känna till och kunna förklara hur reaktionsuttryck kan härledas - Känna till och kunna beskriva några av de viktigaste industriella processerna med avseende på vilka katalysatorer som används och processförhållandena samt med egna ord kunna förklara processerna

## Kursinnehåll

Betydelsen av heterogenfaskatalys i modern kemisk industri. Grundläggande katalys: adsorption, termodynamiska och kinetiska aspekter. Framställning och karakterisering av katalysatorer. Katalysatortyper: sura katalysatorer och zeoliter, metallkatalysatorer, metalloxidkatalysatorer och övriga typer. Katalysatordeaktivering. Katalytiska processer inom raffinaderiindustrin: katalytisk krackning, katalytisk reformering, alkylering, avsvavling. Katalytiska processer inom petrokemisk och övrig kemisk industri: oxidation och partiell oxidation, syntesgasbaserade processer. Miljörelaterade katalytiska processer: avgasrening, katalytisk förbränning, katalytisk kväverening.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Teori och praktik varvas i denna kurs genom att kursen innehåller föreläsningar samt praktiska övningar. Utöver den schemalagda tiden kommer studenterna att genomföra ett laborativt projekt och tillverka, karakterisera och testa katalysatorer. Projektet redovisas både muntligt och skriftligt. Färdigheter i laborativt arbete, projektarbete/samarbete, skriftlig och muntlig presentation tränas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examinationen består av laborativt projektarbete samt skriftlig tentamen med betyg enligt U (underkänd), 3, 4 och 5. För Godkänt laborativt projekt krävs godkänt skriftlig och muntlig presentation av projektet med betygskalan icke godkänd-godkänd. Student som underkänts vid fem provtillfällen har ej rätt att genomgå ytterligare prov.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 4,5 | Obligatorisk | H07 |  |
| 0002 | Laboration | U G# | 3 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2018-02-13

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
