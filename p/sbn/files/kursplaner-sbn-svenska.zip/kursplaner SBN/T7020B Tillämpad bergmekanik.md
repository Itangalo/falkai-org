---
kurskod: "T7020B"
titel: "Tillämpad bergmekanik"
hp: "7,5"
titel_en: "Applied Rock Mechanics"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-06-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7020B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7020B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7020b-tillampad-bergmekanik"
---

# Tillämpad bergmekanik (T7020B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

T0013B Berganläggningsteknik och T0014B Introduktion till bergmekanik eller T7001B Bergmekanikens grunder kunskaper, och T7002B Dimensionering av bergkonstruktioner eller motsvarande kunskaper. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Denna kurs kommer att förbättra studenternas kunskaper och färdigheter samt värderingsförmåga inom bergmekanikområdet och kommer att hjälpa eleverna att lösa praktiska bergmekanikproblem i samband med anläggnings- och gruvtekniska projekt

Kunskap och förståelse

Efter avslutad kurs ska studenten kunna

1. utforma balkar, pelare, öppna bergrum, schakt och återfyllning,

2. analysera gruvinducerade sättningar och seismicitet, samt

3. välja och tillämpa tillgängliga tekniska metoder och verktyg inom tillämpad bergmekanik.

Färdighet och förmåga

Efter avslutad kurs ska studenten kunna

4. formulera och genomföra lämplig analys för de givna uppdragen och en projektuppgift, och

5. förklara princip, mekanism och svårigheter vid dimensionering, konstruktion och kontroll av underjordiska konstruktioner på ett tekniskt sätt muntligt, skriftligt och grafiskt.

Värderingsförmåga och förhållningssätt

Efter avslutad kurs ska studenten kunna

6. bedöma kvaliteten på eget arbete och andras arbete, och

7. försvara sitt arbete i samband med ett fältarbete eller en projektuppgift.

## Kursinnehåll

Kursen behandlar

- Balkteori

- Pelardesign

- Utformning av öppna rum och schakt

- Schaktdesign och konstruktion

- Design för återfyllning

- Numerisk modellering

- Prediktering av sättningar

- Gruvinducerad seismicitet

- Fältbesök eller projektarbete

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Denna kurs inkluderar undervisnings- och inlärningsaktiviteter såsom

- Föreläsningar

- Självstudier

- Uppgifter

- Skriftliga prov

- Fältbesök eller projektarbete

- Teknisk rapportering och muntlig presentation

Ämnena i denna kurs presenteras i form av föreläsningar i klassen av flera föreläsare. Teoretiska färdigheter tränas genom beräkningar och analyser i klassen, självstudier och uppgifter. Förståelsen för ämnena kommer att bedömas genom skriftliga prov. Fokus på ett specifikt tekniskt problem görs genom gruppfältbesök och / eller projektarbete. Resultaten av projektarbetet sammanställs i en skriftlig rapport som kommenteras av kvalitetsgranskningas. Arbetet presenteras muntligt i klassrummet under ett seminarium och eleverna behöver försvara sitt arbete i grupp.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras genom skriftlig examination, skriftlig teknisk rapportskrivning och muntlig tentamen med differentierade betyg (5,0 hk) och obligatoriska uppgifter (2,5 hp) under kursen.

- De avsedda lärandemålen 1, 2, 4, 5 och 6 bedöms genom obligatoriska inlämningsuppgifter, betygsatta med G/U, dvs. godkänd (G) eller underkänd (U).

- De avsedda lärandemålen 1, 2 och 5 utvärderas vidare genom skriftlig examination.

- Avsedda lärandemål 3-7 utvärderas genom skriftlig teknisk rapport och muntlig tentamen.

Alla examinationer inklusive skriftliga prov, skriftlig teknisk rapportering och muntlig tentamen måste genomföras för att erhålla kursbetyg. Betygen för de skriftliga proven, den skriftliga tekniska rapporten och den muntliga tentamen delas ut enligt en betygsskala U, G, 3, 4 och 5, dvs Underkänd (U), Godkänd (3), Godkänd godkänd (4), och Mycket väl godkänd (5).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Skriftliga prov, projektuppgift, muntlig tentamen | GU345 | 5 | Obligatorisk | H08 |  |
| 0006 | Inlämningsuppgift | UG | 2,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-06-14

## Kursplanen fastställd

Kursplanen är godkänd av Institutionen för samhällsbyggnad 2006-02-20 att gälla från H06.
