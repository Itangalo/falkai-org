---
kurskod: "K7028B"
titel: "Beräkningsprojekt, träkonstruktion"
hp: "7,5"
titel_en: "Project Course, Design of Timber Structures"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2026-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "U G VG"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7028B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7028B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7028b-berakningsprojekt-trakonstruktion"
---

# Beräkningsprojekt, träkonstruktion (K7028B)

## Ingår i huvudområde

Samhällsbyggnadsteknik

## Behörighet

Minst 90 hp inom området Samhällsbyggnadsteknik eller motsvarande inklusive kurserna K7026B Träkonstruktion 1 och K0019B Trä som konstruktionsmaterial eller motsvarande. Dessutom krävs Engelska 6/nivå 2 och Svenska 3/nivå 3.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter avslutat kurs skall studenter kunna:

Kunskap och förståelse -redogöra hur en träkonstruktion kan beräknas effektivt med hjälp av programvaror som tillämpas på den finita elementmetoden -beskriva för- och nackdelar med olika modelleringsstrategier för samma problem -redogöra för kritiska aspekter och flaskhalsar vid modellering -redogöra för modelleringsantagandens betydelse för resultaten -redogöra för skillnader i resultat från analytiska och numeriska lösningar

Färdighet och förmåga -välja lämplig modelleringsstrategi för att analysera en problemställning för en träkonstruktion -analysera en träkonstruktion under olika scenarier med avseende på hållfasthet, styvhet och stabilitet -utveckla praktisk skicklighet i en programvara för att modellera och analysera en träkonstruktion -bedöma resultaten av en simulering -jämföra resultat från analytiska beräkningar med numeriska beräkningar -driva och dokumentera sitt eget arbete

Värderingsförmåga och förhållningssätt
- avgöra en modells lämplighet och förmåga att lösa en frågeställning
- värdera tillförlitligheten av modellen för olika val av parametrar samt i jämförelse med analytiska beräkningar

## Kursinnehåll

Kursen består av ett beräkningsprojekt baserat på olika frågeställningar om en träkonstruktion. Beräkningarna ska lösas med hjälp av en programvara för finita elementmetoden samt analytiskt. Det senare som jämförelse.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen ges på distans. Studenten driver sitt eget arbete kring en lämplig konstruktion som regelbundet stäms av med läraren. Studenten väljer en träkonstruktion och en problemställning som sen ska analyseras med programvaran RFEM. Färdighet och förmåga byggs upp genom övning i programvaran och handledningar med läraren. Vissa beräkningar ska även göras analytiskt för att jämföra med numeriska lösningar. Projektet stäms av halvvägs och redovisas i slutet av kursen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examination sker genom en slutpresentation samt projektrapport där problemställningen, modellantaganden och resultat ska redovisas.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K7028B motsvarar kursen W7012T

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Rapport | U G VG | 6 | Obligatorisk | V27 |  |
| 0003 | Slutpresentation | UG | 1,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13
