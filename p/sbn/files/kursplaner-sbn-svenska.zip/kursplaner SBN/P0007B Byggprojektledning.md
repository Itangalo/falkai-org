---
kurskod: "P0007B"
titel: "Byggprojektledning"
hp: "7,5"
titel_en: "Project management"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0007B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0007B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p00/p0007b-byggprojektledning"
---

# Byggprojektledning (P0007B)

## Ingår i huvudområde

Arkitektur, Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kunskap och förståelse

Efter godkänd kurs ska studenten kunna, med tydlig utgångspunkt från forsknings- och erfarenhetsbaserade kunskaper och tillämpningar inom grundläggande projektledningslitteratur:

1. …identifiera och med vedertagen terminologi redogöra för några inom projektledning vanligen förekommande begrepp, modeller, metoder och planeringsverktyg

2. …beskriva några förekommande sätt och principer för att organisera, styra och leda projekt, samt reflektera kring hur dessa:

    - kan vara relaterade till olika projektfaser, förutsättningar och ramar för byggprojekt

    - kan ha betydelse för byggprojekts progress och resultat

    - kan ställa krav på kunskaper och kompetenser hos projektledare och projektmedarbetare i byggprojekt

3. … beskriva nyckelfunktioner i projekt med utgångspunkt från några typiska roller, uppgifter, ansvarsområden och relationer

Färdighet och förmåga

4. Efter godkänd kurs ska studenten med grundläggande färdighet och tillsammans med andra i en projektorganisation kunna använda sådan kunskap som anges i mål 1-3 för att:

    - inom givna ramar planera, genomföra, följa upp, och överlämna ett projektarbete, samt reflektera kring valda tillämpningarnas betydelse för progress och resultat.

    - i mycket tidig projektering av byggprojekt bidra till utveckling av och kritisk reflektion kring mål och relaterade underlag. För lärandemålet gäller särskilt att utgångspunkt tas i beställarsidans perspektiv och att reflektion sker utifrån några relevanta intressenters förutsättningar och behov.

Värderingsförmåga och förhållningssätt

5. Efter godkänd kurs ska studenten kunna reflektera utifrån grundläggande projektledningslitteratur och personliga projektledningserfarenheter kring sitt behov av kunskaps- och kompetensutveckling för roller som projektledare/projektmedarbetare.

## Kursinnehåll

Kursen behandlar grundläggande projektledning, med exempel och övad tillämpning inom samhällsbyggnad/bygg- och anläggning. Kursen behandlar vidare, och lägger särskild vikt vid, tillämpning av kursstoffet med fokus på att i projektsammanhanget tillsammans med andra och inom givna ramar planera, genomföra, följa upp, och överlämna ett byggrelaterat projektarbete, samt kring valda tillämpningarnas betydelse för progress och resultat. Kursen fokuserar och behandlar särskilt byggprojektledning i mycket tidig projektering av byggprojekt och tar särskild utgångspunkt i beställarsidans perspektiv.

Kursstoffet berör inom projektledning vanligen förekommande begrepp, modeller, metoder och planeringsverktyg samt deras grund i forskningsbaserad kunskap och best practice. Områden som kursen innefattar är:

- projektets mål och strategi

- olika projektstyrningsmodeller

- projektplanens innehåll, funktion och framtagning

- verktyg för uppskattning, planering och uppföljning av aktiviteter, resurser och tid

- osäkerhet och risk; analys, planering och olika förhållningssätt

- olika faser i projekt, projektets bemanning och organisering

- roller, funktioner, intressenter och relationer

- kommunikation, kvalitet, ändringshantering och erfarenhetsåterföring

- projektledarskap och projektmedarbetarskap; mandat, befogenheter, kompetenser och utveckling

Med stöd av exempel på samhällsutmaningar tillsammans med trender och forskning inom byggprojektledning introduceras i kursen några grundläggande diskussioner kring behov av kunskapsutveckling och lärande på olika nivåer. Särskilt väcks och berörs frågan om framtida krav och egna utvecklingsbehov och möjligheter för att efter avslutad utbildning kunna verka självständigt som civilingenjör i projektledar- och projektmedarbetarrollen.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av två huvuddelar, del 1 som i huvudsak fokuserar på kunskapsmålen och del 2 som i huvudsak fokuserar på färdighets- och förhållningssättsmålen. Tillsammans syftar del 1 och del 2 till att studenten löpande under kursen ska öva och utveckla sin grundläggande förståelse för, och förmåga i, projektarbete och byggprojektledning.

I del 1 (koncentreras till kursvecka 1-3) inhämtar och bygger studenterna grundläggande kunskaper inom området projektledning och styrning med fokus på kursmålen för kunskap och förståelse. Arbetet är självständigt och sker med stöd av kurslitteratur, referenslitteratur och föreläsningar. I del 2 (kursvecka 1-kursens slut) ) prövar, övar och reflekterar studenterna kring tillämpningen av kursstoffet i en projektuppgift. Därvid tränar studenterna, med stöd av handledning, att tillsammans i projektgrupper tillämpa och reflektera kring kunskaperna i ett projektarbete. Projektuppgiften är organiserad kring ett uppdrag av målsökande karaktär i den tidiga byggprocessen (mycket tidig projektering). Grupperna sätts samman av lärare i början av kursvecka 1.

I del 2 får studenterna träna färdigheter kopplade till projektarbete, samarbete, att angripa öppna problemställningar i ett målsökande arbete, muntlig och skriftlig kommunikationsförmåga och de färdigheter och förmågor som preciseras i kursmålen. Träningen sker under det att studenterna tillsammans i projektgrupper och med given tids- och resursram ska: definiera, planera, organisera, genomföra, del- och slutrapportera (muntligt och skriftligt) samt löpande följa upp sitt anvisade uppdrag. I detta arbete ingår sådant som att ta fram, förankra och följa upp en projektplan med upprätthållen relation till styr- och referensgrupp, att identifiera för uppdraget relevanta intressenter, att organisera kommunikationen med dessa samt att inhämta, sammanställa och tolka information som gruppen bedömer som relevant för uppgiften. Studenterna ges under kursen möjlighet att reflektera kring eget arbete: genom löpande uppföljning av progress/resultat inom projektgruppen; resultatredovisning- och förankringsdialoger med handledare; kritisk granskning och utvärdering av andra gruppers arbete samt; genom att ta emot, diskutera och förhålla sig till återkoppling från andra studenter. Handledning och formativ återkoppling från lärare ges i huvudsak i samband med handledningstillfällen, där några är obligatoriska, schemalagda och utgör delexaminationstillfällen, medan andra bokas på gruppens eget initiativ.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:

Prov 0003 (U G#) examineras genom ett skriftligt individuellt prov ”dugga” (U G#) samt genom en skriftlig och muntlig individuell opponeringsuppgift ”peer-review”(U G#). Båda dessa delexaminationer ska vara godkända för godkänd (G#) modul 0003. Duggan examinerar lärandemål avseende kunskap och förståelse. Studenten ges två möjligheter att uppnå ett godkänt resultat på dugga under kursen och därefter två gånger per år i samband med att kursen ges. Peer-review examinerar lärandemål avseende färdighet och förmåga samt värderingsförmåga och förhållningssätt. Studenten ges två möjligheter att uppnå ett godkänt resultat på peer-review under kursen och därefter två gånger per år i samband med att kursen ges.

Prov 0004 (G U 3 4 5) examineras genom ett ”projektarbete” och för bedömning mot betyg 4 och 5 ingår även en skriftlig individuell ”reflektionsuppgift”. Projektarbete examinerar lärandemål avseende färdighet och förmåga. Examinationen sker löpande genom skriftliga och muntliga rapporteringar under kursens gång (U G#) och genom ett slutligt skriftligt överlämnande av projektarbetet vid kursens slut (U G#). Prov 0004 ställer krav på aktivt deltagande och samarbete inom projektgruppen under hela kurstiden, samt närvaro vid muntliga examinationstillfällen och vissa obligatoriska handledningstillfällen under kursens gång. Samtliga skriftliga och muntliga rapporteringar ska vara godkända för godkänd (G 3) modul 0004. Examination och bedömning av prov 0004 mot betyg 4 och 5 sker mot kursens samtliga lärandemål och genom slutligt skriftligt överlämnande av projektarbete tillsammans med en skriftlig individuell reflektionsuppgift.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen P0007B motsvarar kurser ABP117, P0010B, P0013B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Individuella uppgifter | U G# | 3 | Obligatorisk | H07 |  |
| 0004 | Projektuppgift | GU345 | 4,5 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Institutionen för Samhällsbyggnad 2010-03-10
