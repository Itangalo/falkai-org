---
kurskod: "U0005B"
titel: "Livscykelkostandsanalys"
hp: "7,5"
titel_en: "Life Cycle Cost Analysis"
giltig: "Höst 2019 Lp 1 - Tills vidare"
beslutsdatum: "2019-09-04"
utbildningsniva: "Grundnivå"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=U0005B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=U0005B&lasPeriod=208&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/u00/u0005b-livscykelkostandsanalys"
---

# Livscykelkostandsanalys (U0005B)

## Behörighet

Grundläggande behörighet

## Examinator

Johan Odelius

## Mål/Förväntat studieresultat

Kursen syftar till att ge studenten grundläggande kunskaper i livscykelkostnadsanalys inom underhåll. Efter avslutad kurs ska studenten kunna utföra grundläggande livscykelkostnadsanalyser.

## Kursinnehåll

Kursen innehåller:

- simulering av driftsäkerhetsparametrar

- metodik livscykelanalys

- metodik livscykelkostnadsanalys

- simuleringsverktyg för livscykelkostnadsanalys

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av lektioner och inlämningsuppgifter. Vid lektionerna varvas förinspelade teoretiska moment med diskussionspass.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För godkänt betyg krävs godkända inlämningsuppgifter. Betygskriterier för 3 4 5 enligt studiehandledning.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 7,5 | Obligatorisk | H19 |  |

## Litteratur

*Litteratur. Gäller från Höst 2019 Lp 1* Meddelas vid kursstart.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-09-04
