---
kurskod: "M7011K"
titel: "Teknisk-ekonomisk bedömning av mineralindustriprojekt"
hp: "7,5"
titel_en: "Technical-Economic Evaluation of Mineral Industry Projects"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2023-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Mineralteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7011K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7011K&lasPeriod=213&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/m70/m7011k-teknisk-ekonomisk-bedomning-av-mineralindustriprojekt"
---

# Teknisk-ekonomisk bedömning av mineralindustriprojekt (M7011K)

## Behörighet

60 hp i geovetenskap, gruvteknik, processteknik eller liknande områden eller motsvarande kunskaper från mångårig praktisk arbetslivserfarenhet (minst 5 år). Styrks med intyg från arbetsgivare. Goda kunskaper i engelska, motsvarande Engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursen syftar till att skapa kännedom om alternativa investeringsanalyser för tekniskt genomförbar och ekonomisk mineralutvinning samt förståelse för marknadsmekanismer för mineral och metaller. Efter fullgjord kurs skall studenten kunna:

- Känna till och kunna redogöra för begreppen marknadsmekanismer och globala leveranskedjor för mineral och metaller

- Upprätta delar av den tekniska och ekonomiska dokumentationen för en förstudie

- Beskriva och förklara olika metoder som används för investeringsanalys och riskanalys av mineralindustriprojekt

- Utföra en enklare projektanalys och utvärdering

## Kursinnehåll

Denna kurs omfattar:

Mineral- och metallmarknader

- Mineralförsörjning och efterfrågan

- Intressenter

- Råvarupriser och prissättningsinstitut

- Globala leveranskedjor och trender inom mineralindustrin

Projektanalys - Utvinning av mineral

- Förstudier i olika utvecklingsstadier

- CAPEX och OPEX för gruvdrift, mineralanrikning och återställning

- Produktionsplanering och materialflöden

Investeringsanalys

- Metoder för investeringskalkyl

- Osäkerheter och riskanalys

- Fallstudie

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar som kombineras med inlämningsuppgifter och ett mindre projekt.

Föreläsningar ska ge studenterna kunskap och förståelse för mineral- och metallmarknadernas mekanismer och möjligheten att granska utvecklingen av gruvprojekt ur ett tekniskt-ekonomiskt perspektiv.

Inlämningsuppgifterna och projektet ska träna studenten att självständigt bearbeta och fördjupa utvalda delområden.

Seminarier ägnas åt att i grupp beskriva, analysera, tolka och presentera ett komplext ämne inom det tematiska området.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Inlämningsuppgifter samt seminarier och projekt är obligatoriska. Inlämningsuppgifter och projekt bedöms med poäng i dessa delar. Seminarier betygsätts godkänd/ej godkänd. Den totala poängproduktionen ger totalbetyget för kursen , som ges med graderade betyg i skala 3 4 5.

Obligatorisk närvaro vid första lektionstillfället. Tillstånd att vara frånvarande ges av kursansvarig lärare.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 3 | Obligatorisk | H23 |  |
| 0002 | Seminarier | U G# | 2 | Obligatorisk | H23 |  |
| 0003 | Projekt | GU345 | 2,5 | Obligatorisk | H23 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13
