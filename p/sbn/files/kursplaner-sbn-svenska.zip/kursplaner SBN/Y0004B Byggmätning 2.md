---
kurskod: "Y0004B"
titel: "Byggmätning 2"
hp: "7,5"
titel_en: "Surveying 2"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "U G VG *"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=Y0004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=Y0004B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/y00/y0004b-byggmatning-2"
---

# Byggmätning 2 (Y0004B)

## Behörighet

Grundläggande behörighet samt Byggmätning 1 (Y0003B) eller motsvarande.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursen syftar till att utveckla grundläggande kunskaper och praktiska färdigheter i detaljmätning inom bygg-, anläggnings- och projekteringsmätning, samt en förståelse för stomnätsmätning. Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

Söka information i styrande dokument HMK och SIS, samt känna till hur de tillämpas inom bygg- och anläggningsmätning.

Tolka och beskriva grunderna inom laserscanning, fotogrammetri och UAV.

Kontrollera modeller som ligger till grund för mängdreglering och maskinstyrning.

Kvalitetssäkra mätningar, samt ha förståelse för grundläggande felteori och toleranser inom bygg- och anläggningsmätning.

Kontrollera, kalibrera och justera, GNSS-rover, avvägare och totalstation

Färdighet och förmåga

Etablera enklare byggplatsnät för GNSS och totalstationsmätning.

Utföra och beräkna ett dubbelavvägt höjdtåg.

Reducera och bearbeta satsmätningar.

Värderingsförmåga och förhållningssätt

Upprätta en enklare mätredovisning i enlighet med ”god mätsed”.

## Kursinnehåll

Kursen behandlar följande:

Avvägningståg

Satsmätning

Byggplatsnät och inpassningar

Detaljmätning med GNSS, totalstation, avvägningsinstrument, samt databearbetning

Inmätning för projektering

Utsättning av bultgrupper och betongkonstruktioner

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, lektioner, laborativt arbete, räkneövningar, enskilt arbete, grupparbete, fältövningar.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras genom inlämningsuppgifter och en skriftlig dugga.

Betygssättning sker enligt betygsskala U G VG. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Skriftlig dugga | U G VG * | 4 | Obligatorisk | H08 |  |
| 0005 | Inlämningsuppgift | UG | 3,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2008-01-22 att gälla från H08.
