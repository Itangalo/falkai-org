---
kurskod: "O0008K"
titel: "Petrologi"
hp: "7,5"
titel_en: "Petrology"
giltig: "Höst 2025 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2025-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Malmgeologi"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0008K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0008K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o00/o0008k-petrologi"
---

# Petrologi (O0008K)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet samt O0035K Geologi, grundkurs och O0036K Mineralogi eller motsvarande.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter genomförd kurs skall studenten kunna:

Kunskap och förståelse

- relatera bergartsbildande processer till plattektoniska processer och olika geologiska bildningsmiljöer

- anknyta bergarters egenskaper som kemisk och mineralogisk sammansättning, texturer, och strukturer till bergartsbildande processer

Färdighet och förmåga

- beskriva, identifiera och klassificera de vanligaste sedimentära, magmatiska och metamorfa bergarterna och deras strukturer i fält och i mikroskop

- använda grundläggande metodik i fältkartering

- dokumentera och rapportera geologiska fältdata

## Kursinnehåll

Kursen behandlar bildningsprocesser, -betingelser, och -miljöer av sedimentära, magmatiska, och metamorfa bergarter, deras relation till plattektonik, samt uttrycket i bergarternas kemiska och mineralogiska sammansättning, texturer, och strukturer. Det ingår också identifieringsmetoder för bergarter inkluderande mikroskopi och mineralogiska samt geokemiska klassificeringsdiagram. Vidare täcks grundläggande metodik i fältarbete, geologisk dokumentering och rapportering.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen är delat i fyra delmoment som omfattar (1) magmatiska, (2) sedimentära, och (3) metamorfa bergarter samt (4) en exkursion. Delmomenten om bergarter (1–3) består av föreläsningar där grundläggande teori presenteras och förklaras med fokus på kunskap och förståelse. Praktiska övningar (individuellt och i grupp) anknyter till föreläsningar och fokuserar på studentens färdigheter att i fält och i mikroskop beskriva, tolka och förklara bergarters texturer och strukturer samt att klassificera bergarter. Exkursionen med fältövningar syftar på att styrka och fördjupa kunskaper och förmågor fått från de andra delmomenten samt att introducera grundläggande metodik i fältkartering.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Delmomenten 1–3 examineras igenom en deltentamen (dugga) fokuserat på studiemålen specificerad under kunskap och förståelse. Examination av delmoment 4 (Exkursion) omfattar en grupprapport av exkursionen och ingående fältövningar samt muntlig redovisning. Praktiska övningar i hela kursen är obligatoriska för godkänt på kursen och attestera studentens färdighet att beskriva, identifiera och klassificera de vanligaste bergarter.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen O0008K motsvarar kursen KGO005

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Övningar | U G# | 1,5 | Obligatorisk | H07 |  |
| 0011 | Exkursion, fältövningar och fältrapport | U G# | 1,5 | Obligatorisk | H07 |  |
| 0012 | Dugga: magmatiska bergarter | GU345 | 1,5 | Obligatorisk | H07 |  |
| 0013 | Dugga: sedimentära bergarter | GU345 | 1,5 | Obligatorisk | H07 |  |
| 0014 | Dugga: metamorfa bergarter | GU345 | 1,5 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28
