---
kurskod: "D0017B"
titel: "Projektkurs i drift och underhållsteknik"
hp: "15"
titel_en: "Senior Design Project in Operation and Maintenance Engineering"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2019-01-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0017B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d00/d0017b-projektkurs-i-drift-och-underhallsteknik"
---

# Projektkurs i drift och underhållsteknik (D0017B)

## Behörighet

Grundläggande behörighet samt Minst 60 hp godkända bas- och kärnkurser för programmet högskoleingenjör underhållsteknik.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursens mål är att studenten skall utveckla förmågan att anlägga en helhetssyn på ett företags befintliga och framtida underhållssituation. Efter avslutad kurs skall studenten kunna:

- Problematisera med stöd i relevant teori för ett underhållsteknisk problemområde och med en helhetssyn på ett företag
- Analysera behovet av intern och extern information nödvändig för att utveckla förslag till problemlösningar.
- Genomföra analyser och presentera konsekvenser av förslagna problemlösningar
- Forma, organisera och följa upp en utvecklingsprocess som syftar till utveckling av företagsunderhålls problemlösningar
- Muntligt och skriftligt avrapportera genomförda analyser och förslag till problemlösningar, med en helhetssyn på ett företag.

## Kursinnehåll

Studenten skall i ett större projektarbete, på ett integrerande sätt och med en helhetssyn på företag, tillämpa de kunskaper och färdigheter som förvärvats i programmets bas- och kärnkurser inom underhållsteknik.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av seminarier och handledning. I kursen ingår ett företagsanknutet projektarbete som redovisas skriftligt och muntligt. Kursen ges på campus med möjligheten att delta på distans och studenter kommer att besöka ett företag ca 2 ggr under kursens gång. Obligatorisk närvaro på seminarier och företagsbesök.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Godkänt projektarbete och närvaro vid obligatoriska moment. Genom skriftlig projektrapport examineras studentens förmåga att använda ett systematiskt och analytiskt tillvägagångssätt för att lösa underhållsrelaterade problem. Projektrapporten examinerar också studentens förmåga att tillämpa underhållsstrategier och relevanta kunskaper inom underhållsteknik i ett verkligt fall.

Skriftliga inlämningar av problemformulering, projekt plan och veckorapporter examinerar studentens förmåga att utforma, organisera och styra ett projekt som syftar till att lösa underhållsproblem. Muntlig redovisning av projektarbete och inlämning av presentationsuppgifter utvärderar förmågan att muntligt presentera analyser och

förslag till problemlösningar och att granska och reflektera över andra studenters problem.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsupgifter | U G# | 4 | Obligatorisk | V16 |  |
| 0002 | Projektrapport | GU345 | 11 | Obligatorisk | V16 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-01-11

## Kursplanen fastställd

av Eva Gunneriusson 2015-02-11
