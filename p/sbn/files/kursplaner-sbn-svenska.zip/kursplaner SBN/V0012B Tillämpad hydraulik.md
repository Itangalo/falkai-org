---
kurskod: "V0012B"
titel: "Tillämpad hydraulik"
hp: "7,5"
titel_en: "Applied hydralics"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "VA-teknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0012B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/v00/v0012b-tillampad-hydraulik"
---

# Tillämpad hydraulik (V0012B)

## Behörighet

Grundläggande behörighet samt F0004T Fysik 1 eller motsvaranande

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter fullgjord kurs ska studenten kunna:

1) Beräkna hydrostatiskt tryck mot grundläggande konstruktioner i vatten

2) Lösa grundläggande hydrauliska problem genom att tillämpa de fundamentala ekvationerna inom hydrauliken

3) Identifiera beräkningsgång och lösa grundläggande hydrauliska problem för vätskeströmning i rör

4) Beskriva uppbyggnad av sprinklersystem och andra trycksatta vattensystem som ingår i byggnaders och samhällets brandskydd samt kunna grundläggande dimensioneringsprinciper och beräkningar

5) Beskriva samhällets system för vatten- och avloppshantering och förklara funktionen av dess komponenter

6) Identifiera risk- och säkerhetsaspekter kopplat till räddningstjänsten och som berör stadens vattensystem

## Kursinnehåll

Kursen, som innehåller tre kursdelar, behandlar grundläggande kunskap inom hydraulik samt två tillämpningar såsom sprinklersystem och stadens vattensystem. Syftet är även att ge en ökad förståelse hur dessa system påverkar varandra i förhållande räddningstjänsten och VA-verksamhet.

- Inom hydraulik ges grundläggande kunskap om hydrauliska begrepp/lagar såsom strömningstillstånd, kontinuitet, rörelsemängd och energi samt om rörströmning med friktionsförluster, tilläggsförluster, pumpar och ledningsdimensionering mha formler och diagram.

- Inom samhällets system för brandskydd med vatten som släckmedel ges huvudfokus på grundläggande kunskap om sprinklersystem (utformning, funktion och dimensionering)

- Inom samhällets system för vatten- och avloppshantering ges grundläggande kunskap om allmänna vatten- och avloppsledningsnät, vatten- och reningsverk, reservoarer och dagvattensystem samt översiktlig beskrivning om brandvattenförsörjning och brandposter. Föroreningsspridning via vatten- och avloppssystem samt risker kopplade till räddningstjänsten och VA-verksamhet behandlas också.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen för kursens tre delar:

- Genom salsundervisning och litteraturstudier inhämtas grundläggande hydraulisk teorikunskap. Beräkningskunskap fås genom att delta i salsundervisningen som innehåller räkneövningar samt att på egen hand lösa räkneuppgifter. Vidare finns två laborationstillfällen med praktisk tillämpning av den kunskap som inhämtats vid föreläsningarna. Dessa laborationstillfällen har obligatorisk närvaro då den utgör en del av examinationen (moment 0006).

- Genom salsundervisning och litteraturstudier inhämtas grundläggande kunskap om sprinklersystem, dess utformning, funktion och grundläggande dimensioneringsprinciper och beräkningar. En beräkningsuppgift angående dimensionering av ett sprinklersystem utförs i grupp och redovisas skriftligt (moment 0002). För att få en större förståelse för ett sprinklersystems uppbyggnad och funktion görs ett studiebesök vid en större sprinkleranläggning. Studiebesöket, som också inkluderar en förberedande introduktionsföreläsning, har obligatorisk närvaro då det utgör en del av examinationen (moment 0003).

- Genom salsundervisning och litteraturstudier inhämtas grundläggande kunskap om stadens vattensystem, dess koppling till räddningstjänsten, föroreningsspridning via vatten- och avloppssystem samt risker kopplade till detta. Övergripande beskrivningar av brandvattenförsörjning och brandposter ingår också. Föroreningsspridning och risker diskuteras vid ett seminarium med obligatorisk närvaro, då det ingår i en del av examinationen (0004). Inför seminariet inlämnas en skriftlig uppgift där litteratursökning och referenshantering övas. Vid seminariet tränas muntlig presentation.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. För att bli godkänd på kursen krävs minst betyget godkänt på varje delprov/moment. Lärandemål 1-3 prövas genom en skriftlig salstentamen (moment 0007) samt genom två praktiska laborationer (moment 0010). Lärandemål 4 prövas genom en skriftlig inlämningsuppgift (moment 0002) samt genom ett studiebesök med förberedande föreläsning (moment 0003), lärandemål 5 och 6 med en skriftlig deltenta (moment 0008) samt med ett seminarium och tillhörande inlämningsuppgift (moment 0004). Såvida man inte deltar vid något av de schemalagda studiebesöken så får det, i mån om plats, genomföras annat läsår. Såvida man inte deltar vid någon av de schemalagda laborationerna så får det, i mån om plats, genomföras annat läsår eller tillfälle då laborationen ges på annan kurs. För moment 0002, 0007 och 0009 sker betygssättning enligt betygsskala G U 3 4 5. Övriga moment bedöms enligt betygsskala G U. Slutbetyg på kursen sätts som ett viktat betyg utifrån moment 0002,0007 samt 0009.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Inlämningsuppgift | GU345 | 1,8 | Obligatorisk | H08 |  |
| 0007 | Tentamen | GU345 | 3 | Obligatorisk | H08 |  |
| 0009 | Deltentamen | GU345 | 1 | Obligatorisk | H08 |  |
| 0011 | Seminarium | UG | 0,7 | Obligatorisk | V27 |  |
| 0012 | Laboration | UG | 0,5 | Obligatorisk | V27 |  |
| 0013 | Studiebesök | UG | 0,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2008-01-22 att gälla från H08.
