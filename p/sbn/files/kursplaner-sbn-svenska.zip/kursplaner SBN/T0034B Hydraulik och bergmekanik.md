---
kurskod: "T0034B"
titel: "Hydraulik och bergmekanik"
hp: "7,5"
titel_en: "Hydraulics and Rock Mechanics"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2026-06-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Samhällsbyggnadsteknik"
amnesgrupp_scb: "Samhällsbyggnadsteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0034B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0034B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t00/t0034b-hydraulik-och-bergmekanik"
---

# Hydraulik och bergmekanik (T0034B)

## Behörighet

Grundläggande behörighet samt T0013B Berganläggningsteknik, 7,5 hp B0002B konstruktionsteknik, 7,5 hp F0004T Fysik 1, 7,5 hp eller motsvarande kurser

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

1. lösa grundläggande problem baserad på hydraulikens fundamentallagar (t.ex. beräkna hydrostatiskt tryck, vattennivå, flödeshastighet och flödesmängd). 2. bestämma strömningstillstånd och räkna på övergången från ett tillstånd till ett annat. 3. identifiera beräkningsgång och lösa grundläggande hydrauliska problem inom kanalströmning. 4. beräkna och utvärdera spänningstillståndet för undermarkskonstruktioner i berg med hjälp av analytiska och empiriska modeller samt föreslå optimal geometri och orientering av undermarkskonstruktioner i berg 5. identifiera möjliga brottmekanismer och utifrån det välja och applicera relaterade brottkriterier för att analytiskt och empiriskt kunna analysera och utvärdera stabiliteten hos undermarkskonstruktioner i berg 6. beräkna och utvärdera deformation- och töjningstillståndet för undermarkskonstruktioner i berg med analytiska och empiriska modeller 7. redogöra för och diskutera skriftligt sina analyser, modeller, resultat och slutsatser

## Kursinnehåll

Kursen behandlar följande områden inom hydraulik:

- Hydrostatiskt tryck och resulterande krafter på olika konstruktioner.
- Hydraulikens tre fundamentallagar: kontinuitetsekvationen, rörelsemängdekvationen, och energiekvationen (Bernoullis ekvation).
- Tillämpningar av fundamentallagar vid strömming i trycksatta ledningar och öppna kanaler.
- Strömningstillstånd, övergång mellan olika strömningstillstånd, och hur detta avgör startpunkt och beräkningsgång vid kanalströmning.

Kursen behandlar följande områden inom bergmekanik:
- Repetition Bergmekanik - Repetition av relevanta delar från tidigare kurs i bergmekanik,
- Spänningar - Spänningstillståndet, Mohrs spänningscirklar, Huvudspänningar, Primärspänningar, Sekundärspänningar,
- Hållfasthet - mekaniska egenskaper hos berg (intakt och bergmassa), brottmekanismer, brottkriterier, testmetoder,
- Deformationer - töjning, Mohrs töjningscirklar, elasticitetsmodul,

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av:

- Lektioner - De är en mix av flera undervisnings-/inlärningsaktiviteter: (i) kort teorigenomgång där föreläsaren förklara de viktigaste teoretiska aspekterna relaterade till kursens innehåll och (ii) tillsammans lösa och/eller diskutera typiska hydrauliska och bergmekaniska problem samt frågor vilket ger dig möjlighet att på olika sätt arbeta med flera aspekter kring analyser av olika system ur en praktisk och teoretisk synvinkel samt träna beräkningsprocedurer för frågeställningar relaterade till dessa.[IB2.1]

- Inlämningsuppgifter - Du arbetar tillsammans med andra studenter och använder dina kunskaper för att lösa olika problem. Du presenterar ditt arbete i skriftliga rapporter. Du tränas i att med utgångspunkt från de olika metoder som presenterats vid lektioner och i litteraturen analysera typiska problem relaterat till hydraulik och bergmekanik samt motivera dina lösningar.

- Mellan lektionerna [IB4.1]- Du förväntas förbereda dig inför varje lektion genom att arbeta igenom rekommenderat material, rekommenderade övningar och instuderingsfrågor så att du är beredd att bidra och delta i läraktiviteterna (problemlösning, diskussion, mm) under föreläsningarna samt fält- och laborationsövningarna.

- Laboration om kanalströmning där du i grupp utför mätningar vid en ränna i laboratoriet och redovisar resultat och tillhörande beräkningar i en skriftlig rapport. Övningen kopplar teorin till verkligheten för att öka förståelsen av kanalströmning. Undervisning inom hydraulik kan ske på engelska.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:
- Inlämningsuppgift bergmekanik- Består av problem där du tränar och tillämpar din teoretiska kunskap, förståelse och förmåga samt gör analyser och förklarar dina resultat skriftligt.
- Skriftliga deltentamina bergmekanik - Du löser problem som liknar de som du stöter på under kursen (i föreläsningar och uppgifter) för att testa din individuella kunskap, förståelse, skicklighet och förmågor. Kurskompendiet är tillåtet hjälpmedel på tentamen.
- Laborationsuppgift kanalströmning – en laborationsrapport lämnas in i grupp.
- Skriftlig deltentamen hydraulik – du löser problem inom hydrostatik, hydrodynamik, och kanalströmning likt de som du har arbetat med under kursen. Formelsamlingen är tillåtet hjälpmedel på tentamen.

Mål 1-3, 7 examineras via laboration med tillhörande inlämningsuppgift (modul 0002, betygsskala G U) samt skriftlig tentamen (modul 0001, betygsskala G U 3 4 5). Aktivt deltagande krävs vid laborationstillfället. Såvida man inte deltar vid laborationstillfället får det kursmomentet genomföras annat läsår, i mån av plats.

Mål 4-7 examineras via skriftlig deltentamen (modul 0003, betygsskala: G U 3 4 5) samt via inlämningsuppgifter (modul 0004, betygsskalan G U).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta

innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Hydraulikdelen av kursen (modul 0001 och 0002) motsvarar hydraulikdelen i kursen Naturliga vattentransportprocesser (kurskod V0017B t.o.m. läsåret 2021/2022, därefter V0021B) och i V0014B hydraulik & geologi; därför kan denna kurs inte ingå i samma examen som V0017B, V0021B, eller V0014B. Bergmekanikdelen (modul 0003 och 0004) motsvarar delar av kurserna Introduktion till bergmekanik (T0014B) samt Bergmekanikens grunder (T7001B); därför kan dessa kurs inte ingå i samma examen som denna kurs.[

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Deltentamen hydraulik | GU345 | 3,3 | Obligatorisk | V27 |  |
| 0002 | Laboration hydraulik | UG | 0,5 | Obligatorisk | V27 |  |
| 0003 | Deltentamen bergmekanik | GU345 | 2,7 | Obligatorisk | V27 |  |
| 0004 | Inlämningsuppgift | UG | 1 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-06-17
