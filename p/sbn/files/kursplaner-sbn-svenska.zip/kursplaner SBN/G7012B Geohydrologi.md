---
kurskod: "G7012B"
titel: "Geohydrologi"
hp: "7,5"
titel_en: "Geohydrology"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Hydrologi"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7012B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7012b-geohydrologi"
---

# Geohydrologi (G7012B)

## Ingår i huvudområde

Geovetenskap

## Behörighet

90 hp inom geovetenskap. Kurserna O0035K Geologi och L0039K/V0017B Naturliga vattentransportprocesser eller liknande kurser eller V0014B Hydraulik och geologi eller liknande kurs

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

- beräkna grundvattnets nivå, flöde och riktning i ett område med hjälp av jordprover och vattenståndsrör (piezometrar)

- bestämma de hydrauliska parametrar som karakteriserar en akvifär med hjälp av mätdata från utförda pumptest

- designa dränering, fördämningskonstruktioner och barriärer för t. ex. konstruktionsarbeten med hjälp av hydrauliska parametrar

- beräkna läckage genom dammar, vallar, fördämningar, etc., genom geometrisk samt numerisk iteration

- designa pump- och observationsbrunnar

- redogöra för de lagar som styr vattenflödet i den omättade zonen

- beskriva metoder som används för att förhindra saltvatteninträngning, föroreningstransport i grundvatten samt läckage från avfallsupplag

Efter kursen skall den blivande civilingenjören kunna arbeta hos ett konsultbolag eller i industrin som handläggare med en hydrogeologisk undersökning.

## Kursinnehåll

Kursen avser ge studenten kunskaper om grundvattenteori som kan tillämpas inom områden som dränering, dricksvattenförsörjning, bygg- och anläggning, grundläggning, dammsäkerhet, marksanering etc.

Kursen behandlar:

- Grundvattenförekomst i olika typer av berggrund och jordlager.

- Samband mellan nederbörd och hållbar grundvattenutvinning.

- Uppskattning av transmissivitet med horisontella strömnät.

- Beräkning av tvådimensionell stationär strömning med hjälp av vertikala strömnät.

- Pumptest: Provpumpning för bestämning av en akvifärs egenskaper samt bedömning av möjligt uttag, grundvattenavsänkning, etc.

- Brunnshydraulik i öppna och slutna akvifärer. Theis, Thiems och Cooper-Jacobs metoder.

- Samverkanseffekter mellan flera brunnar. Speglingsmetoder vid barriär eller källor.

- Saltvatteninträngning.

- Icke mättad strömning: Omättad hydraulisk konduktivitet, pF-kurvor, tensiometrar, total potential, bestämning av omättat vatteninnehåll.

- Deponihydrologi: Användning av vattenbalansekvationer för att minimera lakvattenbildning. Mät och beräkningsmetoder för vattenbalansens parametrar i en deponi.

- Konstruktion av pump- och observationsbrunnar.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, skriftlig och muntlig presentation av teoretisk uppgift, diskussion/muntlig presentation av beräkningsuppgift i två workshops, samt två datalaborationer där Geostudio SEEP/W och Modflow demonstreras.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras inom ett flertal moment:

1. I kursen ingår två studentledda beräkningsworkshops, där den teoretiska delen av kursen redovisas och diskuteras. Alla beräkningsexempel som gås igenom syftar till att förbereda studenterna för den avslutande skriftliga tentamen. Obligatorisk närvaro och medverkan krävs för godkänt betyg.

2. Två datorlabbar genomförs under kursen, där simuleringsprogrammen Geostudio SEEP/W och Modflow demonsteras. Datalabbarna har obligatorisk närvaro och obligatorisk inlämning av korrekt lösning krävs för godkänt betyg.

3. En skriftlig rapport om valfritt ämne inom geohydrologi ska lämnas in och redovisas muntligen tid ett avslutande seminarium. Obligatorisk närvaro och medverkan krävs för godkänt betyg.

4. Skriftlig tentamen avslutar kursen och betygssätts enligt skalan U 3 4 5.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation

ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen G7012B motsvarar kursen L7019K

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 5 | Obligatorisk | V16 |  |
| 0004 | Inlämningsuppgift | UG | 1,5 | Obligatorisk | V27 |  |
| 0005 | Datorlaboration | UG | 1 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2015-05-19
