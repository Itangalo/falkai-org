---
kurskod: "K7015B"
titel: "Stål- och träkonstruktioner"
hp: "7,5"
titel_en: "Steel and Timber Structures"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2022-11-03"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Konstruktionsteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7015B&lasPeriod=215&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7015b-stal--och-trakonstruktioner"
---

# Stål- och träkonstruktioner (K7015B)

## Ingår i huvudområde

Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

Kunskaper i
- byggnadsmaterial motsvarande kursen K0002B byggnadsmaterial
- hållfasthetslära och byggnadsmekanik motsvarande kurserna B0002B konstruktionsteknik och B7004B Byggnadsmekanik I
- byggkonstruktion motsvarande kurserna K0013B byggkonstruktion eller W7006B Konstruktionslära

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna
- beskriva och förklara stål- och träkonstruktioners funktion och verkningssätt under belastning,
- redogöra för och beskriva bakgrunderna till gällande regelverk för dimensionering och utförande av stål- och träkonstruktioner
- tillämpa och välja relevanta delar i gällande regelverk för dimensionering och utförande av stål- och träkonstruktioner
- kunna planera och utföra beräkningsuppgifter enskilt och laborationsuppgifter i grupp och presentera resultat och analyser skriftligt på ett           strukturerat sätt så att en tekniskt kvalificerad person kan följa arbetet och nå samma slutsatser

## Kursinnehåll

Kursen behandlar
- stål- och träkonstruktioners verkningssätt under belastning
- dimensionering av stål- och träkonstruktioner enligt gällande normer med avseende på lokal buckling (stål), knäckning, vippning, böjvridknäckning samt förband

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

På föreläsningar härleds, presenteras och exemplifieras bakgrunder och teorier till funktion verkningssätt under belastning. Tillämpning av gällande regelverk och beräkningsmetodik övas enskilt
- på räkneövningspass i klassrum
- i datorsal nyttjande beräkningsdataprogram
- i inlämningsuppgifter Verkningssätt under belastning provas i laborationer. Förmågan att planera, genomföra och redovisa arbete i grupp övas i laborationsuppgifter.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Bakgrunder, teorier och beräkningsmetodik examineras med skriftlig sluttentamen med differentierade betyg. Betygsskala: U, 3, 4, 5. Beräkningsmetodik och förmåga att planera och utföra beräkningsuppgift enskilt examineras genom skriftlig beräkningsrapport. Betygsskala: U, G. Förmåga att planera och utföra laborationsuppgifter i grupp, bearbeta data och presentera resultat examineras genom skriftliga laborationsrapporter. Betygsskala U, G Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Kursen ersätter delar av S7004B Stålkonstruktioner och W7005B Träbyggnad och kan inte kombineras med dessa.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Skriftlig tentamen | GU345 | 4 | Obligatorisk | H19 |  |
| 0002 | Inlämningsuppgifter | U G# | 2 | Obligatorisk | H19 |  |
| 0003 | Laboration | U G# | 1,5 | Obligatorisk | H19 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-11-03

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-02-14
