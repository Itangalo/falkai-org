---
kurskod: "D0012B"
titel: "Livscykel- och livscykelkostnadsanalys"
hp: "7,5"
titel_en: "Life Cycle Assessment (LCA) and Life Cycle Costing (LCC)"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0012B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d00/d0012b-livscykel--och-livscykelkostnadsanalys"
---

# Livscykel- och livscykelkostnadsanalys (D0012B)

## Behörighet

Grundläggande behörighet samt M0043M Matematik II samt D0011B Introduktion till drift- och underhållsteknik eller D0002B Drift och underhåll

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursen syftar till att ge studenten grundläggande kunskaper i livscykelanalys (LCA) och livscykelkostnadsanalys (LCC) inom underhåll.

Efter avslutad kurs ska studenten kunna:

- redogöra för miljöpåverkan under en produkts livscykel

- utföra grundläggande livscykel- och livscykelkostnadsanalyser

- analysera driftsäkerhet och underhållskostnader med hjälp av simuleringsverktyg

- analysera det mest kostnadseffektiva underhållsalternativet

## Kursinnehåll

Kursen omfattar:

- miljöpåverkan under en produkts livscykel

- metodik för livscykelanalys

- metodik för livscykelkostnadsanalys

- driftsäkerhet och beräkningsmodeller för underhållskostnader

- simuleringsverktyg för att analysera livscykelkostnader

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av seminarium, inlämningsuppgifter, grupparbeten och laborationer. Vid seminarierna diskuteras angivna läsanvisningar till kurslitteratur och förinspelade föreläsningar. Ett aktivt deltagande seminarierna krävs för att uppnå kunskap om miljöpåverkan och metodik för livscykelanalys och livscykelkostnadsanalys. Laborationerna ger introduktion av programvara och simuleringsverktyg för analys av driftsäkerhet och beräkning av underhållskostnader. Obligatorisk närvaro vid presentation av inlämningsuppgifter och grupparbeten.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Under laborationerna examineras förmågan att använda simuleringsverktyg för analys av driftsäkerhet och beräkning av underhållskostnader. Kunskaper och färdigheter att kunna redogöra för en produkts miljöpåverkan med hjälp av livscykelanalys och att utföra livscykelkostnadsanalyser examineras genom skriftliga inlämningsuppgifter. Inlämningsuppgifterna genomförs både individuellt och i grupp. En inlämningsuppgift presenteras också muntligt under ett seminarium där studenten bedöms på förmåga att analysera underhåll och kostnadseffektivitet för olika alternativ.

Betygskriterier för G 3 4 5 enligt studiehandledning. Skriftlig inlämning laborationer.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0004 | Inlämningsuppgifter individuellt/grupp | GU345 | 4,5 | Obligatorisk | H14 |  |
| 0005 | Laborationer | UG | 3 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-

02-11

## Kursplanen fastställd

av Eva Gunneriusson 2014-02-13
