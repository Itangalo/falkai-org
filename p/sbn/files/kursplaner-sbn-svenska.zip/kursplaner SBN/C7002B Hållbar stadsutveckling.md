---
kurskod: "C7002B"
titel: "Hållbar stadsutveckling"
hp: "7,5"
titel_en: "Sustainable urban development"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2022-02-10"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=C7002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=C7002B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/c70/c7002b-hallbar-stadsutveckling"
---

# Hållbar stadsutveckling (C7002B)

## Ingår i huvudområde

Arkitektur

## Behörighet

F7003B Urbanmorfologi eller motsvarande kurs. Goda kunskaper i engelska, motsvarande Engelska B/6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursen syftar till att utforska och implementera teorier om hållbarhet i praktisk översiktlig stadsplanering. Kursen behandlar aspekter på social, ekologisk och ekonomisk hållbarhet.

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

- Beskriva och förklara begreppet hållbarhet.

- Beskriva nationella och internationella överenskommelser och mål för hållbar stadsutveckling.

Färdighet och förmåga

- Tolka hur social, ekologisk och ekonomisk hållbarhet är tillämpbar i stadsplanering.

- Analysera hållbarhetsaspekter i en stad ur en översiktlig planeringsnivå.

- Baserat på analysen, utarbeta ett stadsutvecklingsförslag.

- Presentera stadsutvecklingsförslaget muntligt, samt genom text och illustrationer.

Värderingsförmåga och förhållningssätt

- Reflektera över och förklara vilka möjligheter och begränsningar som finns för att implementera en hållbar utveckling i kommunal planering och i stadsutvecklingsprojekt.

## Kursinnehåll

Kursen utforskar teorier om hållbar utveckling i praktiken. Kursen behandlar sociala, ekologiska och ekonomiska aspekter på hållbarhet relaterat till markanvändning, täthet, infrastruktur, rörelsemönster, kulturvård, gröna, blåa och vita strukturer, och offentliga miljöer. Kursen baseras på litteraturstudier och analys av en stadsmiljö som en iterativ process genom kursen.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, litteraturseminarier, projektarbete, och handledningstillfällen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursen mål examineras genom seminarier och en projektuppgift. För att bli godkänd på seminarierna (U/G) krävs aktivt deltagande. För att bli godkänd på projektarbetet krävs aktivt deltagande, samt godkänd muntlig, skriftlig, och illustrerad redovisning och bedöms med graderad betygsskala.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektuppgifter | GU345 | 6 | Obligatorisk | H07 |  |
| 0002 | Seminarier | U G# | 1,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-10

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
