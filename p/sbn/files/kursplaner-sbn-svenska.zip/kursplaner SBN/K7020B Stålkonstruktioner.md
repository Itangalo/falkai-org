---
kurskod: "K7020B"
titel: "Stålkonstruktioner"
hp: "7,5"
titel_en: "Steel Structures"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Konstruktionsteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7020B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7020B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7020b-stalkonstruktioner"
---

# Stålkonstruktioner (K7020B)

## Ingår i huvudområde

Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

Minst 90 hp avklarade kurser där 30 hp kurser i byggmaterial, konstruktionsteknik, byggkonstruktion och byggnadsmekanik ska ingå, t ex K0002B Byggmaterial, B0002B Konstruktionsteknik, K0013B Byggkonstruktion och B7004B Byggnadsmekanik I. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter avklarad kurs förväntas studenten kunna:

Kunskap och förståelse

1. Förklara de teoretiska grunderna och faktorerna bakom buckling och vippning av stålbalkar.

2. Förklara koncepten bakom böjknäckning av stålpelare, inklusive dess orsaker och konsekvenser.

Färdighet och förmåga

3. Visa förmåga att använda både elasticitets- och plasticitetsteori för att dimensionera stålbalkar under beaktande av relevanta dimensioneringsregler och säkerhetsfaktorer.

4. Skickligt beakta olika brottyper (buckling, vippning, böjknäckning) vid dimensionering av stålbalkar och stålpelare under säkerställande av strukturell stabilitet.

5. Dimensionera och utforma effektiva svets- och skruvförband i stålkonstruktioner under beaktande av lastöverföring och materialegenskaper.

Värderingsförmåga och förhållningssätt

6. Utvärdera och identifiera potentiella brott i experimentuppställningar, och visa förmåga att bestämma den maximala bärförmågan för stålkonstruktioner.

7. Använda tydlig och koncis kommunikationsförmåga i presentation av resultat och designlösningar både muntligt och i skriftliga rapporter, säkerställande effektiv överföring av teknisk information.

## Kursinnehåll

Teori och dimensioneringsregler för stabilitetsproblem så som:

- Lokal flänsbuckling

- Skjuvbuckling av livplåtar

- Böjknäckning av pelare

- Vridknäckning av pelare

- Vippning av stålbalkar

Utmattning av stålkonstruktioner

- Bakgrund och dimensioneringsregler

Svetsförband

- Bakgrund och dimensioneringsregler

Skruvförband

- Bakgrund och dimensioneringsregler

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Studenten deltar i lektioner där bakgrund och teorier till kursinnehållet härleds, visas och exemplifieras.

Teoretiska principer och beräkningsmetoder tränas av studenterna på tre olika sätt:

1. individuellt, genom praktiska övningar under klassrumslektioner.

2. individuellt eller i små grupper genom projektarbete.

3. i grupp, genom förberedelse, genomförande och analys av laboratorieförsök.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Denna kurs examineras genom: laborationer, skriftliga rapporter, beräknings-/dimensioneringsuppgifter, muntliga presentationer och quizzar.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 7,5 | Obligatorisk | V25 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14
