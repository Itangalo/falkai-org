---
kurskod: "F0021B"
titel: "Urban design"
hp: "7,5"
titel_en: "Urban Design"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "GU345"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F0021B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F0021B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/f00/f0021b-urban-design"
---

# Urban design (F0021B)

## Ingår i huvudområde

Arkitektur

## Behörighet

Grundläggande behörighet samt 60 hp inom teknikområdet Arkitektur inklusive:
- Kunskaper om plan- och byggprocessen motsvarande F0007B Teknisk arkitektur eller liknande kurs
- Kunskaper om skiss-, rit- och illustrationstekniker motsvarande D0021A SkissArk I eller D0054A Skiss- och rittekniker eller liknande kurs

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse
- Inventera ett område och beskriva dess styrkor, svagheter, möjlighet och hot.

Färdighet och förmåga
- Formulera kvalitativa och kvantitativa mål för att utveckla området.
- Visa förmåga att gestalta ett förslag för en stadsdel baserat på ett planeringsprogram.
- Genomföra ett detaljerat förslag för tomtindelning inom ramen för gestaltningsförslaget.

Värderingsförmåga och förhållningssätt
- Kommunicera gestaltningsidéer genom text och visualiseringar.

## Kursinnehåll

Kursen behandlar processer som genomförs för att utveckla en strategi för urban design på stadsdelsnivå. Kursen är utformad så den speglar olika skeden i verkliga planeringsprocesser och ger färdigheter i att göra förberedande inventeringar, upprätta program, urban design, och detaljerade studier av ett område.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen inkluderar föreläsningar, litteraturseminarier, grupparbete, muntliga presentationer och gruppkritik av en annan grupps projektarbete. Föreläsningar och litteratur åskådliggör olika infallsvinklar för att analysera ett område och utveckla förslag på dess urbana design. Grupparbete är utformat för att ge vägledning för projektutveckling. Genom projektuppgiften kommer studenterna att använda kunskap om att förbereda urban design-inventeringar, utveckla konceptuella gestaltningsförslag och med progression genomföra mer detaljerade gestaltningsförslag. Studenterna ska särskilt utveckla en högkvalitativ, grafisk poster som redovisning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursen mål examineras i fyra delar (i-iv). Inventering och analys (i), struktur (ii) och detaljerad gestaltning (iii) bedöms vid grupphandledningstillfällen. Slutlig examinering (iv) sker genom en formell muntlig/poster redovisning för en inbjuden publik. För godkänt på kursen krävs aktivt deltagande i projektarbetet, godkänt på muntlig/poster redovisning, och minst 80% närvaro på föreläsningarna. Kritik av en annan grupps posterredovisning ska också genomföras. Del I och II bedöms med betyg (U/G#). Del III och IV bedöms med betyg (U G 3 4 5).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen F0021B motsvarar kursen F0002B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Fas 3 | GU345 | 2,3 | Obligatorisk | H21 |  |
| 0004 | Fas 4 | GU345 | 2,2 | Obligatorisk | H21 |  |
| 0005 | Fas 2 | UG | 1,5 | Obligatorisk | V27 |  |
| 0006 | Fas 1 | UG | 1,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-

02-17
