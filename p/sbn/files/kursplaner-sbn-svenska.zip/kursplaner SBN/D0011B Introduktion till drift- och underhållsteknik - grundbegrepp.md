---
kurskod: "D0011B"
titel: "Introduktion till drift- och underhållsteknik - grundbegrepp"
hp: "7,5"
titel_en: "Introduction to Operation and Maintenance Engineering - Basic"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0011B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0011B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d00/d0011b-introduktion-till-drift--och-underhallsteknik---grundbegrepp"
---

# Introduktion till drift- och underhållsteknik - grundbegrepp (D0011B)

## Behörighet

Grundläggande behörighet + Fysik 2, Kemi 1, Matematik 3c eller Matematik D. Eller: Fysik nivå 2, Kemi nivå 1, Matematik fortsättning nivå 1c.

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kursen ger grundläggande kunskaper i drift och underhållsteknik. Vid avslutad kurs ska studenten:

Kunskap och förståelse:

1. förstå varför man underhåller tekniska system

2. visa grundläggande kunskaper i underhållsteknik och driftsäkerhet

3. ha kunskap om de nationella jämställdhetsmålen samt regelverk för jämställdhet i arbetslivet

Kompetens och färdigheter:

4. kunna beräkna tillgänglighet och utföra grundläggande tillförlitlighets- och livscykelkostnadsanalys

5. kunna tillämpa metoder för riskanalys inom drift- och underhållsteknik

6. kunna ge exempel på förutsättning för jämställdhet i arbetslivet

Förhållningssätt och värderingsförmåga:

7. ha insikt i mänskligt felhandlande och dess betydelse för underhållsarbete

## Kursinnehåll

Kursen innehåller:

- Definitioner och grundläggande begrepp

- Metoder för tillståndsövervakning

- Beräkna funktionssäkert hos serie- och parallellsystem

- Underhållsmässighet hos tekniska system

- Människligt felhandlande

- Underhållssäkerhet och beräkning av mätetal för operationseffektivitet

- Livscykelkostnadsanalys

- Metod för riskanalys

- Begreppen jämställdhet och jämställdhetsintegrering

- Nationella mål och lagstiftning om jämställdhet

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. I kursen varvas teoretiska föreläsningar och inläsning med muntlig redovisning och seminarier. Det förutsätts att studenten förbereder sig inför seminarierna genom att gå igenom anvisat material. Aktivt deltagande vid obligatoriska seminarier förväntas. Kursmodulen om jämställdhet består av inspelade föreläsningar samt litteratur.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För att erhålla godkänt betyg på kursen måste inlämningsuppgifter, quiz och seminarier vara avslutade med godkänt betyg.

- Inlämningsuppgifter bedömer färdighet och förmåga relaterat till målen (4-5)

- Seminarierna examinerar kunskap och förståelse som beskrivs i målen (1-2) samt förhållningssätt och värderingsförmåga i mål (7).

- Quiz i jämställhetsmodulen bedömer kunskap och förståelse i mål (3) och färdighet och förmåga i mål (6).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Seminarier | GU345 | 4 | Obligatorisk | V13 |  |
| 0006 | Inlämningsuppgifter | U G# | 3 | Inaktiv | V13 |  |
| 0007 | Jämställdhetsmodul | U G# | 0,5 | Inaktiv | V13 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13

## Kursplanen fastställd

av Eva Gunneriusson 2013-01-18
