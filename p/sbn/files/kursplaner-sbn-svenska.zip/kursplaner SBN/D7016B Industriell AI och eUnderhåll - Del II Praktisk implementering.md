---
kurskod: "D7016B"
titel: "Industriell AI och eUnderhåll - Del II: Praktisk implementering"
hp: "7,5"
titel_en: "Industrial AI and eMaintenance - Part II: Practical Implementation"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7016B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7016b-industriell-ai-och-eunderhall---del-ii-praktisk-implementering"
---

# Industriell AI och eUnderhåll - Del II: Praktisk implementering (D7016B)

## Ingår i huvudområde

Underhållsteknik

## Behörighet

Studenten ska ha kunskaper om grundläggande programmering, databaser och molntjänster, motsvarande D7015B Industriell AI och eUnderhåll - Del I. Industrial AI och eMAintenance I. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter genomgången kurs ska studenten kunna tillämpa termerna eMaintenance och Industrial AI i industriella sammanhang. Studenten ska kunna identifiera och tillämpa lämpliga avancerade dataanalystekniker relaterade till drift- och underhållsprocesser i industriella sammanhang.

## Kursinnehåll

- Förstå begreppet eUnderhåll

- Förstå begreppet Industriell AI

- Översikt över relaterade digitala och AI-teknologier

- Utveckling av programvara

- Tillämpa programvaruteknik

- AI för underhållsanalys

- Information Logistik

- Distribuerad databehandling, moln/edge

- Översikt inom cybersäkerhet i eUnderhållslösningar

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen omfattar föreläsningar och projektuppgifter, inklusive implementeringsarbete. Föreläsningarna kan vara en kombination av online, självstudier, och / eller klassrumsinteraktion. Projektuppgifterna kommer att vara en kombination av obligatoriska och valfria uppgifter som att ta fram lösning (mjukvara och/eller hårdvara) och praktisk rapportskrivning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursmål relaterade till både teoretisk förståelse och praktiska förmågor examineras med inlämningsuppgifter. Uppdragen består av demonstrationer och skriftliga rapporter. Studenterna förväntas genomföra alla uppgifter på minst godkänd nivå för att klara kursen med betyget 3. Varje inlämningsuppgift kommer att ha ytterligare frågor som ger studenten möjlighet att få betyget 4 och 5.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 7,5 | Obligatorisk | H22 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11
