---
kurskod: "D7015B"
titel: "Industriell AI och eUnderhåll - Del I: Teorier & koncept"
hp: "7,5"
titel_en: "Industrial AI and eMaintenance - Part I: Theories & Concepts"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2025-04-16"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7015B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7015b-industriell-ai-och-eunderhall---del-i-teorier--koncept"
---

# Industriell AI och eUnderhåll - Del I: Teorier & koncept (D7015B)

## Behörighet

Minst 60 högskolepoäng i tekniska ämnen. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter genomgången kurs ska studenten kunna beskriva termerna eMaintenance och Industrial AI. Studenten ska kunna analysera avancerade dataanalystekniker relaterade till drift- och underhållsprocesser i industriella sammanhang. Studenten ska även kunna tillämpa några av dessa tekniker i detta sammanhang.

## Kursinnehåll

- Förstå begreppet eUnderhåll

- Förstå begreppet Industriell AI

- Översikt över relaterade digitala och AI-teknologier

- Utveckling av programvara

- Programvaruteknik

- AI för underhållsanalys

- Informationslogistik

- Distribuerad databehandling, moln/edge

- Översikt inom cybersäkerhet i eUnderhållslösningar

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen omfattar föreläsningar och inlämningsuppgifter, inklusive laborativt arbete. Föreläsningarna kan vara en kombination av online, självstudier, och / eller klassrumsinteraktion. Uppgifterna kommer att vara en kombination av obligatoriska och valfria uppgifter som att ta fram lösning (mjukvara och/eller hårdvara) och praktisk rapportskrivning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursmålen examineras genom inlämningsuppgifter-

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgift | GU345 | 7,5 | Obligatorisk | V22 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-04-16

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-06-14
