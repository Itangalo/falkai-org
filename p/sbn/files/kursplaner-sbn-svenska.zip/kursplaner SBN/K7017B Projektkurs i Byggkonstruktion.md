---
kurskod: "K7017B"
titel: "Projektkurs i Byggkonstruktion"
hp: "7,5"
titel_en: "Special Assignment in Structural Engineering"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "U G#"
amne: "Konstruktionsteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7017B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7017b-projektkurs-i-byggkonstruktion"
---

# Projektkurs i Byggkonstruktion (K7017B)

## Behörighet

K0013B Byggkonstruktion eller motsvarande

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Målet med Projektkurs i Byggkonstruktion är att ge studenter erfarenhet och utmaning från konstruktionstekniska projekt tagna från verkligheten eller från intressanta idéer.Efter avslutad kurs ska deltagarna kunna (mål 1) syntetisera och (mål 2) tillämpa de vetenskapliga, matematiska, tekniska och designmässiga färdigheter som undervisats i tidigare kurser. Kursen ger också studenterna möjlighet att tillämpa och utöva avancerade kunskaper som inhämtats tidigare i utbildningen.

## Kursinnehåll

Kursen behandlar aspekter relaterade till beteendet hos belastade enskilda konstruktionselement eller till hela konstruktioner med användning av olika metoder såsom: experiment, simuleringar, fördjupning av kunskap inom specifika områden, grundläggande och avancerad design, samt bedömning av strukturer.Kursens innehåll kommer att skräddarsys efter studentens specifika behov och önskemål i samråd med läraren.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen inkluderar självständiga studier och regelbunden handledning av läraren. Det förväntas att studenten deltar aktivt i doktorandprojekt och samarbetar med forsknings- och utbildningspersonalen hos Byggkonstruktion. Studenten kommer att ha möjlighet att utföra en eller flera av följande aktiviteter: laboratorieförsök, fältundersökningar, finit elementanalys eller litteraturstudie beroende på projektets och studentens behov.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Betygsskalan på kursen är G U och bedöms utifrån en skriftlig rapport på 8 till 10 sidor som presenterar ämnet som studerats. Rapporten ska utformas enligt en specifik mall som följer IMRAD-skrivmetoden I-introduktion, M-metodik (mål 2), R-resultat (mål 2), A-analys (mål 1), D-diskussioner (mål 1).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Övrig kursinformation, såsom exempelvis: om det skett en förändring/revidering utan att ändra kurskod, länk till kursens hemsida med studiehandledningen.Övrig kursinformation, såsom exempelvis: om det skett en förändring/revidering utan att ändra kurskod, länk till kursens hemsida med studiehandledningen.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G# | 7,5 | Obligatorisk | H20 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Övergångsbestämmelser

Motsvarar till exempel denna kurs en tidigare kurs. Ange vilken kurs med namn och kurskod.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-02-14
