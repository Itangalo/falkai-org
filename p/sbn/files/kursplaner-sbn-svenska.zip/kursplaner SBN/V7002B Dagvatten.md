---
kurskod: "V7002B"
titel: "Dagvatten"
hp: "7,5"
titel_en: "Urban Stormwater Management"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "VA-teknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V7002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V7002B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/v70/v7002b-dagvatten"
---

# Dagvatten (V7002B)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

60 hp kurser inom teknik/naturvetenskap. För kurstillfället på svenska: goda kunskaper i svenska, motsvarande Svenska 3. För kurstillfället på engelska: goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna…

1. Beskriva den urbana hydrologin och hur det påverkar dagvattenavrinningen.

2. Beskriva och karaktärisera kvalitén på dagvatten och snö samt föroreningskällor.

3. Förklara dagvattnets inverkan på den naturliga miljön både med hänsyn till kvalitén och volymen/flöden.

4. Känna till olika typer av ledningsnät och beskriva funktionen av dessa

5. Beskriva snöhantering och förklara utmaningar med denna

6. Förstå, förklara och jämföra funktionen av olika typer av grön-blå infrastruktur för att uppnå en hållbar dagvattenhantering med fokus på rening, fördröjning.

7. Beskriva och förklara betydelsen av dagvattnet i staden för olika intressegrupper och/eller discipliner samt hur och varför dessa måste samarbeta för att kunna uppnå en långsiktigt hållbar dagvattenhantering.

8. Beskriva och förklara dagvattnets roll och betydelse i planeringsprocessen.

9. Beskriva ekosystemtjänster kopplade till en hållbar dagvattenhantering.

10. Känna till olika modeller för dagvattenflöden/kvalité samt kunna använda utvalda modeller i enklare sammanhang

11. Beräkna dagvattenflöden och volymer med rationella metoden samt känna till andra metoder för dessa beräkningar.

12. Dimensionera anläggningar för dagvattenhantering.

13. Ha förmågan att uttrycka sig på ett vetenskapligt sätt.

## Kursinnehåll

Kursen behandlar dagvatten i urbana områden med fokus på en hållbar, modern dagvattenhantering som använder blå-grön infrastruktur. Frågor som kommer belysas handlar om dagvattnets kvantitet och kvalitet, dagvattensystem och anläggningar samt deras funktion och dimensionering. Förutom dessa tekniska funktioner behandlar kursen dagvatten i planeringen och ekosystemtjänster som blå-grön infrastruktur kan tillhandahålla. Kursen introducerar datormodeller som kan användas för modellering av dagvattensystemen.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen består av föreläsningar, seminarier, räkneövningarna, studiebesök, datorlabb och grupparbeten.

Föreläsningarna ger förutom teoretiskt bakgrund även omfattande möjlighet till diskussioner av dagvattenhantering. Föreläsningar hålls i seminarieform där diskussioner bland studenterna ska vara en del av undervisningen.

Eftersom fokus ligger på blå-grön infrastruktur ger en inlämningsuppgift djupare inblick i syfte, funktion och utformning av en sådan teknik. Ett grupparbete fokuserar på att studenter med olika kunskaper och bakgrund tillsammans utarbetar en hållbar dagvattenlösning för ett urbant område och diskuterar detta utifrån deras olika bakgrund både i rapporten och under redovisningen i förhållande till de andra gruppernas rapporter.

Ett seminarium och en inlämningsuppgift ger en första inblick i datormodelleringsverktyg. Under ett obligatoriskt studiebesök besöks olika dagvattenanläggningar i fält.

Under vårterminen ges kursen på campus i Luleå. Under höstterminen genomförs kursen som distanskurs med onlineundervisning (8-10 träffar, halvdag).

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Examination på kursen är en deltentamen (modul 0018) som fokuserar på dagvattenhantering generellt (kursmål 1-10) samt en tentamen (modul 0014) som behandlar utformning och dimensionering av blå-grön infrastruktur (kursmål 6, 11 och 12). Båda tentamen har betygsskala G U 3 4 5.

I examinationen ingår även en litteraturstudie (modul 0017) som tidigt i kursen examinerar studentens förmåga att förstå, förklara och diskutera en vald dagvattenteknik (kursmål 3, 6 , 9) samt studentens förmåga att hitta, värdera och sammanfatta vetenskapliga artiklar (kursmål 13).

Obligatorisk närvaro vid ett studiebesök (modul 0017) ingår i kursens examination. Under studiebesöket visas exempel på dagvattenanläggningar/blå-grön infrastruktur (kursmål 4-6).

En modelleringsuppgift (modul 0019) examinerar studentens grundläggande förmåga att använda en datormodell inom dagvattenhantering (kursmål 10).

En gruppuppgift (modul 0016) med anknytning till en fallstudiet examinerar studenternas systemtänk som inkluderar olika aspekter med dagvattenhantering med multifunktionell blå-grön infrastruktur (kursmål 1-3, 6-7, 9, 11-12). Gruppuppgiften skall slutrapporteras genom en skriftlig projektrapport samt en obligatorisk muntlig redovisning och opponering.

Alla provmoment förutom tentamen betygssätts med G eller U. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

Såvida man inte deltar vid något av de obligatoriska schemalagda tillfällena (redovisningar, studiebesök) får dessa genomföras annat läsår, i mån av plats.

Båda tentamen genomförs enligt tentamensschema för kursen som ges på LTU under LP4. För distanskursen finns ett extra tentamenstillfälle enligt kursschemat.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen V7002B motsvarar kurser ABV002, V0019B

## Övrigt

Kursen kan ej ingå i samma examen som kursen V0019B.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0014 | Tentamen | GU345 | 2,5 | Obligatorisk | H07 |  |
| 0018 | Deltentamen | GU345 | 1,5 | Obligatorisk | H07 |  |
| 0020 | Modelleringsuppgift | UG | 0,5 | Obligatorisk | V27 |  |
| 0021 | Grupparbete Dagvattenutredning | UG | 2 | Obligatorisk | V27 |  |
| 0022 | Dagvattenanläggningar: litteraturstudie och studiebesök | UG | 1 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
