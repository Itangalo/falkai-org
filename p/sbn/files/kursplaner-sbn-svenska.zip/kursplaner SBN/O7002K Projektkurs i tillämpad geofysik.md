---
kurskod: "O7002K"
titel: "Projektkurs i tillämpad geofysik"
hp: "15"
titel_en: "Senior Design Project in Applied Geophysics"
giltig: "Höst 2011 Lp 2 - Tills vidare"
beslutsdatum: "2011-10-05"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Geofysik"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser  Prov Provnr       Typ                                                                 Hp        Betyg  0001         Godkänd muntlig och skriftlig redovisning                           15        GU345"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O7002K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O7002K&lasPeriod=166&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o70/o7002k-projektkurs-i-tillampad-geofysik"
---

# Projektkurs i tillämpad geofysik (O7002K)

## Behörighet

Examinator gör individuell prövning.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Examinator

Sten-Åke Elming

## Mål/Förväntat studieresultat

Målet är att studenten självständigt skall utforma, genomföra och redovisa ett projekt inom ämnet.

## Kursinnehåll

Innehållet bestäms i samråd med examinator och skall anknyta till aktuell forskning och teknikutveckling.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Självständigt projektarbete med stöd av examinator.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Skriftlig rapport

## Övrigt

Examinator: Ämnesföreträdare (eller den, som ämnesföreträdaren utser).

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser

Prov Provnr       Typ                                                                 Hp        Betyg

0001         Godkänd muntlig och skriftlig redovisning                           15        GU345

## Litteratur

*Litteratur. Gäller från Höst 2007 Lp 1* Beror på valt projekt och bestäms senare.

## Revidering fastställd

av Eva Gunneriusson 2011-10-05

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
