---
kurskod: "F7008B"
titel: "Arkitektoniskt byggnadsprogram"
hp: "7,5"
titel_en: "Architectural Building Programming"
giltig: "Höst 2025 Lp 1 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7008B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7008B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/f70/f7008b-arkitektoniskt-byggnadsprogram"
---

# Arkitektoniskt byggnadsprogram (F7008B)

## Ingår i huvudområde

Arkitektur

## Behörighet

P0007B Byggprojektledning samt F0012B Konceptuell design

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Målet med kursen är att studenterna ska förstå designorienterade uppgifter för att hantera och diskutera komplexa koncept som används i de tidiga stadierna av design-till-konstruktionsprocessen och samtidigt förstå arkitektens kreativa arbete. I denna kurs kommer studenterna att förvärva:

Kunskap och förståelse för:

- Processer och metoder för att kunna analysera klientens och samhällets behov och krav för vidare (modul 0008)
- Föreslå ett arkitekturprojekt med hänsyn till samhälleliga, användar- och klimatpåverkande aspekter (Moduler 0006, 0008).
- Problem och möjligheter inom design av byggnadskonstruktion (Modul 0008)

Färdigheter och förmåga att:

- Analysera platsens möjligheter utifrån användar-och affärsperspektiv. (Modul 0008)
- Utveckla och designa en arkitektonisk lösning för ett givet arkitekturprogram med en total byggnadsarea upp till 2500 kvm (Moduler 0006, 0008)
- Utveckla systemhandlingar för en byggnad (ritningar, renderingar, och planprogram).(Modul 0008)
- Utföra dagsljusberäkningar (Modul 0006).
- Använda CAD som verktyg för att producera byggnadsritningar och 3D-modeller (Modul 0008).

## Kursinnehåll

Kursen behandlar problemet med att designa byggnader med blandad användning (bostäder plus en alternativ användning) och skapar grunden för F7007B. Kursen tillämpar det samlade innehållet från tidigare kurser när det gäller CAD-BIM-kunskaper, kunskap om byggnadskonstruktion, byggmaterial, regler och representationstekniker i ett realistiskt scenario.

Projektarbetet avser komplexa byggnader innehållande flera funktioner som ger olika krav på byggnadens utformning.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen består av föreläsningar, workshops och iterativt designarbete som löper under hela kursen. Handledda designstudiosessioner med relaterade uppgifter och seminarier (muntliga och skriftliga), som överensstämmer med kursens struktur. Uppgifterna lämnas in via ritningar, 3D-modeller, skisser, affischer och muntliga presentationer, mestadels utförda som grupparbete.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Skriftlig och muntlig presentation i grupp och individuellt under inlämningsseminarier och löpande på designstudior.

Kod 0006: Individuell bedömning baseras på individuella uppgifter, frågesporter och arbetsgruppsprestationer. Betygsskala G/U 3/4/5.

Kod 0008: Gruppbedömning baseras på arbetsgruppsresultat, presentationer och efterlevnad av uppgiftskrav. Byggnadsdesign (ritningar, skriftliga rapporter, renderingar). Betygsskala G/U 3/4/5.

Minst 80 % närvaro vid ordinarie pass (designstudior och föreläsningar) krävs. Närvaro är obligatorisk vid seminarier och presentationstillfällen.

Arbetet ska ha uppnått ställda kvalitetskrav senast inom en vecka efter innevarande läsperiod. Eventuella kvarstående moment kan avslutas vid påföljande kurstillfälle.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0009 | Individuell inlämningsuppgift | GU345 | 3 | Obligatorisk | H24 |  |
| 0010 | Projektarbete, grupp | GU345 | 4,5 | Obligatorisk | H24 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du

behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Eva Gunneriusson 2012-03-14
