---
kurskod: "S7014B"
titel: "Branddynamik"
hp: "7,5"
titel_en: "Fire Dynamics"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2023-06-02"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7014B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s70/s7014b-branddynamik"
---

# Branddynamik (S7014B)

## Behörighet

90hp kurser inom Brandteknik och/eller Väg- och vattenbyggnad

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kunskap och förståelse För godkänd kurs skall studenten kunna:
- förklara brandtillväxt och avgiven effekt från fribrinnande bränder
- förklara hur ett rum påverkar brandförloppet samt utveckling av tryckprofiler vid brandförlopp
- förklara användningsområden och begränsningar för olika handberäkningsmodeller och datormodeller för branddynamiska beräkningar
- återge de viktigaste forsknings- och utvecklingsarbeten som ligger till grund för branddynamiken samt vissa aktuella forsknings och utvecklingsområden

Färdighet och förmåga För godkänd kurs skall studenten:
- kunna räkna typtal för olika storheter vid ett brandförlopp
- kunna återge olika typer av brandgasventilation och räkna typtal för dessa
- kunna lösa problem för dimensionering av brandskydd med motiverade antaganden och rimlighetsbedömning, såväl med handberäkningar som med datormodellering
- kunna planera, genomföra, analysera, tolka samt överskådligt och vetenskapligt presentera resultat från brandtekniska experiment

Värderingsförmåga och förhållningssätt För godkänd kurs skall studenten:
- kunna värdera olika modeller och metoder i analys av brandförlopp
- visa insikt i brandingenjörens ansvar att välja och redovisa parametrar så att resultaten används korrekt

## Kursinnehåll

- Rumsbrandens olika skeden

- Effektutvecklingen och massavbrinning för olika brandtyper och bränslen. Tidsberoende effektutveckling. Alfa-t2 tillväxt. Rummets effekt på effektutvecklingen. Framtagande av effektkurva.

- Flamhöjder, medelflamhöjd och flamhöjdskorrelationer.

- Starka och svaga plymer. Plymkorrelationer. Ceiling jets.

- Beräkning av tryckkrafter. Tryckprofiler. Allmänt om flöden i byggnader. Bernoullis ekvation. Ideala gaslagen. Olika former av tryck. Beräkning tryck, hastighet och massflöde genom öppningar. Grafisk visualisering av tryckskillnad i byggnader vid brand.

- Temperaturförhållanden vid rumsbränder. Brandgastemperaturer. Energibalans. Värmeövergångstal. Korrelationer för beräkning av gastemperatur. Fullt utvecklad brand. Beräkning av temperaturer i rummet med hjälp av olika modeller.

- Bevarandeekvationer och hur dessa används för att beräkna rökfyllnad vid rumsbränder.

- Brandrökens koncentration av giftiga gaser behandlas utifrån begreppet yield och plymekvationer.

- Allmänt om datormodeller och speciellt om tvåzonsmodeller.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen är baserad på självstudier, föreläsningar, räkneövningar, quizzar, laborationer med muntlig och skriftlig redovisning, samt reflexionsuppgift.

För att nå kursens mål rörande kunskap och förståelse bör studenten ta del av föreläsningar och självständigt studera angiven kurslitteratur.

För att nå kursens mål rörande färdighet och förmåga bör studenten dessutom medverka aktivt vid räkneövningar, laborationer samt vid skriftliga och muntliga redovisningar av dessa. Studenten bör även genomföra de individuella quizzarna. Laborationsuppgifterna, en experimentell och en datorbaserad, genomförs i grupp.

För att nå kursens mål rörande värderingsförmåga och förhållningssätt bör studenten dessutom delta i diskussioner om kursinnehållet vid föreläsningar, räkneövningar, laborationer och redovisningar samt genomföra reflexionsuppgiften.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Hela kursinnehållet examineras med en skriftlig tentamen med betygsskala U 3 4 5. För att bli godkänd på kursen behöver studenten dessutom ha blivit godkänd på quizzar, laborationer och reflexionsuppgift.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen S7014B motsvarar kursen S7002B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Skriftlig tentamen | GU345 | 4,5 | Obligatorisk | H22 |  |
| 0002 | Inlämningsuppgifter | U G# | 3 | Obligatorisk | H22 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11
