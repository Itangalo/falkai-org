---
kurskod: "K0015B"
titel: "Verktyg för byggkalkyler och rapporter"
hp: "15"
titel_en: "Tools for Engineering Calculations and Reporting"
giltig: "Vår 2026 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0015B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0015b-verktyg-for-byggkalkyler-och-rapporter"
---

# Verktyg för byggkalkyler och rapporter (K0015B)

## Behörighet

Grundläggande behörighet + Matematik 2a eller 2b eller 2c. Eller: Matematik nivå 2a eller nivå 2b eller nivå 2c.

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

Tolka och förklara grundläggande matematiska begrepp och metoder.

Särskilja och utforma olika sorters tekniska texter.

Uttrycka sig ändamålsenligt i tal och skrift.

Tolka och presentera data i diagram.

Färdighet och förmåga

Utföra och redovisa matematiska beräkningar.

Utföra och presentera enkla kalkylberäkningar.

Skriva och utforma tekniska rapporter.

Presentera resultat och fakta muntligt och skriftligt.

Värderingsförmåga och förhållningssätt

Värdera och tillämpa ett etiskt förhållningssätt vid lösandet olika uppgifter.

## Kursinnehåll

Kursen behandlar tre delmoment: matematik, data och kommunikation.

Matematik

Numeriska beräkningar

Ekvationer och olikheter

Koordinater och ekvationssystem

Formelbehandling

Geometri

Trigonometri

Linjära och icke-linjära ekvationer

Exponential- och logaritmfunktioner

Statistik

Data

Kalkylverktyg

Databehandling

Diagram

Kommunikation

Muntlig kommunikation

Skriftlig kommunikation

Tekniska rapporter

Argumentations- och presentationsteknik

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, lektioner, laborativt arbete, räkneövningar, enskilt arbete, grupparbete, muntlig/skriftlig presentation, kamratrespons.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:

Matematik

Fyra skriftliga duggor

Data

Inlämningsuppgifter

Kommunikation

Skriftliga uppgifter.

Muntliga redovisningar.

Teknisk rapport.

Betygssättning sker enligt betygsskala G U. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0015B motsvarar kursen Y0008B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Data | U G# | 0,9 | Obligatorisk | H19 |  |
| 0002 | Kummunikation | U G# | 3,7 | Obligatorisk | H19 |  |
| 0003 | Matte 1 | U G# | 3,3 | Obligatorisk | H19 |  |
| 0004 | Matte 2 | U G# | 3,3 | Obligatorisk | H19 |  |
| 0005 | Matte 3 | U G# | 1,9 | Obligatorisk | H19 |  |
| 0006 | Matte 4 | U G# | 1,9 | Obligatorisk | H19 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-02-14
