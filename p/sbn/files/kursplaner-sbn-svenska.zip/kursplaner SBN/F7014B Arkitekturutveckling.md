---
kurskod: "F7014B"
titel: "Arkitekturutveckling"
hp: "7,5"
titel_en: "Architecture - Development"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2022-06-15"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7014B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/f70/f7014b-arkitekturutveckling"
---

# Arkitekturutveckling (F7014B)

## Behörighet

Kunskaper motsvarande kandidatexamen inom arkitektur eller byggande t ex slutfört de första tre åren på Civilingenjör Arkitektur. Godkända kurser i Teknisk arkitektur F0007B, F0012B Konceptuell design, CAD + VR W0007B, Urban design F0002B samt P0007B Byggprojektledning.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter genomgången kurs skall studenterna

Kunskap och förståelse

ha insikt i aktuell forskning och utveckling inom temat för det aktuella projektarbetet.

Färdighet och förmåga

- utveckla eller utforma projektförslag, produkter eller processer med hänsyn till människors förutsättningar och behov och samhällets mål för ekonomiskt, socialt och ekologiskt hållbar utveckling.

- genomföra ett kvalificerat projekt som kan innehåller delar av husbyggnad och/eller stadsbyggnad inom givna ramar.

- kunna självständigt genomföra utrednings- eller utvecklingsarbetet.

- presentera sina resultat inför grupp både skriftligt och muntligt.

Värderingsförmåga och förhållningssätt

- bedöma teknikens möjligheter och begränsningar i egna lösningar på problem och reflekterat kring denna begränsning i presentationen av projekt.

- med en helhetssyn kritiskt, självständigt och kreativt identifiera, formulera och hantera frågeställningar för att kunna lösa projektuppgift.

- värdera de etiska och arbetsmiljökonsekvenser om projekt realiseras.

## Kursinnehåll

Kursen behandlar Arkitektur med tema inom husbyggnad och/eller stadsbyggnad. Litteratursökning, seminarier, skiss- och designuppgift, användande av CAD- och datorverktyg för framställning, presentation samt dokumentation.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen genomförs som en tillämpning av de kunskaper studenten tillägnat sig tidigare inom den grundläggande nivån. Tillämpningen sker genom deltagande i planering och genomförande av ett avancerat utrednings- eller utvecklingsprojekt. Arbetet genomförs delvis som individuell arbete och delvis i grupp. Handledningen sker både i grupp och individuellt. Externa handledare och föreläsare med yrkeserfarenhet kan förekomma. Rapporteringen skall hålla hög klass, understödjas av referenslitteratur och referenser samt genomföras så tydligt att en person som inte är insatt i projektet sedan tidigare skall kunna ta del av resultatet av projektet. Kursen är en arkitektur- och designbaserad kurs. Därför förväntas studenten att göra presentationer i form av ritningar med hög gestaltskvalitet och modellera både digitalt och fysiskt. Studenten ska reflektera över slutresultatet av projektet.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

I kursen ingår litteraturseminarium samt seminarium om metodik för projektets genomförande. Betygsättning av gruppens och individuell prestation görs av examinator för kursen. För slutbetyg krävs deltagande i och närvaro vid seminarier, handledning under workshoptider, presentation av projektuppgift samt deltagande i skriftlig rapportering i form av en gemensam kursdokumentation av det ställda temat. Lärandemålet Kunskap och förståelse examineras genom Seminarium (G U ). Övriga lärandemål examineras genom projektarbetet (G U 3 4 5).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Seminarium | U G# | 1 | Obligatorisk | H14 |  |
| 0006 | Projektarbete | GU345 | 6,5 | Obligatorisk | H14 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du

behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-06-15

## Kursplanen fastställd

av Eva Gunneriusson 2014-02-10
