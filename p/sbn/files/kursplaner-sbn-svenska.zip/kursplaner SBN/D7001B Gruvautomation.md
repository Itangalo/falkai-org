---
kurskod: "D7001B"
titel: "Gruvautomation"
hp: "7,5"
titel_en: "Mine Automation"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7001B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7001b-gruvautomation"
---

# Gruvautomation (D7001B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Underhållsteknik

## Behörighet

T0013B Berganläggningsteknik eller motsvarande kurs. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Målet med kursen är att ge kunskap om olika aspekter av automatisering i gruvor och andra undermarksanläggningar samt kunskap om den senaste utvecklingen inom området. Efter avslutad kurs ska studenten:

- veta hur man tar hänsyn till mänskligt felhandlande vid automatisering

- förstå hur driftdata från gruvutrustning kan användas i gruvprocessen

- ha kunskap om automatisering i gruvutrustning

- ha kompetens att utföra tillförlitlighetsanalys av automatiserade system

- veta hur AI-koncept kan användas i gruvautomation

- ha kunskap om navigationssystem i gruvor

## Kursinnehåll

Kursen tar upp

- Gruvautomation ovan och under jord

- Automation av borr- och borriggar

- Automation av underjordiska last- och transportsystem

- Automation i tunnelprojekt

- Automation vid dagbrottsbrytning

- Funktionssäkerhet för enheter och system

- Mänskligt felhandlande

- Datakommunikation och moderna datoriserade styrsystem

- Dataformat och IREDES

- AGV-teknik, navigering under och ovan jord, och GNSS (satellitnavigering)

- AI för gruvautomation

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen baseras på lektioner och projektuppgifter.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Skriftlig examen med betyg och godkända inlämningsuppgifter.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen D7001B motsvarar kursen ABD014

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 4,5 | Obligatorisk | H07 |  |
| 0003 | Inlämningsuppgifter | U G# | 3 | Inaktiv | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
