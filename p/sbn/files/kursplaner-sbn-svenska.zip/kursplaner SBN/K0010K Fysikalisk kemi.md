---
kurskod: "K0010K"
titel: "Fysikalisk kemi"
hp: "7,5"
titel_en: "Physical Chemistry"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Kemi"
amnesgrupp_scb: "Kemi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0010K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0010K&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0010k-fysikalisk-kemi"
---

# Fysikalisk kemi (K0010K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Grundläggande behörighet samt K0016K Kemiska principer eller motsvarande kurs.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursens mål är att studenten efter avslutad kurs skall:

1. kunna beräkna egenskaper av icke ideala gaser

2. kunna tillämpa termodynamikens huvudsatser

3. kunna använda termodynamiska tillståndsfunktioner för kemiska beräkningar

4. vara väl förtrogen med begreppen aktivitet samt partiell molär storhet

5. kunna konstruera och tolka fasdiagram

6. kunna tillämpa termodynamiken för elektrokemisk jämvikt

7. kunna analytiskt beskriva kemiska reaktioners hastighet

8. vara väl förtrogen med utrustning och nå praktisk och beräknings erfarenhet inom det laborativa momentet, ”bombkalorimetri” och ”reaktions kinetik”, och kunna redovisa resultat och skriva labbrapporter efter rekommenderade mallar

## Kursinnehåll

Kursen omfattar delarna:

Kemisk termodynamik

Ideala och icke ideala gaser, termodynamiska tillståndsfunktioner, entropin, entalpin, Gibbs fria energi, kemisk potential, aktivitet, partiella molära storheter, kolligativa egenskaper och fasdiagram.

Elektrokemisk jämvikt

Nernst ekvation, Debye-Hückel lagar för elektrolytlösningar, elektrisk konduktivitet, typer av elektroder och elektrokemiska celler, cell-reaktioner och elektromotorisk spänning, korrosion och korrosionsskydd.

Kinetik

Reaktioners ordning, reaktionsmekanism och aktiveringsenergi.

Kursen innehåller två laborationer:

Ett förbränningsexperiment på en okänd substans m h a bombkalorimeter och efterföljande beräkning av förbränningsentalpin för substansen. En bestämning av hastighetskonstanter vid olika temperaturer och beräkning av reaktionens aktiveringsenergi m h a Arrhenius ekvation.

Teorin tillämpas vid räkneövningar och laborationer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen sker i form av föreläsningar, räkneövningar med inlämningsuppgifter och laborationer. Föreläsningarna innehåller både härledningar och teoretiska avsnitt som förklaras och diskuteras med studenterna i form av exempel, beräkningar och minitävlingar. Föreläsningarna omfattar mål 1-7.

Räkneövningarna innehåller utvalda poängsatta uppgifter i varje kursmoment som får tillgodoräknas på tentamen. Räkneövningarna omfattar mål 1-8.

Det laborativa arbetet är kopplat till föreläsningarna och tränar det praktiska målet 8. Studenterna arbetar i grupp med de praktiska momenten. Varje laboration innehåller förberedande obligatoriska uppgifter som ska lämnas in före laborationen får påbörjas. Obligatoriska labbrapporter skrivs och lämnas in i grupp eller individuellt. Laborationerna är obligatoriska.

1:a lektionen är obligatorisk för alla elever. Frånvaro beviljas av kursansvarig.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Lärandemål 1-8 examineras genom en skriftlig individuell tentamen med betyg U, 3, 4, 5. Tentamen examinerar även de kunskaper som studenterna uppnått i lärandemål 8 under laborationerna. Bonuspoäng från uppgifterna på räkneövningarna och välskrivna och inlämnade i tid labbrapporter räknas med i slutbetyget.

Godkända laborationsredogörelser examinerar lärandemål 8.

Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0010K motsvarar kursen KGK023

## Övrigt

Obligatorisk närvaro vid första lektionstillfället och alla laborationer.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 6 | Obligatorisk | H07 |  |
| 0002 | Laborationer | U G# | 1,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
