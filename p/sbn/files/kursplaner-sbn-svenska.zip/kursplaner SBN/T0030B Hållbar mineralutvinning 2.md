---
kurskod: "T0030B"
titel: "Hållbar mineralutvinning 2"
hp: "15"
titel_en: "Sustainable Resource Engineering 2"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "U G#"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0030B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0030B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t00/t0030b-hallbar-mineralutvinning-2"
---

# Hållbar mineralutvinning 2 (T0030B)

## Behörighet

Grundläggande behörighet samt L0049K Hållbar mineralutvinning 1. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursen ger fördjupade kunskaper om mineral- och metallvärdekedjan, hur värdekedjans olika delar hänger ihop och relationen till det omgivande samhället och miljön.

Efter genomgången kurs ska studenten kunna:

Kunskap och förståelse

1. Förstå användningen av avancerad teknik inom naturresursteknik som kan bidra till att mineral- och metallutvinningsprocesser blir mer hållbara i framtiden.

Kompetens och färdigheter

2. Visa förmåga att söka och samla vetenskaplig information om avancerade teknologier som används inom resursteknik.

Bedömning och förhållningssätt

3. Kunna göra korrekta tekniska bedömningar baserade på vetenskapliga principer.

## Kursinnehåll

Kursen är en projektkurs som ger fördjupade kunskaper om mineralers och metallers värdekedja. Kursen består av olika delar längs värdekedjan i projektform, både självständigt arbete och grupparbete. Kursen består av både praktiska och teoretiska moment samt vikten av muntlig och skriftlig presentation.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av projektarbete i grupper och självständigt kombinerat med föreläsningar, studiebesök och workshops.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Lärandemålen bedöms genom skriftliga projektinlämningar samt muntliga projektpresentationer/diskussioner under workshops.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektarbete 1, inklusive muntlig presentation och rapport | U G# | 3,7 | Inaktiv | H25 |  |
| 0002 | Projektarbete 2, inklusive muntlig presentation och rapport | U G# | 3,8 | Inaktiv | H25 |  |
| 0003 | Projektarbete 3, inklusive muntlig presentation och rapport | U G# | 3,8 | Inaktiv | H25 |  |
| 0004 | Projektarbete 4, inklusive muntlig presentation och rapport | U G# | 3,7 | Inaktiv | H25 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
