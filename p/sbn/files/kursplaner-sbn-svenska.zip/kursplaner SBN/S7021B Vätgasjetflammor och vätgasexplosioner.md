---
kurskod: "S7021B"
titel: "Vätgasjetflammor och vätgasexplosioner"
hp: "1,5"
titel_en: "Hydrogen Jet Flames and Hydrogen Explosions"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2026-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "UG"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7021B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7021B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s70/s7021b-vatgasjetflammor-och-vatgasexplosioner"
---

# Vätgasjetflammor och vätgasexplosioner (S7021B)

## Behörighet

180 hp inom teknik/naturvetenskap. Goda kunskaper i engelska motsvarande Engelska 6/nivå 2 eller motsvarande reella kompetens erhållen genom praktiska erfarenheter. Läs mer om hur du ansöker om reell kompetens via denna länk: https://www.ltu.se/studentwebben/dina-studier/reell-kompetens.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna

1) Oantända utsläpp

- Skilja mellan expanderade och underexpanderade vätgasstrålar.

- Känna igen fenomen som Mach-skivor och chockstrukturer vid högtrycksutsläpp.

- Förklara hur vätgasplymer sprids och bildar antändbara moln beroende på förhållandena.

- Bedöma de säkerhetsmässiga konsekvenserna av olika utsläppsscenarier.

2) Antändning av vätgasblandningar

- Definiera och använda centrala antändningsrelaterade begrepp för vätgas.

- Förstå varför vätgas-luftblandningar är så lättantändliga.

- Förklara olika mekanismer som kan orsaka spontan antändning vid vätgasutsläpp

- Tillämpa denna kunskap i säkerhetsscenarier.

3) Deflagrationer och detonationer

- Beskriva strukturen och egenskaperna hos vätgas-jetflammor.

- Skilja mellan impulsdominerade och lyftkraftsdominerade regimer med hjälp av Froudetalet.

- Tillämpa empiriska korrelationer för att uppskatta flammans längd och risk-/farlighetsavstånd.

- Förklara blow-off-fenomenet och faktorer som påverkar flammans stabilitet.

- Identifiera centrala säkerhetsåtgärder och konstruktionsprinciper för att förebygga och begränsa risker vid jetbränder.

4) Jetlågor

- Skilja mellan deflagration och detonation.

- Förklara begreppet avlastade (ventilerade) detonationer/deflagrationer och tillhörande risker.

- Illustrera deflagration-till-detonation-övergången (DDT) steg för steg.

- Sammanfatta de viktigaste säkerhetsmässiga konsekvenserna av deflagrationer, detonationer och DDT i vätgassystem.

## Kursinnehåll

Kursen behandlar följande ämnen:

1) Oantända utsläpp

a) Över- och underexpanderade jetstrålar

2) Antändning av vätgasblandningar

a) Antändning med pilotlåga och spontan antändning

3) Deflagrationer och detonationer

a) Ventilerade och oventilerade deflagrationer

b) Ventilerade och oventilerade detonationer

c) DDT (övergång från deflagration till detonation)

4) Jetlågor

a) Froude-baserade korrelationer

b) Blow-off-fenomenet (lågslockningsfenomenet)

c) Jetlågegenskaper

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen ges online och är självstudiebaserad. Undervisningen och lärandet stöds av strukturerat kursmaterial online, inklusive förinspelade föreläsningsvideor som studenterna ska titta på och studera självständigt. Studenterna genomför beräkningsuppgifter, obligatoriska quiz och en slutrapport för att visa sin förståelse av kursinnehållet. Varje avsnitt innehåller en diskussionsdel där studenterna reflekterar över vad de har lärt sig och deltar i dialog med andra deltagare. Studenterna ska delta i tre obligatoriska online-seminarier.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:

Alla lärandemålen (1,5 hp) examineras genom att studenten närvarat vid tre obligatoriska onlinemöten samt att studenten vid dessa möten uppvisat en aktivitet och kunskap som godkänns av läraren enligt en betygsskala U G#.

För att bli godkänd på kursen behöver studenten dessutom skriva en uppsats som granskats av andra studenter och därefter reviderats, för att slutligen godkännas av läraren. För att bli godkänd på kursen behöver studenten dessutom bli godkänd på fyra obligatoriska quizar samt en beräkningsuppgift.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Uppsats | UG | 0 | Obligatorisk | V27 |  |
| 0006 | Beräkningsuppgifter | UG | 0 | Obligatorisk | V27 |  |
| 0007 | Onlinemöten | UG | 1,5 | Obligatorisk | V27 |  |
| 0008 | Quizzar | UG | 0 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar

information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13
