---
kurskod: "P0001B"
titel: "Bygg- och anläggningsproduktion"
hp: "7,5"
titel_en: "Construction Management"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2023-06-02"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0001B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p00/p0001b-bygg--och-anlaggningsproduktion"
---

# Bygg- och anläggningsproduktion (P0001B)

## Ingår i huvudområde

Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

Grundläggande behörighet samt V0018B Samhällsbyggande eller P0009B Bygg- och anläggningsprojektering eller motsvarande kurs

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Målet är att kunna beskriva och öva färdigheter inom byggprocessen med fokus på byggproduktion. Specifikt ska kursen ge förståelse för byggprocessens olika skeden avseende produktframställning och byggstyrning. Efter avslutad kurs skall studenten kunna följande:

- Med hjälp av teoretiska modeller redogöra för byggprocessens produktframställning och byggstyrning

- Beskriva hur entreprenören kan styra ett byggprojekt med stöd av olika ledningsverktyg

- Beskriva innehållet i byggprojektets handlingar

- Ha kunskap och förståelse för innebörden av allmänna föreskrifter (AB, ABT och ABK), entreprenadjuridik, PBL och LOU

- Beskriva och tillämpa grundläggande planering och kalkylering av anbud

- Ha kunskap och förståelse för byggprocessen som helhet för bästa utbyte av efterföljande praktikperiod

- Tillämpa metoder för planering och genomförande av grupparbete samt på et strukturerat sätt uttrycka sig både i skrift och muntligt.

## Kursinnehåll

Kursen behandlar produktframtagande och byggstyrning av byggobjekt ur ett entreprenörsperspektiv. Innehållet fokuserar på att ge kunskaper och färdigheter inom främst byggproduktion där entreprenören är den främsta aktören. Teoretiska föreläsningar blandas med praktiska uppgifter samt externa föreläsare för att ge studenten en kunskap och förståelse för byggbranschen.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen kombinerar kunskapsmoment (föreläsningar och dugga) med gruppmoment med inlämningar under delar av kursen. Kursen innehåller en större projektuppgift för att öva färdigheter inom grupparbete, branschrelevant datainsamling och rapportskrivande. Gruppuppgiften tränar studenten i både skriftlig och muntlig presentation. Som stöd i projektarbetet planeras handledningar parallellt med eget arbete. Inlämningar består av anbudskalkyl samt skriftligt material. Under kursen kommer också studenterna individuellt få reflektera över sitt eget lärande. I denna reflektionsuppgift förväntas en ordentlig reflektion (över ditt lärande) kopplat till externa föreläsningar med experter inom vartdera området. Reflektionen tränar studenterna i kritiskt tänkande och förbereder dem för en givande praktikperiod.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursen examineras genom 2 examinationsformer. Betygsskalan är U G på enskilda moment. På hela kursen ges betyget U, 3, 4, 5. Slutbetyget på kursen styrs av de kurspoäng (0-100p) som studenten samlat ihop under kursens gång via fyra delmoment. Systemet beskrivs i detalj i kursbeskrivningen som delas ut vid kursens start samt beskrivs i studiehandledningen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen P0001B motsvarar kursen ABP101

## Övrigt

Kursen kan på grund av överlappning ej ingå i examen tillsammans med P0004B eller annan kurs med liknande innehåll.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0006 | Inlämningsuppgifter | UG | 5,5 | Obligatorisk | V27 |  |
| 0007 | Skriftlig dugga | UG | 2 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du

behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
