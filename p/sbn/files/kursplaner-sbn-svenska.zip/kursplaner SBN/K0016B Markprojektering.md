---
kurskod: "K0016B"
titel: "Markprojektering"
hp: "7,5"
titel_en: "Landscape architecture"
giltig: "Vår 2026 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Konstruktionsteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0016B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0016b-markprojektering"
---

# Markprojektering (K0016B)

## Behörighet

Grundläggande behörighet + Matematik 2a eller 2b eller 2c. Eller: Matematik nivå 2a eller nivå 2b eller nivå 2c.

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kursen skall ge kunskaper om planeringsprocessen och den geometriska utformningen av vägar, järnvägar och VA, el, fiber och övrig marklagd infrastruktur. Begreppen byggs upp av det regelverk som Trafikverket, kommuner m.fl. använder.

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

Tolka och beskriva planeringsprocessen för väg- och järnvägsbyggande med ingående dokument.

Tolka och beskriva planeringsprocessen för byggande av ledningsgator med ingående dokument.

Färdighet och förmåga

Tillämpa geometrisk utformning i plan, profil och sektion.

Beräkna linjeelement för väg- och järnvägslinjer.

## Kursinnehåll

Geometrisk utformning i plan, profil och sektion.

Planeringsprocessen för markprojektering.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, lektioner och projekteringsuppgifter.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras genom konstruktionsuppgifter och dugga.

Betygssättning sker enligt betygsskala G U. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Konstruktionsuppgift | U G# | 5 | Obligatorisk | H19 |  |
| 0002 | Dugga | U G# | 2,5 | Obligatorisk | H19 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-02-14
