---
kurskod: "L0002B"
titel: "Introduktion till programmering och C#"
hp: "7,5"
titel_en: "Basic Programming"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2023-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Geografisk informationsteknologi"
amnesgrupp_scb: "Geografisk informationsteknik och lantmäteri"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0002B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0002b-introduktion-till-programmering-och-c"
---

# Introduktion till programmering och C# (L0002B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna

- bygga egna algoritmer för lösning av programmeringsproblem,

- beskriva dem i något pseudospråk eller grafisk uttryckssätt,

- tillämpa programmeringens grunder inom något representativt programspråk,

- konstruera enklare, väl dokumenterade applikationer.

- känna till något sätt att integrera kartor och dess hantering i en applikation.

## Kursinnehåll

Kursen behandlar följande:

Introduktion till programmering

Hårdvara/Mjukvara

Algoritmer

Programstruktur och vårt första program

Variabler och datatyper

In-/utmatning

Aritmetiska operationer

Tilldelningsoperationer och logiska operationer

Kontrollflöden

Villkorssatser

Repetitionskontroll

Klasser/Metoder

Referens- och värdeparametrar

Variablers räckvidd och varaktighet

Implementation och debugging

Arrayer

Strängar och tecken

Elementärt GUI

Karthantering med MapPoint, Endast teoretiskt.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Allt kursmaterial finns under LTU’s Citrixportal och där hittas mer detaljerade beskrivningar över kursens innehåll och dess genomförande. Det finns inga inspelade föreläsningar och inte heller några obligatoriska sammankomster. Boken utgör inlärningsmaterialet och bör följas enligt dess instruktioner.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen mål examineras med inlämningsuppgifter som görs individuellt eller i grupp om två personer och som examineras under kursens gång. Betygssättning av inlämningsuppgifter sker enligt betygsskala U/G. Samtliga inlämningsuppgifter ska vara avklarade för slutbetyg.

Inlämningsuppgifterna finns under LTU’s Citrixportal.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen L0002B motsvarar kurser ABL005, D0014E, D0009E, D0017D, D0028E, D0017E

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G# | 7,5 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
