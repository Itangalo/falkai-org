---
kurskod: "A7007B"
titel: "Projekt i Avfallsteknik, fördjupning"
hp: "7,5"
titel_en: "Senior design projekt in Waste Science, advanced"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2022-02-10"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "U G#"
amne: "Miljöteknik"
amnesgrupp_scb: "Miljövård och miljöskydd"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=A7007B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=A7007B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/a70/a7007b-projekt-i-avfallsteknik-fordjupning"
---

# Projekt i Avfallsteknik, fördjupning (A7007B)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Avgörs av examinator.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter kursen ska studenten

- ha fördjupade kunskaper inom avfallsteknik´

- kunna göra ett relevant urval av litteratur, genomföra litteraturstudie och dra slutsatser

- självständigt kunna planera, genomföra och presentera ett projektarbete

## Kursinnehåll

Fördjupning inom Avfallsteknik genom litteraturstudie, syntes och redovisning.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Projektplanering. Självständigt arbete. Muntlig och skriftlig redovisning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Muntlig och skriftlig redovisning.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Godkänd muntlig och skriftlig redovisning | U G# | 7,5 | Obligatorisk | H22 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-10

## Kursplanen fastställd

av Institutionen för samhällsbyggnad och naturresurser 2011-02-08
