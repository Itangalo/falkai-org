---
kurskod: "P7006B"
titel: "Datorstödd byggproduktion"
hp: "7,5"
titel_en: "Virtual Construction"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7006B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7006B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p70/p7006b-datorstodd-byggproduktion"
---

# Datorstödd byggproduktion (P7006B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Grundläggande förståelse för byggprocessen och produktionens roll i byggprocessen. Grundläggande kunskap om 3D-modellering samt aktivitetsbaserad och rumsbaserade planeringsmetoder, samt kalkylering motsvarande kursen P0001B Bygg- och anläggningsproduktion. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter kursen skall studenten enskilt och tillsammans med andra kunna
- förklara och kritiskt bearbeta den roll som modeller och andra digitala informationskällor har för att ta datadrivna beslut i produktionsplaneringen
- tillämpa modellbaserade mängdavtagningar ur byggnadsinformationsmodeller för att skapa kalkyler över byggprojekt
- tillämpa modellbaserad tidsplanering för ett byggprojekt så att produktionen fortlöper med gynnsam takt och har möjlighet att tackla störningar
- tillämpa automation för delar av planeringsprocessen med hjälp av programmering och generativ artificiell intelligens
- förklara betydelsen av standarder och klassificering för virtuellt byggande

## Kursinnehåll

Kursen behandlar de förutsättningar som gäller för BIM och det vidare begreppet virtuellt byggande, med byggentreprenörens perspektiv. Studenten får lära sig hur BIM och andra digitala informationskällor påverkar och underlättar planerings- och beredningsarbetet och vilka krav det ställer på den information som levereras mellan olika roller och processer för att kunna ta datadrivna beslut. Studenten får under kursen använda för branschen vanliga datorverktyg.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Första delen av kursen består av föreläsningar och praktiska inlämningsuppgifter som genomförs i datormiljö, där studenten får tillämpa stoffet från föreläsningarna. I den andra delen av kursen får studenterna i mindre grupper djupare tillämpa kunskaperna från den första delen i en projektuppgift med mer öppen problemställning, men även ta del av gästföreläsningar, som fördjupar och breddar studentens bild av virtuellt byggande, samt delta på en workshop. Kursen avslutas med muntlig och skriftlig redovisning av gruppernas resultat.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examinationen består av enskilda uppgifter och ett projektarbete i grupp. Betygsskalan är U G på enskilda moment och projektarbetet. På hela kursen ges betyget U 3 4 5. Alla enskilda uppgifter samt projektuppgiften ska genomföras för att få minst betyg 3. Kursen använder sig av ett poängsystem som beskrivs i detalj i kursbeskrivningen som delas ut vid kursens start. Obligatorisk närvaro gäller för workshoppen samt slutpresentationen. Alla uppgifter ska lämnas in på korrekt engelska.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G# | 3 | Inaktiv | H08 |  |
| 0002 | Projektuppgift | U G# | 4,5 | Inaktiv | H08 |  |

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13

## Kursplanen fastställd

av Institutionen för Samhällsbyggnad 2008-01-22
