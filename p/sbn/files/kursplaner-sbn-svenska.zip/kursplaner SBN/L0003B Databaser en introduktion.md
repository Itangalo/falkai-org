---
kurskod: "L0003B"
titel: "Databaser, en introduktion"
hp: "7,5"
titel_en: "Basic Course in Database Systems"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "U G#"
amne: "Geografisk informationsteknologi"
amnesgrupp_scb: "Geografisk informationsteknik och lantmäteri"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0003B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0003b-databaser-en-introduktion"
---

# Databaser, en introduktion (L0003B)

## Behörighet

Grundläggande behörighet samt Grundläggande kunskaper i programmering, t ex L0002B eller motsvarande kunskaper förvärvade genom annan kurs eller genom praktiskt arbete.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna

- redogöra för och förklara grundläggande begrepp inom databasteori och särskilt relationsdatabasteori.

- konstruera databaser (datamodellera) utifrån en beskriven verklighet.

- grunderna i frågespråket SQL och kunna konstruera enkla applikationer som hanterar databaser.

- dokumentera eget arbete enligt vedertagen metodologi.

## Kursinnehåll

- Databashanteringssystem

- Relationsdatabaser

- SQL -språket, datadefinition och datamanipulation

- Databasdesign, objekt- och datamodellering

- Embedded SQL i Visual Basic

- Transaktionshantering och fleranvändarsystem

- MapPoint, endast teoretiskt

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Allt kursmaterial finns under LTU’s Citrixportal och där hittas mer detaljerade beskrivningar över kursens innehåll och dess genomförande. Det finns inga inspelade föreläsningar och inte heller några obligatoriska sammankomster. Föreläsningsmaterial finns som powerpoint-shower.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen mål examineras med inlämningsuppgifter som görs individuellt eller i grupp om två personer och som examineras under kursens gång. Betygssättning av inlämningsuppgifter sker enligt betygsskala U/G. Samtliga inlämningsuppgifter ska vara avklarade för slutbetyg.

Inlämningsuppgifterna finns under LTU’s Citrixportal.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen L0003B motsvarar kursen ABL006

## Övrigt

Kurs som ska följas via Internet kräver att studenten har tillgång till någon form av bredbandsuppkoppling.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G# | 7,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Institutionen för samhällsbyggnad 2007-01-31
