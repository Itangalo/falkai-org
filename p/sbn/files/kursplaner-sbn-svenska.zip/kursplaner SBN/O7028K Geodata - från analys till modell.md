---
kurskod: "O7028K"
titel: "Geodata - från analys till modell"
hp: "7,5"
titel_en: "Geodata - from analysis to model"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Malmgeologi"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O7028K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O7028K&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o70/o7028k-geodata---fran-analys-till-modell"
---

# Geodata - från analys till modell (O7028K)

## Behörighet

Minst 90 hp avslutade kurser med åtminstone 60 hp inom området naturresursteknik, geologi eller geovetenskap. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter avslutad kurs ska studenten kunna:

1. visa förståelse för olika typer av geodata och kritiskt analysera deras egenskaper.

2. utvärdera olika datainsamlingsmetoder och tillämpa kvalitetsbedömningstekniker för att säkerställa datatillförlitlighet.

3. använda geodatabaser online för analys och tolkning av geovetenskaplig data.

4. visa förmåga att kritiskt analysera och välja lämpliga datatransformationsmetoder och avancerade tekniker, såsom maskininlärning och geostatistiska metoder, för att lösa geovetenskapliga problem.

5. kritiskt bedöma geovetenskapliga modeller från mikro- till regional skala, utvärdera deras underliggande antaganden och tillämpa modelleringstekniker för att extrahera information från komplexa geovetenskapliga data.

6. visa en grundläggande förståelse för tillämpningen av artificiell intelligens i geovetenskap.

7. självständigt utföra databearbetning, validering och modellering baserat på verkliga data.

## Kursinnehåll

Kursen behandlar strategier för att inhämta, lagra och bearbeta geovetenskaplig data, med syfte att skapa en djupare förståelse för dataflödet i gruv- och prospekteringsprojekt och specifika utmaningar som uppstår vid hantering av stora och komplexa datamängder. Ämnen som tas upp inkluderar:

Introduktion till geovetenskap Dataanalys • Datainsamling och kvalitetsbedömning • Datalagring, hantering och validering • Databehandlingstekniker • Modellering • Artificiell intelligens

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen innehåller föreläsningar, praktiska övningar och ett projektarbete. Föreläsningar och praktiska övningar organiseras i en omväxlande ordning där teoretiska principer behandlas i föreläsningarna och de inlärda färdigheterna sedan tillämpas i de relaterade praktiska övningarna.

De praktiska övningarna utförs för att förbättra samarbetet och förbättra problemlösningsförmågan. Projektarbetet ägnas åt att beskriva, analysera, tolka och presentera ett komplext ämne inom området geodataanalys och modellering.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen bedöms genom praktiska övningar, projektarbete och tentamen. Praktiska övningar bedöms endast som godkända – ej godkända. Projektrapporten och examinationen ges med differentierade betyg.

Kursens avsedda lärandemål bedöms genom tre olika bedömningar:

1. Alla lärandemål utom lärandemål 7 bedöms genom tentamen (Betygsskala: 5 4 3 U)

2. Lärandemål 2, 3, 4 och 5 bedöms genom praktiska övningar (Betygsskala: G#/U)

3. Lärandemål 7 bedöms genom projektarbetet (Betygsskala: 5 4 3 U)

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 3 | Obligatorisk | V25 |  |
| 0002 | Projektarbete | GU345 | 3,5 | Obligatorisk | V25 |  |
| 0004 | Övningar | UG | 1 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14
