---
kurskod: "G0015B"
titel: "Väg- och järnvägsbyggnad"
hp: "7,5"
titel_en: "Road and railway engineering"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0015B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g00/g0015b-vag--och-jarnvagsbyggnad"
---

# Väg- och järnvägsbyggnad (G0015B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Målet är att du skall få grundläggande kunskaper om uppbyggnad av vägar, gator och järnvägar samt hur de fungerar under sin tekniska livslängd. Begreppen byggs upp kring de svenska reglerna för väg och järnvägsbyggnad.

Efter kursen ska studenten kunna:

Beskriva

Väg- och järnvägsinfrastrukturens roll inom samhällsplaneringen

Hur samhället styr och planerar investering och drift- och underhåll av väg- och järnvägsinfrastruktur

Geotekniska undersökningsmetoder för väg- och järnvägsbyggnad

Entreprenadformer

Redogöra för

Laborativa metoder för obundna och bundna material

Nedbrytningsmekanismer för järnväg

Nedbrytningsmekanismer för väg

Inventeringsmetoder för tillståndsbedömning av vägar och järnvägar

Analytiska och empiriska dimensioneringsmetoder för väg

Drift- och underhållsplanering

Tjäle, tjällyftning och tjällossning

Förklara

Strukturell uppbyggnad av flexibel och styv överbyggnad

Strukturell uppbyggnad av ballastburna spår

Tillämpa

Tjäldjupsberäkningar

Utvärdera resultat från ballastprovning

På en grundläggande nivå dimensionera vägar

Bestämmelser för arbete på väg

Dimensionera ballastburen järnvägsöverbyggnad

Kursen har även som mål att öva de generella färdigheterna skriftlig och muntlig presentation.

## Kursinnehåll

Kursen behandlar projektering, byggande samt grundläggande drift- och underhållsaspekter av väg- och järnvägsöverbyggnader. Dimensionering och krav utgår från svensk praxis och europeiska standarder. Kursen behandlar översiktligt geotekniska krav, linjeföring, nödvändiga kringanläggningar och byggprocessen. Fokus i kursen ligger på överbyggnadsdimensionering och materialkrav.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar. I kursen ingår tre stycken inlämningsuppgifter som i tur och ordning behandlar: Tjäle, Siktkurvor samt Materialprovning och vägdimensionering. Inlämningsuppgifterna löses i grupper om normalt tre studenter. Uppgifterna rättas efter inlämning av lärare och studentgrupperna får feedback på sitt arbete. Kursen innehåller även en obligatorisk datorlaboration (workshop) inom ämnet järnvägsbyggnad. I kursen ingår en större seminarieuppgift (inlämningsuppgift) där studentgrupperna väljer ett ämne inom kursen att fördjupa sig i, skriver en uppsats och presenterar den muntligt i slutet av kursen. I seminarieuppgiften övas de generella färdigheterna skriftlig och muntlig presentation. Studentgrupperna opponerar på varandras uppsatser och presentationer. Alla seminarieuppgifter rättas av lärare och studentgrupperna erhåller feedback. Kursen innehåller två duggor (deltentamen) som genomförs individuellt. Den ena duggan behandlar vägbyggnad och den andra duggan järnvägsbyggnad.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Alla lärandemål i kursen som har med vägbyggnad att göra examineras i duggan som behandlar vägbyggnad. Alla lärandemål i kursen som har med järnvägsbyggnad att göra examineras i duggan som behandlar järnvägsbyggnad. Kursens inlämningsuppgifter och datorlaboration examinerar kursens tillämpningsmål på en djupare nivå. Genom kursens seminarieuppgift övas de generella färdigheterna skriftlig och muntlig presentation. Läraren ger feedback på presentationstekniken vid de muntliga presentationerna. Både modulen Duggor och Inlämningsuppgifter/datorlaboration betygssätts enligt betygsskalan GU345. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen. Slutbetyget ges som ett vägt medelvärde av prestationerna på Duggor och Inlämningsuppgifter/datorlaboration utifrån betygsskalan GU345.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Duggor | GU345 | 3 | Obligatorisk | V16 |  |
| 0002 | Inlämningsuppgifter och datorlaborationer | GU345 | 4,5 | Obligatorisk | V16 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2015-05-19
