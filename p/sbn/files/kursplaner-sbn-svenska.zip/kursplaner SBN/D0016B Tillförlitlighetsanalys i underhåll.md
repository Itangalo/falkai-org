---
kurskod: "D0016B"
titel: "Tillförlitlighetsanalys i underhåll"
hp: "7,5"
titel_en: "Reliability Engineering and Analysis in Maintenance"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2020-02-14"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0016B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d00/d0016b-tillforlitlighetsanalys-i-underhall"
---

# Tillförlitlighetsanalys i underhåll (D0016B)

## Behörighet

Grundläggande behörighet samt S0001M Matematisk statistik eller motsvarande kurs

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursen ska ge grundläggande kunskaper om analys av funktionssäkerhet för underhållssyften. Efter kursen ska deltagaren kunna:

- Förstå grundläggande begrepp och deras relationer inom funktionssäkerhet;
- Diskutera och tillämpa olika typer av funktionssäkerhetsmodeller för att analysera feldata;
- Förstå och diskutera olika systemkonfigurationer och beräkna deras funktionssäkerhet;
- Förstå innebörden av Weibull-plot och dess tillämpning;
- Diskutera olika standarder för funktionssäkerhet;
- Tillämpa datorverktyg för funktionssäkerhetsanalys.
- Analysera och värdera olika fördelar och utmaningar av datorverktyg för funktionssäkerhetsanalys.

## Kursinnehåll

- grundläggande begrepp och deras relationer inom funktionssäkerhet, inklusive överlevnadsfunktion (MTTF, MTBF, MTTR, MTTF, etc), felsannolikhetsfunktionen, täthetsfunktion, felfrekvens/hazardfrekvens, kumulativa hasardfunktionen, återstående livslängd;
- olika typer av funktionsäkerhetsmodeller, exponentiell fördelning, Weibull distribution, lognormal distribution, etc
- olika systemkonfigurationer, inklusive seriesystem, parallellsystem, k-out-of-n-system, standbysystem;
- Weibullplot
- funktionssäkerhetsstandarder;
- mjukvaruverktyg för funktionssäkerhetsanalys.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen ges på campus med möjlighet att delta på distans. Obligatorisk närvaro vid presentation av inlämningsuppgifter och vid studiebesök.

Kursen innehåller teoretiska moment och seminarier som behandlar teori och metoder. Kursen inkluderar också ett projektarbete som genomförs i samarbete med industrin.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Skriftlig tentamen, godkända inlämningsuppgifter och godkänt projektarbete.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 3,5 | Obligatorisk | H15 |  |
| 0004 | Projektarbete | U G# | 2 | Obligatorisk | H15 |  |
| 0005 | Inlämningsuppgift | U G# | 2 | Obligatorisk | H15 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-02-14

## Kursplanen fastställd

av Eva Gunneriusson 2015-02-09
