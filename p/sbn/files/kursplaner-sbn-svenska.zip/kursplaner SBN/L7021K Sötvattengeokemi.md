---
kurskod: "L7021K"
titel: "Sötvattengeokemi"
hp: "7,5"
titel_en: "Freshwater Geochemistry"
giltig: "Vår 2026 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7021K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7021K&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l70/l7021k-sotvattengeokemi"
---

# Sötvattengeokemi (L7021K)

## Ingår i huvudområde

Kemiteknik, Väg- och vattenbyggnad, Geovetenskap

## Behörighet

90hp inom geovetenskap eller motsvarande. Kursen L0047K Miljögeokemi eller motsvarande ska ingå. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna

Kunskap och föreståelse

1. Förstå allmänna geokemiska principer som reglerar förekomsten och den geokemiska karaktären av grundämnen i sötvatten och jord/sediment.

Färdighet och förmåga

2. Tolka och förklara de biogeokemiska processer som påverkar halterna av metaller och näringsämnen i sötvatten och jord/sediment.

3. Identifiera och förklara geokemiska principer med hjälp av geokemiskt data.

4. Förstå och sammanfatta vetenskaplig forskning i skriftlig och muntlig form.

Väderingsförmåga och förhållningssätt

5. Utföra grundläggande kvalitativa och kvantitativa tolkningar av fältdata med hjälp av relevant programvara samt konstruera boxmodeller som bygger på dessa tolkningar

## Kursinnehåll

Denna kurs är en fortsättningskurs till Miljögeokemi (L0047K) som förklarar grundläggande geokemiska begrepp.

Sötvattengeokemi omfattar elementens kretslopp och mobilitet från sediment/jord mot grundvatten, längs bäck- och flodvatten ut i öppet hav. Kursen behandlar vikten av basparametrar så som pH, redox och alkalinitet samt deras inverkan på fördelningen av huvud- och spårämnen i naturliga vatten. Kursen diskuterar även användningen av stabila isotopsystem som ett viktigt och tillförlitligt verktyg för att belysa geokemiska processer och transportvägar. Geokemiskt data och programvara (tex ioGASTM) för dataanalys kommer att användas för att fördjupa förståelsen för geokemiska processer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Alla kursmaterial finns tillgängliga i dess Canvasrum. Canvasrummet består av olika moduler som strukturerar kursen i förkunskaper, föreläsningar och övningar samt uppgifter. Kursen ges i form av föreläsningar och övningar. Föreläsningarna introducerar studenterna till grundläggande geo-kemisk kunskap, som fördjupas under en serie relevanta övningar. Övningarna ger träning i att fördjupa kunskapen om de geokemiska principerna. Uppgifterna ger möjlighet att tolka och förklara geokemiska fältdata, med målet att ge en djupare förståelse för de teoretiska delarna av kursen. Uppgifterna kan vara av individuell eller gruppkaraktär, vilket hjälper studenterna att utveckla sin självständighet men också lär dem flexibilitet vid samarbete.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Måluppfyllelsen kontrolleras genom

1. Skriftlig individuell tentamen, betygsatt (G U 3 4 5) som examinera ILO 1, 2 och 5. Studenter måste uppnå minimipoäng på 60% att klara tentamen.

2. Litteraturuppgift medreport och muntligt presentation (G U) som examinera ILO 4.

3. Inlämningsuppgift baserad på geokemiska data och deras visualisering (G U) som examinera ILO 3 och 4.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0011 | Skriftlig tentamen | GU345 | 4,5 | Obligatorisk | H07 |  |
| 0012 | Litteraturövning | U G# | 1,5 | Obligatorisk | H07 |  |
| 0014 | Inlämningsuppgift | U G# | 1,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
