---
kurskod: "M7006K"
titel: "Geometallurgi"
hp: "7,5"
titel_en: "Geometallurgy"
giltig: "Höst 2011 Lp 2 - Tills vidare"
beslutsdatum: "2011-10-05"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "U G#"
amne: "Processmetallurgi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser  Prov Provnr       Typ                                                              Hp           Betyg  0001         Laboration och praktisk övning                                   5            U G#  0002         Seminarier                                                       2,5          U G#"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7006K&lasPeriod=175&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/m70/m7006k-geometallurgi"
---

# Geometallurgi (M7006K)

## Behörighet

Kandidatexamen eller motsvarande kunskaper från praktisk erfarenhet (min 5 år arbetslivserfarenhet) inom processteknik eller geologi/mineralogi.

## Examinator

Jan Rosenkranz

## Mål/Förväntat studieresultat

Kursen syftar till att ge en introduktion i de tre ämnesområdena geologi, processmineralogi och mineralteknik med ett geometallurgiskt perspektiv som den röda tråden genom kursen. Kursen skall främst fokusera på LKAB:s malmtyper och processer, men även ta upp andra järnmalmstyper.

Efter fullgjord kurs skall studenten kunna:

- Identifiera och beskriva olika järnmalmtyper och deras bildningsprocesser

- Analysera mineralegenskaper hos järnmalmer med avseende på effektiv utvinning,

- Beskriva och förklara mineraltekniska processer som används inom järnmalmanrikning,

- Analysera orsaker till processval utifrån råvarans egenskaper,

- Beskriva förutsättningarna för att bygga en geometallurgisk modell och förklara dess komponenter.

## Kursinnehåll

Geologi: Mineral och bergarter: ursprung, bildning och metamorfos, malmgeologi för LKAB:s malmer och andra järnmalmstyper; Processmineralogi: karaktärisering av malmmineral and metallurgiska produkter (sammansättning, mineraltexturer, friläggning) baserade på optisk mikroskopi, elektronmikroskopi i kombination med kvantitativ analys (Quemscan), XRD;

Mineralteknik: grundprinciper för LKAB:s enhetsoperationer; utrustningsval, länk till processmineralogi, mineraltekniskt testarbete;

Metallurgi: grundprinciper för järnframställning, produktegenskaper, kundkrav och kvalitet; Geometallurgisk modellering: geostatistisk, processmodellering inom mineralteknik och metallurgi, partikelbaserad materialbalansering.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, seminarier, praktiska övningar och studiebesök (LKAB:s laborationer). Deltagande är obligatoriskt i samtliga moment utom i föreläsningarna.

Föreläsningarna skall ge möjlighet för studenterna att kunna beskriva och förklara teorin och sammanband mellan mineralogi hos olika malmer och anrikningsprocesser.

Praktiska övningar inom geologi, processmineralogi och mineralteknik utförs gruppvis. Studiebesök skall ge möjlighet för studenterna att kunna redogöra för avancerade mineralogiska undersökningar och tekniska testmetoder.

Seminarier ägnas åt att i grupp beskriva, analysera, tolka och presentera ett komplext tema inom geometallurgiskt området.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Övningar och seminarier är obligatoriska

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser

Prov Provnr       Typ                                                              Hp           Betyg

0001         Laboration och praktisk övning                                   5            U G#

0002         Seminarier                                                       2,5          U G#

## Litteratur

*Litteratur. Gäller från Vår 2011 Lp 3* Kompendiematerial från avdelningen för industiell miljö- och processteknik

## Revidering fastställd

av Eva Gunneriusson 2011-10-05

## Kursplanen fastställd

av Eva Gunneriusson 2011-04-19
