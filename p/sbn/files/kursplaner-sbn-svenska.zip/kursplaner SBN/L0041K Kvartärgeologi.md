---
kurskod: "L0041K"
titel: "Kvartärgeologi"
hp: "7,5"
titel_en: "Quaternary Geology"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-01-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0041K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0041K&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0041k-kvartargeologi"
---

# Kvartärgeologi (L0041K)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet samt K0016K Kemiska principer, O0035K Geologi, grundkurs eller motsvarande kurser.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten:

Kunskap och förståelse

- översiktligt kunna beskriva den geologiska utvecklingen under Kvartärperioden

- kunna beskriva och förklara glaciärers tillväxt, massbalans och rörelse

- kunna beskriva de viktigaste glaciala miljöerna och förklara vilka processer som styr avlagring av sediment och bildning av landformer i dessa miljöer

- utgående från vertikalprofiler genom kvartära avlagringar kunna beskriva den kvartärgeologiska utvecklingen i ett område

Färdighet och förmåga

Efter godkänd kurs ska studenten:

- kunna beskriva den kvartärgeologiska utvecklingen i norra Sverige genom att tillämpa enklare flygbildstolkning och tolka en jordartskarta

## Kursinnehåll

Klimatvariationer under Kvartärperioden. Glaciärer och glaciärisens egenskaper. Glacial erosion, transport och deposition. Glaciala landformer. Sediment och landformer bildade i strömmande vatten, hav och sjöar. Kvartär stratigrafi. Landhöjning. Kvartära avlagringar och landformer i Sverige. Kol-14-datering. Tolkning av flygbilder och jordartskartor.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, övningsuppgifter och en projektuppgift. Föreläsningarna ägnas åt genomgång av grundläggande teori som tillämpas på övningsuppgifter som utförs under lektionstid. Kursens teorimoment tillämpas även i en projektuppgift som utförs i grupp. Övningsuppgifterna och projektuppgiften ska medföra en ökad djupinlärning av kursens huvudmoment genom att studenterna aktivt deltar i kunskapsinhämtningen. Projektuppgiften ska även ge färdighet i grupparbete och vetenskaplig rapportskrivning. I kursen ingår även en exkursion i Luleåområdet.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Förmågan att beskriva och redogöra för grundläggande teori samt innehållet i övningsuppgifter kontrolleras vid en skriftlig tentamen (betyg 3, 4, 5). Förmågan att tolka flygbilder och jordartskartor, att beskriva den kvartärgeologiska utvecklingen i norra Sverige, samt förmågan att skriva en kortare vetenskaplig rapport kontrolleras i en projektuppgift med inlämning av skriftlig rapport (betyg U, G). Deltagande i obligatorisk exkursion (U, G). Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen L0041K motsvarar kursen KGL004

## Övrigt

Kursen ges på grundnivå och ingår i kandidat- och civilingenjörsprogrammet Naturresursteknik. Studiehandledning återfinns i Canvas i aktuellt kursrum.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Skriftlig tentamen | GU345 | 3,7 | Obligatorisk | H08 |  |
| 0004 | Projektuppgift | UG | 3 | Obligatorisk | V27 |  |
| 0005 | Exkursion | UG | 0,8 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-01-11

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2008-01-22 att gälla från H08.
