---
kurskod: "O0040K"
titel: "Praktik inom naturresursteknik"
hp: "15"
titel_en: "Internship in natural resources engineering"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "UG"
amne: "Naturresursteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0040K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0040K&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o00/o0040k-praktik-inom-naturresursteknik"
---

# Praktik inom naturresursteknik (O0040K)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet samt Minst 60 hp inom geovetenskap

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

-skriva en praktikansökan med CV och ansöka om praktikplats med koppling till pågående utbildning (Lärandemål 1).

-självständigt planera och genomföra projekt under handledning (Lärandemål 2).

-tillämpa teoretiska kunskaper och färdigheter praktiskt (Lärandemål 3).

-analysera och reflektera över ingenjörsmässiga problem och över sin kommande yrkesroll (Lärandemål 4).

## Kursinnehåll

Kursen behandlar ett ämnesområde som har anknytning till vald inriktning inom utbildningsprogrammet genom praktikarbete. Den som gör praktiken i annat ämne anhåller om detta hos institutionen.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av att studenten under praktiken skall, enskilt eller tillsammans med en annan student, behandla en eller flera givna uppgifter. Praktikarbetet skall ha karaktären av enklare forsknings- eller utredningsarbete. Studenten arbetar självständigt under handledning. Slutligen redovisas erfarenheterna skriftligt och muntligt.

Tidsbegränsning av praktiken: Student som påbörjat praktikkurs och inte slutfört inom 15 månader kan inte kräva att få fullfölja kursen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras genom godkännande av praktikplats, slutförande av praktikarbete, skriftlig och muntlig redovisning.

Lärandemål 1- bedöms genom godkännande av praktikplats.

Lärandemål 2-4: Bedöms genom skriftlig rapport samt muntligt vid ett seminarium där samtliga studenter skall närvara för att lära av andras erfarenheter. Språket kan vara svenska eller engelska.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0004 | Genomförd praktik | UG | 14 | Obligatorisk | V27 |  |
| 0005 | Muntlig och skriftlig rapport | UG | 1 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2012-03-14
