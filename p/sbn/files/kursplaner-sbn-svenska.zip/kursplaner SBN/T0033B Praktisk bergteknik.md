---
kurskod: "T0033B"
titel: "Praktisk bergteknik"
hp: "7,5"
titel_en: "Practical Rock Engineering"
giltig: "Höst 2025 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2025-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0033B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0033B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t00/t0033b-praktisk-bergteknik"
---

# Praktisk bergteknik (T0033B)

## Behörighet

Grundläggande behörighet samt T0013B Berganläggningsteknik eller motsvarande.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

1. Utvärdera olika bergbrytningstekniker och metoder inom anläggnings- och gruvbranschen,

2. Bestämma designparametrar för slänter, tunnlar, bergrum och gruvöppningar

3. Välja lämplig brytningsmetod (dagbrott eller underjordgruva) för olika malmkroppar och geologiska miljöer, och

4. Utveckla praktisk problemlösningsförmåga för verkliga ingenjörsutmaningar.

## Kursinnehåll

Modul 1: Introduktion till praktisk bergteknik

Modul 2: Designprocesser för bergteknik

Modul 3: Stabilitet och övervakning av bergkonstruktioner

Modul 4: Yt- och underjordsbrytning

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Modul 1: Introduktion till praktisk bergteknik

- State of the art inom bergteknik

- Typer av bergtekniska konstruktioner

- Bergbrytningsmetoder och -processer

- Quiz 1

Modul 2: Designprocesser för bergkonstruktioner

- Designhänsyn för anläggningsbyggande

- Konstruktionshänsyn för gruvkonstruktion

- Konstruktionsmetoder för anläggnings- och gruvkonstruktioner

- Design av stora slänter

- Quiz 2

- Uppgift 1

Modul 3: Stabilitet och övervakning i bergkonstruktioner

- Metoder för stabilitetsanalyser och bedömningar

- Övervakningssystem inom bergteknik

- Realtidsövervakning i gruvapplikationer

- Introduktion till riskhantering

- Quiz 3

- Uppgift 2

Modul 4: Yt- och underjordsbrytning

- Introduktion till värdekedjan för gruvdrift

- Process för val av gruvmetoder

- Dagbrottsbrytning

- Underjordsbrytning

- Quiz 4

- Uppgift 3

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

- Uppgifter – Består av problem där eleverna övar och tillämpar sina teoretiska kunskaper, förståelse och förmågor, genomför analyser (empiriska och analytiska) och förklarar sina resultat skriftligt. (ILO 1, 2)

- Quiz – kommer att ges i slutet av varje modul som ett sätt att sammanfatta och utvärdera hur väl studenterna har förstått begreppen som presenteras i respektive modul. (ILO 1, 2)

- Skriftlig tentamen – Studenterna svarar på frågor och löser problem som liknar de som man stöter på under kursen (i föreläsningar och uppgifter) för att testa sina individuella kunskaper, förståelse, färdigheter och förmågor. (ILO 1, 2, 4)

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Skriftlig tentamen | GU345 | 3,5 | Obligatorisk | H25 |  |
| 0002 | Uppgifter | U G# | 3 | Obligatorisk | H25 |  |
| 0003 | Quiz | U G# | 1 | Obligatorisk | H25 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
