---
kurskod: "P0008K"
titel: "Mineralteknisk och metallurgisk processteknik"
hp: "7,5"
titel_en: "Mineral and Metallurgical Process Technology"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Processmetallurgi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0008K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0008K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p00/p0008k-mineralteknisk-och-metallurgisk-processteknik"
---

# Mineralteknisk och metallurgisk processteknik (P0008K)

## Behörighet

Grundläggande behörighet samt Kännedom om mineraler (mineralogi) motsvarande O0045K Mineralogi och kristallografi, och om grundläggande kemi motsvarande P0007K Kemiska reaktioner i hållbar mineralutvinning. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursen syftar till att ge möjlighet att förvärva grundläggande kunskaper i mekanisk processteknik och högtemperaturprocesser.

Efter avslutad kurs förväntas deltagarna kunna:

- Förklara teoretiska begrepp inom mekanisk processteknik

- Beskriva och förklara vanligen förekommande apparater/maskiner inom mekanisk processteknik med fokus på järnmalmsförädling

- Göra standardberäkningar för processanalys och processdesign

- Beskriva och förklara de enhetsoperationer som är vanliga inom högtemperaturprocesser med fokus på järn och stål

- Beskriva och tillämpa de teoretiska grunderna för högtemperaturprocesser

- Ur ett teoretiskt och praktiskt perspektiv förklara utvinning av järn och stål

## Kursinnehåll

Introduktion till mineralteknik

- Karakterisering av dispersa system

- Genomgång av enhetsoperationer och mineralförädlingsprocesser: Sönderdelning, klassering, anrikning, avvattning

- Laborationer: Malning, klassering, magnetseparering

- Övningar: Partikelstorleksfördelningar, värdering av mineraltekniska processer

Introduktion till högtemperaturprocesser med fokus på järn- och stålproduktion ur ett hållbart perspektiv

- Översikt över enhetsoperationer och processystem

- Laborationer: Agglomerering, reduktion, smältning

Introduktion till termodynamik med fokus på högtemperaturprocesser

- Mass- och energibalanser för högtemperaturprocesser

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av undervisnings- och lärandeaktiviteter såsom föreläsningar, övningar, laborationer och studiebesök. Föreläsningarna ger möjlighet för studenterna att kunna beskriva och förklara verkningssättet för enhetsoperationer samt beskriva teoretiska koncept. Övningar används för att träna beräkningsprocedurer. Laborationerna (genomförande av labb och skrivande av rapport) görs i grupper. Studenterna tränas i att utföra undersökningsarbeten och arbeta i grupp samt att utvärdera, beskriva och rapportera försök. Studiebesöken ger möjlighet för studenterna att lära sig beskriva processtekniska sammanhang.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras genom laborationer och övningar, skriftliga tentamina och studiebesök. Laborationerna och övningarna samt studiebesöken är obligatoriska och bedöms endast med godkänt – underkänt. Godkända laborationsövningar, en strukturerad och välformulerad skriftlig rapport och deltagande i laborationslektioner krävs för att bli godkänd på laborationerna. Rapporterna kan behöva skrivas på engelska.

Den teoretiska förståelsen av ämnesområdet kontrolleras genom en skriftlig individuell tentamen, betygsatt 3 4 5. För betyg 3 måste studenten kunna beskriva vad som ingår i ämnesområdet och göra rutinberäkningar. För betyg 4 måste studenten kunna förklara vad som ingår i ämnesområdet och rapportera undersökningsresultat. För betyg 5 måste studenten kunna tillämpa de förvärvade kunskaperna på delvis nya teoretiska och praktiska problem.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen mineralteknik | GU345 | 2 | Obligatorisk | V26 |  |
| 0002 | Tentamen processmetallurgi | GU345 | 2 | Obligatorisk | V26 |  |
| 0005 | Studiebesök | UG | 0,5 | Obligatorisk | V27 |  |
| 0006 | Laborationer och övningar | UG | 3 | Obligatorisk | V27 |  |

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
