---
kurskod: "O0001K"
titel: "Tillämpad geofysik, grundkurs"
hp: "7,5"
titel_en: "Applied Geophysics, basic course"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Geofysik"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0001K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0001K&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o00/o0001k-tillampad-geofysik-grundkurs"
---

# Tillämpad geofysik, grundkurs (O0001K)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet samt O0035K Geologi, grundkurs eller motsvarande kurs.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

- förklara innebörden av begreppen geofysisk modell, geofysiska data och anomalier

- redogöra kvantitativt för petrofysiska egenskaper av vanliga bergarter och mineraliseringer

- förklara innebörden av begreppet ekvivalenta modeller med användning av allmänna statistiska verktyg

- redogöra kvalitativt för jordens magnetfält

- redogöra kvalitativt för jordens tyngdkraftfält och geoiden

- förklara allmänna principer (fysik, mätmetodik och tolkning) för geofysiska metoder som ingår i kursen

- beskriva partikelrörelse för seismiska vågor

- härleda formler för reflektions- och refraktionsseismiska löptider för simple två-skikts fall och identifiera och tolka seismiska löptider i ett seismogram

- härleda formler för reflektion av radarvågor för ett två-skikts fall och identifiera och tolka löptidskurvar i ett radargram

## Kursinnehåll

Seismologi-seismik-akustisk profilering: De olika typerna av seismiska vågor. Sambandet mellan elastiska materialparametrar och P- och S-våghastigheter. Reflektion och refraktion. Tolkning av refraktionsseismiska data. Tillämpningar av refraktions- och reflektionsseismik.

Jordens magnetfält-magnetometri: Jordens magnetfält. Bergarters och lösa jordarters magnetiska egenskaper. Mätmetodik och framställning av mätresultat. Prospektering efter malmer.

Jordens gravitation-gravimetri: Geodesi med huvudvikt på jordens tyngdkraftsfält. Bergarters och jordarters densitet. Korrektioner av gravimetriska data och beräkning av Bouguer anomalier, regional- och residual-anomali separation. Gravimetri och prospektering.

Elektriska och elektromagnetiska metoder: Elektrisk ledningsförmåga hos jordar och bergarter. Dielektricitetskonstant hos jord och bergarter. Elektriska metoder med naturliga och artificiella strömmar. Elektrisk sondering och kartering. Exempel från mineralprospektering, miljö-tekniska problem, vattenresursplanering och spårning av föroreningar i grundvatten. Elektromagnetiska fält. Inträngningsförmåga. Olika elektromagnetiska metoder med exempel från prospektering och miljöundersökningar. Markradar och borrhålsradar med tillämpningar vid miljöundersökningar.

Magnetisk resonsans sondering.

Radiometriska metoder: Mättning av gamma-strålning och tillämpningar.

Borrhålsmetoder och borrhålsloggning: akustisk loggning (sonic-logg), caliperlogg, densitetslogg, gammastrålningslogg, induktionslogg/konduktivitetslogg, neutronlogg, resistivitetslogg, SP-logg (självpotential), temperaturlogg, IP-logg (inducerad polarisations-) och magnetisk logg. Exempel från loggning i urberg och sediment.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen ges i form av föreläsningar, lektioner och fältövningar. Deltagande i fältövningar är obligatoriskt. Lektionerna ägnas åt genomgång av grundläggande teori samt tillämpning på konkret geofysiskt material. Fältövningarna ägnas åt genomgång av ett antal geofysiska fältinstrument samt fältmätningar med åtföljande bearbetning och tolkning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Skriftlig tentamen med differentierade betyg anordnas efter läsperioden och omfattar såväl redogörelse för kursens teoretiska delar som problemlösning. Betygssättning sker enligt betygsskala G U 3 4 5.

Fältövningen examineras genom en rapport enligt betygsskala G/U. Rapporten ska innehålla genomgång av mätmetodik och tolkning av data.

Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

Fältövningen är obligatorisk.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen O0001K motsvarar kursen KGG001

## Övrigt

O0001K motsvarar KGG001 och kan ej kombineras i examen.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 6 | Obligatorisk | H07 |  |
| 0003 | Laborationsrapport | UG | 1,5 | Obligatorisk | V27 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
