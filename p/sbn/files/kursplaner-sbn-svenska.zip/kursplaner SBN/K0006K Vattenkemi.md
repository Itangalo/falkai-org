---
kurskod: "K0006K"
titel: "Vattenkemi"
hp: "7,5"
titel_en: "Water Chemistry"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Kemi"
amnesgrupp_scb: "Kemi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0006K&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0006k-vattenkemi"
---

# Vattenkemi (K0006K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Grundläggande behörighet samt K0016K Kemiska principer eller motsvarande kurs.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

- Efter genomgången kurs ska du ha kunskap och förmåga att formulera och behandla jämviktsproblem. Enklare system skall behärskas att lösas för hand, mer komplicerade system skall även kunna behandlas med beräkningsprogram.

- Förändringar av jämvikter och jämviktslägen, orsakade av förändringar i variabler som temperatur, tryck, jonstyrka och sammansättning skall kunna förutses och beräknas vid tillgång på lämpliga data. Jämviktsdiagram ska kunna tolkas och i en del fall konstrueras.

- Du ska också ha bildat dig en uppfattning om de möjligheter och begränsningar som finns att använda jämviktsmodellering samt jämvikters betydelse för regleringen av sammansättningen av olika vattentyper.

- Principerna för vattenrening samt klors reaktioner i vatten ska vara kända, liksom grundläggande reaktionskinetik. Där detta är relevant, identifiera och föreslå åtgärder för att upprätthålla en hållbar utveckling. Vidare ska du ytterligare utveckla din kommunikativa kompetens, framförallt då med fokus på skriftlig rapportering.

## Kursinnehåll

Del 1: Kursen inleds med en kortfattad genomgång av vattnets egenskaper och olika vattentyper. Därefter behandlas aktivitetsbegreppet utgående från jonstyrkeberoende, samt temperaturens inverkan. Sedan redox-, komplex-, löslighets- och fördelningsjämvikter. En kortfattad introduktion till gasjämvikter ingår även.

Del 2: Omfattar syrabasjämvikter, inkluderande heterogena syrabasjämvikter och alkalinitet samt vattenrening och reaktionskinetik. En introduktion till behandling av ytkomplexjämvikter samt exempel på behandling av problemställningar i industriella- och naturliga system ingår även.

Teorin i kursdelarna tillämpas med räkneövningar. Som hjälpmedel används jämviktsdiagram och datorverktyg. Laborationerna består av enklare jämviktsmätningar samt analys av vattenprover. I laborationsmomentet ingår också användning av beräkningsverktyg som stöd för de moment som tas upp under del 1 respektive del 2.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av lektioner, obligatoriska laborationer och datorsimuleringar. Vid frånvaro första lektionen, meddela kursansvarig för att underlätta fortsatt planering av kursen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Provet Laborationer (modul 0005) examinerar de tre första punkterna under rubriken ”Mål”. Godkända förberedelser, genomförande och rapportering enligt utdelade instruktioner krävs för godkänt betyg.

Laborationer och redovisning ska ha uppnått ställda kvalitetskrav senast inom en vecka efter innevarande läsperiod. Eventuella kvarstående moment kan avslutas vid påföljande kurstillfälle. Studenten ansvarar själv för att en aktiv dialog hålls med labbhandledaren i syfte att uppnå godkänt betyg på detta prov inom fastställd tidsram.

Tentamen (modul 0008) examinerar alla kursmålen. Obligatoriska inlämningsuppgifter kan ingå i båda proven (0005 och 0008).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0006K motsvarar kursen KGK013

## Övrigt

Studiehandledningen finns tillgänglig via LTUs lärplattform

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0008 | Skriftlig tentamen | GU345 | 6 | Obligatorisk | H07 |  |
| 0005 | Laborationer | U G# | 1,5 | Inaktiv | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
