---
kurskod: "D7020B"
titel: "Intelligent asset management"
hp: "7,5"
titel_en: "Intelligent Asset Management"
giltig: "Höst 2025 Lp 1 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7020B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7020B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7020b-intelligent-asset-management"
---

# Intelligent asset management (D7020B)

## Behörighet

90 högskolepoäng i tekniska ämnen. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter genomgången kurs ska deltagarna kunna:

Kunskap och förståelse:

1. Förstå grundläggande koncept för underhåll och dess roll i intelligent asset management.

2. Beskriva de centrala principerna för asset management och hur det kan stödja systemprestanda och livscykelhantering.

3. Visa kunskaper i grundläggande programvaruteknik för utveckling av lösningar inom asset management.

Kompetens och färdigheter:

4. Använda programvaruteknik för att implementera AI-baserade lösningar för asset management.

5. Visa analytiska färdigheter för att hantera komplexa industriella utmaningar och datadrivet beslutsfattande.

Värderingsförmåga och förhållningssätt:

6. Utvärdera verkliga fallstudier från industrin för att identifiera effektiva metoder och strategiska tillvägagångssätt inom intelligent asset management.

## Kursinnehåll

Denna kurs omfattar:

- Grundläggande principer för asset management

- Underhåll som en del av asset management

- Systemprestanda och livscykelhantering

- Verktyg för asset management: analys, AI, digitalisering

- Programvaruteknik och mjukvaruutveckling

- Fallstudier och praktiska tillämpningar inom industrin

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen kombinerar online- och personliga sessioner i ett hybridformat. Leveransmetoder inkluderar föreläsningar, uppgifter, laboratorier och analyser av verkliga fallstudier.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen inkluderar både formativa bedömningar (för lärande) och summativa bedömningar (av lärande). De summativa bedömningarna, i form av uppgifter och rapporter, examinerar de angivna lärandemålen, medan de formativa bedömningarna (klassdiskussioner, reflektioner, quiz, grupparbeten, återkoppling) stödjer lärandet.

För att klara kursen måste fem uppgifter slutföras. För att klara varje uppgift måste studenten först demonstrera sin lösning för den tilldelade handledaren, helst under den löpande sessionen eller sammanfattningssessionen för den uppgiften. Efter godkänd demonstration lämnas filerna in via Canvas. Handledaren granskar filerna och markerar uppgiften som godkänd eller begär en revidering.

Slutbetyget (3, 4 eller 5) baseras på medelbetyget för de fem uppgifterna, där varje uppgift har lika vikt.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 7,5 | Obligatorisk | H25 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
