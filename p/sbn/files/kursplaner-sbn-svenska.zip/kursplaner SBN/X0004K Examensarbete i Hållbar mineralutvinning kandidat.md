---
kurskod: "X0004K"
titel: "Examensarbete i Hållbar mineralutvinning, kandidat"
hp: "15"
titel_en: "Degree Project in Mineral Resource Engineering, Bachelor"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2026-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2E"
betygsskala: "UG"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X0004K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X0004K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/x00/x0004k-examensarbete-i-hallbar-mineralutvinning-kandidat"
---

# Examensarbete i Hållbar mineralutvinning, kandidat (X0004K)

## Behörighet

Grundläggande behörighet samt Minst 135 hp avklarade kurser av examensfordringarna. Utöver ovanstående avgör examinator om det föreslagna examensarbetet ligger inom ämnesområdet och om studenten har den fördjupning som krävs. Goda kunskaper i engelska motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursens övergripande mål är att studenten skall öva, utveckla och visa färdigheter i att tillämpa teori och metod för att lösa problem på vetenskaplig grund med relevans för en yrkesverksamhet som högskoleingenjör inom området hållbar mineralutvinning. Detta innebär att studenten efter kursen ska kunna:

- Formulera en relevant problemställning utifrån ett valt ämne inom ämnesområdet hållbar mineralutvinning.

- Tillämpa kunskaper och färdigheter som har förvärvats under studietiden i ett utrednings-, utvecklings- eller mindre forskningsprojekt på ett självständigt och systematiskt sätt.

- Välja och motivera metod för studien

- Med relevant information på ett ingenjörsmässigt sätt analysera och besvara formulerad problemställning.

- Finna och kritiskt värdera information och sammanfatta denna på ett ingenjörsmässigt sätt.

- Planera strukturera och genomföra ett utvecklings- eller utredningsarbete.

- Bedöma relevansen av erhållna resultat

- Arbeta efter tidplan.

- Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt

- Utforma och genomföra en presentation där arbetets resultat och slutsatser redovisas och försvaras.

- Kritiskt granska andra studier på ett konstruktivt sätt.

## Kursinnehåll

Innehållet i examensarbetet utformas i dialog med handledare. Examensarbetet innehåller alltid en teoretisk uppbyggnad i form av en litteraturstudie som belyser teknikområde och metodik, sammanfattad på ett vetenskapligt sätt.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten genomför och planerar självständigt examensarbetet med handledare som stöd. I examensarbetet ingår att göra en tidplan för hela projektet som kontinuerligt följs upp.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

- Skriftlig presentation av eget arbete. I rapporten skall studenten visa förmåga att:

    - Motivera den valda problemställningen

    - Välja och motivera metod för studien

    - Med koppling till vald teori/metod samla in information relevant för problemformuleringen

    - På ett relevant sätt skriftligt presentera den insamlade informationen

    - Utifrån vald teori/metod analysera och besvara formulerad problemställning

    - Med ett kritiskt förhållningssätt bedöma relevansen av erhållna resultat

    - Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt

- Muntlig presentation av eget arbete

- Opponering på annans arbete

- Närvara vid presentationer av andra examensarbeten.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Institutionen tillhandahåller aktiv handledning under en termin från kursstart. Examensarbetet utförs företrädesvis enskilt och endast i undantagsfall med maximalt två deltagande studenter. I de fall där examensarbetet utförs av två studenter skall detta synas i rapportens omfång och djup.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Muntlig presentation | UG | 0 | Obligatorisk | V27 |  |
| 0006 | Start av examensarbete | UG | 0 | Obligatorisk | V27 |  |
| 0007 | Godkänd rapport | UG | 15 | Obligatorisk | V27 | Ja |
| 0008 | Opponering av annat examensarbete | UG | 0 | Obligatorisk | V27 |  |

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13
