---
kurskod: "A7011B"
titel: "Miljöföroreningar och reningsteknik"
hp: "7,5"
titel_en: "Environmental Pollution and Treatment"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-06"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Miljöteknik"
amnesgrupp_scb: "Miljövård och miljöskydd"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=A7011B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=A7011B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/a70/a7011b-miljofororeningar-och-reningsteknik"
---

# Miljöföroreningar och reningsteknik (A7011B)

## Ingår i huvudområde

Naturresursteknik, Samhällsbyggnadsteknik

## Behörighet

Minst 90 hp i kemiteknik, geovetenskap eller naturresursteknik. Goda kunskaper i engelska motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter genomförd kurs ska studenten ha en grundläggande förståelse för miljöföroreningar, deras källor, risker och metoder för behandling.

Efter avslutad kurs ska studenten kunna:

- Beskriva källor och typer av föroreningar i luft, vatten, jord och avfall.

- Förklara kemiska och fysikaliska processer som påverkar transport, omvandling och öde för föroreningar i miljön.

- Identifiera och diskutera viktiga oorganiska och organiska föroreningar (t.ex. metaller, PFAS, POPs, bekämpningsmedel).

- Utvärdera renings- och saneringstekniker för förorenad luft, vatten och jord.

- Tolka relevant miljölagstiftning och policyer kopplade till föroreningskontroll.

- Bedöma miljörisker relaterade till föroreningar och föreslå åtgärdsstrategier.

- Arbeta i grupp med att kritiskt granska vetenskaplig litteratur och presentera fördjupad kunskap om en specifik förorening.

## Kursinnehåll

Kursen behandlar följande områden:

- Förekomst och källor till föroreningar i luft, vatten, jord och avfall.

- Kemiska och fysikaliska egenskaper hos föroreningar, inklusive metaller, persistenta organiska föroreningar (POPs), PFAS och bekämpningsmedel.

- Transport- och omvandlingsprocesser i miljön.

- Hälso- och miljörisker kopplade till miljöföroreningar.

- Miljölagstiftning och regelverk för kontroll av föroreningar.

- Behandlings- och saneringsmetoder för förorenade medier, inklusive fysikaliska, kemiska och biologiska tekniker.

- Fallsstudier av specifika föroreningar som illustrerar miljöproblem och metoder för sanering.

- Grupparbete med fokus på en specifik förorening, inklusive litteraturstudie, skriftlig rapport och muntlig presentation.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen består av föreläsningar, litteraturbaserade grupparbeten och seminarier.

Studenterna arbetar i grupper för att fördjupa sina kunskaper om en specifik förorening genom litteraturstudier, rapportskrivning och muntlig presentation. Aktivt deltagande i diskussioner och seminarier uppmuntras för att fördjupa förståelsen för miljöföroreningar och saneringsstrategier.

Allt kursmaterial och kommunikation tillhandahålls via lärplattformen Canvas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

- En skriftlig tentamen som utvärderar förståelsen av samtliga förväntade studieresultat.

- Ett grupparbete som inkluderar skriftlig rapport, muntlig presentation och diskussion.

För att bli godkänd på kursen krävs godkänt resultat på båda delmomenten.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 4,5 | Obligatorisk | H26 |  |
| 0002 | Grupparbete (rapport och muntlig presentation) | U G# | 3 | Inaktiv | H26 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-06
