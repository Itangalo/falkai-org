---
kurskod: "D7022B"
titel: "Prediktiv analys och tillståndsbaserat underhåll"
hp: "7,5"
titel_en: "Predictive Analytics and Condition Based Maintenance"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7022B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7022b-prediktiv-analys-och-tillstandsbaserat-underhall"
---

# Prediktiv analys och tillståndsbaserat underhåll (D7022B)

## Behörighet

Minst 90 hp samt D7007B Underhållsteknik eller motsvarande. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter genomgången kurs ska deltagarna kunna:

Kunskap och förståelse:

1. Förklara begrepp och metoder för tillståndsövervakning, tillståndsbaserat underhåll och prediktivt underhåll.

2. Visa på en grundläggande förståelse för mätteknik, signalbehandlingstekniker för tillståndsövervakning.

3. Förklara hur modellering och simulering med hjälp av datorverktyg kan stödja tillståndsbaserat underhåll.

4. Beskriva tekniker för prediktionsmodeller och metoder för maskininlärning för prognostik och beslutstöd för underhåll.

Kompetens och färdigheter:

5. Analysera mätdata med hjälp av signalbehandlingstekniker och prediktionsmodeller för att bedöma och förutse system och anläggningars tillstånd.

6. Implementera diagnostik och prognostik med hjälp av maskininlärning, med data från sensorer och tillståndsövervakningssystem.

7. Planera och schemalägga underhållsaktiviteter med hänsyn till anläggningens tillgänglighet, risker och livscykelkostnad.

## Kursinnehåll

Denna kurs omfattar:

- Tillståndsbaserat underhåll och prediktivt underhåll

- Sensor-, mätteknik och signalanalys

- Maskininlärning och prediktiv analys för underhåll

- Diagnostik och prognostik.

- Beslutsstöd för underhållsplanering och schemaläggning

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. I kursen ingår föreläsningar och laborationer för att ge både teoretiska kunskaper och praktiska färdigheter. Föreläsningar kommer att täcka teoretiska begrepp om tillståndsbaserat underhåll, signalanalystekniker och modelleringsmetoder för prediktivt underhåll och beslutstöd för underhåll. Laboratorierna kommer att ge praktisk erfarenhet av sensorer och datainsamling, signalbehandling och implementering av modeller för diagnostik och prognostik med hjälp av analysmjukvara.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För att erhålla godkänt betyg på kursen måste inlämningsuppgifterna och laborationerna vara avslutade med godkänt betyg.

- Inlämningsuppgifter bedömer kunskap och förståelse relaterat till målen (1-4) samt kompetenser i underhållsplanering beskrivit i mål 7.

- Laborationer och labbrapporter utvärderar den praktiska kompetenserna och färdigheterna som beskrivs i mål 5-6. Laborationerna kommer att genomföras i grupper, med labbrapporter för att utvärdera både gruppens och individernas kompetens och färdigheter.

- Peer Review mellan grupper ingår för att låta studenterna utvärdera varandras bidrag och reflektera över sin egen förståelse.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgift | GU345 | 4 | Obligatorisk | H25 |  |
| 0003 | Laboration | UG | 3,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
