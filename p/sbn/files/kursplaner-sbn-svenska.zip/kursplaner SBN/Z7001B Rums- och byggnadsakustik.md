---
kurskod: "Z7001B"
titel: "Rums- och byggnadsakustik"
hp: "7,5"
titel_en: "Architectural acoustics"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-11-02"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Teknisk akustik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=Z7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=Z7001B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/z70/z7001b-rums--och-byggnadsakustik"
---

# Rums- och byggnadsakustik (Z7001B)

## Ingår i huvudområde

Arkitektur

## Behörighet

Kunskaper i akustik motsvarande innehållet i kursen W0008B Byggnadsfysik

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter fullgjord kurs ska studenten kunna:

- Projektera lokaler för att få rätt akustiska egenskaper för det avsedda ändamålet

- Bedöma rums akustiska egenskaper för att säkerställa att rummet har rätt akustik

- Beräkna/uppskatta ljudisoleringsförmågan hos väggar

- Mäta väggars och bjälklags ljudisolerande förmåga

- Använda programvara för att modellera och akustiskt utvärdera lokaler som ännu befinner sig på projekteringsstadiet

- Dimensionera vibrationsisolering

- Arbeta och lösa tekniska problem i grupp samt redovisa resultaten i skriftlig rapport

## Kursinnehåll

Kursen behandlar följande moment med ett fördjupat innehåll relaterat till byggnader:

- Akustiska begrepp och definitioner

- Akustisk planering av bostäder beträffande inom- och utomhusmiljö

- Lagstiftning och ljudstandarder för bostäder

- Mätteknik och mätmetoder för ljud och vibrationer

- Hörseln – örats anatomi och fysiologi, psykoakustik och hörselskador

- Ljudalstringsmekanismer – fysikaliska fenomen bakom alstring och spridning av ljud

- Rumsakustik – ljudfält och ljudutbredning i slutna utrymmen (efterklangstid, absorption, reflektion, transmission etc.)

- Metoder för beräkning av väggars och bjälklags ljudisolerande förmåga och metoder för att bygga tysta miljöer

- Vibrationsisolering – teori och beräkningsmetoder för vibrationsisolering med fokus på att minska stomljud

- Rumsakustisk modellering – genomgång av programvara för att modellera ljudutbredning i rum och/eller för modellering av ljudisolering

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen sker i form av föreläsningar som innehåller teorigenomgång, demonstrationer och problemlösningar. Laborationer utförs i grupper och redovisas skriftligt. Projektarbete som innefattar akustisk modellering utförs i grupp. Projektarbetet kan även innefatta en serie gästföreläsningar.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Skriftlig tentamen i slutet av kursen. Skriftlig redovisning av laborationerna samt skriftlig och/eller muntlig redovisning av projektarbete.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 5 | Obligatorisk | V15 |  |
| 0005 | Laboration | UG | 1 | Obligatorisk | V27 |  |
| 0006 | Projektarbete | UG | 1,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-11-02

## Kursplanen fastställd

av Eva Gunneriusson 2014-02-12
