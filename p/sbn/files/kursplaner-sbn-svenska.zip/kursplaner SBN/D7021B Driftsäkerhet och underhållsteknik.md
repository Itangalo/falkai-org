---
kurskod: "D7021B"
titel: "Driftsäkerhet och underhållsteknik"
hp: "7,5"
titel_en: "Reliability and Maintenance Engineering"
giltig: "Höst 2025 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7021B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7021B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7021b-driftsakerhet-och-underhallsteknik"
---

# Driftsäkerhet och underhållsteknik (D7021B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Underhållsteknik

## Behörighet

90 högskolepoäng i tekniska ämnen. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Denna kurs är utformad för att ge studenterna grundläggande principer och koncept inom underhållsteknik, för att möjliggöra analys av systemtillförlitlighet, bedöma risken för fel och utveckla effektiva underhållsstrategier för ökad operationell effektivitet, säkerhet och kostnadseffektivitet. Kursen betonar tillämpningen av driftsäkerhet och underhållsteknik inom industri, inklusive områden som gruvdrift, jord och bergbyggnad. Efter genomgången kurs ska studenterna kunna:

Kunskap och förståelse

1. Förklara principer för driftsäkerhet, inklusive funktionssäkerhet, tillgänglighet, underhållsmässighet och säkerhet (RAMS), och utvärdera dess inbördes relationer och tillämpningar vid bedömning av RAMS-prestanda för ett system.

2. Förklara underliggande koncept, tillämpbarheten och effektiviteten av olika underhållsstrategier.

3. Visa en allmän förståelse för principer inom underhållsteknik och deras tillämpningar i industrin.

Kompetens och färdigheter

4. Utföra grundläggande tillförlitlighetsanalys och tillämpa grundläggande modeller för systemtillförlitlighet.

5. Visa förmågan att använda riskutvärderingstekniker.

6. Använda metoder inom underhållsteknik för att identifiera lämpliga och effektiva underhållsstrategier.

## Kursinnehåll

- Underhåll och livscykelhantering

- Grundläggande principer för driftsäkerhet och RAMS (funktionssäkerhet, tillgänglighet, underhållsmässighet och säkerhet)

- Bedömning av systemprestanda

- Grundläggande tillförlitlighetsanalys och systemtillförlitlighetsanalys

- Underhållsstrategier och effektivitetskriterier

- Funktionssäkerhetsinriktat underhåll (RCM)

- Riskanalys, inklusive metoder som felmod och effektsanalys (FMEA), felträdsanalys (FTA), händelseträdsanalys (ETA) och Hazard and Operability Study (HAZOP)

- Modellering och optimering av underhåll

- Mänskliga faktorer inom underhållsteknik

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Föreläsningar kommer att presentera viktiga koncept med exempel. Föreläsningarna stöds av grupparbeten för att stärka förståelsen för varje ämne. Studenterna ska interagera för att lösa problem, tillämpa, förklara, analysera eller identifiera aspekter av de presenterade ämnena. Studenterna kommer också att arbeta med ett antal grupprojekt och individuella övningar och uppgifter för att stärka deras inlärning av varje ämne. Vid grupparbete krävs att studenten lämnar in en rapport samt en gruppresentation, för att få kommentarer för förbättring från deltagarna och instruktören. Individuella uppgifter kommer att granskas av lärarna för att ge studenterna konstruktiva kommentarer och vägledning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursbedömningen inkluderar två obligatoriska komponenter: en skriftlig tentamen och inlämningsrapporter. Den skriftliga tentamen bedömer studenternas omfattande förståelse av kursens kärninnehåll i förhållande till kursmålen. Tentamen, betygsatt på en skala U, 3, 4, 5, är värd 5 poäng. Dessutom måste studenterna genomföra och få godkänt på sina uppgifter, betygsatta på en U, G-skala, som motsvarar 2,5 poäng av kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Skriftlig tentamen | GU345 | 5 | Obligatorisk | H25 |  |
| 0002 | Inlämningsuppgifter | U G# | 2,5 | Obligatorisk | H25 |  |

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
