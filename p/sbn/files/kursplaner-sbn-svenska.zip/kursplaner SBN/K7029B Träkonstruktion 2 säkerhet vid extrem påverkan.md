---
kurskod: "K7029B"
titel: "Träkonstruktion 2, säkerhet vid extrem påverkan"
hp: "7,5"
titel_en: "Design of Timber Structures 2, Extreme Conditions and Safety"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2026-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "U G VG"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7029B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7029B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7029b-trakonstruktion-2-sakerhet-vid-extrem-paverkan"
---

# Träkonstruktion 2, säkerhet vid extrem påverkan (K7029B)

## Ingår i huvudområde

Samhällsbyggnadsteknik

## Behörighet

Minst 90 hp inom området Samhällsbyggnadsteknik eller motsvarande inklusive kurserna K7026B Träkonstruktion 1 och K0019B Trä som konstruktionsmaterial eller motsvarande. Dessutom krävs Engelska 6/nivå 2 och Svenska 3/nivå 3.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter genomgången kurs skall du som student kunna:

Kunskap och förståelse
- Förklara hur yttre påverkan, som kan leda till ett byggnadsras, ska beaktas i projekteringen
- Beskriva olika metoder för att förebygga fortskridande ras i träkonstruktioner
- Redogöra om en träkonstruktions känslighet gällande stabilitet
- Beskriva åtgärder för att förhindra spridning av brand.

Färdighet och förmåga
- Välja lämplig åtgärd för att förebygga fortskridande ras i en träkonstruktion.
- Avgöra stabilitetsgränser för sammankopplade konstruktioner.
- Avgöra och kommunicera konsekvenser av extrem/ovanlig påverkan på en träkonstruktion.

Värderingsförmåga och förhållningssätt
- Bedöma tillämpbarhet av åtgärder för att förebygga fortskridande ras i träkonstruktioner
- Värdera tillförlitlighet av olika åtgärder för att förebygga ett byggnadsras

## Kursinnehåll

Kursen behandlar hur stora träkonstruktioners integritet kan drabbas av olika speciella påverkningar och hur ett oproportionerligt ras kan förhindras. Följande aspekter tas upp:

- Orsaker till ras i träbyggnader
- Stabilitetsproblem
- Åtgärder för att förebygga fortskridande ras i olika byggnadstyper
- Oförutsebara yttre laster som exempelvis olyckor och explosioner
- Brand
- Dynamiska belastningar som exempelvis vind, jordbävningar och explosioner

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen ges på distans och baseras på självstudier av litteratur och annat material; enligt studiehandledning, kompletterade med inspelade föreläsningar och föreläsningar och i realtid med handledare. Färdighet och förmåga tränas genom övningsexempel och en inlämningsuppgift individuellt eller i grupp. Under regelbundna handledningar följs lärandet upp med läraren.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Examination sker kontinuerligt genom båda quizzar och en inlämningsuppgift.

Studenternas kunskaper och färdigheter examineras genom både teoretiska och praktiska moment. De teoretiska kunskaperna prövas genom flera quizzar som innehåller varierande uppgifter, vilka kräver god förståelse och insikt i kursens innehåll. Den praktiska förmågan att tillämpa inlärda metoder och teorier bedöms genom en inlämningsuppgift som kan genomföras individuellt eller i grupp. Uppgiften omfattar både en skriftlig rapport och en muntlig presentation, där studenten även förväntas reflektera över resultaten och dra egna slutsatser.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K7029B motsvarar kursen W7013T

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Inlämningsuppgift | U G VG | 5 | Obligatorisk | V27 |  |
| 0003 | Quizzar | UG | 2,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13
