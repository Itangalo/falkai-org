---
kurskod: "W7003B"
titel: "Datorstödd projektering"
hp: "7,5"
titel_en: "Virtual design"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-04-20"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Träbyggnad"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=W7003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=W7003B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/w70/w7003b-datorstodd-projektering"
---

# Datorstödd projektering (W7003B)

## Ingår i huvudområde

Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

W0007B CAD&VR eller P0009B Bygg och Anläggningsprojektering eller motsvarande kunskaper. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Målet med kursen är att studenten skall kunna leverera korrekta handlingar (ritningar och

modeller) från projekteringen av ett byggt objekt. Efter avslutad kurs kommer studenten inneha följande färdigheter:

Du skall kunna tillämpa:

- granska utformning och val av tekniska lösningar mot gällande regler i BBR (Boverket)

- modellering i 3D-CAD av byggobjekt

- ritningsläsning inom byggande

- generering och formatering av ritningshandlingar av byggda objekt

- måttsättning av byggritningar

Du skall förstå:

- projekteringens betydelse för övriga byggprocessen

- modellernas betydelse för projekteringssamordning

- hur modellframtagning samordnas (CAD-samordning)

- import/export mellan olika verktyg, standardiserade och icke standardiserade

- intilliggande datorverktyg och deras interaktion med CAD-verktyget

Du skall kunna identifiera ditt behov av ytterligare kunskap inom området projektering.

Du skall ha insikt i den aktuella utvecklingen inom Building Information Modelling (BIM) via reflektionsuppgifter understödda av referenser.

Du skall kunna hantera komplexa frågor kring husbyggande och sammanväga motstridiga krav i lösningsgenereringen i relation till Boverkets byggregler (BBR).

Du skall kunna utvärdera olika tekniska lösningar mot varandra och presentera dem på ritning och med BIM–modeller.

## Kursinnehåll

Kursen delas i två skeden, en del där grundläggande kunskaper i BIM och projekteringsprocessen kopplat till olika byggsystem. De grundläggande kunskaperna tränas i ett antal enskilda inlämningsuppgifter tillsammans 35% av kursen. Varje enskild uppgift består av ett delmoment som skall övas och en reflektion kring delmomentet. De enskilda uppgifterna behandlar:

- Ritningsläsning på befintliga bygghandlingar

- 3D-modellering av ett våningsplan

- Ritningsgenerering från 3D-modellen

- Simuleringar utifrån brand och design automation

Projektuppgiften genomförs i grupper om 5-6 personer som tillsammans projekterar för ett reellt byggnadsprojekt. Studenterna får tillgängligt bygglovshandlingarna för en byggnad. Varje grupp skall sedan tillsammans öva sig på färdigheter för att projektera fram bygghandlingar (ritningar, modeller, leveranser). Redovisningen skall möjliggöra att en byggnadsentreprenör skall kunna uppföra byggnaderna enligt ritningar och modeller. Projekteringen skall tas till den nivå som är praxis för redovisning av byggda objekt, både för ritningen och 3D-modellen, enligt Bygghandling 90.

För modellering används Revit Structure, med olika applikationer för teknikområde.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenterna arbetar självständigt under den första delen av kursen och examineras in två enskilda uppgifter. Under projektuppgiften arbetar studenterna i grupper om 5-6 personer och ska då planera och genomföra projektuppgiften inom en given tids- och resursram. De färdigheter inom byggande som tränas i kursen är förmågan att förstå och beskriva byggda objekt, förmågan att kommunicera lösningar nedströms i byggprocessen och förmågan att dokumentera tekniska lösningar i ritning och skrift. Kursen vilar på eget arbete i datormiljö.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examinationen består av två enskilda uppgifter och ett projektarbete i grupp med olika delinlämningar. Betygsskalan är U G på enskilda moment och projektarbete. På hela kursen ges betyget U 3 4 5. Slutbetyget på kursen styrs av de kurspoäng (0-100p) som studenten samlat ihop under kursens gång. Systemet beskrivs i detalj i studiehandledningen som delas ut vid kursens start.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i

förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Kursen ges på avancerad nivå och ingår som inriktningskurs i inriktningen Byggande inom civilingenjör Väg- och Vatten samt obligatorisk inom civilingenjör Brandteknik.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Projektuppgift | UG | 4,5 | Obligatorisk | V27 |  |
| 0004 | Inlämningsuppgifter | UG | 3 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-04-20

## Kursplanen fastställd

av Institutionen för samhällsbyggnad 2008-01-22
