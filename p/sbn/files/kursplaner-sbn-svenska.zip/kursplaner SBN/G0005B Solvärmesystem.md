---
kurskod: "G0005B"
titel: "Solvärmesystem"
hp: "7,5"
titel_en: "Solar Heating Systems"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0005B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0005B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g00/g0005b-solvarmesystem"
---

# Solvärmesystem (G0005B)

## Behörighet

Grundläggande behörighet + Engelska 6, Fysik 2, Kemi 1, Matematik 4 eller Matematik E. Eller: Engelska nivå 2, Fysik nivå 2, Kemi nivå 1, Matematik fortsättning nivå 2 (äldre kurs Matematik E).

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter godkänd kurs kommer studenten att kunna dimensionera en solfångaranläggning för villabruk genom både handberäkningar och datorsimuleringar. Studenten kommer även att kunna uppskatta solinstrålning på godtycklig plats i världen med hjälp av statistiska molnmodeller, samt utvärdera olika typer av solvärmeanläggningar. Studenten skall även kunna utnyttja solenergiberäkningar för att utforma och utvärdera ett solcellssystem för villabruk.

## Kursinnehåll

Kursen avser att ge teoretiska och praktiska kunskaper om hur solenergi kan utnyttjas för värme- och elproduktion i liten och stor skala.

Kursen behandlar:

Solens potential: Internationell överblick av solenergins användning.

Solenergi: Solinstrålningens årliga variationer. Beräkning av solinstrålning mot en yta. Hur geografi, topografi och solfångarnas/solcellernas läge påverkar systemets effektivitet. Solvärmesystem: Beskrivning av små- och storskaliga solvärmesystem. Ingående komponenter i ett solvärmesystem. Exempel på existerande solvärmesystem. Solfångarteori: Olika typer av solfångare och deras användningsområden.

Solcellsteori: Beskrivning av solcellen, uppbyggnad effektivitet och ekonomi.

Dimensionering: Dimensionering av solvärmesystem för olika ändamål (Hjälpmedel: Excel eller liknande).

Systemsimulering: Dimensionering av ett solvärmesystem med hjälp av datorprogrammet Polysun.

Obligatoriskt studiebesök till en solvärmeanläggning.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar samt ett projektarbete, som utförs i grupper av 1-3 studenter. Projektet består av att designa och simulera prestanda för ett solvärmesystem för ett hus eller anläggning som studenten själv väljer. Varje undervisningstillfälle syftar till att ta studenterna vidare till nästa nivå i deras solvärmeprojekt. I slutfasen av kursen utförs en datorlaboration och ett obligatoriskt studiebesök till en solvärmeanläggning. Kursen innehåller inga muntliga presentationer.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Examinationen består projektarbetet, vilket är uppdelat i tre delmoment, med tillhörande dugga. Momenten är jämnt fördelade över läsperioden och innehåller följande:

Delmoment 1: beräkning av hur solstrålningens infallsvinkel och intensitet varierar med tid, plats och molnighet.

Delmoment 2: Teori och dimensionering av solfångare.

Delmoment 3: Uppskattning av en villas uppvärmnings- och varmvattenbehov samt dimensionering av solvärmesystemet (genom egna beräkningar och genom datorsimuleringar). Ekonomisk analys av systemet. Studiebesök hos en solvärmeanläggning (obligatoriskt).

En förutsättning för ett godkänt betyg är att grupparbeten lämnas in inom utsatta stopptider. Den sammanvägda bedömningen av grupparbete och dugga ger det slutgiltiga betyget enligt skalan U(underkänd) 3 4 5.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen G0005B motsvarar kursen E0002B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0004 | Inlämningsuppgift | GU345 | 6,5 | Obligatorisk | H15 |  |
| 0006 | Övrigt | UG | 1 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Eva Gunneriusson 2015-02-12
