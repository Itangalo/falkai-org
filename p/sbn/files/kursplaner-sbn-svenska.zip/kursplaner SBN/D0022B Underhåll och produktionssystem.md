---
kurskod: "D0022B"
titel: "Underhåll och produktionssystem"
hp: "7,5"
titel_en: "Maintenance and Production Systems"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2020-02-14"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0022B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d00/d0022b-underhall-och-produktionssystem"
---

# Underhåll och produktionssystem (D0022B)

## Behörighet

Grundläggande behörighet samt D0010B Underhållsstrategi eller motsvarande kurs.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursen syftar till att ge de studerande en fördjupad förståelse för underhåll av produktionssystem. Efter avslutad kurs ska studenten:

- förstå system och processer i olika industriella sektorer

- fördjupad kunskap i hur underhållet i olika produktionssystem planeras, utförs och utvärderas

- ha grundläggande kunskap och förståelse för underhållssystem

- ha förmåga att praktiskt kunna utföra mättekniker för inspektion och tillståndsövervakning

- ha grundläggande färdigheter i digitalisering, sakernas internet och datahantering relaterat till underhåll

## Kursinnehåll

Kursen omfattar följande:

- processer och produktionssystem för olika industriella sektorer

- underhållsprocesser, strategier och underhållaktiviteter för olika produktionssystem

- metoder för inspektion och tillståndsövervakning

- verktyg för att systematisera underhållsdata och underhållsplanering

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen ges på campus med möjlighet att delta på distans. Obligatorisk närvaro vid presentation av inlämningsuppgifter. Obligatorisk närvaro vid campus och studiebesök förekommer.

Kursen genomförs genom att förinspelade teoretiska moment varvas med diskussionspass. Det förutsätts att studenten förbereder sig inför diskussionspassen genom att gå igenom anvisat material. Ett aktivt deltagande på lektionen förväntas. Kursen innehåller även laborationsmoment och studiebesök.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. För godkänt slutbetyg på kursen krävs att grupparbeten, laborationer och inlämningsuppgifter utförts med godkänt resultat.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Inlämningsuppgifter | GU345 | 4 | Obligatorisk | V21 |  |
| 0003 | Grupparbeten/laborationer | UG | 3,5 | Obligatorisk | V27 |  |

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-02-14
