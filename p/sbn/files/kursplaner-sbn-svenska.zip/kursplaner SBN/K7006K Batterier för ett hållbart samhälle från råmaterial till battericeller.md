---
kurskod: "K7006K"
titel: "Batterier för ett hållbart samhälle: från råmaterial till battericeller"
hp: "7,5"
titel_en: "Batteries for a sustainable society: from raw materials to battery cells"
giltig: "Vår 2020 Lp 3 - Tills vidare"
beslutsdatum: "2020-03-06"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Kemi"
amnesgrupp_scb: "Kemi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7006K&lasPeriod=202&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7006k-batterier-for-ett-hallbart-samhalle-fran-ramaterial-till-battericeller"
---

# Batterier för ett hållbart samhälle: från råmaterial till battericeller (K7006K)

## Behörighet

BSc inom kemi, metallurgi, materialvetenskap eller minst 180 hp från en civilingenjörsutbildning i kemiteknik. Studierna skall ha inkluderat kurser i allmän kemi (exempelvis K0016K), oorganisk kemi (exempelvis K0011K) samt fysikalisk kemi (exempelvis K0010K). Goda färdigheter i det engelska språket, motsvarande engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Examinator

Faiz Ullah Shah

## Mål/Förväntat studieresultat

Kursens mål är att studenten efter avslutad kurs skall:

- kunna förklara och tillämpa grundläggande elektrokemi i analysen av olika typer av elektrokemiska celler och batterier

- ha kännedom om olika batterityper, superkondensatorer, bränsleceller och deras egenskaper

- ha kännedom om elektroder, elektrolyter och batteriuppbyggnad för batterier och hur dessa                  framställs ur råmaterial

- kunna förklara hur olika belastningar påverkar batterier: cykling, temperatur, potentialfönster

- kunna analysera de vanligaste elektrokemiska mekanismerna för elektrodmaterial och hur de tar sig uttryck: interkalation, legering, ”conversion” mm

- kunna förklara jonledningsmekanismer i elektrolyter

- kunna identifiera de vanligaste mineralen innehållande Li, Co, Mn, Ni och grafit

- ha kännedom om de viktigaste malmtyperna innehållande Li, Co, Mn, Ni och grafit, samt var den huvudsakliga brytningen av dessa malmer sker i dagsläget

- ha kännedom om kända fyndigheter av Li, Co, Mn, Ni och grafit i den svenska berggrunden

- ha kännedom om vanliga utvinningsprocesser för Li, Co, Mn, Ni och grafit

- ha kännedom om olika återvinningsmetoder för litiumjon batterier och dess begränsningar

## Kursinnehåll

Kursen omfattar grundläggande elektrokemi. Betydelsen av Helmhotzlager och gränsytor i batterier beskrivs och dess påverkan på batteriprestanda.

Batteriuppbyggnad, olika typer av kemiska sammansättningar av elektroder och elektrodernas material samt elektrolyt ska omfattas teoretiskt samt även i praktiska övningar.

Fyndighetstyper för Li, Co, Mn, Ni och grafit samt deras förekomst globalt och i Sverige, människans behov av metaller, mineralidentifiering.

Generell genomgång av metallurgiska metoder. Genomgång av vanliga processvägar för utvinning av Li, Co, Mn, Ni och grafit. Fördjupning i metoder för framställning av litiumprodukter för batteriproduktion som Li-hydroxid. Genomgång av olika kommersiella återvinningsprocesser samt översikt av forskning avseende återvinning av litiumjonbatterier.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen sker i form av föreläsningar, räkneövningar med inlämningsuppgifter och laborationer. Laborationer och inlämningsuppgifter är obligatoriska. 1:a lektionen obligatorisk för alla studenter. Frånvaro beviljas av kursansvarig.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Godkända laborationsredogörelser och godkända inlämningsuppgifter (utan betyg) och skriftlig tentamen med differentierade sifferbetyg, 3, 4, 5.

## Övrigt

Under v. 33 (10-14 augusti 2020) sker undervisningen vid Uppsala universitet.

Under v. 34-35(17-28 augusti 2020) sker undervisningen vid Luleå tekniska universitet.

Studiebesök hos Northvolt AB i Västerås (under v.33 eller v.35) och Skellefteå (under v.34 eller v.35). Kostnader som uppstår i form av resor och extra boende täcks av studenten själv.

Skriftlig tentamen äger rum vid Luleå tekniska universitet under v. 35 (24-28 augusti 2020).

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Skriftlig tentamen | GU345 | 6 | Obligatorisk | V20 | Ja |
| 0002 | Laboration | U G# | 1,5 | Obligatorisk | V20 | Ja |

## Litteratur

*Litteratur. Gäller från Vår 2020 Lp 3* Helena Berg “Batteries for electric vehicles (materials and electrochemistry)” ISBN 9781107085930, 2015 eller senaste upplagan. Kompendium: ”Exempelsamling och laborationshandledning”.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-03-06
