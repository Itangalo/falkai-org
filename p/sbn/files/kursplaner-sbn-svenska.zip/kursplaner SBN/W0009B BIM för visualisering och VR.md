---
kurskod: "W0009B"
titel: "BIM för visualisering och VR"
hp: "7,5"
titel_en: "BIM for visualisation and VR"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-06-15"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "UG"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=W0009B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=W0009B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/w00/w0009b-bim-for-visualisering-och-vr"
---

# BIM för visualisering och VR (W0009B)

## Behörighet

Grundläggande behörighet samt Grundläggande kunskaper i AutoCad och Revit eller ArchiCad motsvarande kursen K0001B Ingenjörens datorverktyg eller P0009B Bygg och Anläggningsprojektering.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Målet är att studenten får lära sig en process för att skapa BIM-modeller i CAD för visualisering och granskning i en virtuell miljö samt skapa parameterstyrda modeller som används för att effektivisera projekteringen.

Kunskaper och förståelse

- Studenten ska erhålla kunskaper om hur modellering för visualisering och granskning kan tillämpas för byggprocessens olika skeden.

- Studenten ska bygga en teoretisk bas för hur Byggnadsinformationsmodeller (BIM) kan tillämpas för visualisering och granskning av olika bostadsprojekt och vilka teknologier för Virtual reality som används i byggbranschen.

Färdigheter och förmågor

Studenten skall:

- Kunna arbeta individuellt samt i grupp.

- Ta in och bearbeta samt använda instruktioner på engelska och svenska.

- Presentera konceptförslag med text, bilder och VR-miljö

Färdigheter relaterade till sakkunskap:

- Förstå och analysera hur ritningsunderlag används för bostadsbyggande.

- Förstå och tolka bygglovsritningar för att skapa BIM-modeller.

- Kunna använda avancerade funktioner i CAD-verktyg & VR-verktyg

- Skapa BIM-modeller med material (texturer) med hjälp av CAD-verktyg.

- Samordna BIM-modeller via export/import mellan olika verktyg.

- Visualisera med bilder och i realtidsmiljöer

3.3 Värderingsförmåga och förhållningssätt

- Studenten ska även övas i rapportskrivande genom läsning av branschrapporter och vetenskapliga artiklar med enklare analys formulera egen rapport samt med följande reflektion på annans arbete.

## Kursinnehåll

Kursen introducerar studenten i reflekterat skrivande genom en teoretisk fördjupning inom området för VRteknologier för byggprocessen. Kursen innehållet övningar i Revit Architecture där studenten får öva på att modellera hela hus inklusive fönster, dörrar, tak, trappor och bjälklag. Att koppla objekt till varandra för att underlätta modelleringen lärs ut. Dessutom ges en översikt över de egenskaper varje objekt har och hur man förser modellen med icke-geometrisk information via dessa egenskaper. Varje student modellerar en byggnad som sedan exporteras i två versioner till VR-miljö. Tillverkning av egna BIM-objekt övas i två steg, dels genom att parametrisera en enkel byggdel, dels genom att parametrisera en system-del av ett byggnadsverk.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av fem delmoment var av tre är teoretiskt introducerande och övningsrelaterade för färdigheter (A,B,C) samt två är projektrelaterade moment (D, E). För att nå målen ska studenterna i momenten A, genom att läsa om och fördjupa sig i litteratur inom området för VR-teknologier för byggprocessen, skriva och reflektera över sitt och andras arbeten. I moment B och C ska studenten genom övningar för modellering och programmering själv öva färdigheter för BIM och VR-metoder. I moment D ska studenten själv utveckla parametriska funktioner baserat på tidigare övade färdigheter och tillämpa dessa på projektbaserade byggnadsdelar och byggnadsverk. Slutligen i moment E ska studenten i grupp öva på att kombinera olika 3D-modeller i en VR-miljö med interaktiva funktioner.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras genom U eller G för moment A, B, C där A är en skriftlig rapport examineras genom inlämning och reflektion samt där moment B och C examineras genom inlämning.

För moment D och E examineras momenten i betygsskala U, G där nivå G bedöms utifrån att studenten

tillägnat sig merparten av de färdigheter som övats inom kursen på projektet. Studenten skall förstå vad förelagd uppgift innebär och kunna tillämpa den mot de krav som ställs i instruktionen. Obligatoriska tillfällen för examination av reflektion moment A och presentation av moment E.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen W0009B motsvarar kursen W0007B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Projektuppgifter | UG | 5 | Obligatorisk | V27 |  |
| 0004 | Inlämningsuppgifter | UG | 2,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-06-15
