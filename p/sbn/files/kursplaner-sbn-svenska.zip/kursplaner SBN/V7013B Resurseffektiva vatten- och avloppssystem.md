---
kurskod: "V7013B"
titel: "Resurseffektiva vatten- och avloppssystem"
hp: "7,5"
titel_en: "Resource-oriented Water and Sanitation Systems"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2022-01-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "VA-teknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V7013B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V7013B&lasPeriod=220&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/v70/v7013b-resurseffektiva-vatten--och-avloppssystem"
---

# Resurseffektiva vatten- och avloppssystem (V7013B)

## Behörighet

V0016B VA-system eller motsvarande

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna

- redogöra för avloppsfraktioners sammansättning och dess resurser (växtnäring, vatten, energi och mull) samt göra enklare massbalanser för dessa resurser,

- beskriva principer och tekniska lösningar för hur resurser i avloppsfraktioner kan tas tillvara, från hushåll via behandling till återanvändning och kritiska faktorer för att detta ska ske (t.ex risker),

- beskriva för- och nackdelar med olika systemlösningar för avloppshantering, inklusive dagens system, nationellt och internationellt,

- dimensionera och optimera systemkomponenter för effektiv avloppsvattenhantering och –behandling samt för separata avloppsflöden så att resurser kan tas tillvara på ett säkert sätt,

- planera, genomföra och redovisa laboratorieförsök relaterat till avloppsvattenbehandling,

- beskriva och dimensionera lösningar där insamling av regnvatten och dagvatten samt s.k. tekniskt vatten kan användas som resurser för att minska trycket på dricksvattensystemet, och

- beskriva existerande regelverk i relation till sorterande avloppssystem.

## Kursinnehåll

Denna kurs ska ge en bred överblick över resurseffektiva vatten- och avloppssystem vilka är viktiga verktyg i ett framtida hållbart samhälle. Kursen behandlar viktiga resurser, såsom växtnäring, mullbildande ämnen, värme och energi, som avlopp från hushåll innehåller och vilka alla måste tas omhand på ett mer omfattande sätt i en hållbar framtid. Kursen behandlar sorterande avloppssystem, där näringsrika flöden såsom urin eller klosettvatten tas om hand separat från bad-, disk- och tvättvatten, möjliggör en mer effektiv resurshantering. I kursen kommer resurserna i avloppsvatten, och också resursen vatten, genomgående att vara i fokus. Kursen kommer att behandla bland annat (i) principer för insamling, behandling och återföring, (ii) dimensionering och optimering av systemkomponenter, (iii) för- och nackdelar med olika systemlösningar och skala, (iv) existerande regelverk. Relevans av sorterande system i ett internationellt perspektiv belyses också.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. I kursen ges föreläsningar som syftar till att ge en översikt över ämnesområdet samt även viss detaljkunskap om exempelvis dimensionering av systemkomponenter. En litteraturuppgift delas ut tidigt i kursen som syftar till fördjupning i några behandlingstekniker. Denna uppgift resulterar i en skriftlig rapport och en muntlig redovisning. För att sätta kunskaperna som erhålls under kursen i ett sammanhang introduceras en fallstudie några veckor in i kursen i vilken du tillsammans med kurskamrater motiverar och föreslår en systemlösning med resurseffektiva komponenter för vatten och avlopp, inklusive dimensionering av vissa delkomponenter. Denna studie redovisas skriftligt och muntligt med en rapport respektive presentation. För att praktiskt få en förståelse för utförande av behandlingskomponenter genomför du tillsammans med kurskamrater en laboration där ni utformar och bygger en prototyp för behandling av BDT-vatten samt testar och utvärderar dess funktion. Funktionen av ert system kommer att redovisas muntligt samt genom en skriftlig rapport. I kursen spelar vi ett brädspel som fokuserar på etablering av sorterande avloppssystem vilket avslutas med en individuell reflektion. Teoretiska aspekter och beräkningskunskaper examineras med en tentamen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursen examineras genom litteraturuppgift, laboration, fallstudie, reflektionsuppgift och tentamen (se tabell nedan). Aktivt deltagande vid redovisning av litteraturuppgift, fallstudie och laboration är obligatoriska. Såvida man inte deltar vid något av de obligatoriska schemalagda tillfällena får dessa genomföras annat läsår, i mån av plats.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen V7013B motsvarar kursen V7012B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Litteraturuppgift | GU345 | 1 | Obligatorisk | H20 |  |
| 0002 | Laboration | GU345 | 1,8 | Obligatorisk | H20 |  |
| 0003 | Fallstudie | GU345 | 1,7 | Obligatorisk | H20 |  |
| 0006 | Reflektionsuppgift | U G# | 0,5 | Obligatorisk | H20 |  |
| 0007 | Skriftlig tentamen | GU345 | 2,5 | Obligatorisk | H20 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-01-11

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-02-14
