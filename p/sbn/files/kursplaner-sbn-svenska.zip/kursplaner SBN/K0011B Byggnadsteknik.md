---
kurskod: "K0011B"
titel: "Byggnadsteknik"
hp: "7,5"
titel_en: "Building Technology"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0011B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0011B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0011b-byggnadsteknik"
---

# Byggnadsteknik (K0011B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kursens mål är att studenten ska kunna

- beskriva, förklara och ge exempel på olika byggnadstekniska         lösningar och byggnadsstilar

- hänvisa till och tolka de byggnadsbestämmelser som reglerar, styr och rekommenderar utformning, innehåll och funktion av byggnader

- tolka byggnadsritningar och därtill göra beräkningar av boarea (BOA) och biarea (BIA) enligt svensk standard

- beskriva orsaker till och effekter av olika byggnadsskador

- ge exempel på olika byggnadsgarantisystem

- tolka och förklara innehållet i energideklarationer

- tolka, förklara och motivera överlåtelsebesiktningar

- upprätta byggnadstekniska beskrivningar

## Kursinnehåll

- byggnadsbestämmelser

    - Boverkets författningssamling

    - Plan- och bygglagen

    - Miljöbalken

- byggnadsteknik

    - olika typer av byggnader (utformning, tidsepoker, funktioner)

    - byggmaterial

    - uppvärmnings- och energisystem, värmelära

    - byggnadsdelar: grunder, stommar, tak, installationer (el, vvs, ventilation)

- byggnadsritningar

    - arkitekt-, konstruktions-, vvs- och elritningar; skalor; mått

- beräkning av boarea (BOA) och biarea (BIA) enligt svensk standard SS 020153

- byggnadsskador

    - fukt, brand, radon, sättningar, skadedjur

- energideklarationer enligt Svensk författningssamling SFS 2006:1592

- reparationer, ombyggnationer och tillbyggnader samt rot-avdrag

- överlåtelsebesiktningar – innehåll, omfattning, dolda fel

- byggnadstekniska beskrivningar: innehåll, saklighet, omfattning

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Studenten deltar på och tar del av lektioner och övningar där bakgrunder, teorier och fakta presenteras och exemplifieras.

Studenterna övar på att upprätta byggnadstekniska beskrivningar i ett projektarbete i grupp där ett verkligt objekt (enfamiljshus eller lägenhet) besöks, undersöks och beskrivs ingående. Arbetet redovisas i en skriftlig rapport. Studenterna tränas även i muntlig redovisning av sitt objekt i ett avslutande seminarium.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Bakgrunder, teorier och fakta examineras med skriftlig tentamen med differentierade betyg. Betygsskala: U, 3, 4, 5.

Byggnadsteknisk beskrivning examineras med skriftlig rapport och muntlig redovisning - seminarium. Betygsskala U, G.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0011B motsvarar kursen U0001B

## Övrigt

Progression: kursen utgör grund för efterföljande kurs i Värderingsteknik

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 3 | Obligatorisk | H07 |  |
| 0005 | Seminarium | UG | 1,5 | Obligatorisk | V27 |  |
| 0006 | Skriftlig rapport | UG | 3 | Obligatorisk | V27 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
