---
kurskod: "B7003K"
titel: "Bioprocessteknik"
hp: "7,5"
titel_en: "Bioprocess Engineering"
giltig: "Höst 2025 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Kemisk apparatteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B7003K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B7003K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/b70/b7003k-bioprocessteknik"
---

# Bioprocessteknik (B7003K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Kursen förutsätter fökunskaper motsvarande grundläggande kunskaper i kemi och fysik, behärskande av dfferentilaekvationer, inledande biokemi, transportprocesser och enhetsoperationer. Motsvarar kurserna K0016K Kemiska principer, B0007K Organisk kemi och biokemi, B0003K Transportprocesser, B0004K Enhetsoperationer och F0004T Fysik 1.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursen ska ge den studerande en introduktion till industriell bioteknik samt ge färdigheter i användning av

mikroorganismer i biotekniska produktionssystem. Efter fullgjord kurs ska studenten kunna:

1. redogöra för teoretiska begrepp inom bioprocessteknik

2. beskriva och förklara enzymers grundläggande funktion och deras betydelse i biokemiska processer.

3. beskriva centrala metaboliska reaktionsvägar samt förklara cellens energiomsättning.

4. förklara vilka faktorer som styr mikrobiell celltillväxt och produktbildning samt utföra beräkningar för detta.

5. matematiskt beskriva bioreaktorer.

6. handha och designa bioreaktorer.

7. beskriva och förklara olika processer för produktutvinning och rening.

8. beskriva vanligt förekommande storskaliga bioprocesser.

9. genomföra, utvärdera och redovisa experimentellt biotekniskt arbete

## Kursinnehåll

Kursen består i stora drag av följande moment:

- Industriell mikrobiologi

- Mikrobiell metabolism

- Enzymkatalys och kinetik

- Fermentationsteknik

- Design och styrning av bioreaktorer

- Processer för produktutvinning

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, räkneövningar samt laborationer. På föreläsningarna diskuteras teori rörande de utvalda momenten. På räkneövningarna löses exempeluppgifter och de på teoriföreläsningarna diskuterade begreppen illustreras. Laborationerna belyser nyckelmoment från föreläsningarna och ska ge studenterna praktiskt erfarenhet av fermentationsteknik.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen bedöms genom en skriftlig tentamen och laboratorierapporter.

Lärandemål 1-8 examineras genom den skriftliga individuell tentamen och inlämning av hemuppgifterna (Betygsskala G U 3 4 5).

Lärandemål 6 och 9 examineras genom laboratorierapporterna (betygsskala U G).

Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

Laborationer har obligatorisk närvaro.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

B7003K motsvarar KGB008 och kan ej kombineras i examen.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 6 | Obligatorisk | H07 |  |
| 0003 | Laborationsrapporter (experimentella) | U G# | 1,5 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
