---
kurskod: "S7018B"
titel: "Tillämpad brandteknik"
hp: "7,5"
titel_en: "Applied Fire Engineering"
giltig: "Vår 2025 Lp 3 - Tills vidare"
beslutsdatum: "2024-09-19"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "U G#"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7018B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7018B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s70/s7018b-tillampad-brandteknik"
---

# Tillämpad brandteknik (S7018B)

## Behörighet

S0003B Branddynamik I, S7002B Branddynamik II och K0017B Tillämpad riskhantering eller motsvarande.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter avslutad kurs ska studenten kunna:

Kunskap och förståelse

1. Redogöra för de grundläggande principerna för funktionsbaserad dimensionering vid brand.

2. Redogöra för strategier för funktionsbaserad dimensionering vid brand.

3. Redogöra för det juridiska ramverk som gäller för funktionsbaserad dimensionering vid brand i Sverige.

Färdighet och förmåga

4. Tillämpa funktionsbaserad dimensionering på brandtekniska utmaningar med analytiska och numeriska verktyg.

Värderingsförmåga och förhållningssätt

5. Utvärdera funktionsbaserade dimensioneringar och bedöma deras utförande.

6. Redogöra för olika funktionsbaserade dimensioneringsstrategiers tillämpning på brandtekniska problem.

## Kursinnehåll

Olika områden som kommer att behandlas inom ramen för kursen kan vara, men är inte begränsat till:

- Klassificering av byggkomponenter

- Utrymningsberäkningar

- Rökfyllnadsberäkningar

- Riskanalys

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Studenterna deltar i föreläsningar där teori och bakgrund till kursinnehållet härleds, presenteras och förklaras.

Teoretiska principer och beräkningar tillämpas av studenterna genom

1. Individuella övningar i klassrum, eller

2. Individuella eller gruppinlämningar i form av projektarbeten.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursen examineras genom ett antal inlämningsuppgifter i form av: skrivna rapporter, beräkningar/projekteringsuppgifter, muntlig framställan, quizzar.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen S7018B motsvarar kursen S7008B

## Övrigt

Kursen motsvarar delar av S7008B. Kursen kan därför inte ingå i en examen tillsammans med den kursen.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G# | 7,5 | Obligatorisk | V25 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-09-19

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-19
