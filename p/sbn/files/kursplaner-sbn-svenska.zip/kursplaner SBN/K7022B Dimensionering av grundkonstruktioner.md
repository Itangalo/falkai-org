---
kurskod: "K7022B"
titel: "Dimensionering av grundkonstruktioner"
hp: "7,5"
titel_en: "Structural Design of Foundations"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Konstruktionsteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7022B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7022b-dimensionering-av-grundkonstruktioner"
---

# Dimensionering av grundkonstruktioner (K7022B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Minst 90 hp avklarade kurser där 30 hp kurser i byggmaterial, konstruktionsteknik, byggkonstruktion och geoteknik ska ingå, t ex K0002B Byggmaterial, B0002B Konstruktionsteknik, K0013B Byggkonstruktion och G0003B Geoteknik gk. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

1. Beskriva vanliga typer av grundkonstruktioner och klassificera de material som vanligtvis används i grundkonstruktioner

2. Identifiera lämplig typ av grundläggning utifrån överbyggnad och markförhållanden.

3. Definiera lämpliga lastkombinationer som krävs för dimensionering av fundament.

Kompetens och färdigheter:

1. Utföra kontroller av fundament för att säkerställa att de uppfyller säkerhets- och normkraven, inklusive bedömning av böj-, skjuv- och genomstansningskapacitet och krav i bruksgränstillstånd.

2. Specifiera nödvändig armering och övrig dimensionering för olika typer av fundament med hänsyn till böj-, skjuv- och genomstansningskapacitet och krav i bruksgränstillstånd.

3. Tolka och tillämpa relevanta byggnadsföreskrifter och standarder för design av fundament, inklusive de som hänför sig till laster, materialegenskaper och säkerhet vid brott- och bruksgränstillstånd (ULS, SLS).

Bedömning och Tillvägagångssätt:

1. Konstatera och hantera strukturella och tekniska svårigheter i samband med val av fundamenttyp, inklusive utmaningar som härrör från markförhållanden och begränsningar inom byggprocessen.

2. Ta fram strukturerade tekniska rapporter och dokumentation relaterade till dimensionering av fundament, inklusive konstruktionsritningar.

## Kursinnehåll

Under denna kurs kommer studenterna att lära sig om:

- Översikt över olika grundkonstruktioner och deras funktion.

- Brottyper för grundkonstruktioner

- Strukturella laster på fundament

- Interaktion mellan mark och konstruktion

- Översikt över relevanta designkoder och standarder

- Tolkning och tillämpning av standarder

- Säkerhetsfaktorer och lastkombinationer

- Plattgrundläggning

- Djupgrundläggning

- Design av stödmurar

- Design av speciella grundtyper

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Denna kurs omfattar instruerande föreläsningar där teorin och de grundläggande begreppen presenteras och illustreras av läraren. Dessutom håller en gästföreläsare, med expertis inom grundkonstruktioner, en dedikerad föreläsning för att dela med sig av sin erfarenhet. Kursen innehåller också seminarier där studenter aktivt engagerar sig i praktiska problemlösningsövningar relaterade till dimensionering. Läraren finns tillgänglig för handledning under dessa seminarier, särskilt för projektarbete. Som en del av kursen får studenterna i uppdrag att individuellt eller i grupp utforma grunden för en byggnad i ett praktiskt projekt.

Föreläsningar: I den här kursen presenteras flera föreläsningar för att förmedla teori och grundläggande principer för dimensionering, där instruktören ger förklaringar och praktiska demonstrationer. Dessa föreläsningar lägger grunden till kunskapsbasen på vilken studenterna bygger sin förståelse.

Gästföreläsare: En gästföreläsare berikar kunskapsresan genom att dela med sig av sin expertis inom området dimensionering av grundkonstruktioner. Detta praktiska perspektiv ger studenterna insikter från en yrkesverksam för att bredda deras förståelse.

Seminarier: En integrerad del av vår kurs består av interaktiva seminarier där studenterna aktivt deltar i problemlösningsövningar centrerade kring dimensionering av fundament. Dessa sessioner ger studenterna chansen att omsätta sina teoretiska kunskaper i praktiken. I de fall elever behöver hjälp finns läraren lättillgänglig för att erbjuda vägledning och stöd.

Projektarbete: En betydande del av denna kurs kretsar kring det praktiska projektet, där studenter, antingen individuellt eller i små grupper, tar sig an utmaningen att utforma en grundkonstruktion. Detta praktiska moment ger studenterna en möjlighet att tillämpa sina färdigheter i ett verkligt sammanhang och skaffa sig värdefulla insikter. Inom ramen för projektuppgiften kommer studenterna också att delta i peer-review-aktiviteter, vilket uppmuntrar till kollaborativt lärande.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Denna kurs examineras genom olika inlämningsformer: skriftliga rapporter, beräknings-/designuppgifter, muntliga presentationer och quizzar.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 7,5 | Obligatorisk | H24 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14
