---
kurskod: "C0022B"
titel: "Samhällets planering för risker och kriser"
hp: "7,5"
titel_en: "Society's planning for hazards"
giltig: "Vår 2015 Lp 3 - Höst 2017 Lp 2"
beslutsdatum: "2014-05-28"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "U G#"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)  Prov Provuppsättning saknas"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=C0022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=C0022B&lasPeriod=187&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/c00/c0022b-samhallets-planering-for-risker-och-kriser"
---

# Samhällets planering för risker och kriser (C0022B)

## Behörighet

Grundläggande behörighet samt 30 hp inom området teknik eller samhällsbyggnad

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Examinator

Glenn Berggård

## Mål/Förväntat studieresultat

Studenten skall ha kunskap om samhällsplanering och dess processer samt kunna delta med riskanalyser i planeringsprocessen.

## Kursinnehåll

Studenten skall i en projektuppgift öva dessa kunskaper om planering på framför allt översiktlig planering och fördjupad översiktsplan. Vissa kunskapsområden kommer dessutom att behandlas på mer detaljerad nivå. Projektarbetet genomförs i grupp där olika roller övas. Parallellt med planeringsuppgiften löper en teoridel vars syfte är att ge kunskaper om hur risker av olika slag kan hanteras i samhällsplaneringen med riskanalyser som utgångspunkt. Denna kursdel skall ge insikt i användning av lagstiftningen som styrmedel för att risker skall beaktas i samhällsplaneringen. Olika centrala, regionala och kommunala myndigheters syn på begreppet ”Riskhänsyn i samhällsplaneringen” skall förstås av studenten. En viktig aspekt utgör koppling mellan miljökonsekvensbeskrivningar – riskhänsyn. I kursen ingår föreläsningar och litteratur som belyser problemen samhällets sårbarhet och beredskapshänsyn i samhällsplaneringen. Projektarbetet redovisas skriftligt och muntligt

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Föreläsningar, övningspass, studiebesök Undervisningen består av föreläsningar, lektioner och seminarier. Deltagande i seminarierna är obligatoriskt.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. För godkänd kurs krävs aktivt deltagande i projektarbete, godkänd muntlig och skriftlig redovisning av projektuppgifter, deltagande i seminarierna samt närvaro vid studiebesök

## Överlappning

Kursen C0022B motsvarar kurser C0023B, C0024B

## Övrigt

Kursen motsvaras av C0011B och kan inte ingå tillsammans i examen

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

Prov Provuppsättning saknas

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Litteratur

*Litteratur. Gäller från Vår 2015 Lp 3* Boverket och Räddningsverket (2006) Säkerhetshöjande åtgärder i detaljplaner. Karlskrona och Karlstad: Boverket och Statens räddningsverk, 2006 Krisberedskapsmyndigheten (2008) Klarar vi krisen? Samhällets krisberedskapsförmåga 2007. KBM:s temaserie 2008:2 Räddningsverket (2004) Riskhantering i Översiktsplaner. Karlstad: Statens räddningsverk, 2001 Myndigheten för samhällsskydd och beredskap (2012) Olycksrisker och MKB. Att integrera risk- och säkerhetsfrågor i MKB-processen Myndigheten för samhällsskydd och beredskap (2011) Vägledning för risk- och sårbarhetsanalyser.

## Kursplanen fastställd

av Eva Gunneriusson, biträdande huvudansvarig utbildningsledare vid Institutionen för Samhällsbyggnad och naturresurser 2014-05-28
