---
kurskod: "T7001B"
titel: "Bergmekanikens grunder"
hp: "7,5"
titel_en: "Fundamentals of Rock Mechanics"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7001B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7001b-bergmekanikens-grunder"
---

# Bergmekanikens grunder (T7001B)

## Ingår i huvudområde

Väg- och vattenbyggnad

## Behörighet

Goda kunskaper i hållfasthetslära. Goda kunskaper i geologi är önskvärda.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

1. genomföra fältförsök med beprövade metoder samt med analytiska, empiriska och numeriska metoder utvärdera berg- och sprickparametrar samt bergmassans kvalitet

2. identifiera strukturellt styrda brottformer i bergslänter och undermarkskonstruktioner med hjälp av sfärisk projektion och ingenjörsgeologiska beskrivningar av bergmassan, och där möjligt kunna beräkna säkerheten mot brott

3. beräkna och utvärdera spänningstillståndet för undermarkskonstruktioner i berg med hjälp av analytiska, empiriska och numeriska modeller samt föreslå optimal geometri och orientering av undermarkskonstruktioner i berg

4. identifiera möjliga brottmekanismer och utifrån det välja och applicera relaterade brottkriterier för att analytiskt, empiriskt och numeriskt kunna analysera och utvärdera stabiliteten hos undermarkskonstruktioner i berg

5. beräkna och utvärdera deformation- och töjningstillståndet för undermarkskonstruktioner i berg med analytiska, empiriska och numeriska modeller

6. identifiera brottformer för belastad berggrund utifrån förenklade geologiska beskrivningar, och där möjligt kunna beräkna säkerheten mot brott

7. redogöra för och diskutera skriftligt sina analyser, modeller, resultat och slutsatser

Efter avslutad kursmodul om jämställdhet ska studenten

8. visa förståelse för de nationella jämställdhetsmålen, regelverk för jämställdhet i arbetslivet samt ge exempel på förutsättning för jämställdhet i arbetslivet.

## Kursinnehåll

Kursen omfattar följande områden:

- Inledning – Kursutformning, studiehandledning, schema, introduktion till ämnet bergmekanik, etc.

- Materialet berg – Teoretiskt och praktiskt arbeta med bergmekanisk förundersökning och bergmasseklassificering, geologiska strukturer i berg och deras betydelse för det mekaniska beteendet, strukturstyrda brott, sfärisk projektion, insamling och analys av fältdata, presentation av ingenjörsarbete och fältdata, etc.

- Spänningar - Primärspänningar och sekundärspänningar. Bergspänningsmätningar. Absoluta och effektiva spänningar. Spänningstillståndet kring underjordsöppningar och slänter. Mohrs spänningscirklar. Ytliga och djupa underjordskonstruktioner behandlas.

- Deformationer och brott i berg - Konstitutiva samband. Brottmekanismer och brottkriterier. Experimentella metoder för att bestämma deformations- och hållfasthetsegenskaper. Mohr’s spänningscirklar och brottkriterier. Mohr’s töjningscirklar. Elasticitetsmodul.

- Analytisk design - Deformationer och spänningar kring underjordsöppningar. Empiriska, analytiska och numeriska metoder behandlas och används. Brott och stabilitet för underjordskonstruktioner och slänter. Brottmekanismer och brottkriterier. Stabilitet vid höga spänningsnivåer.

- Släntstabilitet - Strukturstyrda brottformer i slänter, cirkulärt skjuvbrott i slänt, stabilitetsanalyser av slänter, säkerhetsfaktor, effekten av grundvattentryck och effekten av dränering.

- Belastad berggrund - Brottformer, hållfasthetsberäkningar, säkerhetsfaktor.

- Kursmodul om jämställdhet - De svenska nationella jämställdhetsmålen, reformer som bidragit till ökad jämställdhet, samt grunderna i jämställdhetslagen och diskrimineringslagen. Begrepp som används i jämställdhetsarbete och för fortsatt utveckling av jämställdhetskunskapen. Introduktion till jämställdhetsintegrering inom det tekniska området. Introduktion till resurser för jämställdhetsintegrering och jämställdhetskunskap på arbetsplatser och i tekniska projekt.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av:

- Lektioner - De är en mix av flera undervisnings-/inlärningsaktiviteter: (i) kort teorigenomgång där föreläsaren förklara de viktigaste teoretiska aspekterna relaterade till kursens innehåll och (ii) tillsammans lösa och/eller diskutera typiska bergmekaniska problem samt frågor vilket ger dig möjlighet att på olika sätt arbeta med flera aspekter kring empiriska och analytiska stabilitetsanalyser av olika undermarkskonstruktioner i berg ur en praktisk och teoretisk synvinkel samt träna beräkningsprocedurer för frågeställningar relaterade till dessa.

- Datorövningar - Under dessa arbetar vi i datasal där vi praktisk övar på olika numeriska applikationer och hur de kan användas för att analysera sprickdata, spänningar, deforamtioner och stabiliteten hos undermarkskonstruktioner i berg.

- Fältövning - Här tränas du i att utföra och utvärdera försök i fält samt skriftligt redovisa arbetsgång och resultat.

- Inlämningsuppgifter - Du arbetar tillsammans med andra studenter och använder dina kunskaper för att lösa olika problem. Du presenterar ditt arbete i skriftliga rapporter. Du tränas i att med utgångspunkt från de empiriska och analytiska analyser som utförs samt nyttogörande av föreläsningar, föreslå och motivera hur en bergkonstruktion ska göras stabil.

- Mellan lektionerna - Du förväntas förbereda dig inför varje lektion genom att arbeta igenom rekommenderat materialet, rekommenderade övningar och instuderingsfrågor så att du är beredd att bidra och delta i läraktiviteterna (problemlösning, diskussion, mm) under föreläsningarna och datorövningarna.

- Kursmodulen om jämställdhet består av inspelade föreläsningar samt litteratur.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:

- Skriftliga delprov - Består av frågor som testar din teoretiska kunskap och förståelse för vissa bergmekaniska aspekter relaterade till kursens innehåll.

- Inlämningsuppgifter - Består av problem där du tränar och tillämpar din teoretiska kunskap, förståelse och förmåga samt gör analyser och förklarar dina resultat skriftligt.

- Fältövning - Genom övning i fält samt inlämning av skriftlig lösning.

- Skriftlig tentamen - Du löser problem som liknar de som du stöter på under kursen (i föreläsningar och uppgifter) för att testa din individuella kunskap, förståelse, skicklighet och förmågor. Kurskompendiet är tillåtet hjälpmedel på tentamen.

Mål 1-7 examineras via skriftlig tentamen. Betygsskala: G U 3 4 5.

Mål 1, 2 och 7 examineras via fältövning och laboration. Ingår i övrigt med betygsskalan G U.

Mål 1-7 examineras via skriftliga delprov och inlämningsuppgifter. Ingår i övrigt med betygsskalan G U.

Mål 8 examineras via ett quiz. Ingår i övrigt med betygsskalan G U.

För att blir godkänd på modulen Övrigt krävs att du är godkänd på skriftligt inlämnade inlämningsuppgifter och fältövningen samt godkänd på skriftliga delprov och quizzen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen T7001B motsvarar kursen ABM023

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 3 | Obligatorisk | H07 |  |
| 0002 | Övrigt | U G# | 4,5 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2006-02-13 att gälla från H06.
