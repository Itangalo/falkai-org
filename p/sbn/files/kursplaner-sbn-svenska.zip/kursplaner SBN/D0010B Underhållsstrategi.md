---
kurskod: "D0010B"
titel: "Underhållsstrategi"
hp: "7,5"
titel_en: "Maintenance Strategy"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0010B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0010B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d00/d0010b-underhallsstrategi"
---

# Underhållsstrategi (D0010B)

## Behörighet

Grundläggande behörighet samt D0011B Introduktion till drift- och underhållsteknik eller D0002B Drift och underhåll

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursen syftar till att ge de studerande kunskap om hur underhållsstrategier kan tillämpas för att nå produktionsmål och sätta dessa i relation till övergripande företagsmål. Efter godkänd kurs ska studenten visa färdighet i att ta fram en underhållsstrategi för ett industriellt system genom att utveckla underhållsplaner för ingående enheter.

## Kursinnehåll

Kursen behandlar:

- Underhållsprocess i en industriell organisation

- System- och flödeskartläggning av industriella system

- Anläggningens livscykelkostnader

- Underhållsmål i relation till företagsmål

- Metoder och principer för förebyggande underhåll

- Funktionssäkerhetsinriktat underhåll (RCM)

- Arbetssätt för att utveckla en underhållsstrategi

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisning består av seminarier och inlämningsuppgifter. Det förutsätts att studenten förbereder sig inför seminarium genom att gå igenom anvisat material. Ett aktivt deltagande på seminarium förväntas. Inlämningsuppgifterna genomförs enskilt och i grupp. Obligatorisk närvaro vid muntlig presentation av inlämningsuppgift.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Skriftlig tentamen, aktivt deltagande vid seminarier och godkända inlämningsuppgifter.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Seminarium/inlämningsuppgifter | GU345 | 7,5 | Obligatorisk | H21 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2014-02-13
