---
kurskod: "D0002B"
titel: "Drift och underhåll"
hp: "7,5"
titel_en: "Operation and Maintenance"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-04-20"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0002B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d00/d0002b-drift-och-underhall"
---

# Drift och underhåll (D0002B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Underhållsteknik

## Behörighet

Grundläggande behörighet samt Linjär algebra och integralkalkyl (M0048M) och Matematiskt statistik (S0001M) eller motsvarande.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Målet med kursen är att ge studenterna kunskap om och förståelse för begrepp, teorier och metoder i underhållsteknik. Efter genomförd kurs ska studenten ha färdigheter att utföra analyser för en tillförlitlig och ekonomisk drift av olika verksamheter. Kunskaperna kan tillämpas för de som är verksamma inom infrastruktur, bygg och anläggning.

## Kursinnehåll

Kursen innehåller:

- Underhålls- och driftsäkerhetsbegrepp

- Beräkning av tillgänglighet och funktionssäkert hos serie- och parallellsystem

- Tillståndsövervakning och tillståndbaserat underhåll

- Prediktionsmodeller för skattning av återstående livslängd

- Livscykelkostnadsanalys

- Underhållsorganisation, beställar- och entreprenörsrelation

- Metoder för riskanalys och underhållsplanering

- Underhållstillämpningar för väg, järnväg, bro, bygg och anläggning

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, grupparbeten, seminarium och laborationer.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Godkända inlämningsuppgifter. Skriftlig tentamen med differentierade betyg.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen D0002B motsvarar kursen ABD004

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Skriftlig tentamen | GU345 | 4 | Obligatorisk | H07 |  |
| 0005 | Grupparbeten/inlämningsuppgifte r | UG | 3,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-04-20

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
