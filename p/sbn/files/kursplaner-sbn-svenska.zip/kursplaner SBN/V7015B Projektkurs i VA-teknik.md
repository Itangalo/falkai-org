---
kurskod: "V7015B"
titel: "Projektkurs i VA-teknik"
hp: "7,5"
titel_en: "Senior Design Project in Urban Water Engineering"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "UG"
amne: "VA-teknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V7015B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/v70/v7015b-projektkurs-i-va-teknik"
---

# Projektkurs i VA-teknik (V7015B)

## Ingår i huvudområde

Samhällsbyggnadsteknik

## Behörighet

Minst 60 hp inom miljö-, samhällsbyggnads-, eller naturresursteknik. Grundläggande kurser som berör urbana VAsystem, exempelvis V0016B VA-system. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2. För utbytesstudenter gäller att examinator gör individuell prövning av behörigheten beroende på typ av projekt.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter avslutad kurs skall studenten kunna:

- självständigt beskriva ett specifikt ämnesområde inom VA-teknik,

- avgränsa ett specifikt ämnesområde länkat till VA-teknik,

- självständigt arbeta med frågor inom VA-teknik som icke är väl dokumenterade eller beskrivna i tillgänglig litteratur,

- skriva en vetenskaplig rapport,

- ge en muntlig presentation.

## Kursinnehåll

Kursen fokuserar på ett aktuellt tema inom VA-teknik. Innehållet avgörs beroende på frågeställning från fall till fall och frågeställningarna som berörs ska uppvisa viss komplexitet. Självständigt arbete genomsyrar kursen.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen genomförs som ett individuellt arbete där studenten arbetar självständigt med att lösa ett problem inom VAteknik som antingen är självvalt eller valt tillsammans med handledaren. Studenten ska kontakta kursexaminator i god tid före kursstart för bedömning av förkunskapskrav och för att komma fram till lämpligt projekt. Problemet är av sådan art att en direkt lösning inte finns tillgänglig i litteraturen. Inom ramen för kursen ska en rapport med vetenskapligt upplägg skrivas och en muntlig presentation ges.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursens mål examineras genom en skriftlig rapport och muntlig redovisning.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Projektrapport | UG | 6,5 | Obligatorisk | V27 |  |
| 0004 | Muntlig presentation | UG | 1 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02
