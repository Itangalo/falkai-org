---
kurskod: "G7008B"
titel: "Geoteknik fk"
hp: "7,5"
titel_en: "Soil Mechanics, Advanced Course"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7008B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7008B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7008b-geoteknik-fk"
---

# Geoteknik fk (G7008B)

## Ingår i huvudområde

Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

Grundkurs i geoteknik eller geomekanik, Väg- och järnvägsbyggnad.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Under kursens gång ska fördjupade kunskaper inom någon eller några delar av ämnet geoteknik förvärvas och därutöver ska en kontakt med något aktuellt forskningsområde inom ämnet erhållas. Kursen strävar efter att behandla några väsentliga områden som kan vara lämpliga för kommande examensarbete.

## Kursinnehåll

Jorddynamik och geoteknik relaterat till jordbävningar (30%). Harmonisk oscillator och principerna för jorddynamik. Vågutbredning. Elastiskt beteende. Grunderna i geoteknik relaterat till jordbävningar. Vibrationer. Likvifiering. Åtgärder.

Hållfasthets- och deformationsegenskaper hos jord - konstitutiv modellering (30%). Metoder för att bestämma hållfasthets- och deformationsegenskaper i jord. Jords beteende under kompression och skjuvning. Reversibel och irreversibel deformation. Kontraktans, dilatans och kritiskt tillstånd. Triaxialförsök för bestämning av hållfasthets- och deformationsegenskaper. Konstitutiva modeller, plasticitet. Cam clay. Datorlaboration.

Släntstabilitet och skred (30%). Skredmekanismer. Numeriska beräkningsmetoder i geoteknik (20%). Datorlaboration med kommersiellt finita elementprogram (PLAXIS). Fokus på dränerad analys.

Fallstudie (ca 10%). Några föreläsningar av yrkesverksamma geotekniker.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Lektioner. konstruktionsuppgifter och laborationer. Självständig kunskapsinhämtning, sammanställning och värdering av information i ett valt ämne samt författande av en seminarieuppsats. Muntlig presentation av uppsatsen med tillhörande opposition vid ett särskilt seminarium.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examinationen sker utifrån redovisningen av konstruktionsuppgifterna, laborationerna och seminarieuppgiften. Hänsyn tas till såväl den skriftliga rapporten som till det muntliga framförandet. Kursen betygssätts med differentierade betyg.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen G7008B motsvarar kurser ABG112, ABG105

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Seminarieuppsats | U G# | 3,8 | Obligatorisk | H07 |  |
| 0002 | Konstruktionsuppgifter | U G# | 3,7 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
