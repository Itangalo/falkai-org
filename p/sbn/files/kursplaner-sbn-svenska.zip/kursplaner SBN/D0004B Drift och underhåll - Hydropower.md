---
kurskod: "D0004B"
titel: "Drift och underhåll - Hydropower"
hp: "7,5"
titel_en: "Operation and Maintenance - Hydropower"
giltig: "Höst 2026 Lp 1 - Tills vidare"
beslutsdatum: "2026-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0004B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d00/d0004b-drift-och-underhall---hydropower"
---

# Drift och underhåll - Hydropower (D0004B)

## Behörighet

Grundläggande behörighet samt 60 högskolepoäng i tekniska ämnen

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Målet med kursen är att erhålla kunskap om och förståelse för begrepp, metoder och teorier i underhållsteknik. Vid avslutad kurs ska studenten:

Kunskap och förståelse:

1. kunna redogöra för definitioner och grundläggande begrepp i driftsäkerhet och underhållsteknik

2. visa kunskap om underhållsprocessen, underhållsmål, underhållsstrategier och nyckeltal inom tillgångsförvaltning (Asset Management)

3. kunna beskriva uppbyggnad, drift och underhåll av vattenkraftsystem

Kompetens och färdigheter:

4. kunna utföra tillförlitlighetsanalys och livscykelkostnadsanalys

5. kunna tillämpa metoder för tillståndsövervakning av roterande maskiner

6. kunna tillämpa metoder för riskanalys inom drift- och underhållsteknik

## Kursinnehåll

Kursen omfattar:

- Definitioner och grundläggande begrepp
- Underhållsprocessen i tillgångsförvaltning (Asset Management)
- Underhållsstrategi: policy, underhållsmål och nyckeltal
- Funktionssäkerhetsinriktat underhåll (RCM) och FMECA
- Underhållsmässighet och mänskligt felhandlande
- Beräkning av tillgänglighet och funktionssäkert (serie och parallellsystem)
- Livscykelkostnadsanalys (LCC)
- Systemkännedom och underhåll inom vattenkraft
- Tillståndsövervakning och tillståndsbaserat underhåll
- Underhållstillämpningar inom vattenkraft och roterande maskiner

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. I kursen varvas teoretiska föreläsningar och inläsning med inlämningsuppgifter, muntlig redovisning och seminarier. Det förutsätts att studenten förbereder sig inför seminarierna genom att gå igenom anvisat material. Aktivt deltagande vid obligatoriska seminarier förväntas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För att erhålla godkänt betyg på kursen måste inlämningsuppgifter och seminarier vara avslutade med godkänt betyg.

- Inlämningsuppgifter bedömer kunskaper, färdighet och förmåga relaterat till målen (3-6)

- Seminarierna examinerar kunskap och förståelse som beskrivs i målen (1-2)

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen D0004B motsvarar kursen ABD012

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Inlämningsuppgifter | GU345 | 4 | Obligatorisk | H26 |  |
| 0006 | Seminarier | GU345 | 3,5 | Obligatorisk | H26 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13

## Kursplanen fastställd

av Department of Civil and Environmental Engineering 2007-01-31
