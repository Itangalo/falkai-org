---
kurskod: "F0022B"
titel: "Gestaltning och funktion"
hp: "7,5"
titel_en: "Design and Function"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2026-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "GU345"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F0022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F0022B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/f00/f0022b-gestaltning-och-funktion"
---

# Gestaltning och funktion (F0022B)

## Ingår i huvudområde

Arkitektur

## Behörighet

Grundläggande behörighet samt Minst 60 hp avklarade kurser inom teknikområdet Arkitektur inklusive kunskaper om:
- användning av olika skalor och ritningstyper, t.ex. avklarat kursen F0007B Teknisk Arkitektur eller motsvarande
- Kunskaper i skiss- och rittekniker, t.ex. avklarat kursen D0054A Skiss- och rittekniker eller motsvarande
- Kunskaper om den arkitektoniska designprocessen för olika kontexter, t.ex. avklarat kurserna F0012B Konceptuell design och F0021B Urban design eller motsvarande

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

- Visa kunskap om gestaltning för funktion och upplevelser av byggnader och bebyggelsemiljöer.

- Beskriva former, volymer och proportioner mellan olika element i en byggnad och bebyggelsemiljöer.

Färdighet och förmåga

- Använda metoder för att utarbeta program för innehåll som kan omsättas i väl fungerande, estetiskt tilltalande fysisk gestaltning.

- Förstå hur regler och grundläggande krav som ställs på långsiktig hållbarhet, användbarhet och tillgänglighet implementeras vid gestaltning av byggnader och bebyggelsemiljöer.

- Sätta samman program för byggnad och bebyggelsemiljö i en given kontext.

Värderingsförmåga och förhållningssätt

- Beskriva samspelet mellan arkitektonisk gestaltning och teknik i byggnader och bebyggelsemiljöer.

- Redovisa gestaltningsförslag visuellt, muntligt, och skriftligt.

## Kursinnehåll

Kursen behandlar processer för att utveckla en förståelse för olika byggnads- och stadsbyggnadstypologier. Detta görs genom teorier om skissmetodik och kommunikation via visualisering. Kursen utforskar utarbetande av program för gestaltning av byggnader och bebyggelsemiljöer i olika skalor och detaljeringsnivåer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen inkluderar föreläsningar, seminarier, studiebesök, studioarbete, muntliga presentationer och gruppkritik av en annan grupps projektarbete. Föreläsningar och litteratur åskådliggör olika infallsvinklar för att analysera olika byggnads- och stadsbyggnadstypologier. Studioarbetet är utformat för att ge vägledning i skissmetodik och kommunikation genom visualisering. Genom projektuppgiften kommer studenterna att använda kunskap om att förbereda program för gestaltning av byggnader och bebyggelsemiljöer i olika skalor och detaljeringsnivåer. Studentgrupperna ska särskilt utveckla en högkvalitativ, grafisk poster som redovisning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen mål examineras genom ett projektarbete och seminarier. För att bli godkänd på kursen krävs aktivt deltagande i projektarbetet, godkänd muntlig/poster redovisning, samt deltagande i studiebesök. Kritik av en annan grupps posterredovisning ska också genomföras. Betyg G/U ges för seminarierna. Betygen för projektarbetet är G/U 3 4 5.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektarbete | GU345 | 6 | Obligatorisk | V27 |  |
| 0003 | Seminarier | UG | 1,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13
