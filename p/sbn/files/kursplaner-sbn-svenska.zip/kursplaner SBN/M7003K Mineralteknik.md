---
kurskod: "M7003K"
titel: "Mineralteknik"
hp: "7,5"
titel_en: "Mineral Processing"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2022-06-15"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Mineralteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7003K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7003K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/m70/m7003k-mineralteknik"
---

# Mineralteknik (M7003K)

## Ingår i huvudområde

Kemiteknik, Geovetenskap

## Behörighet

90hp inom kemiteknik. Kursen M0001K Fysikaliska separationsmetoder ska ingå.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursen syftar till att ge en möjlighet att förstå mineraltekniska processer för beredning av malmer, industrimineral, mineralbränslen och återvinningprodukter. Efter fullgjord kurs skall eleven kunna:
- beräkna tekniskt-ekonomiska samband för utvinning av mineralråvaror,
- beskriva och förklara vanligen förekommande processer inom mineralteknik,
- analysera orsaker till gjorda processval utifrån råvarans egenskaper,
- generalisera kunskaper om processförhållanden till att ge förslag till processval för hypotetiska råmaterial.

## Kursinnehåll

Beredning av malmmineral. * Magnetit- och hematitmalmer. Malmer för legeringsmetaller. Flotationsteori. Autogenmalning. Kopparmalmer, bly- och zinkmalmer samt komplexa sulfidmalmer. Ädelmetallmalmer. * Datorlaboration: Massbalansering. * Räkneövningar: Gränshalter och selektivitet. Flotation. Produkt- och vattenbalans. Anrikningsutbyte.

Partikelteknologi. * Mekanisk nedbrytning av mineral. Reaktioner med vätskor och gaser. Upplösning. Utfällning. Reologi för suspensioner och partikelsamlingar. Porositet och porstorleksfördelning. Skärhållfasthet och mekaniska egenskaper. Hantering av bulkmaterial. Ultrafin malning.

Beredning av industrimineral och mineralbränslen. * Ballastmaterial för väg och betong. Kalk, cement och andra bindemedel. Tegel, gasbetong, lättviktsbetong. Glas och isoleringsmaterial samt andra byggmaterial. Keramiska produkter. Eldfasta produkter. Pigment och fyllmedel. Beredning av stenkol.

Miljöfrågor. * Hantering och deponering av anrikningsavfall. Processvatten.

Återvinning. * Användning av mineraltekniska metoder för återvinning av industri- och konsumentprodukter. Jordtvätt och marksanering. Utvalda återvinningsprocesser.

Management och ekonomi. * Aktuella teman. * Räkneövningar: Intäkter, Teknisk-ekonomiska beräkningar, Kostnadsanalys.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, inlämningsuppgifter, datorlaboration, räkneövningar och studiebesök. Deltagande är obligatoriskt i samtliga moment utom i föreläsningarna. Föreläsningarna skall ge möjlighet för eleverna att kunna beskriva och förklara verkningssättet för industriprocesser samt att kunna redogöra för teoretiska begrepp. Inlämningsuppgifterna, som introduceras under räkneövningarna, tränar eleven att självständigt utföra beräkningar och tekniska sammanställningar. Datalaborationen utförs gruppvis. Eleverna tränas att i grupp ställa upp indata för, utvärdera, och rapportera datoriserade materialbalanser. Studieresorna skall ge möjlighet för eleverna att kunna redogöra för industriellt processtekniska sammanhang.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Skriftlig deltentamen efter läsperiod I och muntlig sluttentamen efter kursens slut. Skriftlig deltentamen skall vara avlagd före den muntliga sluttentamen. Den teoretiska förståelsen för ämnesinnehållet kontrolleras med skriftlig och muntlig tentamen med graderade betyg i skala 3 4 5. För betyg 3 skall eleven kunna beskriva och förklara vad som förekommer inom ämnet och utföra rutinmässiga beräkningar. För betyg 4 skall eleven kunna analysera orsaker till gjorda processval utifrån råvarans egenskaper. För betyg 5 skall eleven kunna tillämpa sina kunskaper på delvis nya teoretiska och praktiska problemställningar.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och

som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen M7003K motsvarar kursen KGM003

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen, Lp 1 skriftlig | GU345 | 2,4 | Obligatorisk | H07 |  |
| 0002 | Muntlig tentamen, Lp 2 | GU345 | 3 | Obligatorisk | H07 |  |
| 0003 | Laboration och räkneövning | U G# | 1,5 | Obligatorisk | H07 |  |
| 0004 | Studieresa | U G# | 0,6 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-06-15

## Kursplanen fastställd

av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28
