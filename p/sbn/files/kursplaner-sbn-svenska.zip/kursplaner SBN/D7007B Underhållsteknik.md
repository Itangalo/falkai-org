---
kurskod: "D7007B"
titel: "Underhållsteknik"
hp: "7,5"
titel_en: "Maintenance Engineering"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2022-06-15"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7007B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7007B&lasPeriod=216&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7007b-underhallsteknik"
---

# Underhållsteknik (D7007B)

## Ingår i huvudområde

Underhållsteknik

## Behörighet

Kurser om minst 60 hp i några av de följande områdena ska ingå: Drift och underhållsteknik, Energiteknik, Maskinteknik, Materialteknik, Väg- och vattenbyggnad, Träteknik eller motsvarande kunskaper, samt minst 15 hp i matematik.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Syftet med denna kurs är att ge kunskap om teori och tillämpning av drift- och underhållsteknik för system, process och infrastruktur. Efter genomförd kurs ska studenten kunna:

- definiera och visa insikt i olika definitioner av tillförlitlighet och underhållsteknik

- reflektera över olika typer av underhållsstrategier

- förstå driftsäkerhet och förklara förhållandet mellan dess olika moduler; funktionssäkerhet, underhållsmässighet, underhållssäkerhet, tillgänglighet och säkerhet (RAMS)

- bestämma olika risker under underhållsprocessen

- motivera val av metoder för underhållsbeslut

- beräkna kostnader under en anläggnings olika livscykelfaser

- integrera RAMS-, livscykelkostnads- och riskanalys vid underhållsbeslut

- utvärdera olika underhållsscenarier med hjälp av modellering och optimering

## Kursinnehåll

- Grundläggande begrepp inom underhållsteknik, som inkluderar teori, process och underhållsplanering

- Tillförlitlighets- och RAMS-analys

- Livscykelkostnad (LCC)

- Riskanalys

- Underhållsmål och strategiutformning

- Operatörsunderhåll (TPM)

- Funktionssäkerhetsinriktat underhåll (RCM)

- Tillståndsbaserat underhåll (CBM)

- Ut- och inkontraktering

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen tillämpar flipped classroom med konstruktiv länkning mellan kursmål och aktiviteter. Det förutsätts att studenten förbereder sig inför föreläsningen. Kursen genomförs genom både individuella uppgifter, gruppuppgifter och diskussioner på samarbetsplattformar. Ett aktivt deltagande i seminarium förväntas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursmålen bedöms genom inlämningsuppgifter, aktivt deltagande i seminarier, fallstudie och skriftlig tentamen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0004 | Skriftlig tentamen | GU345 | 3 | Obligatorisk | H21 |  |
| 0005 | Seminarier och inlämningsuppgifter | GU345 | 4,5 | Obligatorisk | H21 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-06-15

## Kursplanen fastställd

av Eva Gunneriusson 2016-01-19
