---
kurskod: "G7015B"
titel: "Jorddynamik och naturliga geotekniska faror"
hp: "7,5"
titel_en: "Soil Dynamics and Geotechnical Natural Hazards"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7015B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7015b-jorddynamik-och-naturliga-geotekniska-faror"
---

# Jorddynamik och naturliga geotekniska faror (G7015B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

90hp i väg- och vattenbyggnad varav kursen G0003B Geoteknik, gk eller motsvarande ska ingå. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

- ILO1: Introducera studenterna till koncept kring risk, faror och konsekvenser relaterat till geotekniska naturliga faror.

- ILO2: Förklara mekaniska modellers generella koncept vad gäller tillämpning vid analys av naturliga faror som tex. jordbävningar.

- ILO3: Inse sambandet mellan jordmekanik och geotekniska aspekter av jordbävningsteknik. Förstå konsekvenserna av – och valet samt design av förebyggande åtgärder mot effekter av jordbävningar.

- ILO4: Förstå mekanismen kring gravitationsdrivna faror. Bedöma potentiella konsekvenser och åtgärder.

- ILO5: Relatera inverkan av klimatförändringar och extrema meteorologiska händelser till gravitationsdrivna faror, permafrost, översvämningar och tex. havsnivåhöjning.

- ILO6: Identifiera faror framkallade av mänsklig aktivitet samt analysera interaktion mellan orsak och verkan.

- ILO7: Ta ställning till värdet av forskning inom naturliga faror och göra det möjligt för studenterna att läsa och förstå komplex och omfattande vetenskaplig litteratur. Studenten ska genom ett kritiskt förhållningssätt granska information som är öppen för allmänheten.

## Kursinnehåll

Denna kurs behandlar olika naturliga farors inverkan på det byggda samhället. Dessa delar ingår i kursen:

- Introducera studenterna till kursen och till grundläggande riskanalys relaterad till naturliga faror och konsekvenser.

- Grundläggande kunskap inom jorddynamik inklusive enkla mekaniska modeller samt vågutbredning.

- Effekten av jordbävningar samt säkerhetshöjande åtgärder.

- Gravitationsdrivna faror orsakade av extrema meteorologiska händelser.

- Åtgärder mot översvämningar

- Faror framkallade av mänsklig aktivitet.

- Konsekvens av klimatförändringar på permafrost samt andra naturliga faror.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av:

- Lektioner: De är en blandning av flera undervisnings-/inlärningsaktiviteter: (i) kort teorigenomgång där föreläsaren förklarar de viktigaste teoretiska aspekterna relaterade till kursens innehåll och (ii) tillsammans diskutera typiska fenomen relaterade till naturliga faror inom geotekniken, vilket ger studenterna möjlighet att tillämpa den teoretiska kunskapen samt diskutera frågeställningar och analysera verkliga händelser.

- Datorövningar: Studenterna får en inblick i olika numeriska applikationer.

- Inlämningsuppgifter: Studenterna samarbetar och använder inhämtad kunskap för att lösa olika problem. Arbetet presenteras genom skriftliga konstruktionsuppgifter samt en seminarieuppgift. Studenterna tränar på problemlösning samt att redogöra för arbetet i skriftlig och muntlig form.

- Mellan lektionerna: Studenterna förväntas och uppmuntras att förbereda sig inför lektionerna genom att ta del av rekommenderat material, rekommenderade uppgifter eller genom att använda information som är tillgänglig för allmänheten för att kunna bidra till och aktivt delta i diskussionerna under lektionerna.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Examinationen sker utifrån redovisningen av konstruktionsuppgifterna och seminarieuppgiften:

- Konstruktionsuppgifter: Består av problem där studenten över och tillämpar teoretisk kunskap, förståelse samt förmåga att utföra och förklara analyser i skriftlig form. Detta återkopplar till ILO 2+5 samt ILO 4-5, medan ILO 6 kan vara orsaken till den naturliga faran. Följande mål/ILO examineras i de olika uppgifterna:

    - Konstruktionsuppgift 1, ILO 7 och ILO 3-6, med särskild fokus på hur det kritiska förhållningssättet till inhämtad information görs (ILO 7)

    - Konstruktionsuppgift 2, ILO 2+3

    - Konstruktionsuppgift 3, ILO 4+5

- Seminarieuppgift: ILO 7 och ILO 3-6. Hänsyn tas till såväl den skriftliga rapporten som till det muntliga framförandet samt opposition vid redovisningstillfället.

Kursen betygssätts med differentierade betyg.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Konstruktionsuppgifter | UG | 5 | Obligatorisk | V27 |  |
| 0004 | Seminarieuppgift | UG | 2,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11
