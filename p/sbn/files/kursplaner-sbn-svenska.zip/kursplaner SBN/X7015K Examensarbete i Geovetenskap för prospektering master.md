---
kurskod: "X7015K"
titel: "Examensarbete i Geovetenskap för prospektering, master"
hp: "30"
titel_en: "Degree Project in Exploration Geosciences, Master"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A2E"
betygsskala: "UG"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X7015K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X7015K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/x70/x7015k-examensarbete-i-geovetenskap-for-prospektering-master"
---

# Examensarbete i Geovetenskap för prospektering, master (X7015K)

## Behörighet

Minst 60 hp avklarade kurser av examensfordringarna. Utsedd examinator avgör om studenten har den fördjupning som krävs för det föreslagna examensarbetet. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens övergripande mål är att studenten skall öva, utveckla och visa färdigheter i att på ett korrekt sätt tillämpa teori och metod för att lösa ostrukturerade problem inom huvudområdet geovetenskap.

Detta innebär att studenten efter kursen ska kunna:

- Formulera en relevant problemställning utifrån ett valt ämne inom huvudområdet geovetenskap.

- Tillämpa kunskaper och färdigheter som har förvärvats under studietiden för ett komplext utvecklings- eller mindre forskningsprojekt på ett självständigt och systematiskt sätt.

- Välja och motivera metod för studien med tydlig förståelse för valens inverkan på studiens resultat

- Utan fullständig information på ett vetenskapligt korrekt sätt analysera och besvara formulerad problemställning.

- Finna och kritiskt värdera information och sammanfatta denna på ett vetenskapligt sätt.

- Planera, strukturera och genomföra ett forsknings- eller utvecklingsarbete.

- Bedöma den vetenskapliga relevansen av erhållna resultat

- Arbeta efter tidplan.

- Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt.

- Utforma och genomföra en presentation där arbetets resultat och slutsatser redovisas och försvaras.

- Kritiskt granska andra studier på ett konstruktivt och vetenskapligt sätt.

## Kursinnehåll

Innehållet i examensarbetet utformas i dialog med handledare. Examensarbetet innehåller alltid en teoretisk uppbyggnad i form av en litteraturstudie som belyser teknikområde och metodik, sammanfattad på ett vetenskapligt sätt.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten genomför och planerar självständigt examensarbetet med handledare som stöd. I examensarbetet ingår att göra en tidplan för hela projektet som kontinuerligt följs upp.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

- Skriftlig presentation av eget arbete.

I rapporten skall studenten visa förmåga att:

    - Motivera den valda problemställningen

    - Välja och motivera metod för studien med tydlig förståelse för valens inverkan på studiens resultat

    - Med tydlig koppling till vald teori/metod samla in information relevant för problemformuleringen

    - På ett relevant sätt skriftligt presentera den insamlade informationen

    - Utifrån vald teori/metod på ett korrekt sätt analysera och besvara formulerad problemställning

    - Med ett kritiskt förhållningssätt bedöma den vetenskapliga relevansen av erhållna resultat

    - Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt.

- Muntlig presentation av eget arbete

- Opponering på annans arbete

- Närvara vid presentationer av andra examensarbeten.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Institutionen tillhandahåller aktiv handledning under två terminer från kursstart.

Examensarbetet utförs företrädesvis enskilt och endast i undantagsfall med maximalt två deltagande studenter.

I de fall där examensarbetet utförs av två studenter skall detta synas i rapportens omfång och djup.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Opponering av annat examensarbete | UG | 0 | Obligatorisk | V27 |  |
| 0006 | Start av examensarbete | UG | 0 | Obligatorisk | V27 |  |
| 0007 | Godkänd rapport | UG | 30 | Obligatorisk | V27 |  |
| 0008 | Muntlig presentation | UG | 0 | Obligatorisk | V27 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
