---
kurskod: "B7004B"
titel: "Byggnadsmekanik I"
hp: "7,5"
titel_en: "Structural Mechanics I"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Konstruktionsteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B7004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B7004B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/b70/b7004b-byggnadsmekanik-i"
---

# Byggnadsmekanik I (B7004B)

## Ingår i huvudområde

Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

Grundläggande kurs i balkteori, tex B0002B Konstruktionsteknik

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens mål är att studenten ska kunna

- förklara skillnaden mellan statiskt bestämda och statiskt obestämda bärverk

- beräkna snittkrafter (normalkrafter, tvärkrafter och moment) i statiskt obestämda 2-dimensionella fackverk och ramar

- beräkna deformationer (förskjutningar och rotationer) i statiskt obestämda 2-dimensionella fackverk och ramar

- tillämpa och bestämma influenslinjer för att beräkna snittkrafter av rörliga laster på 1-dimensionella statiskt bestämda och obestämda bärverk

- beräkna snittkrafter och påkänningar av vridning av cirkulära tvärsnitt och av skev böjning

- bestämma huvudtröghetsmoment

- planera och utföra beräkningsuppgifter i grupp, bearbeta resultat och presentera dem skriftligt (beräkningsrapport)

## Kursinnehåll

Snittkrafter och deformationer i statiskt obestämda 2-dimenionella fackverk och ramar med

- Energimetoder:

    - Castiglianos sats

    - Minsta arbetets princip

    - Virtuella arbetets princip

- Förskjutningsmetoden

- Kraftmetoden

Snittkrafter av rörliga laster på 1-dimensionella statiskt bestämda och obestämda bärverk med

- tillämpning av kända influenslinjer

- framtagning av nya influenslinjer med generella principer för en eller flera punktlaster och för utbredda laster.

Snittkrafter och påkänningar av vridning för statiskt bestämda och obestämda element med cirkulära tvärsnitt.

Huvudtröghetsmoment för icke-symmetriska och sammansatta tvärsnitt.

Spänningar av skev böjning.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Studenterna deltar på föreläsningar där bakgrunder och teorier till kursinnehållet härleds, presenteras och exemplifieras.

Studenterna övar beräkningsmetodik till kursinnehållet

- enskilt på övningspass i klassrum och i datorsal för enklare bärverk (ett fåtal element)

- i grupp för större bärverk, dels i en konstruktionsuppgift där ett fackverk konstrueras och beräknas, dels i två projektuppgifter där två olika ramar analyseras med datorprogram.

Studenterna övar förmågan att planera, genomföra och redovisa beräkningsuppgifter i grupp i en konstruktionsuppgift och i två projektuppgifter.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Bakgrund och teorier examineras med skriftlig halvtidstentamen (dugga). Beräkningsmetodik för enklare bärverk (ett fåtal element) examineras med skriftlig sluttentamen. Resultaten från de två tentorna summeras. Betygsskala: U, 3, 4, 5.

Beräkningsmetodik för större bärverk examineras genom skriftliga beräkningsrapporter för konstruktionsuppgiften och projektuppgifterna. För godkänt på kursen krävs godkända beräkningsrapporter.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen B7004B motsvarar kursen B0004B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 6 | Obligatorisk | V11 |  |
| 0004 | Uppgifter | UG | 1,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Lars Bernspång 2010-03-01
