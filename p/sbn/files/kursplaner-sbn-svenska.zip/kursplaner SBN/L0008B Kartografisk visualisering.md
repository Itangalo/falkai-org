---
kurskod: "L0008B"
titel: "Kartografisk visualisering"
hp: "7,5"
titel_en: "Cartographic Visualization"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2023-06-02"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "UG"
amne: "Geografisk informationsteknologi"
amnesgrupp_scb: "Geografisk informationsteknik och lantmäteri"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0008B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0008B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0008b-kartografisk-visualisering"
---

# Kartografisk visualisering (L0008B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten:

- kunna producera bättre och mer informativa kartor,

- ha en fördjupad kännedom om metoder och tekniker för visualisering av geografiska data från olika datakällor, med fokus på praktisk tillämpning.

## Kursinnehåll

- Kartografiska grundregler - Visuella variabler - Generalisering - Symbolhantering - Färgsystem och färgsättning - Textsättning - Layout - Presentation av statistik - Kartor från olika datakällor - Kartor för olika media, Webb, Mobiltelefoner

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Allt kursmaterial och programvaror finns under LTU’s Citrixportal och där hittas mer detaljerade beskrivningar över kursens innehåll och dess genomförande. Det finns inga inspelade föreläsningar och det är inte några obligatoriska sammankomster. Föreläsningar ges i textform.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursens mål examineras med inlämningsuppgifter som görs individuellt eller i grupp om två personer samt projektuppgift som görs individuellt, som examineras under kursens gång. Betygssättning av inlämningsuppgifter och projektuppgift sker enligt betygsskala U/G. Samtliga inlämningsuppgifter ska vara avklarade för slutbetyg. Inlämningsuppgifterna finns under LTU’s Citrixportal.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen L0008B motsvarar kursen ABL030

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Inlämningsuppgifter | UG | 4,5 | Obligatorisk | V27 |  |
| 0004 | Projektarbete | UG | 3 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
