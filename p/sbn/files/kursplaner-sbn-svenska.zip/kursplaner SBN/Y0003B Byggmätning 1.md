---
kurskod: "Y0003B"
titel: "Byggmätning 1"
hp: "7,5"
titel_en: "Basic surveying"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "U G VG *"
amne: "Geografisk informationsteknologi"
amnesgrupp_scb: "Geografisk informationsteknik och lantmäteri"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=Y0003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=Y0003B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/y00/y0003b-byggmatning-1"
---

# Byggmätning 1 (Y0003B)

## Behörighet

Grundläggande behörighet samt Y0008B Verktyg för byggkalkyler och rapporter

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursen syftar till att utveckla grundläggande kunskaper om, och praktiska färdigheter i, detaljmätning (inmätning generellt, utsättning speciellt) i samband med byggande av hus och anläggningar. Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

Beskriva grunderna i framtagande av utsättningsdata och praktisk utsättning med GPS.

Känna till och förstå innebörden av olika koordinatsystem, GPS-system och maskinstyrning.

Läsa mängdförteckningar och tekniska beskrivningar som används inom bygg- och anläggningsverksamhet.

Färdighet och förmåga

Hantera totalstation, GNSS-utrustning samt avvägningsinstrument och anläggningslasrar

Tillämpa vanliga mjukvaror och överföra resultat mellan instrument och datorer.

Utföra enklare utsättning och inmätning.

Läsa ritningar och genomföra referenslinjeutsättning för hus.

## Kursinnehåll

Kursen behandlar följande:

Instrumentlära (GNSS, totalstation, samt avvägningsinstrument och anläggningslasrar).

Mjukvaror (Geo, Topocad, m fl).

Anläggningsmätning

Husutsättning

Ritningsläsning för väg, hus och mark

Bygghandlingar, mängdförteckning, teknisk beskrivning och AMA

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, lektioner, laborativt arbete, räkneövningar, enskilt arbete, grupparbete, fältövningar.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras genom inlämningsuppgifter och en skriftlig dugga.

Betygssättning för duggan sker enligt betygsskala U G VG och inlämningsuppgiften har betygsskalan U G. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen Y0003B motsvarar kursen O0002K

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Skriftlig dugga | U G VG * | 4 | Obligatorisk | H08 |  |
| 0004 | Inlämningsuppgift | U G# | 3,5 | Obligatorisk | H08 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2008-01-22 att gälla från H08.
