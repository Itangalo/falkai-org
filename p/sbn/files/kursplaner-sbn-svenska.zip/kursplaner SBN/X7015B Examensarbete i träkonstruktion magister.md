---
kurskod: "X7015B"
titel: "Examensarbete i träkonstruktion, magister"
hp: "15"
titel_en: "Degree project in Timber Structures, Master"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2026-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1E"
betygsskala: "UG"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X7015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X7015B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/x70/x7015b-examensarbete-i-trakonstruktion-magister"
---

# Examensarbete i träkonstruktion, magister (X7015B)

## Ingår i huvudområde

Samhällsbyggnadsteknik

## Behörighet

Minst 30 hp avklarade kurser av examensfordringarna. Utsedd examinator avgör om studenten har den fördjupning som krävs för det föreslagna examensarbetet. Dessutom krävs Engelska 6/nivå 2 och Svenska 3/nivå 3.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens övergripande mål är att studenten skall öva, utveckla och visa färdigheter i att på ett korrekt sätt tillämpa teori och metod för att lösa ostrukturerade problem inom huvudområdet träkonstruktion.

Detta innebär att studenten i kursen ska kunna visa prov på:

•Formulera en relevant problemställning utifrån ett valt ämne inom huvudområdet träkonstruktion

-Tillämpa kunskaper och färdigheter som har förvärvats under studietiden för ett komplext utvecklings- eller mindre forskningsprojekt på ett självständigt och systematiskt sätt

-Välja och motivera metod för studien med tydlig förståelse för valens inverkan på studiens resultat

-Utan fullständig information på ett vetenskapligt korrekt sätt analysera och besvara formulerad problemställning.

-Finna och kritiskt värdera information och sammanfatta denna på ett vetenskapligt sätt.

-Planera, strukturera och genomföra ett forsknings- eller utvecklingsarbete.

-Bedöma den vetenskapliga relevansen av erhållna resultat

-Arbeta efter tidplan

-Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt.

-Utforma och genomföra en presentation där arbetets resultat och slutsatser redovisas och försvaras

-Kritiskt granska andra studier på ett konstruktivt och vetenskapligt sätt

-Förmåga att kritiskt analysera projektuppgiften ur ett hållbarhetsperspektiv med avseende på jämställdhet, miljöpåverkan och samhällsutveckling

## Kursinnehåll

Innehållet i examensarbetet utformas i dialog med handledare. Examensarbetet innehåller alltid en teoretisk uppbyggnad i form av en litteraturstudie som belyser teknikområde och metodik, sammanfattad på ett vetenskapligt sätt.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten genomför och planerar självständigt examensarbetet med handledare som stöd. I examensarbetet ingår att göra en tidplan för hela projektet som kontinuerligt följs upp.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Skriftlig presentation av eget arbete. I rapporten skall studenten visa förmåga att:

-Motivera den valda problemställningen

-Välja och motivera metod för studien med tydlig förståelse för valens inverkan på studiens resultat

-Med tydlig koppling till vald teori/metod samla in information relevant för problemformuleringen

-På ett relevant sätt skriftligt presentera den insamlade informationen

-Utifrån vald teori/metod på ett korrekt sätt analysera och besvara formulerad problemställning

-Med ett kritiskt förhållningssätt bedöma den vetenskapliga relevansen av erhållna resultat

-Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt.

-Redovisa en hållbarhetsanalys med inriktning mot jämställdhet, miljöpåverkan samt samhällsutveckling som baseras på projektuppgiften dess utformning och genomförande samt resultat

–Muntlig presentation av eget arbete

-Opponering på annans arbete

-Närvara vid presentationer av andra examensarbeten

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i

förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen X7015B motsvarar kursen W7014T

## Övrigt

Examensarbetet utförs företrädesvis enskilt och endast i undantagsfall med maximalt två deltagande studenter. I de fall där examensarbetet utförs av två studenter skall detta synas i rapportens omfång och djup.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Muntlig presentation | UG | 0 | Obligatorisk | V27 |  |
| 0006 | Opponering av annat examensarbete | UG | 0 | Obligatorisk | V27 |  |
| 0007 | Start av examensarbete | UG | 0 | Obligatorisk | V27 |  |
| 0008 | Godkänd rapport | UG | 15 | Obligatorisk | V27 | Ja |

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13
