---
kurskod: "G7014B"
titel: "Projektkurs i geoteknik"
hp: "30"
titel_en: "Senior Design Project in Soil Mechanics"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2023-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "U G#"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7014B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7014b-projektkurs-i-geoteknik"
---

# Projektkurs i geoteknik (G7014B)

## Behörighet

Minst 90 hp inom området Väg- och vattenbyggand, där kursen G7008B Geoteknik fk eller motsvarande ska ingå. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2. För utbytesstudenter gäller att examinator gör individuell prövning av behörigheten beroende på typ av projekt.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Det övergripande målet för kursen är att studenten ska uppvisa, utveckla och tillämpa teori och metoder för att lösa problem relevanta för en ingenjör inom väg- och vattenbyggnad som är verksam inom geoteknikområdet.

Vid kursens slut ska studenten kunna: Formulera ett relevant problem för att undersöka ett utvalt område inom geotekniken. Tillämpa kunskap och färdighet som har erhållits under studietiden för att studera ett komplext utvecklingsprojekt eller ett mindre forskningsprojekt på ett individuellt och systematiskt sätt. Välja och motivera metoder som har valts i studien. Analysera och försvara problemet i sitt sammanhang relaterat till vetenskap och ingenjörsmässighet. Hitta och kritiskt granska information samt sammanfatta detta vetenskapligt. Planera, strukturera och utföra projektet inom forskning, utveckling eller utredning. Avgöra den vetenskapliga eller praktiska relevansen av de erhållna resultaten. Jobba enligt ett schema. Uttrycka sig skriftligen, såväl som muntligen, språkligt och vetenskapligt korrekt. Utforma och genomföra en presentation av resultaten i projektet, som försvarar slutsatserna. Kristligt ganska andra arbeten på ett konstruktivt och vetenskapligt sätt.

## Kursinnehåll

Projektens område väljs i samarbete med examinatorn och ska vara relaterat till forskning eller utveckling inom ett område inom geotekniken.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten jobbar individuellt med handledning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

I rapporten skall studenten visa förmåga att: Motivera den valda problemställningen Välja och motivera metod för studien Samla relevant information för problemet som ska studeras, där kopplingen till studerat område är tydlig På ett relevant sätt skriftligt presentera den insamlade informationen Utifrån vald teori/metod på ett korrekt sätt analysera och besvara formulerad problemställning Med ett kritiskt förhållningssätt bedöma den ingenjörsmässiga och vetenskapliga relevansen av erhållna resultat Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt Muntlig presentation och försvar av eget arbete

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Institutionen tillhandahåller handledning under kursens gång. Projektet utförs individuellt, endast i undantagsfall får det utföras i grupp om maximalt två personer. I de fall där projektarbetet utförs av två studenter, ska det tydligt framgå i kursens omfattning samt i djupet i rapporten.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Godkänd muntlig och skriftlig redovisning | U G# | 30 | Obligatorisk | H19 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-02-14
