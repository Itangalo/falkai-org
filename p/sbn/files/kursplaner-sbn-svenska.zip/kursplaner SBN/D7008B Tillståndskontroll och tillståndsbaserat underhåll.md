---
kurskod: "D7008B"
titel: "Tillståndskontroll och tillståndsbaserat underhåll"
hp: "7,5"
titel_en: "Condition Monitoring and Condition Based Maintenance"
giltig: "Höst 2017 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2017-02-10"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser  Prov Provnr        Typ                                                             Hp           Betyg  0002          Obligatoriskt grupparbete                                       3,5          U G#  0003          Inlämningsuppgifter                                             4            GU345"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7008B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7008B&lasPeriod=209&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7008b-tillstandskontroll-och-tillstandsbaserat-underhall"
---

# Tillståndskontroll och tillståndsbaserat underhåll (D7008B)

## Behörighet

Kurser om minst 60 hp i några av de följande områdena ska ingå: Drift och underhållsteknik, Energiteknik, Maskinteknik, Materialteknik, Väg- och vattenbyggnad, Träteknik eller motsvarande kunskaper, samt minst 15 hp i matematik.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Examinator

Matti Rantatalo

## Mål/Förväntat studieresultat

Syftet med kursen är att utveckla färdigheter och förmågor för avancerade tillståndsövervakningstekniker för att samla in information som används för att stödja underhållsbeslut.

## Kursinnehåll

- Grundläggande begrepp underhåll och tillståndsbaserat underhåll
- Inspektion och tillståndövervakning
- Sensor och mätteknik
- Datainsamling och analys
- Diagnostik och prognostisk
- Tillståndsbaserat underhåll för beslutsfattande

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen innehåller föreläsningar och laborationer och behandlar teori och metoder.Kunskaper från kursen appliceras på verkliga industriella problem. De studerande ska genomföra självständiga litteraturstudier samt muntlig och skriftlig redovisning av inlämningsuppgifter.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För att få godkänt betyg i kursen måste inlämningsuppgifter och laborationer genomföras med godkänt resultat.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser

Prov Provnr        Typ                                                             Hp           Betyg

0002          Obligatoriskt grupparbete                                       3,5          U G#

0003          Inlämningsuppgifter                                             4            GU345

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Litteratur

*Litteratur. Gäller från Höst 2016 Lp 1* Literatur ges före kursstart

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2017-02-10

## Kursplanen fastställd

av Eva Gunneriusson 2016-01-19
