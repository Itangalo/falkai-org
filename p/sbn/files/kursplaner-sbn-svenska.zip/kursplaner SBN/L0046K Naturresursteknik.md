---
kurskod: "L0046K"
titel: "Naturresursteknik"
hp: "7,5"
titel_en: "Natural Resources Engingeering"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Naturresursteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0046K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0046K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0046k-naturresursteknik"
---

# Naturresursteknik (L0046K)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet + Fysik 2, Kemi 1, Matematik 4 eller Matematik E. Eller: Fysik nivå 2, Kemi nivå 1, Matematik fortsättning nivå 2 (äldre kurs Matematik E).

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna

Kunskap och förståelse

1. Redogöra för och reflektera över samhällets behov och försörjning av naturresurserna malm, mineral och vatten

2. Översiktligt beskriva planeten jordens uppkomst och uppbyggnad, malm och mineral förekomster, globala geokemiska och hydrologiska kretslopp

3. Redogöra för och kritiskt förhålla sig till begreppet hållbar utveckling

4. Översiktligt beskriva samhällets tekniska system för vatten- och avfallshantering-

5. Översiktligt beskriva metoder för utvinning av malm och mineral och konsekvenser för miljön

6. Ge exempel på ingenjörens roll och ansvar för en hållbar utveckling i sin profession

7. Efter avslutad kursmodul om jämställdhet ska studenten visa förståelse för uppsatta jämställdhetsmål, regelverk för jämställdhet i arbetslivet samt  ge exempel på förutsättning för jämställdhet i arbetslivet.

Färdighet och förmåga

8. Använda bibliotekets databaser för att söka vetenskaplig litteratur

## Kursinnehåll

Kursen behandlar behov, användning, förekomst och tillgång av malm och vatten. Begreppet Hållbar utveckling. Atmosfärens uppkomst och utveckling och planeten jorden uppkomst och uppbyggnad. Kemiska vittringsprocesser och de globala syrets och kolets kretslopp. Naturliga och urbana hydrologiska kretslopp. Samhällets system för vatten och avfallshantering. Bergskedjan-från prospektering till metall. Ingenjörsrollen. Informationssökning i vetenskapliga databaser. Jämställdhet.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar och seminarium, samt obligatorisk litteratursökning med efterföljande uppgift. En obligatorisk studieresa under två dagar med efterföljande reflektionsuppgift ingår. Kursen inkluderar ett grupparbete där studenterna fördjupar sig inom en vald frågeställning med handledning av lärare. Uppgiften redovisas individuellt i tvärgrupper. Kursmodulen om jämställdhet består av inspelade föreläsningar samt litteratur.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

De teoretiska delarna av kursen (lärandemål 1-5) examineras med ett skriftlig tentamen med graderade betyg (3 4 5).

Fördjupning av hållbar utveckling och ingenjörsrollen examineras genom aktivt deltagande i grupparbete och i efterföljande seminarium och betygssätts med betyg (UG). Obligatoriskt deltagande i studiebesök och inlämning av reflektionsuppgift betygssätts med betyg (UG). Informationssökning där obligatoriska inlämningsuppgifter ingår examineras med betyg (UG). Kursmodulen om jämställdhet examineras genom quizzar med betyg (UG).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Tentamen | GU345 | 4 | Obligatorisk | H13 |  |
| 0002 | Studiebesök | U G# | 1 | Inaktiv | H13 |  |
| 0004 | Bibliotek, litteratursökning | U G# | 0,5 | Inaktiv | H13 |  |
| 0007 | Seminarier | U G# | 1,5 | Inaktiv | H13 |  |
| 0008 | Quiz, jämställdhet | U G# | 0,5 | Inaktiv | H13 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2013-01-25
