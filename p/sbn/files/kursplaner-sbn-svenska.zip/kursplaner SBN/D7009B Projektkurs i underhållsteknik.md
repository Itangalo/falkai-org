---
kurskod: "D7009B"
titel: "Projektkurs i underhållsteknik"
hp: "30"
titel_en: "Senior Design Project in Maintenance Engineering"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2016-06-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "U G#"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7009B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7009B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7009b-projektkurs-i-underhallsteknik"
---

# Projektkurs i underhållsteknik (D7009B)

## Behörighet

Minst 120 Hp inom ämnet underhållsteknik eller motsvarande kurser

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter genomgången kurs kan studenten utforma, genomföra och redovisa ett projekt inom ämnet och lära sig att självständigt arbeta i en forskningsnära miljö.

## Kursinnehåll

Innehållet utformas i dialog med examinator eller utsedd handledare. Projektarbetet innehåller alltid en teoretisk uppbyggnad i form av en litteraturstudie som belyser teknikområde och metodik, sammanfattad på ett vetenskapligt sätt.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Självständigt projektarbete med stöd av en handledare som utsetts av examinator

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursens examinationsform specificeras, av examinatorn, i en detaljerad kursbeskrivning vid det aktuella kurstillfället och kan innefatta

- skriftlig presentation av eget arbete

- muntliga presentationer och försvar av eget arbete

- opponering på annans arbete

- seminarier

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Institutionen tillhandahåller aktiv handledning under två terminer från kursstart.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektuppgift | U G# | 30 | Obligatorisk | V17 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Eva Gunneriusson 2016-06-13
