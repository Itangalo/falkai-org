---
kurskod: "O7029K"
titel: "Tillämpad strukturgeologi"
hp: "7,5"
titel_en: "Applied Structural Geology"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O7029K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O7029K&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o70/o7029k-tillampad-strukturgeologi"
---

# Tillämpad strukturgeologi (O7029K)

## Behörighet

Minst 90 hp avslutade kurser med åtminstone 60 hp inom området naturresursteknik, geologi eller geovetenskap, inklusive O0007K Strukturgeologi eller motsvarande. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursen ger avancerade kunskaper i tillämpad strukturgeologi med fokus på malmbildande processer i olika skalor, mineralprospektering och kartering.

Kunskap och förståelse Efter avslutad kurs bör deltagarna kunna: 1. Förklara och diskutera vilken roll geologiska strukturer har för malmbildande system i olika tektoniska miljöer. 2. Analysera strukturgeologiska data och formulera hypoteser om sannolika transportvägar och fällor i mineraliserade områden och föreslå strategier för att utforska dessa fällor. 3. Återskapa deformationshistorier för malmfyndigheter och andra bergvolymer och diskutera dess påverkan på prospektering såväl som ingenjörsgeologi. 4. Visa förmågan att tillämpa de kunskaper som förvärvats under kursen för att lösa strukturgeologiska problem i grupp.

Kompetens och färdigheter Efter avslutad kurs bör deltagarna kunna: 1. Identifiera, beskriva och kartlägga vanliga geologiska strukturer från mikro- till regional skala. 2. Visa förmågan att noggrant samla strukturgeologiska data och presentera geologiskt välgrundade tolkningar baserade på data och kurslitteraturen inför olika målgrupper.

Bedömning och tillvägagångssätt Efter avslutad kurs bör deltagarna kunna: 1. Visa insikt i strukturgeologins roll för att förstå malmbildande system samt för att minska riskerna i infrastrukturobjekt.

## Kursinnehåll

Denna kurs inom tillämpad strukturgeologi omfattar teoretiska och praktiska moment. Kursen behandlar:

- Deformation av berg i plastiska och spröda miljöer.
- Stress- och strainanalys.
- Mikrostrukturer och kinematik.
- Transport/flöde av fluider i litosfären.
- Strukturkontroll av malmbildning i olika tektoniska miljöer.
- Deformation av malmfyndigheter.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen ges på engelska och består av föreläsningar där teori presenteras och förklaras. Den teoretiska kunskapen omsätts i praktiska tillämpningar . och ökad förståelse genom praktiska övningar, peer-reviews, gruppdiskussioner och fältexkursion. Kursens uppgifter inkluderar begrepp inom petrologi, prospektering och geografiska informationssystem (GIS).

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

De avsedda lärandemålen (ILO) för kursen bedöms genom fyra bedömningskriterier:

1. Projektarbete ILO 1, 2, 3, 4, 5, 6, 7, 2. Individuella uppgifter och presentationer ILO 2, 3, 5, 6, 7, 3. Exkursion ILO 5, 6 4. Muntlig tentamen ILO 1, 2, 3, 4, 5, 6, 7,

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektarbete | GU345 | 2 | Obligatorisk | V25 |  |
| 0004 | Muntlig tentamen | GU345 | 3 | Obligatorisk | V25 |  |
| 0005 | Individuella uppgifter och presentationer | UG | 1,5 | Obligatorisk | V27 |  |
| 0006 | Exkursion | UG | 1 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar

information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14
