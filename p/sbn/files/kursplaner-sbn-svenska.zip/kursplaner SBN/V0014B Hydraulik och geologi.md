---
kurskod: "V0014B"
titel: "Hydraulik och geologi"
hp: "7,5"
titel_en: "Hydraulics and geology"
giltig: "Höst 2024 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2024-02-14"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "GU345"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0014B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/v00/v0014b-hydraulik-och-geologi"
---

# Hydraulik och geologi (V0014B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Grundläggande behörighet samt Grundläggande kunskaper i matematik och fysik.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter fullgjord kurs ska studenten kunna:

1. Beskriva och lösa grundläggande problem baserad på hydraulikens fundamentallagar (t.ex. beräkna hydrostatiskt tryck, vattennivå, flödeshastighet och flödesmängd).

2. Identifiera olika strömningstillstånd och räkna på övergången från ett tillstånd till ett annat.

3. Identifiera beräkningsgång och lösa grundläggande hydrauliska problem inom kanalströmning.

4. Beskriva grunddragen för vittring och erosion samt de bergartsbildande processer (magmatiska, metamorfa och sedimentära bergarter) och huvuddragen i plattektonik.

5. Beskriva grunddragen för hur geologiska strukturer bildas.

6. Identifiera de vanligaste mineralen, jord- och bergarterna, beskriva deras bildningssätt och viktigaste egenskaper.

7. Beskriva de viktigaste glaciala miljöerna och förklara vilka processer som styr bildning av landformer och sediment i dessa miljöer.

8. Beskriva grunddragen i förekomsten av geologiska råvaruresurser i Sverige

9. Tolka en jordartskarta.

## Kursinnehåll

Kursen består av två kursdelar som syftar till att ge grundläggande kunskaper inom hydraulik med fokus på kanalströmning och geologi. Inom hydrauliken behandlas hydrostatiskt tryck, fundamentalekvationerna: kontinuitets- , rörelsemängds- och energiekvationen samt kanalströmning innefattande olika strömningstillstånd och övergångar mellan strömningstillstånd. Inom geologi behandlas jordens uppbyggnad, jordskorpan samt plattektonik. Bergartsbildande processer samt magmatiska, sedimentära och metamorfa bergarter. Metoder för bestämning av mineraler och bergarter. Kvartärgeologi. Jordarterna, deras bildning och något om deras fysikaliska och kemiska egenskaper. Tolkning av jordartskartor.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

För kursens två delar gäller följande:

- Genom salsundervisning och litteraturstudier inhämtas grundläggande hydraulisk teorikunskap. Beräkningskunskap fås genom att delta i salsundervisningen som innehåller räkneövningar samt att på egen hand lösa räkneuppgifter och arbeta med en beräkningsuppgift i grupp kopplad till laborationen (moment 0005). Laborationstillfället har obligatoriskt närvaro då den utgör en del av examinationen. Beräkningsuppgiften redovisas muntligt och en laborationsrapport lämnas in. Undervisning inom hydraulik kan ske på engelska.

- Genom föreläsningar, övningar och litteraturstudier inhämtas grundläggande geologisk kunskap om jordskorpans uppbyggnad, mineral och bergartskunskap samt kvartärgeologi. Genom praktiska övningar lär sig studenten identifiera olika mineraler och bergarter samt att tolka en jordartskarta. Övningstillfället med tolkning av jordartskarta har obligatorisk närvaro då den utgör en del av examinationen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. För att bli godkänd på kursen krävs minst betyget godkänt på varje delprov/moment samt närvaro vid laborationstillfället. Slutbetyg på kursen sätts som ett viktat betyg utifrån moment 0006 och 0008. Lärandemål 1-3 examineras genom en skriftlig salstentamen (moment 0006, bedöms enligt graderad betygsskala) samt genom en laboration med medföljande beräkningsuppgift och laborationsrapport (moment 0005, bedöms U/G). Aktivt deltagande krävs vid laborationstillfället. Såvida man inte deltar vid laborationstillfället får det kursmomentet genomföras annat läsår, i mån om plats. Lärandemål 4-8 examineras genom en skriftlig deltentamen (moment 0008, bedöms enligt graderad betygsskala), lärandemål 6 med en praktisk skrapdugga (moment 0007, bedöms U/G) samt lärandemål 9 med en jordartsövning (moment 0003, bedöms U/G).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen V0014B motsvarar kurser V0021B, V0017B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Jordartsövn | U G# | 0,1 | Obligatorisk | H09 |  |
| 0005 | Laboration | U G# | 0,6 | Obligatorisk | H09 |  |
| 0006 | Tentamen | GU345 | 3,2 | Obligatorisk | H09 |  |
| 0007 | Skrapdugga | U G# | 1 | Obligatorisk | H09 |  |
| 0008 | Deltentamen | GU345 | 2,6 | Obligatorisk | H09 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2009-01-20 att gälla från H09.
