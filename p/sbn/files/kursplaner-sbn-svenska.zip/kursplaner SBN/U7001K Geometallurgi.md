---
kurskod: "U7001K"
titel: "Geometallurgi"
hp: "7,5"
titel_en: "Geometallurgy"
giltig: "Vår 2024 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2023-06-02"
utbildningsniva: "Avancerad nivå"
betygsskala: "U G#"
amne: "Kemiteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=U7001K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=U7001K&lasPeriod=223&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/u70/u7001k-geometallurgi"
---

# Geometallurgi (U7001K)

## Behörighet

Kandidatexamen eller motsvarande kunskaper från praktisk erfarenhet (min 5 år arbetslivserfarenhet) inom processteknik eller geologi/mineralogi. Engelska 6.

## Mål/Förväntat studieresultat

Kursen syftar till att ge en introduktion i de tre ämnesområdena geologi, processmineralogi och mineralteknik med ett geometallurgiskt perspektiv som den röda tråden genom kursen. Kursen skall främst fokusera på LKAB:s malmtyper och processer, men även ta upp andra järnmalmstyper.

Efter fullgjord kurs skall studenten kunna:

- Identifiera och beskriva olika järnmalmtyper och deras bildningsprocesser

- Analysera mineralegenskaper hos järnmalmer med avseende på effektiv utvinning,

- Beskriva och förklara mineraltekniska processer som används inom järnmalmanrikning,

- Analysera orsaker till processval utifrån råvarans egenskaper,

- Beskriva förutsättningarna för att bygga en geometallurgisk modell och förklara dess komponenter.

## Kursinnehåll

Geologi: Mineral och bergarter: ursprung, bildning och metamorfos, malmgeologi för LKAB:s malmer och andra järnmalmstyper;

Processmineralogi: karaktärisering av malmmineral and metallurgiska produkter (sammansättning,mineraltexturer,friläggning) baserade på optisk mikroskopi, elektronmikroskopi i kombination med kvantitativ analys (Quemscan), XRD;

Mineralteknik: grundprinciper för LKAB:s enhetsoperationer; utrustningsval, länk till processmineralogi, mineraltekniskt testarbete;

Metallurgi: grundprinciper för järnframställning, produktegenskaper, kundkrav och kvalitet; Geometallurgisk modellering: geostatistisk, processmodellering inom mineralteknik och metallurgi, partikelbaserad materialbalansering.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, seminarier, praktiska övningar och studiebesök (LKAB:s laborationer). Deltagande är obligatoriskt i samtliga moment utom i föreläsningarna.

Föreläsningarna skall ge möjlighet för studenterna att kunna beskriva och förklara teorin och sammanband mellan mineralogi hos olika malmer och anrikningsprocesser.

Praktiska övningar inom geologi, processmineralogi och mineralteknik utförs gruppvis. Studiebesök skall ge möjlighet för studenterna att kunna redogöraför avancerade mineralogiska undersökningar och tekniska testmetoder.

Seminarier ägnas åt att i grupp beskriva, analysera, tolka och presentera ett komplext tema inom geometallurgiskt området.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Övningar och seminarier är obligatoriska

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Laboration och praktisk övning | U G# | 5 | Obligatorisk | V22 |  |
| 0003 | Seminarier | U G# | 2,5 | Obligatorisk | V22 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-04-19
