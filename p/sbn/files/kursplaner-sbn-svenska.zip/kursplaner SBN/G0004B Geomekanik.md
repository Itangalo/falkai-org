---
kurskod: "G0004B"
titel: "Geomekanik"
hp: "7,5"
titel_en: "Geomechanics"
giltig: "Höst 2007 Lp 1 - Tills vidare"
beslutsdatum: "2007-01-31"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser  Prov Provnr        Typ                                                             Hp              Betyg  0001          Tentamen                                                        3               GU345  0002          Övrigt                                                          4,5             U G#"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0004B&lasPeriod=154&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g00/g0004b-geomekanik"
---

# Geomekanik (G0004B)

## Behörighet

Grundläggande behörighet samt Grundläggande behörighet. Goda kunskaper i hållfasthetslära, geologi, jordmateriallära och jordmekanik.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Examinator

Hans Mattsson

## Mål/Förväntat studieresultat

Att erhålla praktiskt tillämpbara kunskaper om hur man använder jord som ett konstruktionsmaterial och hur man dimensionerar och utformar berganläggningar. Inom geotekniken kunna härleda och använda beräkningsmodeller för bärighetsproblem, sättningar, jordtryck och stabilitet. Erhålla tillräckliga kunskaper om bergets spänningar, deformationer, hållfasthet och stabilitet för att kunna tillämpa vedertagna beräkningsmodeller. Behärska allmänna projektfärdigheter som grupparbete och skriftlig presentation.

## Kursinnehåll

Bärighet i jord (10%) Hur stora laster från exempelvis fundament och jordbankar klarar jorden. Sättningar i jord (15%) Hur stora blir sättningarna i en jord på grund av pålastning från exempelvis jordbankar och byggnader? Hur lång tid tar det för sättningarna att utbildas. Jordtryck (10%) Jordtryck mot vertikala stödkonstruktioner, murar, sponter etc. Olika fall av bottenupptryckning. Jordslänters stabilitet (15%) Hur kan säkerheten för en slänt beräknas? Stabilitet sett ur ett kort respektive långt tidsperspektiv. Spänningar i berggrunden (10%) Bergets deformations- och hållfasthetsegenskaper (25%) Dimensionering och stabilitet – underjordsanläggningar (10%) Dimensionering och stabilitet – slänter (5%)

## Genomförande

Undervisningen består av lektioner, laborationer, inlämningsuppgifter etc. Lektionerna består av en kombination av teori och övningar.

## Examination

Skriftlig tentamen med differentierade betyg. För att erhålla godkänt slutbetyg krävs godkända inlämningsuppgifter och övningar.

## Överlappning

Kursen G0004B motsvarar kursen ABG104

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser

Prov Provnr        Typ                                                             Hp              Betyg

0001          Tentamen                                                        3               GU345

0002          Övrigt                                                          4,5             U G#

## Litteratur

*Litteratur. Gäller från Höst 2007 Lp 1* Fastställs senast tre veckor innan kursstart.

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
