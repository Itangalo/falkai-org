---
kurskod: "G7003B"
titel: "Miljögeoteknik, förorenad mark"
hp: "7,5"
titel_en: "Environmental Geotechnics"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7003B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7003b-miljogeoteknik-fororenad-mark"
---

# Miljögeoteknik, förorenad mark (G7003B)

## Ingår i huvudområde

Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

Grundläggande kunskaper i geoteknik.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Studenten ska kunna:

1. utföra miljötekniska markundersökningar och riskbedömning av förorenade markområden

2. ta fram lämpliga förslag på efterbehandlingsåtgärder av förorenade markområden

3. beräkna föroreningars spridning i mark

4. redogöra för olika barriärmaterials egenskaper och hur barriärkonstruktioner kan byggas upp

5. redogöra för olika alternativa materials egenskaper och hur de kan användas vid byggande av olika konstruktioner

6. redogöra för sulfidjords miljögeotekniska egenskaper

7. redogöra problem relaterade till radon

8. beskriva lagar tillämpliga inom området förorenad mark

## Kursinnehåll

- Ingenjörsgeologi: Anläggningstekniskt viktiga kvartära bildningar och karakteristiska jordprofiler innehållande olika jordtyper.

- Miljötekniska markundersökningar: Hur miljötekniska undersökningar bör företagas för att utreda hur marken kan komma att påverkas eller har påverkats av olika föroreningar. Riskbedömning.

- Markkemi: Organiska och oorganiska föroreningars spridning i mark. Här ingår markens filter- och barriäregenskaper och hur olika faktorer kan påverka dessa.

- Barriärteknik: Leror (olika lermineral), bentonitliners, geomembran, uppbyggnad av olika barriärkonstruktioner.

- Marksanering: Olika typfall av föroreningsskador. Tillämpbarhet och begränsningar i olika saneringsåtgärder.

- Alternativa material: Egenskaper och tillämpningsområden för olika alternativa material (askor, gummiklipp, mm)

- Radon: Vad innebär radon i mark och hur undersöks om radon förekommer och hur undviks att vid nybyggnation skapa ett radonproblem.

- Juridik: Rättstillämpning vid markföroreningar.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen sker i form av föreläsningar (lektioner), konstruktionsuppgift och laborationer. Konstruktionsuppgiften tar upp de olika delmomenten som ingår i en miljögeoteknisk utredning, från det att en förorening misstänks tills dess att saneringsåtgärder föreslås. Avsikten är att ge en praktisk tillämpning av kursinnehållet. Laborationerna omfattar undersökning av barriärmaterial och saneringsmetoder för dieselförorenad jord och vatten. Konstruktionsuppgiften och laborationerna utförs i grupper och redovisningen av dessa sker skriftligt, i rapportform. Konstruktionsuppgiften redovisas även muntligt.

Studenterna förväntas, om möjligt, att närvara vid samtliga lektioner. Det är obligatoriskt att genomföra laboration och projektarbete. Gruppmöten förväntas att genomföras bland studenterna för att öva färdigheter inom samarbete och kommunikation.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursen bedöms genom en skriftlig tentamen, projektarbete samt laborationer. Projektarbetet och laborationerna presenteras i form av en skriftlig rapport. Projektarbetet presenteras muntligt också. Samtliga aktiviteter inkluderade i projektarbetet och laborationerna är obligatoriska att slutföra.För att erhålla godkänt betyg på kursen krävs godkända laborationer och inlämningsuppgift. Betygsgränserna är U/G 3 4 5, där slutbetyg på kursen bestämt av tentamensbetyget.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen G7003B motsvarar kursen ABG107

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 3 | Obligatorisk | H07 |  |
| 0002 | Konstruktionsuppgift | U G# | 3 | Obligatorisk | H07 |  |
| 0003 | Laboration | U G# | 1,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
