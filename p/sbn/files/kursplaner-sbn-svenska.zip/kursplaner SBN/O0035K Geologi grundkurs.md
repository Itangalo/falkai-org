---
kurskod: "O0035K"
titel: "Geologi, grundkurs"
hp: "7,5"
titel_en: "Geology, basic course"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-01-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0035K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0035K&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o00/o0035k-geologi-grundkurs"
---

# Geologi, grundkurs (O0035K)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet + Engelska 6, Naturkunskap 1b eller 1a1+1a2, Samhällskunskap 1b eller 1a1+1a2. Eller: Engelska nivå 2, Naturkunskap nivå 1b eller nivå 1a2, Samhällskunskap nivå 1b eller nivå 1a2.

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter genomför kurs skall studenten kunna förklara grundläggande geologiska begrepp och processer som är av betydelse för dem som kommer att arbeta med frågor som rör miljö, naturresurser, berg och jord. Studenten ska även kunna identifiera de vanligaste mineralen, berg- och jordarterna, samt redogöra för deras bildningssätt och ha kunskap om deras användningsområden. Studenten ska även kunna söka, sammanställa och muntligt presentera geologisk information samt ha en översiktlig kännedom om Sveriges berggrund.

## Kursinnehåll

Jordens uppbyggnad och sammansättning.

Plattektoniska processer och dess drivkrafter.

Mineral och metoder för mineralkännedom.

Magmatiska, sedimentära och metamorfa bergarter och deras bildningsprocesser.

Jordskorpans strukturformer och strukturgeologiska övningar.

Den geologiska tidsskalan, historisk geologi och jordens utveckling.

Regional geologi och Sveriges berggrund.

Kvartärgeologi och recenta exogena processer.

Istider och förändringar av havsnivåer.

Jordarterna, deras bildning och något om deras fysikaliska och kemiska egenskaper.

Tolkning av geologiska kartor.

Malmer, industrimineral och energiråvaror samt deras förekomst i Sverige.

Geologiska exkursioner omfattande kvartärgeologiska lokaler, berggrund, mineral samt studiebesök vid gruva.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar där grundläggande teori presenteras och förklaras. Metoder för identifiering av mineral, bergarter och jordarter tillägnas genom praktiska övningar, laborationer jämte fältövningar. Användning av strukturgeologiska begrepp och metoder liksom grundläggande förståelse av geologiska kartors framställning tränas genom praktiska övningar. Kännedom om Sveriges berggrund uppnås genom föreläsning och eget projektarbete. Teoretiska kunskaper omsätts till praktiska tillämpningar och ökad förståelse genom fältövning och exkursioner till geologiska lokaler. Obligatoriska moment är muntlig redovisning av projektuppgift, laborationer, fältövningar, exkursion och vissa övningar.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursen examineras med differentierade betyg dels genom en skriftlig tentamen vid läsperiodens slut och dels genom praktiskt prov i mineral- och bergartskännedom under läsperioden. Laborationer, obligatoriska övningar samt fältövning redovisas genom inlämningsuppgifter och ges enbart betyget godkänd/icke godkänd liksom den muntliga redovisningen av individuellt projektarbete.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen O0035K motsvarar kurser K0023K, KGO006

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Tentamen allmän geologi | GU345 | 4,5 | Obligatorisk | H08 |  |
| 0004 | Praktiska prov mineral | GU345 | 1 | Obligatorisk | H08 |  |
| 0005 | Praktiska prov bergarter | GU345 | 1 | Obligatorisk | H08 |  |
| 0007 | Fältövning, övningar/laborationer med inlämningsuppgifter och eget projektarbete | UG | 1 | Obligatorisk | V27 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-01-11

## Kursplanen fastställd

av Institutionen för Tillämpad kemi och geovetenskap 2008-01-22 att gälla från H08. 2008-01-22
