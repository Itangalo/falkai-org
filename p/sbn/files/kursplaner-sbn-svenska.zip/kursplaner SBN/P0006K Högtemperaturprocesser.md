---
kurskod: "P0006K"
titel: "Högtemperaturprocesser"
hp: "7,5"
titel_en: "High Temperature Processes"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "UG"
amne: "Processmetallurgi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0006K&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p00/p0006k-hogtemperaturprocesser"
---

# Högtemperaturprocesser (P0006K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Grundläggande behörighet samt K0016K Kemiska principer, K0010K Fysikalisk kemi eller motsvarande kurser.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter fullgjord kurs skall studenten kunna

- beskriva och förklara vanligt förekommande enhetsoperationer inom högtemperaturprocesser

- beskriva och tillämpa de teoretiska grunderna för högtemperaturprocesser

- ur teoretiskt och praktiskt synvinkel redogöra för processgången vid framställning av de vanligaste metallerna

- beskriva olika tekniker för rening av processgaser och teoretiskt utforma samt motivera val av reningsoperationer för processgaser som bildas vid högtemperaturprocesser

- muntligt och skriftligt presentera förslag på lösningar till processtekniska frågeställningar relaterade till högtemperaturprocesser

Hållbar utveckling

- Ge exempel på ingenjörens roll och ansvar för en hållbar utveckling i sin professionsutövning.

## Kursinnehåll

Högtemperatur processer är en grundkurs som tar upp grunderna i järn-, stål- och koppartillverkning ur ett hållbart samhällsperspektiv. Kursen behandlar de teoretiska grunderna och de praktiska aspekterna av tillverkningen genom att inkludera processteknik, miljömedvetenhet och termodynamik. Kursen består i stora drag av följande moment:

Enhetsoperationer kopplade till högtemperaturprocesser så som smältugnar, konverteringsugnar etc.

Enhetsoperationer kopplade till gasrening av processgaser från högtemperaturprocesser så som olika filtertyper och cykloner.

Termodynamik med fokus på högtemperaturkemi så som värmebalanser och lösningskemi. Här introduceras även beräkningsverktyget FactSage.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar som kombineras med övningar, laborationer, projektarbete och studiebesök.

Föreläsningar och övningar skall ge studenterna möjlighet att kunna beskriva högtemperaturprocesser ur en praktisk och teoretisk synvinkel samt träna beräkningsprocedurer för frågeställningar relaterade till dessa. Laborationer och industrirelaterade projektarbeten utförs gruppvis. I samband med laborationen tränas studenterna i att utföra och utvärdera försök samt skriftligt redovisa arbetsgång och resultat. Under projektgenomförandet tränas studenterna i att, med utgångspunkt från de datorsimuleringar som utförs samt nyttogörande av föreläsningar, föreslå och motivera val av processteknik för industriella högtemperaturprocesser. Projektuppgiften redovisas såväl muntligt som i en skriftlig rapport.

Studiebesöken länkar samman teori från föreläsningar, laborationer och projektarbete med praktiska tillämpningar i industrin.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Godkänt resultat på laboration och projektarbete inklusive skriftlig och muntlig redovisning. På laboration och projektarbete ges enbart betygen icke godkänd eller godkänd. Ämneskunskapen i högtemperaturprocesser examineras kontinuerligt under kursens gång genom seminarium och inlämningsuppgifter med betygen icke godkänd eller godkänd.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen P0006K motsvarar kursen P0001K

## Övrigt

Obligatorisk närvaro vid första föreläsningstillfället, seminarium, laboration, studiebesök samt projektintroduktion och projektredovisning. Kursen ges på grundläggande nivå och ingår i civilingenjörsprogrammet Hållbar process- och kemiteknik. Studiehandledning återfinns i Canvas.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Seminarium och inlämningsuppgifter | UG | 5,3 | Obligatorisk | V27 |  |
| 0004 | Övrigt | UG | 2,2 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17
