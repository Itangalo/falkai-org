---
kurskod: "F7001B"
titel: "Planeringsmetoder"
hp: "7,5"
titel_en: "Planning methods"
giltig: "Vår 2026 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2022-02-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7001B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/f70/f7001b-planeringsmetoder"
---

# Planeringsmetoder (F7001B)

## Ingår i huvudområde

Arkitektur

## Behörighet

Kunskaper motsvarande kurs F0002B Urban design. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

- Beskriva olika kvalitativa och kvantitativa metoder som används i planeringsprocessen (värderingsmetoder, prognoser, SWOT, framtidsscenarier, backcasting, strategiska miljöbedömningar, multikriterieanalys, samverkansmetoder).

Färdighet och förmåga

- Söka och värdera policyinformation som härrör från FN, EU, nationell, regional och lokal nivå.

- Analysera policyerna i ett samhällssammanhang och urskilja avsikt, vision och mål för planeringen.

- Identifiera områden som kan utvecklas för att nå samhällets planeringsvisioner- och mål.

- Undersöka utvecklingsstrategier för planering.

Värderingsförmåga och förhållningssätt

- Utveckla indikatorer för att nå uppsatta planeringsmål.

- Utarbeta rekommendationer för planeringsprocessen.

## Kursinnehåll

Kursen behandlar processer som används i design och hantering av planeringspolicyer för byggda miljöer, samt verktyg och metoder som vanligtvis används, inklusive dess tillhörande terminologi. Särskilt fokus är på upprättandet av mål, alternativ, planeringsscenarier och indikatorer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen omfattar föreläsningar, seminarier och grupparbete. Vid föreläsningar och seminarier gås olika metoder igenom som finns att tillgå i planeringsprocessen. Fokus är på förståelse av terminologi som används i planeringsverktygen, vilken roll olika verktyg har och i vilka sammanhang de är lämpliga för i planeringsarbetet. Föreläsningarna utforskar även olika skalor för planeringspolicyer. Genom projektarbetet kommer studenten att använda kunskap om hantering och värdering av utvecklingsförslag och scenarier i planeringsprocessen. Detta inkluderar övning i att skriva forskningsrapporter och att visuellt och muntligt förklara sitt arbete.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursens mål examineras genom seminarier och ett projektarbete. Seminarierna examineras genom aktivt deltagande. Godkända seminarier betygsätts med betyg G/U. För att bli godkänd på projektarbetet krävs aktivt deltagande samt godkänd muntlig, skriftlig, och illustrerad redovisning. Projektarbetet examineras med graderat betyg G/U 3 4 5.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektarbete | GU345 | 6 | Obligatorisk | H07 |  |
| 0002 | Seminarier | U G# | 1,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
