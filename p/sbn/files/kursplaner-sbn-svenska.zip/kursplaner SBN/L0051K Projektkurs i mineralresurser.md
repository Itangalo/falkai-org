---
kurskod: "L0051K"
titel: "Projektkurs i mineralresurser"
hp: "15"
titel_en: "Project Course in Mineral Resources"
giltig: "Höst 2026 Lp 1 - Tills vidare"
beslutsdatum: "2026-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0051K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0051K&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0051k-projektkurs-i-mineralresurser"
---

# Projektkurs i mineralresurser (L0051K)

## Behörighet

Grundläggande behörighet samt Minst 90 hp avklarade kurser inom teknikområdet Geovetenskap/Naturresursteknik, inklusive kurserna O0041K Geovetenskap, O0042K Mineralogi och kristallografi, L0050K Geokemi, P0008K Mineralteknisk och metallurgisk processteknik eller motsvarande kurser. Goda kunskaper i engelska motsvarande Engelska 6/nivå 2

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Studenten utvecklar kunskap inom ett område som inte täcks av ordinarie kurser och lär sig att arbeta självständigt, nära forskning. Detta innebär att studenten efter avslutad kurs kan:

- Formulera ett relevant problem för undersökning utifrån ett valt ämne inom ämnesområdet mineralresurser.

- Tillämpa kunskap och färdigheter som förvärvats under studietiden på ett komplext utvecklingsprojekt eller ett mindre forskningsprojekt självständigt och systematiskt.

- Välja och motivera studiemetod för en undersökning.

- Analysera och försvara ett korrekt formulerat problem med avseende på vetenskap och teknik, utan fullständig information.

- Lokalisera och kritiskt granska information och sedan sammanfatta den vetenskapligt.

- Planera, strukturera och genomföra ett projekt inom forskning, utveckling eller undersökning

- Uttrycka sig väl skriftligen på ett muntligt och vetenskapligt korrekt sätt.

## Kursinnehåll

Examinatorn specificerar kursens innehåll i en detaljerad kursbeskrivning vid kurstillfället. Kurserna ges ofta i anslutning till pågående forskningsprojekt vid institutionen för samhällsbyggnad och naturresurser.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursens genomförande specificeras av examinatorn i en detaljerad kursbeskrivning vid kurstillfället. Kurserna placeras senare i programmet, så studenterna förväntas ta ett större ansvar för sitt lärande jämfört med grundkurser.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examinationen av kursen specificeras av examinatorn i en detaljerad kursbeskrivning vid kurstillfället och kan bestå av skriftliga rapporter, skriftliga/muntliga presentationer, skriftliga/muntliga prov och/eller seminarier.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektarbete | GU345 | 15 | Obligatorisk | H26 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13
