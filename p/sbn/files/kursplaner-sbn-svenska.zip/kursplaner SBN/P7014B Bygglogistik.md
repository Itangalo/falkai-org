---
kurskod: "P7014B"
titel: "Bygglogistik"
hp: "7,5"
titel_en: "Construction Supply Chain Management"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2020-11-06"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7014B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7014B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p70/p7014b-bygglogistik"
---

# Bygglogistik (P7014B)

## Ingår i huvudområde

Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

Minst 90hp kurser inom väg och vattenbyggnad eller arkitektur. Kursen P0007B Byggprojektledning eller motsvarande ska ingå.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Målet med kursen är att studenten skall kunna förstå och förklara koncept och metoder inom bygglogistik.

Förväntat studieresultat Efter genomförd kurs ska studenten kunna under givna förutsättningar:
- definiera och tillämpa grundläggande koncept, modeller, verktyg och metoder för att observera, beskriva och analysera byggplatsen och bygglogistiken
- definiera och tillämpa planering, koordinering, integration, styrning och kontroll av bygglogistik på ett projekt
- självständigt planera, utveckla och föreslår implementering av bygglogistiken med avseende på tjänster, underentreprenörer, materielleveranser och andra resurser
- reflektera på bygglogistikens strategiska betydelse för aktiviteter inom bygg och dess påverkan på hållbarhet, socialt ansvar, hälsa, miljö och säkerhet samt riskhantering
- definiera, beskriva och reflektera på bygglogistikens framtida utmaningar och trender

## Kursinnehåll

Kursen behandlar teorifältet bygglogistik relaterat till metoder, processer, produktionssystem, koncept, flöden av yrkesgrupper och information, samt material- och kassaflöden. Delområden som avhandlas är planläggning av bygglogistik, planering, koordinering, integration samt styrning av försörjningskedjan inom ramen för byggandets kontext.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Initialt inhämtar studenterna den grundläggande teoretiska kunskapen med stöd av föreläsningar. Tillämpningen av teorin övas, testas och reflekteras genom grupp- och individuella uppgifter. Grupperna redovisar resultat och diskuterar de val som gjorts i seminarieform.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Grundläggande kunskaper testas genom individuella uppgifter. Djupare kunskap utvärderas genom muntlig och skriftlig redovisning av gruppuppgiften i seminarieform.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Individuell inlämningsuppgift | GU345 | 3 | Obligatorisk | V20 |  |
| 0002 | Gruppuppgift | U G# | 4,5 | Obligatorisk | V20 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-11-06

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institut 2019-06-14
