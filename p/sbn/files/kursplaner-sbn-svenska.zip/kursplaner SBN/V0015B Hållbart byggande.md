---
kurskod: "V0015B"
titel: "Hållbart byggande"
hp: "7,5"
titel_en: "Sustainable Building"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "GU345"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0015B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0015B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/v00/v0015b-hallbart-byggande"
---

# Hållbart byggande (V0015B)

## Ingår i huvudområde

Arkitektur, Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Grundläggande behörighet samt Kunskaper om byggande och byggmaterial tex V0011B, F0007B och K0002B.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kunskap och förståelse 1. redogöra för begreppet hållbar utveckling på nationell och global nivå; hur det uppstått, utvecklats över tiden, dess olika nutida definitioner, yttringar och etiska utgångspunkter

2. beskriva och förklara ekosystemets livsuppehållande och resursskapande strukturer och funktioner och kunna relatera detta till byggande

3. Beskriva hot mot en hållbar utveckling, ange, förklara och analysera bakomliggande orsaker samt de effekter som är/kan bli konsekvenser av icke hållbar utveckling, både generellt och kopplat till byggande och samhällsbyggande.

4. förklara vilka ekonomiska, rättsliga och politiska styrmedel, branschspecifika verktyg och systemanalyser som finnssom finns, i för hållande till en hållbar utveckling och kan användas i arbetet med det hållbara byggandet.

5. beskriva energi- material- och avfallsströmmar i samhället och ge exempel på materialhantering och återvinningsmöjligheter inom bygg- och anläggningsbranschen

6. ge exempel på hur bebyggelse kan planeras, utformas och byggas för att erhålla en hållbar utveckling inom bebyggd miljö och som kan leda till förbättrade sociala förhållanden och minska belastningen på natur- och kulturmiljö.

Färdighet och förmåga

7. visa på förmåga att skriva och granska vetenskaplig text och argumentera med hjälp av referenser.

Värderingsförmåga och förhållningssätt 8. ge exempel på och reflektera över ingenjörens roll och ansvar för en hållbar utveckling i sin yrkesutövning. 9. diskutera och reflektera över samt kritiskt förhålla sig till hållbar utveckling i byggande och samhällsbyggande utifrån arbetsmiljö och systemperspektiv.

## Kursinnehåll

Kursen behandlar begreppet hållbar utveckling utifrån ekologiska, ekonomiska och sociala perspektiv och relaterar detta till samhällsbyggande och professioner inom branschen. Kursen behandlar även hoten mot hållbar utveckling och även detta relateras till byggande. Energi-, Material- och avfallsströmmar i samhället samt materialhantering och återvinningsmöjligheter inom bygg- och anläggningsbranschen ingår också samt olika verktyg och styrmedel som finns som hjälpmedel för att arbeta för en hållbar utveckling. Även arbetsmiljöförhållande tas upp i kursen, i relation till samhällsbyggnadssektorn.

Inom ramen för kursen fokuseras även på vetenskapligt skrivande och argumentation med vetenskapliga referenser och hur citeringar i text görs.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen inkluderar föreläsningar, ett projektarbete, en seminarieserie med obligatoriska seminarier samt en reflektionsuppgift. Teoretiska aspekter gås igenom på föreläsningar. Syftet med projektuppgiften är att ge studenterna möjlighet att arbeta med begreppet hållbar utveckling mer praktiskt och sätta det i relation till samhällsbyggande och byggbranschen. Projektarbetet resulterar i en artikel med vetenskapligt format och redovisas muntligt i tvärgrupper. Genom seminarierna och reflektionsuppgiften får studenten reflektera över begreppet hållbar utveckling i sig och även sin roll och sitt ansvar i sin framtida yrkesutövning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Lärandemål 1-6 examineras med skriftlig tentamen (#0005) som bedöms enligt en graderad skala. Kursmål 8 och 9 examineras med aktivt deltagande på seminarierna (#0007) och med en individuellt skriven reflektion (#0008). Lärandemål 3, 4, 6, 7 och 9 examineras genom ett godkänt projektarbete (#0006). För godkänt projektarbete krävs en godkänd skriftlig artikel, en individuell skriftlig opponering som lämnats in och godkänts samt ett aktivt deltagande på den muntliga redovisningen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen V0015B motsvarar kursen L0010N

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Skriftlig tentamen | GU345 | 4,5 | Obligatorisk | H09 |  |
| 0006 | Projektuppgift | GU345 | 2,5 | Obligatorisk | H09 |  |
| 0007 | Seminarium | U G# | 0,3 | Inaktiv | H09 |  |
| 0008 | Reflektionsuppgift | U G# | 0,2 | Inaktiv | H09 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13

## Kursplanen fastställd

av Institutionen för samhällsbyggnad 2009-01-20
