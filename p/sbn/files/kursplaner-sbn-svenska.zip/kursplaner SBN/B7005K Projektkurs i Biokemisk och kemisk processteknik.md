---
kurskod: "B7005K"
titel: "Projektkurs i Biokemisk och kemisk processteknik"
hp: "7,5"
titel_en: "Senior Design Project in Biochemical and Chemical Engineering"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2023-06-02"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Kemisk apparatteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B7005K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B7005K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/b70/b7005k-projektkurs-i-biokemisk-och-kemisk-processteknik"
---

# Projektkurs i Biokemisk och kemisk processteknik (B7005K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Minst 90hp inom kemiteknik. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2. För utbytesstudenter gäller att examinator gör individuell prövning av behörigheten beroende på typ av projekt.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Målet är att studenten självständigt skall utforma, genomföra och redovisa ett projekt inom Biokemisk processteknik.

Studenten skall efter avslutad kurs kunna:

- Formulera ett relevant problem för utredning inom ämnet Biokemisk processteknik.

- Tillämpa teoretiska kunskaper som förvärvats under studier inom ett forskningsprojekt på ett självständigt och systematiskt sätt.

- Välj och motivera valda forskningsmetoder för ett forskningsprojekt.

- Effektivt planera och genomföra ett projektarbete inom det valda forskningsämnet.

- Självständigt lösa problem som uppkommer i projektet.

- Identifiera och kritiskt granska vetenskaplig information som är relevant för projektet.

- Utvärdera projektresultat med hjälp av erhållen teoretiska kunskap.

- Skriva en vetenskaplig rapport, håll en muntlig presentation och argumentera för slutsatserna.

## Kursinnehåll

Projektets frågeställning kommer att vara relaterat till Biokemiska Processteknikens nuvarande forskningsfront och kommer att definieras i samarbete med examinator. Exempel på ämnen (men inte begränsat) är användningen av mikroorganismer (som mikroalger, bakterier, jäst och svampar) och enzymer för produktion av produkter med högt mervärde (bioenergi, kemikalier, material, etc.) från förnybara resurser (som till exempel biomassa, organiskt avfall och CO2).

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten kommer att arbeta självständigt under handledning av en lärare som tilldelas utifrån det valda forskningsämnet. Studenter kommer att ges tillgång till relevant laboratoriefaciliteter för biokemisk processteknik, inklusive analytisk utrustning. Innan vetenskaplig och analytisk utrustning används kommer lämpliga utbildnings- och säkerhetsinstruktioner att ges. Studenterna kommer att ha en regelbunden kommunikation med läraren för att säkerställa att de får lämpligt stöd och att projektets framskrider enligt plan.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Lärandemålen examineras genom en skriftlig rapport och en muntlig presentation. Betygssättning sker enligt betygsskala G U 3 4 5. Praktisk tillämpning av lärandemålen examineras via projektarbetet.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Godkänd muntlig och skriftlig redovisning | GU345 | 7,5 | Obligatorisk | H07 | Ja |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-05-28 att gälla från H07.
