---
kurskod: "U0006B"
titel: "Tillståndsbaserat underhåll"
hp: "7,5"
titel_en: "Condition Based Maintenance"
giltig: "Höst 2019 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2019-09-04"
utbildningsniva: "Grundnivå"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=U0006B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=U0006B&lasPeriod=208&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/u00/u0006b-tillstandsbaserat-underhall"
---

# Tillståndsbaserat underhåll (U0006B)

## Behörighet

Grundläggande behörighet

## Examinator

Matti Rantatalo

## Mål/Förväntat studieresultat

Studenten skall visa grundläggande kunskap och förståelse för oförstörande provning, tillståndsövervakning och tillståndsbaserat underhåll. Studenten skall ha färdighet och förmåga att utföra provning och mätningar för tillståndkontroll och tillämpa adekvata analysmetoder.

## Kursinnehåll

Kursen innehåller:

- Sensorer och mätteknik

- Oförstörande provning

- Tillståndsövervakning

- Nedbrytningsmodeller och prediktion

- Datainsamling och analys

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av lektioner och laborationer. I kursen ingår att självständigt utföra provning. inspektion eller tillståndsövervakning av valda industriella system

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För godkänt betyg krävs godkända laborationer och inlämningsuppgift.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 4 | Obligatorisk | H19 |  |
| 0002 | Laborationer | U G# | 3,5 | Obligatorisk | H19 |  |

## Litteratur

*Litteratur. Gäller från Höst 2019 Lp 1* Meddelas vid kursstart.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-09-04
