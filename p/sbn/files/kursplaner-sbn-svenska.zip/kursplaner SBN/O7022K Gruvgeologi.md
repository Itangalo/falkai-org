---
kurskod: "O7022K"
titel: "Gruvgeologi"
hp: "7,5"
titel_en: "Mining Geology"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Malmgeologi"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O7022K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O7022K&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o70/o7022k-gruvgeologi"
---

# Gruvgeologi (O7022K)

## Ingår i huvudområde

Geovetenskap

## Behörighet

90hp inom geovetenskap.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens mål är att studenten skaffar sig en avancerad förståelse för malm- och mineralfyndigheters undersökning och värdering.

Studenten ska kunna utföra modellering av mineralfyndigheters halt och tonnage baserat på geologiska data och behandling av haltdata i 3D miljö. Studenten skall kunna redogöra för hur cut-off begreppet inverkar på mineraltillgångars storlek och halt, och kunna applicera grundläggande geostatistiska metoder för beräkningar av medelhalter i borrhål och profiler utifrån halt, längd och densitetsdata.

Studenten skall kunna redogöra för skillnaden i konfidensnivå mellan antagna, indikerade och kända mineraltillgångar, samt deras distinktion från mineralreserver. I detta ingår att kunna förklara hur olika modifierande faktorer såsom val av brytningsmetoder, anrikningsmetoder, metallurgiska faktorer, miljöfaktorer, sociala faktorer, juridiska faktorer och ekonomiska faktorer inverkar på ett gruvprojekts genomförbarhet. Studenten skall kunna kritiskt analysera tekniska rapporter från gruv- och prospekteringsprojekt med avseende hur väl de lever upp till de krav som ställs i internationella branschstandarder för rapportering av mineraltillgångar.

Studenten skall kunna skall kunna redogöra för olika strategier för haltkontroll och gruvkartering, och kunna välja metoder baserat på fyndighetens geologi samt brytningsmetoden. Studenten skall kunna insamla geologisk information från brytningsrum för att karaktärisera malmgränser och geologiska strukturer, och använda denna information för att utföra uppskattningar av gråbergsinblandning och medelhalter.

## Kursinnehåll

Under kursen arbetar studenterna med olika aspekter av gruvprojekt och avancerade prospekteringsprojekt i värdekedjan, från modellering av mineraltillgångar från geologisk data innan brytning, till processen att konvertera mineraltillgångar till mineralreserver genom applicering av modifierande faktorer, till de gruvgeologiska metoder som används för fortsatta karaktärisering och utvärdering av fyndigheter i samband med brytning.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Ämnet presenteras i form av klassföreläsningar av flera föreläsare. Fördjupning i ämnet sker genom individuella studentprojekt som baseras på litteraturstudie av tekniska rapporter från gruvprojekt och avancerade prospekteringsprojekt, skriftlig redovisning, samt gruppdiskussioner i seminarieform.

Praktiska färdigheter tränas genom övningar i malmberäkningsmetodik på papper och i programvara, beräkning av malmsektioner, gruvkartering, haltkontroll och malmgränskontroll. Övningarna kommer delvis att vara kopplade till föreläsningar och utföras parallellt.

Dokumenthantering sker i lärplattformen CANVAS.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Skriftlig tentamen ges med differentierade betyg. Betygsskala: 5 4 3 U. För att blir godkänd på kursen krävs dessutom att studenten genomför och skriftligt redovisar både praktiska uppgifter och sina individuella projektarbeten och får godkänt på dem.

Rapporter som inte uppnått ställda kvalitetskrav inom en vecka efter innevarande läsperiods slut innebär betyget underkänt för det praktiska momentet. Det praktiska momentet i sin helhet får då utföras vid ett kommande kurstillfälle, under förutsättningen att lediga platser finns tillgängliga.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen O7022K motsvarar kursen O7011K

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 4 | Obligatorisk | H16 |  |
| 0002 | Projektuppgifter | GU345 | 2,5 | Obligatorisk | H16 |  |
| 0003 | Övningsuppgifter | U G# | 1 | Obligatorisk | H16 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2016-02-10
