# Kursplaner vid SBN/CENE, Luleå tekniska universitet

257 aktiva kursplaner där Kursgivare är Institutionen för samhällsbyggnad och naturresurser (SBN). Hämtade 2026-08-17 från LTU:s kursplanearkiv (epok.ltu.se), svensk version, senaste antagningstermin. Konverterade från PDF till Markdown med YAML-frontmatter.

Engelska versioner av samma kursplaner finns i `../Syllabi SBN (English)/`. Strukturanalysen ligger i `../Analys av kursplaner SBN.md`.

## Metod

- Alla aktiva kursplaner vid LTU listades via kursplanearkivet på ltu.se (1 508 unika kurser, filtrerat på Utbildningstyp = Kurs och Nedlagd = Nej).
- För varje kurs hämtades den officiella kursplane-PDF:en från epok.ltu.se.
- Kursplanerna filtrerades på fältet **Kursgivare**, som anger vilken institution som ger kursen.
- Fördelningen över hela LTU: ETKS 432, SRT 337, HLT 275, **SBN 257**, TVM 195, övriga 12.

## Kurser per ämne

### Väg- och vattenbyggnad (36)

- [C0022B Samhällets planering för risker och kriser](C0022B%20Samhällets%20planering%20för%20risker%20och%20kriser.md) – 7,5 hp, Grundnivå
- [D7001B Gruvautomation](D7001B%20Gruvautomation.md) – 7,5 hp, Avancerad nivå
- [G0001B Väg och järnvägsprojektering med datorstöd](G0001B%20Väg%20och%20järnvägsprojektering%20med%20datorstöd.md) – 7,5 hp, Grundnivå
- [G0002B Vägar och järnvägar](G0002B%20Vägar%20och%20järnvägar.md) – 7,5 hp, Grundnivå
- [G0005B Solvärmesystem](G0005B%20Solvärmesystem.md) – 7,5 hp, Grundnivå
- [G0015B Väg- och järnvägsbyggnad](G0015B%20Väg-%20och%20järnvägsbyggnad.md) – 7,5 hp, Grundnivå
- [G7009B Gruvdammar och dammsäkerhet](G7009B%20Gruvdammar%20och%20dammsäkerhet.md) – 3 hp, Avancerad nivå
- [G7011B Vägar och järnvägar, fortsättningskurs](G7011B%20Vägar%20och%20järnvägar%20fortsättningskurs.md) – 7,5 hp, Avancerad nivå
- [K0002B Byggmaterial](K0002B%20Byggmaterial.md) – 7,5 hp, Grundnivå
- [K0007B Risk och säkerhet - Grundkurs](K0007B%20Risk%20och%20säkerhet%20-%20Grundkurs.md) – 7,5 hp, Grundnivå
- [K0011B Byggnadsteknik](K0011B%20Byggnadsteknik.md) – 7,5 hp, Grundnivå
- [K0013B Byggkonstruktion](K0013B%20Byggkonstruktion.md) – 7,5 hp, Grundnivå
- [K0015B Verktyg för byggkalkyler och rapporter](K0015B%20Verktyg%20för%20byggkalkyler%20och%20rapporter.md) – 15 hp, Grundnivå
- [K0017B Tillämpad riskhantering](K0017B%20Tillämpad%20riskhantering.md) – 7,5 hp, Grundnivå
- [K0018B Utlandsbyggande](K0018B%20Utlandsbyggande.md) – 7,5 hp, Grundnivå
- [K7018B Projektkurs i Byggmaterial](K7018B%20Projektkurs%20i%20Byggmaterial.md) – 7,5 hp, Avancerad nivå
- [K7019B Byggmaterialens påverkan på inomhusmiljön: Uppfattning och verklighet](K7019B%20Byggmaterialens%20påverkan%20på%20inomhusmiljön%20Uppfattning%20och%20verklighet.md) – 7,5 hp, Avancerad nivå
- [K7026B Träkonstruktion 1](K7026B%20Träkonstruktion%201.md) – 7,5 hp, Avancerad nivå
- [K7027B Modellering och simulering av träkonstruktioner](K7027B%20Modellering%20och%20simulering%20av%20träkonstruktioner.md) – 7,5 hp, Avancerad nivå
- [K7028B Beräkningsprojekt, träkonstruktion](K7028B%20Beräkningsprojekt%20träkonstruktion.md) – 7,5 hp, Avancerad nivå
- [K7029B Träkonstruktion 2, säkerhet vid extrem påverkan](K7029B%20Träkonstruktion%202%20säkerhet%20vid%20extrem%20påverkan.md) – 7,5 hp, Avancerad nivå
- [T0028B Utlandsbyggande](T0028B%20Utlandsbyggande.md) – 7,5 hp, Grundnivå
- [T7025B Projektkurs i Jord och Berg](T7025B%20Projektkurs%20i%20Jord%20och%20Berg.md) – 7,5 hp, Avancerad nivå
- [U0007B Byggnadsteknik](U0007B%20Byggnadsteknik.md) – 7,5 hp, Grundnivå
- [V0014B Hydraulik och geologi](V0014B%20Hydraulik%20och%20geologi.md) – 7,5 hp, Grundnivå
- [V0015B Hållbart byggande](V0015B%20Hållbart%20byggande.md) – 7,5 hp, Grundnivå
- [V0018B Samhällsbyggande](V0018B%20Samhällsbyggande.md) – 7,5 hp, Grundnivå
- [X0007B Examensarbete i Väg- och vattenbyggnad, kandidat](X0007B%20Examensarbete%20i%20Väg-%20och%20vattenbyggnad%20kandidat.md) – 15 hp, Grundnivå
- [X7003B Examensarbete i Väg- och vattenbyggnad, master](X7003B%20Examensarbete%20i%20Väg-%20och%20vattenbyggnad%20master.md) – 30 hp, Avancerad nivå
- [X7004B Examensarbete i Brandteknik, civilingenjör](X7004B%20Examensarbete%20i%20Brandteknik%20civilingenjör.md) – 30 hp, Avancerad nivå
- [X7006B Examensarbete i Väg- och vattenbyggnad, inriktning Byggande, civilingenjör](X7006B%20Examensarbete%20i%20Väg-%20och%20vattenbyggnad%20inriktning%20Byggande%20civilingenj.md) – 30 hp, Avancerad nivå
- [X7009B Examensarbete i Väg- och vattenbyggnad, inriktning Jord- och bergbyggnad, civilingenjör](X7009B%20Examensarbete%20i%20Väg-%20och%20vattenbyggnad%20inriktning%20Jord-%20och%20bergbyggna.md) – 30 hp, Avancerad nivå
- [X7010B Examensarbete i Väg- och vattenbyggnad, inriktning Konstruktion, civilingenjör](X7010B%20Examensarbete%20i%20Väg-%20och%20vattenbyggnad%20inriktning%20Konstruktion%20civilin.md) – 30 hp, Avancerad nivå
- [X7015B Examensarbete i träkonstruktion, magister](X7015B%20Examensarbete%20i%20träkonstruktion%20magister.md) – 15 hp, Avancerad nivå
- [Y0004B Byggmätning 2](Y0004B%20Byggmätning%202.md) – 7,5 hp, Grundnivå
- [Y0009B Examensarbete, Samhällsbyggnad](Y0009B%20Examensarbete%20Samhällsbyggnad.md) – 7,5 hp, Grundnivå

### Underhållsteknik (32)

- [D0002B Drift och underhåll](D0002B%20Drift%20och%20underhåll.md) – 7,5 hp, Grundnivå
- [D0004B Drift och underhåll - Hydropower](D0004B%20Drift%20och%20underhåll%20-%20Hydropower.md) – 7,5 hp, Grundnivå
- [D0010B Underhållsstrategi](D0010B%20Underhållsstrategi.md) – 7,5 hp, Grundnivå
- [D0011B Introduktion till drift- och underhållsteknik - grundbegrepp](D0011B%20Introduktion%20till%20drift-%20och%20underhållsteknik%20-%20grundbegrepp.md) – 7,5 hp, Grundnivå
- [D0012B Livscykel- och livscykelkostnadsanalys](D0012B%20Livscykel-%20och%20livscykelkostnadsanalys.md) – 7,5 hp, Grundnivå
- [D0016B Tillförlitlighetsanalys i underhåll](D0016B%20Tillförlitlighetsanalys%20i%20underhåll.md) – 7,5 hp, Grundnivå
- [D0017B Projektkurs i drift och underhållsteknik](D0017B%20Projektkurs%20i%20drift%20och%20underhållsteknik.md) – 15 hp, Grundnivå
- [D0018B Projektkurs i underhållsteknik](D0018B%20Projektkurs%20i%20underhållsteknik.md) – 15 hp, Grundnivå
- [D0019B Mänskliga faktorer för säkerhet i arbetsmiljön](D0019B%20Mänskliga%20faktorer%20för%20säkerhet%20i%20arbetsmiljön.md) – 7,5 hp, Grundnivå
- [D0020B Sakernas internet och signalanalys för tillståndsövervakning](D0020B%20Sakernas%20internet%20och%20signalanalys%20för%20tillståndsövervakning.md) – 7,5 hp, Grundnivå
- [D0022B Underhåll och produktionssystem](D0022B%20Underhåll%20och%20produktionssystem.md) – 7,5 hp, Grundnivå
- [D0023B IoT-baserad tillståndsövervakning och underhållsteknologier](D0023B%20IoT-baserad%20tillståndsövervakning%20och%20underhållsteknologier.md) – 7,5 hp, Grundnivå
- [D7004B Drift och underhållsteknik](D7004B%20Drift%20och%20underhållsteknik.md) – 7,5 hp, Avancerad nivå
- [D7007B Underhållsteknik](D7007B%20Underhållsteknik.md) – 7,5 hp, Avancerad nivå
- [D7008B Tillståndskontroll och tillståndsbaserat underhåll](D7008B%20Tillståndskontroll%20och%20tillståndsbaserat%20underhåll.md) – 7,5 hp, Avancerad nivå
- [D7009B Projektkurs i underhållsteknik](D7009B%20Projektkurs%20i%20underhållsteknik.md) – 30 hp, Avancerad nivå
- [D7012B Avancerad tillförlitlighetsteknik](D7012B%20Avancerad%20tillförlitlighetsteknik.md) – 7,5 hp, Avancerad nivå
- [D7015B Industriell AI och eUnderhåll - Del I: Teorier & koncept](D7015B%20Industriell%20AI%20och%20eUnderhåll%20-%20Del%20I%20Teorier%20%20koncept.md) – 7,5 hp, Avancerad nivå
- [D7016B Industriell AI och eUnderhåll - Del II: Praktisk implementering](D7016B%20Industriell%20AI%20och%20eUnderhåll%20-%20Del%20II%20Praktisk%20implementering.md) – 7,5 hp, Avancerad nivå
- [D7017B Augmented decision- making](D7017B%20Augmented%20decision-%20making.md) – 7,5 hp, Avancerad nivå
- [D7018B Industriell AI för drift och underhåll](D7018B%20Industriell%20AI%20för%20drift%20och%20underhåll.md) – 7,5 hp, Avancerad nivå
- [D7019B Robust infrastruktur - Anpassning av drift och underhåll till klimatförändringar](D7019B%20Robust%20infrastruktur%20-%20Anpassning%20av%20drift%20och%20underhåll%20till%20klimatfö.md) – 7,5 hp, Avancerad nivå
- [D7020B Intelligent asset management](D7020B%20Intelligent%20asset%20management.md) – 7,5 hp, Avancerad nivå
- [D7021B Driftsäkerhet och underhållsteknik](D7021B%20Driftsäkerhet%20och%20underhållsteknik.md) – 7,5 hp, Avancerad nivå
- [D7022B Prediktiv analys och tillståndsbaserat underhåll](D7022B%20Prediktiv%20analys%20och%20tillståndsbaserat%20underhåll.md) – 7,5 hp, Avancerad nivå
- [D7023B Intelligent asset management och industriell AI](D7023B%20Intelligent%20asset%20management%20och%20industriell%20AI.md) – 3 hp, Avancerad nivå
- [U0003B Introduktion till drift- och underhållsteknik](U0003B%20Introduktion%20till%20drift-%20och%20underhållsteknik.md) – 7,5 hp, Grundnivå
- [U0004B Underhållsstrategi](U0004B%20Underhållsstrategi.md) – 7,5 hp, Grundnivå
- [U0005B Livscykelkostandsanalys](U0005B%20Livscykelkostandsanalys.md) – 7,5 hp, Grundnivå
- [U0006B Tillståndsbaserat underhåll](U0006B%20Tillståndsbaserat%20underhåll.md) – 7,5 hp, Grundnivå
- [X0009B Examensarbete i Underhållsteknik, högskoleingenjör](X0009B%20Examensarbete%20i%20Underhållsteknik%20högskoleingenjör.md) – 15 hp, Grundnivå
- [X7013B Examensarbete i Underhållsteknik, master](X7013B%20Examensarbete%20i%20Underhållsteknik%20master.md) – 30 hp, Avancerad nivå

### Geovetenskap (20)

- [L0041K Kvartärgeologi](L0041K%20Kvartärgeologi.md) – 7,5 hp, Grundnivå
- [L0047K Miljögeokemi](L0047K%20Miljögeokemi.md) – 7,5 hp, Grundnivå
- [L0048K Klimatförändringar, principer och processer](L0048K%20Klimatförändringar%20principer%20och%20processer.md) – 7,5 hp, Grundnivå
- [L0049K Hållbar mineralutvinning 1](L0049K%20Hållbar%20mineralutvinning%201.md) – 15 hp, Grundnivå
- [L0050K Geokemi](L0050K%20Geokemi.md) – 7,5 hp, Grundnivå
- [L0051K Projektkurs i mineralresurser](L0051K%20Projektkurs%20i%20mineralresurser.md) – 15 hp, Grundnivå
- [L7003K Projektkurs i tillämpad geologi](L7003K%20Projektkurs%20i%20tillämpad%20geologi.md) – 15 hp, Avancerad nivå
- [L7021K Sötvattengeokemi](L7021K%20Sötvattengeokemi.md) – 7,5 hp, Avancerad nivå
- [L7022K Projektkurs i tillämpad geologi](L7022K%20Projektkurs%20i%20tillämpad%20geologi.md) – 7,5 hp, Avancerad nivå
- [L7027K Hydrogeokemi](L7027K%20Hydrogeokemi.md) – 7,5 hp, Avancerad nivå
- [O0007K Strukturgeologi](O0007K%20Strukturgeologi.md) – 7,5 hp, Grundnivå
- [O0035K Geologi, grundkurs](O0035K%20Geologi%20grundkurs.md) – 7,5 hp, Grundnivå
- [O0036K Mineralogi](O0036K%20Mineralogi.md) – 7,5 hp, Grundnivå
- [O7029K Tillämpad strukturgeologi](O7029K%20Tillämpad%20strukturgeologi.md) – 7,5 hp, Avancerad nivå
- [X0001K Examensarbete i Naturresursteknik, kandidat](X0001K%20Examensarbete%20i%20Naturresursteknik%20kandidat.md) – 15 hp, Grundnivå
- [X0004K Examensarbete i Hållbar mineralutvinning, kandidat](X0004K%20Examensarbete%20i%20Hållbar%20mineralutvinning%20kandidat.md) – 15 hp, Grundnivå
- [X7001K Examensarbete i Geovetenskap, master](X7001K%20Examensarbete%20i%20Geovetenskap%20master.md) – 30 hp, Avancerad nivå
- [X7004K Examensarbete i Naturresursteknik, inriktning Malm och mineral, civilingenjör](X7004K%20Examensarbete%20i%20Naturresursteknik%20inriktning%20Malm%20och%20mineral%20civiling.md) – 30 hp, Avancerad nivå
- [X7015K Examensarbete i Geovetenskap för prospektering, master](X7015K%20Examensarbete%20i%20Geovetenskap%20för%20prospektering%20master.md) – 30 hp, Avancerad nivå
- [X7016K Examensarbete i Tillämpad miljögeokemi, master](X7016K%20Examensarbete%20i%20Tillämpad%20miljögeokemi%20master.md) – 30 hp, Avancerad nivå

### Arkitektur (19)

- [C0024B Samhällets planering för risker och kriser](C0024B%20Samhällets%20planering%20för%20risker%20och%20kriser.md) – 7,5 hp, Grundnivå
- [C0025B Samhällets planering för risker och kriser](C0025B%20Samhällets%20planering%20för%20risker%20och%20kriser.md) – 7,5 hp, Grundnivå
- [C7002B Hållbar stadsutveckling](C7002B%20Hållbar%20stadsutveckling.md) – 7,5 hp, Avancerad nivå
- [F0018B Arkitekturhistoria - En modern metropol och dess historia - en exkursion till Paris](F0018B%20Arkitekturhistoria%20-%20En%20modern%20metropol%20och%20dess%20historia%20-%20en%20exkursi.md) – 7,5 hp, Grundnivå
- [F0019B Arkitekturhistoria](F0019B%20Arkitekturhistoria.md) – 7,5 hp, Grundnivå
- [F0020B Gestaltning och funktion](F0020B%20Gestaltning%20och%20funktion.md) – 7,5 hp, Grundnivå
- [F0021B Urban design](F0021B%20Urban%20design.md) – 7,5 hp, Grundnivå
- [F0022B Gestaltning och funktion](F0022B%20Gestaltning%20och%20funktion.md) – 7,5 hp, Grundnivå
- [F7001B Planeringsmetoder](F7001B%20Planeringsmetoder.md) – 7,5 hp, Avancerad nivå
- [F7003B Urbanmorfologi](F7003B%20Urbanmorfologi.md) – 7,5 hp, Avancerad nivå
- [F7007B Arkitektonisk byggnadsprojektering](F7007B%20Arkitektonisk%20byggnadsprojektering.md) – 7,5 hp, Avancerad nivå
- [F7008B Arkitektoniskt byggnadsprogram](F7008B%20Arkitektoniskt%20byggnadsprogram.md) – 7,5 hp, Avancerad nivå
- [F7014B Arkitekturutveckling](F7014B%20Arkitekturutveckling.md) – 7,5 hp, Avancerad nivå
- [F7016B Detaljplanering](F7016B%20Detaljplanering.md) – 7,5 hp, Avancerad nivå
- [F7017B Stadsmiljö](F7017B%20Stadsmiljö.md) – 7,5 hp, Avancerad nivå
- [P0016A Boendetillfredställelse](P0016A%20Boendetillfredställelse.md) – 7,5 hp, Grundnivå
- [X0006B Examensarbete i Arkitektur, kandidat](X0006B%20Examensarbete%20i%20Arkitektur%20kandidat.md) – 15 hp, Grundnivå
- [X7005B Examensarbete i Arkitektur, inriktning Husbyggnad, civilingenjör](X7005B%20Examensarbete%20i%20Arkitektur%20inriktning%20Husbyggnad%20civilingenjör.md) – 30 hp, Avancerad nivå
- [X7008B Examensarbete i Arkitektur, inriktning Stadsbyggnad, civilingenjör](X7008B%20Examensarbete%20i%20Arkitektur%20inriktning%20Stadsbyggnad%20civilingenjör.md) – 30 hp, Avancerad nivå

### Brandteknik (14)

- [S0005B Projektkurs i brandteknik](S0005B%20Projektkurs%20i%20brandteknik.md) – 7,5 hp, Grundnivå
- [S0006B Brandtekniska beräkningar](S0006B%20Brandtekniska%20beräkningar.md) – 7,5 hp, Grundnivå
- [S0010B Byggkonstruktion brand](S0010B%20Byggkonstruktion%20brand.md) – 7,5 hp, Grundnivå
- [S0011B Brandfysik](S0011B%20Brandfysik.md) – 7,5 hp, Grundnivå
- [S7002B Branddynamik II](S7002B%20Branddynamik%20II.md) – 7,5 hp, Avancerad nivå
- [S7008B Tillämpad branddynamik](S7008B%20Tillämpad%20branddynamik.md) – 7,5 hp, Avancerad nivå
- [S7013B Brandutsatta konstruktioner](S7013B%20Brandutsatta%20konstruktioner.md) – 15 hp, Avancerad nivå
- [S7014B Branddynamik](S7014B%20Branddynamik.md) – 7,5 hp, Avancerad nivå
- [S7015B Brandmodellering](S7015B%20Brandmodellering.md) – 7,5 hp, Avancerad nivå
- [S7016B Projektkurs i brandteknik](S7016B%20Projektkurs%20i%20brandteknik.md) – 15 hp, Avancerad nivå
- [S7017B Projektkurs i brandteknik](S7017B%20Projektkurs%20i%20brandteknik.md) – 30 hp, Avancerad nivå
- [S7018B Tillämpad brandteknik](S7018B%20Tillämpad%20brandteknik.md) – 7,5 hp, Avancerad nivå
- [S7021B Vätgasjetflammor och vätgasexplosioner](S7021B%20Vätgasjetflammor%20och%20vätgasexplosioner.md) – 1,5 hp, Avancerad nivå
- [X7014B Examensarbete i Väg- och vattenbyggnad, inriktning Byggkonstruktion och brand, civilingenjör](X7014B%20Examensarbete%20i%20Väg-%20och%20vattenbyggnad%20inriktning%20Byggkonstruktion%20och.md) – 30 hp, Avancerad nivå

### Byggproduktion (13)

- [P0001B Bygg- och anläggningsproduktion](P0001B%20Bygg-%20och%20anläggningsproduktion.md) – 7,5 hp, Grundnivå
- [P0004B Byggstyrning A- Anbudskalkylering](P0004B%20Byggstyrning%20A-%20Anbudskalkylering.md) – 7,5 hp, Grundnivå
- [P0005B Byggstyrning B- Produktionsplanering](P0005B%20Byggstyrning%20B-%20Produktionsplanering.md) – 7,5 hp, Grundnivå
- [P0007B Byggprojektledning](P0007B%20Byggprojektledning.md) – 7,5 hp, Grundnivå
- [P0012B Projektering](P0012B%20Projektering.md) – 7,5 hp, Grundnivå
- [P7006B Datorstödd byggproduktion](P7006B%20Datorstödd%20byggproduktion.md) – 7,5 hp, Avancerad nivå
- [P7014B Bygglogistik](P7014B%20Bygglogistik.md) – 7,5 hp, Avancerad nivå
- [U0002B Industrialiserat byggande](U0002B%20Industrialiserat%20byggande.md) – 7,5 hp, Grundnivå
- [U0012B Lean Construction grund](U0012B%20Lean%20Construction%20grund.md) – 1,5 hp, Grundnivå
- [W0009B BIM för visualisering och VR](W0009B%20BIM%20för%20visualisering%20och%20VR.md) – 7,5 hp, Grundnivå
- [W7011B Byggnaden som system](W7011B%20Byggnaden%20som%20system.md) – 7,5 hp, Avancerad nivå
- [Y0010B Bygg och anläggning VFU](Y0010B%20Bygg%20och%20anläggning%20VFU.md) – 15 hp, Grundnivå
- [Y0011B Examensarbete Bygg och anläggning](Y0011B%20Examensarbete%20Bygg%20och%20anläggning.md) – 7,5 hp, Grundnivå

### Berg- och mineralteknik (12)

- [T0024B Praktisk bergmekanik](T0024B%20Praktisk%20bergmekanik.md) – 7,5 hp, Grundnivå
- [T0029B Jord och berg som konstruktionsmaterial](T0029B%20Jord%20och%20berg%20som%20konstruktionsmaterial.md) – 7,5 hp, Grundnivå
- [T0030B Hållbar mineralutvinning 2](T0030B%20Hållbar%20mineralutvinning%202.md) – 15 hp, Grundnivå
- [T0031B Hållbara brytningsmetoder](T0031B%20Hållbara%20brytningsmetoder.md) – 7,5 hp, Grundnivå
- [T0032B Hållbar gruvdrift och tunnelbyggande](T0032B%20Hållbar%20gruvdrift%20och%20tunnelbyggande.md) – 7,5 hp, Grundnivå
- [T0033B Praktisk bergteknik](T0033B%20Praktisk%20bergteknik.md) – 7,5 hp, Grundnivå
- [T7001B Bergmekanikens grunder](T7001B%20Bergmekanikens%20grunder.md) – 7,5 hp, Avancerad nivå
- [T7002B Dimensionering av bergkonstruktioner](T7002B%20Dimensionering%20av%20bergkonstruktioner.md) – 7,5 hp, Avancerad nivå
- [T7006B Tillämpad sprängteknik](T7006B%20Tillämpad%20sprängteknik.md) – 7,5 hp, Avancerad nivå
- [T7020B Tillämpad bergmekanik](T7020B%20Tillämpad%20bergmekanik.md) – 7,5 hp, Avancerad nivå
- [T7023B Tunnelprojektering](T7023B%20Tunnelprojektering.md) – 7,5 hp, Avancerad nivå
- [T7026B Gruvdesign och brytningsekonomi](T7026B%20Gruvdesign%20och%20brytningsekonomi.md) – 7,5 hp, Avancerad nivå

### Geoteknik (12)

- [G0003B Geoteknik gk](G0003B%20Geoteknik%20gk.md) – 7,5 hp, Grundnivå
- [G0004B Geomekanik](G0004B%20Geomekanik.md) – 7,5 hp, Grundnivå
- [G0017B Snö och is](G0017B%20Snö%20och%20is.md) – 7,5 hp, Grundnivå
- [G7002B Projektkurs i geoteknik, fördjupning](G7002B%20Projektkurs%20i%20geoteknik%20fördjupning.md) – 7,5 hp, Avancerad nivå
- [G7003B Miljögeoteknik, förorenad mark](G7003B%20Miljögeoteknik%20förorenad%20mark.md) – 7,5 hp, Avancerad nivå
- [G7004B Damm II - dammar och dammsäkerhet](G7004B%20Damm%20II%20-%20dammar%20och%20dammsäkerhet.md) – 7,5 hp, Avancerad nivå
- [G7006B Grundläggningsteknik](G7006B%20Grundläggningsteknik.md) – 7,5 hp, Avancerad nivå
- [G7008B Geoteknik fk](G7008B%20Geoteknik%20fk.md) – 7,5 hp, Avancerad nivå
- [G7010B Jordmodellering med finita elementprogrammet PLAXIS](G7010B%20Jordmodellering%20med%20finita%20elementprogrammet%20PLAXIS.md) – 7,5 hp, Avancerad nivå
- [G7013B Naturvärme](G7013B%20Naturvärme.md) – 7,5 hp, Avancerad nivå
- [G7014B Projektkurs i geoteknik](G7014B%20Projektkurs%20i%20geoteknik.md) – 30 hp, Avancerad nivå
- [G7015B Jorddynamik och naturliga geotekniska faror](G7015B%20Jorddynamik%20och%20naturliga%20geotekniska%20faror.md) – 7,5 hp, Avancerad nivå

### Konstruktionsteknik (11)

- [B0002B Konstruktionsteknik](B0002B%20Konstruktionsteknik.md) – 7,5 hp, Grundnivå
- [B7003B Byggnadsmekanik II](B7003B%20Byggnadsmekanik%20II.md) – 7,5 hp, Avancerad nivå
- [B7004B Byggnadsmekanik I](B7004B%20Byggnadsmekanik%20I.md) – 7,5 hp, Avancerad nivå
- [K0004B Betongteknik](K0004B%20Betongteknik.md) – 7,5 hp, Grundnivå
- [K0016B Markprojektering](K0016B%20Markprojektering.md) – 7,5 hp, Grundnivå
- [K7015B Stål- och träkonstruktioner](K7015B%20Stål-%20och%20träkonstruktioner.md) – 7,5 hp, Avancerad nivå
- [K7016B Hallbyggnader](K7016B%20Hallbyggnader.md) – 7,5 hp, Avancerad nivå
- [K7017B Projektkurs i Byggkonstruktion](K7017B%20Projektkurs%20i%20Byggkonstruktion.md) – 7,5 hp, Avancerad nivå
- [K7020B Stålkonstruktioner](K7020B%20Stålkonstruktioner.md) – 7,5 hp, Avancerad nivå
- [K7021B Träkonstruktioner](K7021B%20Träkonstruktioner.md) – 7,5 hp, Avancerad nivå
- [K7022B Dimensionering av grundkonstruktioner](K7022B%20Dimensionering%20av%20grundkonstruktioner.md) – 7,5 hp, Avancerad nivå

### Miljöteknik (11)

- [A0013B Avfallsteknik](A0013B%20Avfallsteknik.md) – 7,5 hp, Grundnivå
- [A7001B Upplagsteknik](A7001B%20Upplagsteknik.md) – 7,5 hp, Avancerad nivå
- [A7005B Miljöteknisk mikrobiologi](A7005B%20Miljöteknisk%20mikrobiologi.md) – 7,5 hp, Avancerad nivå
- [A7007B Projekt i Avfallsteknik, fördjupning](A7007B%20Projekt%20i%20Avfallsteknik%20fördjupning.md) – 7,5 hp, Avancerad nivå
- [A7008B Projekt i Avfallsteknik, fördjupning](A7008B%20Projekt%20i%20Avfallsteknik%20fördjupning.md) – 15 hp, Avancerad nivå
- [A7009B Projekt i Avfallsteknik, fördjupning](A7009B%20Projekt%20i%20Avfallsteknik%20fördjupning.md) – 30 hp, Avancerad nivå
- [A7011B Miljöföroreningar och reningsteknik](A7011B%20Miljöföroreningar%20och%20reningsteknik.md) – 7,5 hp, Avancerad nivå
- [L7025K Miljöprovtagning och utvärdering](L7025K%20Miljöprovtagning%20och%20utvärdering.md) – 7,5 hp, Avancerad nivå
- [L7026K Provtagning och utvärdering vid miljökontroll](L7026K%20Provtagning%20och%20utvärdering%20vid%20miljökontroll.md) – 7,5 hp, Avancerad nivå
- [M0002K Miljöanalys](M0002K%20Miljöanalys.md) – 7,5 hp, Grundnivå
- [X7002K Examensarbete i Naturresursteknik, inriktning Miljö och vatten, civilingenjör](X7002K%20Examensarbete%20i%20Naturresursteknik%20inriktning%20Miljö%20och%20vatten%20civiling.md) – 30 hp, Avancerad nivå

### Kemiteknik (10)

- [B7007K Projektkurs i Biokemisk och kemisk processteknik](B7007K%20Projektkurs%20i%20Biokemisk%20och%20kemisk%20processteknik.md) – 15 hp, Avancerad nivå
- [K0024K Hållbar process- och kemiteknik](K0024K%20Hållbar%20process-%20och%20kemiteknik.md) – 7,5 hp, Grundnivå
- [K7007K Ingenjörspraktik](K7007K%20Ingenjörspraktik.md) – 30 hp, Avancerad nivå
- [M0004K Ytor och kolloider](M0004K%20Ytor%20och%20kolloider.md) – 7,5 hp, Grundnivå
- [T0007K Kemisk processteknik](T0007K%20Kemisk%20processteknik.md) – 7,5 hp, Grundnivå
- [U7001K Geometallurgi](U7001K%20Geometallurgi.md) – 7,5 hp, Avancerad nivå
- [X0002K Examensarbete i Industriell miljö- och processteknik, kandidat](X0002K%20Examensarbete%20i%20Industriell%20miljö-%20och%20processteknik%20kandidat.md) – 15 hp, Grundnivå
- [X7005K Examensarbete i Industriell miljö- och processteknik, inriktning Hållbar mineral- och metallutvinning, civilingenjör](X7005K%20Examensarbete%20i%20Industriell%20miljö-%20och%20processteknik%20inriktning%20Hållba.md) – 30 hp, Avancerad nivå
- [X7011K Examensarbete i Hållbar process- och kemiteknik, inriktning Mineralteknik och metallurgi, civilingenjör](X7011K%20Examensarbete%20i%20Hållbar%20process-%20och%20kemiteknik%20inriktning%20Mineraltekn.md) – 30 hp, Avancerad nivå
- [X7012K Examensarbete i Hållbar process- och kemiteknik, inriktning Kemi- och bioprocessteknik, civilingenjör](X7012K%20Examensarbete%20i%20Hållbar%20process-%20och%20kemiteknik%20inriktning%20Kemi-%20och%20b.md) – 30 hp, Avancerad nivå

### Geografisk informationsteknologi (9)

- [L0002B Introduktion till programmering och C#](L0002B%20Introduktion%20till%20programmering%20och%20C.md) – 7,5 hp, Grundnivå
- [L0003B Databaser, en introduktion](L0003B%20Databaser%20en%20introduktion.md) – 7,5 hp, Grundnivå
- [L0005B ArcGIS](L0005B%20ArcGIS.md) – 7,5 hp, Grundnivå
- [L0008B Kartografisk visualisering](L0008B%20Kartografisk%20visualisering.md) – 7,5 hp, Grundnivå
- [L0010B Geografisk analys](L0010B%20Geografisk%20analys.md) – 7,5 hp, Grundnivå
- [L0021B ArcGIS Pro](L0021B%20ArcGIS%20Pro.md) – 7,5 hp, Grundnivå
- [L0022B Introduktion till Pyhton med inriktning mot Geografiska informationssystem (GIS)](L0022B%20Introduktion%20till%20Pyhton%20med%20inriktning%20mot%20Geografiska%20informationssy.md) – 7,5 hp, Grundnivå
- [L0023B Introduktion till QGIS](L0023B%20Introduktion%20till%20QGIS.md) – 7,5 hp, Grundnivå
- [Y0003B Byggmätning 1](Y0003B%20Byggmätning%201.md) – 7,5 hp, Grundnivå

### VA-teknik (9)

- [V0012B Tillämpad hydraulik](V0012B%20Tillämpad%20hydraulik.md) – 7,5 hp, Grundnivå
- [V0016B VA-system](V0016B%20VA-system.md) – 7,5 hp, Grundnivå
- [V0017B Naturliga vattentransportprocesser](V0017B%20Naturliga%20vattentransportprocesser.md) – 7,5 hp, Grundnivå
- [V7002B Dagvatten](V7002B%20Dagvatten.md) – 7,5 hp, Avancerad nivå
- [V7010B Projektkurs - VA -teknik](V7010B%20Projektkurs%20-%20VA%20-teknik.md) – 15 hp, Avancerad nivå
- [V7013B Resurseffektiva vatten- och avloppssystem](V7013B%20Resurseffektiva%20vatten-%20och%20avloppssystem.md) – 7,5 hp, Avancerad nivå
- [V7014B Projektkurs i VA-teknik](V7014B%20Projektkurs%20i%20VA-teknik.md) – 30 hp, Avancerad nivå
- [V7015B Projektkurs i VA-teknik](V7015B%20Projektkurs%20i%20VA-teknik.md) – 7,5 hp, Avancerad nivå
- [V7016B Projektkurs i VA-teknik](V7016B%20Projektkurs%20i%20VA-teknik.md) – 15 hp, Avancerad nivå

### Mineralteknik (8)

- [M7001K Simulering av mineraltekniska processer](M7001K%20Simulering%20av%20mineraltekniska%20processer.md) – 7,5 hp, Avancerad nivå
- [M7003K Mineralteknik](M7003K%20Mineralteknik.md) – 7,5 hp, Avancerad nivå
- [M7007K Processmineralogi](M7007K%20Processmineralogi.md) – 7,5 hp, Avancerad nivå
- [M7011K Teknisk-ekonomisk bedömning av mineralindustriprojekt](M7011K%20Teknisk-ekonomisk%20bedömning%20av%20mineralindustriprojekt.md) – 7,5 hp, Avancerad nivå
- [M7012K Offentliggörande av mineralresurser och tillståndsprocesser](M7012K%20Offentliggörande%20av%20mineralresurser%20och%20tillståndsprocesser.md) – 7,5 hp, Avancerad nivå
- [X7008K Examensarbete i Geovetenskapliga resurser, master](X7008K%20Examensarbete%20i%20Geovetenskapliga%20resurser%20master.md) – 30 hp, Avancerad nivå
- [X7013K Examensarbete i Arktiska mineralresurser, inriktning Mineralentreprenörskap, master](X7013K%20Examensarbete%20i%20Arktiska%20mineralresurser%20inriktning%20Mineralentreprenör.md) – 30 hp, Avancerad nivå
- [X7014K Examensarbete i Arktiska mineralresurser, inriktning Mineralresurshantering, master](X7014K%20Examensarbete%20i%20Arktiska%20mineralresurser%20inriktning%20Mineralresurshante.md) – 30 hp, Avancerad nivå

### Processmetallurgi (8)

- [M7006K Geometallurgi](M7006K%20Geometallurgi.md) – 7,5 hp, Avancerad nivå
- [P0006K Högtemperaturprocesser](P0006K%20Högtemperaturprocesser.md) – 7,5 hp, Grundnivå
- [P0008K Mineralteknisk och metallurgisk processteknik](P0008K%20Mineralteknisk%20och%20metallurgisk%20processteknik.md) – 7,5 hp, Grundnivå
- [P7005K Hydrometallurgi](P7005K%20Hydrometallurgi.md) – 7,5 hp, Avancerad nivå
- [P7006K Högtemperaturmaterial](P7006K%20Högtemperaturmaterial.md) – 7,5 hp, Avancerad nivå
- [P7007K Projektkurs i Processmetallurgi](P7007K%20Projektkurs%20i%20Processmetallurgi.md) – 7,5 hp, Avancerad nivå
- [P7009K Designer för hållbar processteknik](P7009K%20Designer%20för%20hållbar%20processteknik.md) – 7,5 hp, Avancerad nivå
- [P7012K Design för hållbar processteknik](P7012K%20Design%20för%20hållbar%20processteknik.md) – 3 hp, Avancerad nivå

### Kemi (7)

- [B0007K Organisk kemi och biokemi](B0007K%20Organisk%20kemi%20och%20biokemi.md) – 7,5 hp, Grundnivå
- [K0006K Vattenkemi](K0006K%20Vattenkemi.md) – 7,5 hp, Grundnivå
- [K0010K Fysikalisk kemi](K0010K%20Fysikalisk%20kemi.md) – 7,5 hp, Grundnivå
- [K0011K Oorganisk kemi](K0011K%20Oorganisk%20kemi.md) – 7,5 hp, Grundnivå
- [K0025K Kemi för hållbar utveckling](K0025K%20Kemi%20för%20hållbar%20utveckling.md) – 7,5 hp, Grundnivå
- [K7006K Batterier för ett hållbart samhälle: från råmaterial till battericeller](K7006K%20Batterier%20för%20ett%20hållbart%20samhälle%20från%20råmaterial%20till%20battericeller.md) – 7,5 hp, Avancerad nivå
- [KX002K Kemi G1, gymnasiekomplettering](KX002K%20Kemi%20G1%20gymnasiekomplettering.md) – 7,5 hp, Förberedande nivå

### Malmgeologi (6)

- [O0008K Petrologi](O0008K%20Petrologi.md) – 7,5 hp, Grundnivå
- [O0038K Ekonomisk geologi](O0038K%20Ekonomisk%20geologi.md) – 7,5 hp, Grundnivå
- [O0043K Strukturer och deformation](O0043K%20Strukturer%20och%20deformation.md) – 7,5 hp, Grundnivå
- [O7022K Gruvgeologi](O7022K%20Gruvgeologi.md) – 7,5 hp, Avancerad nivå
- [O7023K Tillämpad fältprospektering](O7023K%20Tillämpad%20fältprospektering.md) – 3 hp, Avancerad nivå
- [O7028K Geodata - från analys till modell](O7028K%20Geodata%20-%20från%20analys%20till%20modell.md) – 7,5 hp, Avancerad nivå

### Kemisk teknologi (5)

- [T7004K Industriell katalys](T7004K%20Industriell%20katalys.md) – 7,5 hp, Avancerad nivå
- [T7005K Cellulosa - och pappersteknik](T7005K%20Cellulosa%20-%20och%20pappersteknik.md) – 7,5 hp, Avancerad nivå
- [T7006K Projektkurs i Kemisk teknologi](T7006K%20Projektkurs%20i%20Kemisk%20teknologi.md) – 7,5 hp, Avancerad nivå
- [T7009K Avancerad kemisk reaktionsteknik](T7009K%20Avancerad%20kemisk%20reaktionsteknik.md) – 7,5 hp, Avancerad nivå
- [T7010K Kemisk reaktionsteknik](T7010K%20Kemisk%20reaktionsteknik.md) – 7,5 hp, Avancerad nivå

### Geofysik (4)

- [O0001K Tillämpad geofysik, grundkurs](O0001K%20Tillämpad%20geofysik%20grundkurs.md) – 7,5 hp, Grundnivå
- [O7001K Projektkurs i tillämpad geofysik](O7001K%20Projektkurs%20i%20tillämpad%20geofysik.md) – 7,5 hp, Avancerad nivå
- [O7002K Projektkurs i tillämpad geofysik](O7002K%20Projektkurs%20i%20tillämpad%20geofysik.md) – 15 hp, Avancerad nivå
- [O7003K Projektkurs i tillämpad geofysik](O7003K%20Projektkurs%20i%20tillämpad%20geofysik.md) – 30 hp, Avancerad nivå

### Kemisk apparatteknik (3)

- [B7001K Projektering av biokemiska/kemiska processanläggningar](B7001K%20Projektering%20av%20biokemiskakemiska%20processanläggningar.md) – 7,5 hp, Avancerad nivå
- [B7003K Bioprocessteknik](B7003K%20Bioprocessteknik.md) – 7,5 hp, Avancerad nivå
- [B7005K Projektkurs i Biokemisk och kemisk processteknik](B7005K%20Projektkurs%20i%20Biokemisk%20och%20kemisk%20processteknik.md) – 7,5 hp, Avancerad nivå

### Naturresursteknik (2)

- [L0046K Naturresursteknik](L0046K%20Naturresursteknik.md) – 7,5 hp, Grundnivå
- [O0040K Praktik inom naturresursteknik](O0040K%20Praktik%20inom%20naturresursteknik.md) – 15 hp, Grundnivå

### Teknisk akustik (2)

- [L7001A Experimentell akustik och dynamik](L7001A%20Experimentell%20akustik%20och%20dynamik.md) – 7,5 hp, Avancerad nivå
- [Z7001B Rums- och byggnadsakustik](Z7001B%20Rums-%20och%20byggnadsakustik.md) – 7,5 hp, Avancerad nivå

### Hydrologi (1)

- [G7012B Geohydrologi](G7012B%20Geohydrologi.md) – 7,5 hp, Avancerad nivå

### Samhällsbyggnadsteknik (1)

- [T0034B Hydraulik och bergmekanik](T0034B%20Hydraulik%20och%20bergmekanik.md) – 7,5 hp, Grundnivå

### Trafikteknik (1)

- [C7001B Trafik för en attraktiv stad](C7001B%20Trafik%20för%20en%20attraktiv%20stad.md) – 7,5 hp, Avancerad nivå

### Träbyggnad (1)

- [W7003B Datorstödd projektering](W7003B%20Datorstödd%20projektering.md) – 7,5 hp, Avancerad nivå
