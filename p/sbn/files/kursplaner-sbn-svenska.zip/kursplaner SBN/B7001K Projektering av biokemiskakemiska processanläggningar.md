---
kurskod: "B7001K"
titel: "Projektering av biokemiska/kemiska processanläggningar"
hp: "7,5"
titel_en: "Design of Biochemical/Chemical Process Plants"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2023-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Kemisk apparatteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B7001K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B7001K&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/b70/b7001k-projektering-av-biokemiska-kemiska-processanlaggningar"
---

# Projektering av biokemiska/kemiska processanläggningar (B7001K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Grundläggande behörighet. Transportprocesser (motsvarande KGB006) Enhetsoperationer (motsvarande KGB007) Bioprocessteknik (motsvarande KGB008)

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursen syftar till att ge möjlighet att utifrån kunskap i grundläggande biokemisk och kemisk processteknik kunna designa en biokemisk/kemisk process. Efter fullgjord kurs ska studenten kunna:

1. visa på fördjupad förmåga att genomföra en fullständig projektering av en biokemisk processanläggning

2. utföra mass- och energibalanser för processflödesdiagram

3. utföra en ekonomisk utvärdering av den designade processen

4. tillämpa ett representativt simuleringsprogram för modellering, utvärdering och optimering av en vald process

5. presentera en processdesign både muntligt och skriftligt

## Kursinnehåll

Kursen omfattar följande områden

- Processdesign

- Processmodellering och simulering

- Översikt enhetsoperationer

- Flödesscheman

- Mass- och energibalanser

- Processekonomi

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar samt ett projektarbete. Föreläsningarna kommer att täcka teorin och erbjuda praktisk träning för att ge studenterna möjlighet att lära sig hur man använder ett representativt processimuleringsprogram. Projektarbetet är en undervisnings- och lärandeaktivitet som kommer att pågå under hela läsperioden. Inom projektarbetet kommer studenterna att arbeta i grupper för att självständigt utforma en komplett process för framställning av en biobaserad kemikalie. Projektarbetet täcker hela processen, från råvaruintag till den slutliga produkten som ska vara redo för försäljning och leverans till kunder. Under hela projektarbetet kommer kursens lärare att stötta studenterna genom att ordna samrådsmöten. För att stödja studenterna i deras projektarbete kommer studenterna under läsperioden att lämna in ett antal obligatoriska uppgifter. I slutet av projektarbetet kommer studenterna att lämna in en slutlig skriftlig rapport och även presentera sitt projekt muntligt för att öva på skriftlig och muntlig kommunikationsförmåga.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen betygsätta utifrån kvalitén på projektet (övningsuppgifter, muntlig presentationen och projektrapporten). Lärandemål 1-4 bedöms genom de uppgifter som lämnas in under projektarbetet. Lärandemål 5 bedömas genom skriftlig rapport och muntlig presentation.

De studerande måste lämna in alla inlämningsuppgifter samt rapporter inom kursens tidsram samt medverka i den muntliga presentationen, i annat fall kommer inlämnat material att granskas och bedömas vid nästa kurstillfälle.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen B7001K motsvarar kursen KGB010

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektuppgift | GU345 | 7,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
