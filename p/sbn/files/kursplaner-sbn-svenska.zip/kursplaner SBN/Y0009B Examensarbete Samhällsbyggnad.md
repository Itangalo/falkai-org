---
kurskod: "Y0009B"
titel: "Examensarbete, Samhällsbyggnad"
hp: "7,5"
titel_en: "Final year project, University diploma"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2026-06-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1E"
betygsskala: "U G#"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=Y0009B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=Y0009B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/y00/y0009b-examensarbete-samhallsbyggnad"
---

# Examensarbete, Samhällsbyggnad (Y0009B)

## Behörighet

Grundläggande behörighet samt Minst 90 hp avklarade kurser av examensfordringarna.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

Visa generell ämneskunskap inom utbildningens huvudområde.

Visa kännedom om huvudområdets vetenskapliga grund.

Visa kunskap och förståelse för några tillämpliga metoder inom utbildningens huvudområde.

Färdighet och förmåga

Söka och samla relevant information i en problemställning.

Kritiskt tolka relevant information för att formulera svar på väldefinierade frågeställningar.

Visa sådan färdighet som fordras för att självständigt arbeta med vissa uppgifter inom det område som utbildningen avser.

Skriva en rapport av typen enklare forskningsrapport eller utredningsrapport.

Analysera och dra slutsatser av undersökningsresultat

Värderingsförmåga och förhållningssätt

Visa kunskap om och ha förutsättningar för att hantera etiska frågeställningar inom huvudområdet för utbildningen.

## Kursinnehåll

Studenten ska i examensarbetet planera och lösa en självvald uppgift inom utbildningsområdet och redovisa resultatet. Examensarbetet skall ha karaktären av ett enklare forskningsarbete eller avancerat utredningsarbete.

Innehållet i kursen utformas tillsammans med studenten när val av examensarbete har gjorts.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av självständiga studier med stöd av handledare/examinator från universitetet samt extern handledare på arbetsplatsen. Genomförandet utformas i anslutning till planeringen av examensarbetet.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras genom en skriftlig rapport/examensarbete.

Betygssättning sker enligt betygsskala G U.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen Y0009B motsvarar kursen Y0011B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Skriftlig rapport | U G# | 7,5 | Obligatorisk | H09 | Ja |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du

behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-06-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2009-01-20 att gälla från H09.
