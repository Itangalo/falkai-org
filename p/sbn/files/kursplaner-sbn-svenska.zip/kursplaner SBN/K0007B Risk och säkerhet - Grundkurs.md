---
kurskod: "K0007B"
titel: "Risk och säkerhet - Grundkurs"
hp: "7,5"
titel_en: "Risk and safety - Basic course"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2020-02-14"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0007B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0007B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0007b-risk-och-sakerhet---grundkurs"
---

# Risk och säkerhet - Grundkurs (K0007B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Studenten skall kunna beskriva och förhålla sig objektivt till risker. Studenten skall också formulera och motivera det perspektiv vilken risk studeras för. Studenten skall vidare kunna avgöra hur olika risker uppfattas i allmänhet beroende på riskens karaktär. Studenterna skall också kunna tillämpa etiska aspekter vid riskhantering.

Efter avslutad kursmodul om jämställdhet ska studenten visa förståelse för de nationella jämställdhetsmålen, regelverk för jämställdhet i arbetslivet samt ge exempel på förutsättningar för jämställdhet i arbetslivet.

## Kursinnehåll

Kursen är uppdelad enligt:

- ·    introduktion till risk och säkerhet,
- ·    grundläggande riskanalys
- ·    grundläggande riskhantering
- ·    lagstiftning om brandskydd
- ·    jämställdhet

Kursen består bland annat av föreläsningar, studiebesök, projektuppgifter i form av grupparbeten och individuella uppgifter.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Studenterna skall vara närvarande vid föreläsningarna där de tränas i diskussion av risker samt därtill hörande frågeställningar. Vid flertalet av föreläsningar kommer externa föreläsare att presentera hur arbete med risker bedrivs i den egna organisationen och branschen. Exempel från byggbranschen, processindustri och kommunal verksamhet kommer att ges. Studenterna skall tränas att i grupp genomföra en mindre uppgift i riskhantering. Gruppindelning av studenterna görs av läraren. Studenterna tränas i rapportskrivning, muntlig presentation och opponering.

Kursmodulen om jämställdhet består av inspelade föreläsningar samt litteratur.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För att erhålla godkänt slutbetyg krävs 80% närvaro samt att projektuppgifterna är godkända. I projektuppgifterna skall begrepp användas korrekt och innehållet skall vara objektivt. Olika risker samt ur vilket perspektiv dessa bestäms skall tydligt kunna redovisas av studenten. Studenten skall inför grupp göra sig förstådd vid presentation inom riskområdet. Det är närvaroplikt vid redovisning av projektuppgifter.

Kursmodulen om jämställdhet examineras genom quizzar.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0007B motsvarar kursen ABKR01

## Övrigt

Kursen utgör grunden till K0017B.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Projektuppgifter och quizzar | U G# | 5 | Obligatorisk | H07 |  |
| 0006 | Föreläsningar och studiebesök | U G# | 2,5 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-02-14

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
