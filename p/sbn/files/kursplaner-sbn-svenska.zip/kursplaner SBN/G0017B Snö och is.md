---
kurskod: "G0017B"
titel: "Snö och is"
hp: "7,5"
titel_en: "Snow and Ice"
giltig: "Vår 2023 Lp 3 - Tills vidare"
beslutsdatum: "2022-06-15"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G VG"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0017B&lasPeriod=210&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g00/g0017b-sno-och-is"
---

# Snö och is (G0017B)

## Behörighet

Grundläggande behörighet + Engelska 6.

## Urval

Urvalet grundas på betyg och högskoleprov

## Examinator

Nina Lintzén

## Mål/Förväntat studieresultat

Kunskap och förståelse

Efter avslutad kurs ska studenterna kunna förklara:

- Grunderna om hur snö bildas, istillväxt, och hur snö och is förändras

- Klassificeringsmetoder för snö och is

- Ämnesområden och tekniker där snö och is utnyttjas

- Hur laviner utlöses och beskriva lavinsäkerhet

- Snöackumulering och smältning samt hur föroreningar i snö hanteras

Kompetens och färdigheter

Studenterna ska kunna beskriva:

- Hur snö, is och kallt klimat påverkar samhället

- Hur snö och is kan användas och nyttjas som material

- Hur kallt klimat påverkar människan fysiskt

- Hur man bygger en bivack eller säkert tillbringar en natt utomhus på vintern

Bedömning och förhållningssätt

Studenterna ska kunna utföra:

- Arbete i grupp och praktiskt arbete i kallt klimat

## Kursinnehåll

Denna kurs behandlar grundläggande kunskaper om snö, is och kallt klimat och dess påverkan på samhället och individen. Vinterrelaterade fenomen påverkar hur vi bygger och planerar vårt samhälle och vår vardag. Snö, is och kallt klimat medför stora samhällskostnader men också stora möjligheter, samt ekonomisk potential för aktörer inom vinterindustrin, till exempel vinterturism. Snö och is är komplexa material som kan användas och nyttjas fördelaktigt i kallt klimat. Kursen snö och is behandlar grunderna i snö- och ismekanik, snöbildning, klassificeringsmetoder för snö, lavinkunskap, tekniker för att utnyttja snö och is samt arbete i kallt klimat. Denna kunskap sätts i ett samhälleligt och individuellt perspektiv. Efter kursen har du användbara kunskaper för arbete inom vinterturism, samt bygg- och civilsamhällesrelaterade områden. Under kursens projektarbete kan du fördjupa dig inom ett specifikt och relevant område, som exempelvis snö- och ismekanik, tjäle, vinterturism, ledarskap m.m.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen bedrivs i form av föreläsningar, projektarbete i grupp, studiebesök och en obligatorisk fältövning där en avgift tillkommer som inkluderar resa, logi och måltider.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursen bedöms genom inlämning av rapporter, inlämningsuppgifter och muntliga presentationer. Deltagande i fältövningen samt tillhörande fältarbete och inlämningsuppgifter är obligatoriska.

## Överlappning

Kursen G0017B motsvarar kursen G0008B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Uppgifter | U G VG | 4,5 | Obligatorisk | V23 |  |
| 0002 | Projektarbete | U G VG | 3 | Obligatorisk | V23 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Litteratur

*Litteratur. Gäller från Vår 2023 Lp 3* All litteratur kommer att finnas tillgänglig på lärplattformen Canvas vid kursstart. Du hittar lärplattformen via Mitt LTU.

[1] LTU Ice Handbook for Engineers, Version 1.2, Lennart Fransson [2] The International Classification for Seasonal Snow on the ground, IACS 2009, Fierz et.al. [3] Slope Preparation and Grooming, 2019, Wolfsperger et.al. Artiklar, utdrag från böcker och kompendium

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-06-15
