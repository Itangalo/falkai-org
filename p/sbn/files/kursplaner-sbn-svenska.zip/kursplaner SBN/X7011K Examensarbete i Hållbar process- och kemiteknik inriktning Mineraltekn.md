---
kurskod: "X7011K"
titel: "Examensarbete i Hållbar process- och kemiteknik, inriktning Mineralteknik och metallurgi, civilingenjör"
hp: "30"
titel_en: "Master Degree project, Sustainable Process & Chemical Engineering, specialization Minerals & Metallurgical Engineering"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A2E"
betygsskala: "UG"
amne: "Kemiteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X7011K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X7011K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/x70/x7011k-examensarbete-i-hallbar-process--och-kemiteknik-inriktning-mineralteknik-och-metallurgi-civilingenjor"
---

# Examensarbete i Hållbar process- och kemiteknik, inriktning Mineralteknik och metallurgi, civilingenjör (X7011K)

## Behörighet

Minst 240 hp avklarade kurser av examensfordringarna. Av bas- och kärnkurserna får högst två 7,5 hp kurser (alt. en 15 hp kurs) vara oavklarade. Av avklarade kurser ska minst 30 hp vara på avancerad nivå. Utöver ovanstående avgör examinator om det föreslagna examensarbetet ligger inom ämnesområdet och om studenten har den fördjupning som krävs.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens övergripande mål är att studenten skall öva, utveckla och visa färdigheter i att tillämpa teori och metod för att lösa ostrukturerade problem med relevans för en yrkesverksamhet som civilingenjör Hållbar process- och kemiteknik inom området Mineralteknik och metallurgi.

Detta innebär att studenten efter kursen ska kunna:

- Formulera en relevant problemställning utifrån ett valt ämne inom ämnesområdet Mineralteknik och metallurgi.

- Tillämpa kunskaper och färdigheter som har förvärvats under studietiden i ett komplext utrednings-, utvecklings- eller mindre forskningsprojekt på ett självständigt och systematiskt sätt.

- Välja och motivera metod för studien.

- Utan fullständig information på ett ingenjörsmässigt och vetenskapligt sätt analysera och besvara formulerad problemställning.

- Finna och kritiskt värdera information och sammanfatta denna på ett vetenskapligt sätt.

- Planera, strukturera och genomföra ett forsknings-, utvecklings- eller utredningsarbete.

- Bedöma den vetenskapliga och praktiska relevansen av erhållna resultat

- Arbeta efter tidplan.

- Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt

- Utforma och genomföra en presentation där arbetets resultat och slutsatser redovisas och försvaras.

- Kritiskt granska andra studier på ett konstruktivt och vetenskapligt sätt.

metallurgi, civilingenjör 30 hp                                                  Lp3

## Kursinnehåll

Innehållet i examensarbetet utformas i dialog med handledare. Examensarbetet innehåller alltid en teoretisk uppbyggnad i form av en litteraturstudie som belyser teknikområde och metodik, sammanfattad på ett vetenskapligt sätt.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten genomför och planerar självständigt examensarbetet med handledare som stöd. I examensarbetet ingår att göra en tidplan för hela projektet som kontinuerligt följs upp.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

- Skriftlig presentation av eget arbete.

I rapporten skall studenten visa förmåga att:

    - Motivera den valda problemställningen

    - Välja och motivera metod för studien

    - Med tydlig koppling till vald teori/metod samla in information relevant för problemformuleringen

    - På ett relevant sätt skriftligt presentera den insamlade informationen

    - Utifrån vald teori/metod på ett korrekt sätt analysera och besvara formulerad problemställning

    - Med ett kritiskt förhållningssätt bedöma den ingenjörsmässiga och vetenskapliga relevansen av erhållna resultat

    - Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt

- Muntlig presentation och försvar av eget arbete

- Opponering på annans arbete

- Närvara vid presentationer av andra examensarbeten

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Institutionen tillhandahåller aktiv handledning under två terminer från kursstart.

metallurgi, civilingenjör 30 hp                                                      Lp3

Examensarbetet utförs företrädesvis enskilt och endast i undantagsfall med maximalt två deltagande studenter.

I de fall där examensarbetet utförs av två studenter skall detta synas i rapportens omfång och djup.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Godkänd rapport | UG | 30 | Obligatorisk | V27 |  |
| 0006 | Start av examensarbete | UG | 0 | Obligatorisk | V27 |  |
| 0007 | Muntlig presentation | UG | 0 | Obligatorisk | V27 |  |
| 0008 | Opponering av annat examensarbete | UG | 0 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13
