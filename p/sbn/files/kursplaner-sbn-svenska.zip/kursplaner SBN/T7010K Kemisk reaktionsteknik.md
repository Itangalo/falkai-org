---
kurskod: "T7010K"
titel: "Kemisk reaktionsteknik"
hp: "7,5"
titel_en: "Chemical Reaction Engineering"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Kemisk teknologi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7010K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7010K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7010k-kemisk-reaktionsteknik"
---

# Kemisk reaktionsteknik (T7010K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

M0048M Linjär algebra och integralkalkyl, M0049M Linjär algebra och differentialekvationer, K0010K Fysikalisk kemi, samt B0003K Transportprocesser eller motsvarande kurser. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Målen för kursen i Kemisk reaktionsteknik är att studenten efter fullgjord kurs skall:

1. ha erhållit de grundläggande teoretiska grunderna för att kunna välja och dimensionera reaktorer för kemiska processers genomförande samt att bestämma driftsätt och optimering av dessa reaktorer.

2. kunna matematiskt beskriva kemiska reaktorer, begränsat till de områden som tas upp i kursen.

3. kunna lösa enklare reaktionstekniska problem med hjälp av datorverktyg såsom MATLAB.

4. kunna beskriva och förklara hur de vanligaste kemiska reaktorerna fungerar och deras för- och nackdelar.

## Kursinnehåll

Introduktion till numeriska metoder och MATLAB. Material- och värmebalanser, reaktionskinetik, ideala batch-, tank- och tubreaktorer, adiabatiska jämviktsprocesser, reaktorkapacitet, tryckfall i reaktorer, komplexa reaktioner med selektivitetsproblem samt reaktorstabilitet.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Denna kurs innehåller undervisnings- och inlärningsaktiviteter består av lektioner, räkneövningar, inlämningsuppgifter, och laborationer.

- Lektionerna belyser den viktigaste teorin bakom kemisk reaktionsteknik. Under räkneövningarna går läraren igenom hur de vanligaste typerna av problem löses.

- Obligatoriska inlämningsuppgifter som utförs i mindre grupper tränar studenten i matematisk modellering av reaktorer/reaktorsystem, lösning av de erhållna modellerna, analys av resultatet samt muntlig presentation.

- Laborationen tränar studenten i grupparbete, öppna problemställningar samt ger bättre förståelse för teorin. Rapportskrivning tränas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Examinationen består av skriftlig tentamen, inlämningsuppgifter, samt laboration.

- Förväntat studieresultat 1 och 2 bedöms genom en skriftlig tentamen. På tentamen ges betyg enligt skalorna U(underkänd), 3, 4 och 5.

- Förväntat studieresultat 3 bedöms genom inlämningsuppgifter. På inlämningsuppgifterna ges betyget godkänd – icke godkänd, dessa moment examineras kontinuerligt under kursens gång.

- Förväntat studieresultat 4 bedöms genom en laborationen. På laborationerna ges betyget godkänd – icke godkänd.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen T7010K motsvarar kursen T0006K

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Skriftlig tentamen | GU345 | 4 | Obligatorisk | V23 |  |
| 0004 | Laborationer | UG | 1 | Obligatorisk | V27 |  |
| 0005 | Inlämningsuppgifter | UG | 2,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11
