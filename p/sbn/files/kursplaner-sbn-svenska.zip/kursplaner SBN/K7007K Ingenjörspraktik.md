---
kurskod: "K7007K"
titel: "Ingenjörspraktik"
hp: "30"
titel_en: "Internship"
giltig: "Höst 2025 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "U G#"
amne: "Kemiteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7007K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7007k-ingenjorspraktik"
---

# Ingenjörspraktik (K7007K)

## Behörighet

Tre års studier på civilingenjör Hållbar process- och kemiteknik

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens övergripande mål är att studenten skall öva, utveckla och visa färdigheter i att tillämpa teori och metod för att lösa problem med relevans för en yrkesverksamhet som civilingenjör i Hållbar process- och kemiteknik.

Detta innebär att studenten efter kursen ska kunna:

- Skriva en praktikansökan inkluderande ett CV

- Tillämpa kunskaper och färdigheter som har förvärvats under de tre första årens studier i ett utrednings-, utvecklings- eller mindre forskningsprojekt på ett självständigt och systematiskt sätt.

- Planera, strukturera och genomföra ett forsknings-, utvecklings- eller utredningsarbete under handledning

- Skriva och arbeta efter en tidplan.

- Uttrycka sig väl i skrift på ett språkligt och vetenskapligt korrekt sätt

- Utforma och genomföra en presentation där arbetets resultat och slutsatser redovisas och försvaras.

## Kursinnehåll

Innehållet i praktikarbetet utformas i dialog med en handledare där praktikarbetet utförs. Arbetet ska även ha en teoretisk uppbyggnad som belyser teknikområde och metodik, sammanfattad på ett vetenskapligt sätt.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten skall under praktiken behandla en eller flera givna uppgifter. Praktikprojekten skall ha karaktären av ett enklare forsknings- eller utredningsarbete. Studenten arbetar självständigt under handledning. Slutligen redovisas resultatet skriftligt och muntligt.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

- Skrivande och inlämnande av en praktikansökan inkluderande ett CV, följt av påbörjat examensarbete.

- Presentation av eget praktikarbete i en skriftlig rapport som visar att de kunskaper och färdigheter som har förvärvats under de tre första årens studier tillämpats i ett utrednings-, utvecklings- eller mindre forskningsprojekt på ett självständigt och systematiskt sätt. Rapporten ska vara skriven på ett språkligt och vetenskapligt korrekt sätt.

- Utformande och genomförande av en presentation där arbetets resultat och slutsatser redovisas och försvaras.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K7007K motsvarar kursen K7005K

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Påbörjat praktikarbete | U G# | 1 | Obligatorisk | H22 |  |
| 0004 | Godkänd rapport | U G# | 24 | Obligatorisk | H22 |  |
| 0005 | Muntlig presentation av eget praktikarbete | U G# | 5 | Obligatorisk | H22 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11
