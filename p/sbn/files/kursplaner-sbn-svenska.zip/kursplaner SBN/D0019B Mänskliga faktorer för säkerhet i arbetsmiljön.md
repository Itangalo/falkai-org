---
kurskod: "D0019B"
titel: "Mänskliga faktorer för säkerhet i arbetsmiljön"
hp: "7,5"
titel_en: "Human Factors for Safety in the Work Environment"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2022-02-10"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0019B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0019B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d00/d0019b-manskliga-faktorer-for-sakerhet-i-arbetsmiljon"
---

# Mänskliga faktorer för säkerhet i arbetsmiljön (D0019B)

## Behörighet

Grundläggande behörighet + Engelska 6, Fysik 2, Kemi 1, Matematik 3c eller Matematik D. Eller: Engelska nivå 2, Fysik nivå 2, Kemi nivå 1, Matematik fortsättning nivå 1c.

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kunskap och förståelse Efter avklarad kurs ska studenten kunna visa kunskap och förståelse:
- För hur teorier och metoder inom psykosocial arbetsmiljö kan tillämpas

Färdighet och förmåga Efter avklarad kurs ska studenten kunna visa förmåga att:
- För hur människors prestation på arbetsplatsen påverkas av ergonomiska faktorer
- Samla information i en problemställning rörande människan i arbetsmiljön samt tillämpa metoder
- Värdera och kritiskt granska insamlad information från studier
- Kritiskt diskutera psykosocial arbetsmiljö
- Identifiera, beskriva, och lösa problem relaterade till arbetsmiljön
- Muntligt och skriftligt redovisa och diskutera

Värderingsförmåga och förhållningssätt Efter avklarad kurs ska studenten kunna visa förmåga att:
- Göra bedömningar av arbetsmiljön med hänsyn till psykosociala och ergonomiska aspekter
- Visa insikt i människans roll i arbetsmiljön utifrån ett hållbart perspektiv

## Kursinnehåll

Grundläggande principer för ergonomi, säkerhet och arbetsmiljö. Ergonomiska faktorer och dess påverkan på fysisk och psykosocial arbetsmiljö. I kursen behandlas hur samspelet mellan människa och arbetsmiljö kan förstås och utvecklas utifrån ett psykolsocialt perspektiv, samt hur människor påverkas av arbetsmiljön. Mer specifikt berör kursen hur människans informationsprocessande, perception, uppmärksamhet, minne, tänkande, beslutsfattande och stressnivå påverkar samspelet mellan människa och arbetsmiljö. Kursen berör även aktuell teknikutveckling i samhället utifrån ett hållbart perspektiv för människa och samhälle.

Kursen introducerar flera olika metoder för att analysera arbetsmiljön (ex PEAR modell) samt metoder för att undersöka människans förmågor och begränsningar i arbetet (ex FAIR modell).

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen är baserad på seminarier med muntlig och skriftlig redovisning. För att nå kursens mål rörande kunskap och förståelse bör studenten självständigt studera angiven kurslitteratur och övrig litteratur tillhandahållen under kursens gång, samt ta del av seminarium och övningar.

För att nå kursens mål rörande färdighet och förmåga bör studenten medverka aktivt under seminarium samt vid skriftliga och muntliga redovisningar. Genom seminarium tränas förmågan att samla och värdera information genom att använda olika metoder och teorier. Genom presentationer och diskussion tränas även förmågan att identifiera, beskriva, lösa och kritiskt granska problem och företeelser relaterade till samspelet mellan människa och arbetsmiljö. För att nå kursens mål rörande värderingsförmåga och förhållningssätt bör studenten medverka aktivt under seminarier, diskussioner och presentationer samt aktivt studera kurslitteraturen. Förmåga att se psykosociala utmaningar i arbetsmiljön utifrån ett hållbart perspektiv tränas genom diskussioner och reflektion.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kunskap och förståelse examineras främst genom seminarier och inlämningsuppgifter. Färdighet och förmåga samt värderingsförmåga och förhållningssätt examineras genom projektuppgift och muntlig och skriftlig redovisning. Muntlig redovisning sker genom presentationer och diskussioner. Skriftlig redovisning sker via inlämningsuppgifter, projektuppgiften och reflektioner. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg i kursen (7.5 hp, betygsskala: G 3 4 5).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0004 | Projektuppgift, presentationer och inlämningar | GU345 | 7,5 | Obligatorisk | H17 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-10

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2017-02-08
