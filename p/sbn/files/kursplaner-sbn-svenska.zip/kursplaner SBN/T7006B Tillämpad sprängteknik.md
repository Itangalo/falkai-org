---
kurskod: "T7006B"
titel: "Tillämpad sprängteknik"
hp: "7,5"
titel_en: "Applied Blasting"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7006B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7006B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7006b-tillampad-sprangteknik"
---

# Tillämpad sprängteknik (T7006B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Berganläggningsteknik T0013B eller motsvarande kunskaper samt Introduktion till bergmekanik T0014B eller motsvarande kunskaper. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Sprängning är en kemisk, fysisk och mekanisk process som börjar med att detonera sprängämnet och resulterar i trasigt material i slutet. Denna process har använts i många år i olika gruvor och bergutgrävningar (såsom tunnlar, bergrum, stenbrott). Idag är sprängning det mest kostnadseffektiva sättet att extrahera bergmaterial. Sprängning används inte bara för gruvändamål utan också i speciella fall som vid rivning eller tunneldrivning. Syftet med kursen är att hjälpa studenter att utveckla kunskap i bergsprängningsprocessen; från detonationen till miljöaspekter.

Kunskap och förståelse

För att klara kursen ska studenten kunna:

- Förklara begrepp, definitioner och terminologier vid sprängning.

- Beskriv sprängmedel och initieringssystem

- Förklara detonationsteori

- Analysera utbrednings- och dämpningsegenskaper hos stressvågor i bergmassa

- Beskriv lagar och regelverk relaterade till sprängning

Färdighet och förmåga

För att klara kursen ska studenterna kunna:

- Utforma borr- och sprängplan under- och ovan jord.

- Utvärdera och förutsäga spränginducerad skada i kvarvarande bergmassa.

- Utvärdera och uppskatta bergfragmenteringen efter sprängning.

Värderingsförmåga och förhållningssätt

För godkänd kurs ska studenten visa förmågan att

- Utvärdera hur problem och skador på den omgivande miljön kan hanteras och förhindras vid en sprängning

## Kursinnehåll

- Allmän introduktion av borrning och sprängning

- Sprängämnen, typer av produkter och kemi

- Detonationsteori

- Pallsprängning: Grunder och design

- Design av sprängsalva under jord

- Säkerhetsåtgärder

- Sprängskador på kvarvarande bergmassa

- Fragmenteringsteori

- Numerisk modellering av sprängning

- Miljöeffekter av sprängning

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen innehåller föreläsningar, självstudier, projektuppgifter i grupper och muntlig presentation av projektuppgiften. Under kursen ska en projektuppgift genomföras i grupper och presenteras i slutet av kursen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras genom skriftlig tentamen med differentierade betyg (5.0HP) och godkända projektuppgifter (2.5HP) under kursen.

Enligt kursmålen bedöms enligt följande

Kursmålen under rubrikerna Kunskap och förståelse samt Värderingsförmåga och förhållningssätt genom en skriftlig tentamen. Kursmålen under Färdighet och förmåga examineras genom en projektuppgift och en skriftlig rapport.

Betyg för den skriftliga tentamen delas ut enligt en betygsskala på G / U 3 4 5. dvs Underkänd (U), Godkänd (3), Väl Godkänd (4), Mycket väl godkänd (5). Projektuppgiften betygsätts med G / U. d.v.s. Underkänd (U), godkänd (G).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 5 | Obligatorisk | H07 |  |
| 0003 | Projektuppgift | UG | 2,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
