---
kurskod: "D0020B"
titel: "Sakernas internet och signalanalys för tillståndsövervakning"
hp: "7,5"
titel_en: "Internet of Things and Signal Analysis for Condition Monitoring"
giltig: "Höst 2023 Lp 1 - Höst 2025 Lp 2"
beslutsdatum: "2023-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0020B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0020B&lasPeriod=220&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d00/d0020b-sakernas-internet-och-signalanalys-for-tillstandsovervakning"
---

# Sakernas internet och signalanalys för tillståndsövervakning (D0020B)

## Ingår i huvudområde

Underhållsteknik

## Behörighet

Grundläggande behörighet samt Linjär algebra och integralkalkyl (M0048M) eller motsvarande kurs samt goda kunskaper i engelska, motsvarande Engelska 6.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Syftet med kursen är att utveckla kunskaper och färdigheter i mätteknik, Sakernas Internet och signalanalys för att självständigt kunna utföra tillståndsövervakning.

Kunskap och förståelse

Efter godkänd kurs ska du:

- ha grundläggande kunskap om Sakernas Internet och dess implementering

- visa förståelse för hur Sakernas Internet kan användas för tillståndsövervakning och stödja underhållsbeslutstöd

Färdighet och förmåga

Efter godkänd kurs ska du kunna:

- tillämpa grundläggande metoder i signalanalys

- beräkna och beskriva indikatorer i tids- och frekvensdomän för en signal

- självständigt och i grupp planera och genomföra tillståndsövervakning med uppkopplade mätsystem, molntjänster och applikationer

- identifiera behov av och inhämta ytterligare kunskap på egen hand.

## Kursinnehåll

- Grundläggande begrepp tillståndsövervakning och tillståndbaserat underhåll

- Sakernas internet, mätteknik, mikrokontroller, sensorer och molntjänster

- Signalanalys i tids- och frekvensdomän (för både tidskontinuerliga och tidsdiskreta signaler)

- Tidserieanalys och prediktion

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen består av tre delar. Den första delen är teoretisk med föreläsningar och lektioner om tillståndsövervakning, Sakernas Internet och signalanalys. Andra delen består av laborationer och övningar om Sakernas Internet. I den tredje delen genomför du ett projektarbete där du planerar och genomför tillståndsövervakning med hjälp av Sakernas Internet. Som stöd i arbetet med projektuppgiften erbjuds handledning från lärare.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Tre examinationsmoment ingår i kursen: inlämningsuppgifter, laborationer och projektarbete.

Inlämningsuppgifterna examinerar kunskap och förståelse om tillståndsövervakning och hur Sakernas Internet kan tillämpas för tillståndsövervakning samt färdigheter i signalanalys.

Laborationerna examinerar kunskaper och implementering av Sakernas Internet samt att genomföra tillståndsövervakning med uppkopplade mätsystem

Projektarbetet examinerar förmågan att självständigt planera och genomföra tillståndsövervakning med uppkopplade mätsystem, molntjänster och applikationer samt att identifiera behov av och inhämta ytterligare kunskap.

För att få godkänt betyg i kursen måste inlämningsuppgifter, projekt och laborationer genomföras med godkänt resultat. Projektuppgiften redovisas både muntligt och skriftligt.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 4 | Obligatorisk | H18 |  |
| 0002 | Projektarbete | U G# | 2 | Obligatorisk | H18 |  |
| 0003 | Laboration | U G# | 1,5 | Obligatorisk | H18 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2018-02-13
