---
kurskod: "B0002B"
titel: "Konstruktionsteknik"
hp: "7,5"
titel_en: "Structural engineering"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Konstruktionsteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B0002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B0002B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/b00/b0002b-konstruktionsteknik"
---

# Konstruktionsteknik (B0002B)

## Ingår i huvudområde

Arkitektur, Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

Grundläggande behörighet samt M0047M Differentialkalkyl samt M0048M Linjär algebra och integralkalkyl samt F0004T Fysik 1 eller motsvarande kurser.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursens mål är att studenten ska kunna

- beräkna snittkrafter (normalkrafter, tvärkrafter och moment) i statiskt bestämda balkar och pelare

- beräkna spänningstillståndet i balkar och pelare

- beräkna spänningars och töjningars variation i olika riktningar

- beräkna deformationer i statiskt bestämda system

- tillämpa vinkeländringsmetoden för beräkning av stödreaktioner i statiskt obestämda balkar

- förklara verkningssättet i fackverk och kunna beräkna dess stångkrafter

- förklara och tillämpa Eulerknäckning

- beskriva begreppen flyt- och brottvillkor, elasticitet, plasticitet och dimensionering

- planera och utföra laborationsuppgifter i grupp, bearbeta resultat och presentera dem skriftligt (laborationsrapport)

## Kursinnehåll

Snittkrafter (normalkrafter, tvärkrafter och moment) i statiskt bestämda balkar och pelare

- lasttyper och upplag

- friläggning

- jämvikt

- snitt

- elementarfall

- normalkrafts-, tvärkrafts- och momentdiagram

Spänningstillståndet i balkar och pelare

- normal-, böj- och skjuvspänningar

- yttröghetsmoment, böjmotstånd (elastiskt och plastiskt), statiskt moment

Spänningars variation i olika riktningar

- spänningstransformation

- Mohrs spänningscirkel

- huvudspänningar och huvudspänningsriktning

Deformationer i statiskt bestämda system

- elastiska linjens differentialekvation

- elementarfall

Stödreaktioner i statiskt obestämda balkar med hjälp av vinkeländringsmetod

- uppdelning i statiskt bestämda delar

- kontinuitetsvillkor

- elementarfall

Fackverk

- friktionsfria leder och stänger

- statisk bestämdhet

- knutpunktsmetod

- snittmetod

Eulerknäckning

- Eulers knäckfall

- knäckningslängd och knäckningsmoder

- knäckningsspänning

- Eulerhyperbel

Flyt- och brottvillkor plasticitet och dimensionering

- arbetskurvor

- sprödhet och seghet

- elasticitet och plasticitet, flyt- och brottvillkor

Laborationsuppgifter

- balkböjning – en stålbalk provas i trepunktböjning

    - förberedelser: beräkning av stödreaktioner, tvärsnittstorheter, spänningar och deformationer

    - provning

    - sammanställning och analys av resultat

    - laborationsrapport

- knäckning – stålstav provas i knäckning

    - förberedelser: beräkning av teoretiska knäckningslaster

    - effekt av upplagsförhållanden och knäcklängd

    - inverkan av imperfektioner

    - provning, sammanställning och analys av resultat

    - laborationsrapport

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Studenterna deltar på föreläsningar där bakgrunder och teorier till kursinnehållet härleds, presenteras och exemplifieras.

Studenterna övar beräkningsmetodik till kursinnehållet

- enskilt på övningspass i klassrum

- i grupp genom förberedelse- och efterarbete till laborationsuppgifterna.

Studenterna övar förmågan att planera, genomföra och redovisa laborationsuppgifter i grupp genom två laborationer. Förberedelse till laborationerna redovisas muntligt innan laborationerna får påbörjas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Bakgrund och teorier examineras med skriftlig halvtidstentamen (dugga). Beräkningsmetodik för kursinnehållet examineras med skriftlig sluttentamen. Resultaten från de två deltentorna summeras. Betygsskala: U, 3, 4, 5.

Förmågan att planera, genomföra och redovisa laborationsuppgifter i grupp examineras dels genom muntlig redovisning av förberedande beräkningar, dels genom skriftliga laborationsrapporter. För godkänt på kursen krävs godkända laborationsrapporter. Betygsskala: U, G.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen B0002B motsvarar kursen ABB025

## Övrigt

Kursen ges på grundläggande nivå och ingår i kärnkurspaketet för civilingenjör Arkitektur och civilingenjör Väg- och Vatten.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 6 | Obligatorisk | H07 |  |
| 0002 | Laboration | U G# | 1,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
