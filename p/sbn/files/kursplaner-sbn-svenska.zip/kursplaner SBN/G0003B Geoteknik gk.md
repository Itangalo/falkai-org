---
kurskod: "G0003B"
titel: "Geoteknik gk"
hp: "7,5"
titel_en: "Soil Mechanics"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-01-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "GU345"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0003B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g00/g0003b-geoteknik-gk"
---

# Geoteknik gk (G0003B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Grundläggande behörighet samt M0011T Hållfasthetslära eller B0002B Konstruktionsteknik eller motsvarande kurs.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Lärandemålen i kursen är:

(1) Kunna tillämpa de grundläggande områdena kvartärgeologi, jordmateriallära och jordmekanik, både var för sig och inom kursens geotekniska tillämpningsområden: bärförmåga, sättningar, jordtryck, bottenupptryckning och stabilitet.

(2) Kunna härleda och tillämpa beräkningsmodeller för bärförmågeproblem, sättningar, jordtryck, bottenupptryckning och stabilitet.

(3) I grupp kunna planera och lösa praktiska geotekniska problem relaterade till kursens geotekniska tillämpningsområden.

(4) Kunna utföra geotekniska försök i fält och laboratorium och därefter utvärdera resultaten.

(5) Förmåga att arbeta effektivt i grupp.

## Kursinnehåll

Kvartärgeologi (5%)

Hur våra jordar bildats.

Jords uppbyggnad och klassificering (10%)

Vad består jord av? Hur kan jord klassificeras med hänsyn till bl a kornens

storlek, hur jorden bildats, innehållet av organiskt material samt vilka faktorer som bestämmer jordens hållfasthet m m.

Spänningar i jord (5%)

Vilka spänningar verkar i en jordmassa. Begrepp som medelspänning, deviatorspänning, totalspänning, portryck och effektivspänning.

Spänningsförändringar i jorden på grund av olika laster på markytan.

Hållfasthet- och deformationsegenskaper hos jord (20%)

Hur reagerar materialet jord på olika typer av spänningsförändringar. Vilka

parametrar används för att beskriva en jords hållfasthets- och

deformationsegenskaper. Hur kan man bestämma dessa parametrar.

Bärförmåga i jord (15%)

Hur stora laster från exempelvis fundament och jordbankar klarar jorden.

Sättningar i jord (15%)

Hur stora blir sättningarna i en jord på grund av pålastning från exempelvis

jordbankar och byggnader? Hur lång tid tar det för sättningarna att utbildas.

Jordtryck (10%)

Jordtryck mot vertikala stödkonstruktioner, murar, sponter etc.

Bottenupptryckning (5%)

Hur kan man bedöma risken för att botten trycks upp i en schaktgrop.

Jordslänters stabilitet (15%)

Hur kan säkerheten för en slänt beräknas? Stabiliteten sett ur ett kort

respektive långt tidsperspektiv.

Integrerad konstruktionsuppgift med anknytning till ett praktiskt fall. Uppgiften består av flera delmoment med anknytning till de olika delområdena som beskrivits ovan. Konstruktionsuppgiften genomförs i grupper om ca fyra studenter. Inomhus- och fältlaborationer innehållande moment för att bestämma de nödvändiga jordparametrar som används i kursens tillämpningsområden. Laborationsmomenten genomförs med hjälp av instruktionsvideo och tillhörande handledning. Laborationerna genomförs i grupper om ca fyra studenter.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Läsperioden är indelad i två block. Det första blocket på ca 3 veckor omfattar kvartärgeologi, jordmateriallära och jordmekanik och består i huvudsak av föreläsningar och räkneövningar. Perioden avslutas med en icke obligatorisk dugga. Godkänt på duggan ger bonuspoäng till tentamensresultatet. Det andra blocket byggs upp kring konstruktionsuppgiften och dess delmoment, vilka är analoga med kursens tillämpningsområden: bärförmåga, sättningar, jordtryck/bottenupptryckning och stabilitet. Varje delmoment innehåller en introduktionsföreläsning för konstruktionsuppgiften, en eller flera föreläsningar samt övningsräkningstimmar. Varje moment avslutas med inlämning och rättning av konstruktionsuppgiftsdelen. Konstruktionsuppgiftens delmoment utförs gruppvis. Varje delmoment av konstruktionsuppgiften bedöms vid rättning och när samtliga moment är godkända kan bonuspoäng erhållas till tentamensresultatet om arbetet med konstruktionsuppgiften bedöms vara speciellt bra genomfört. I kursens andra block genomförs även momentet inomhus- och fältlaborationer gruppvis. Inomhuslaborationerna redovisas gruppvis genom en inspelad videofilm som beskriver respektive försök, erhållna resultat och utvärdering av resultat. Videofilmen rättas. Fältlaborationerna redovisas gruppvis genom en skriftlig inlämning där försök, resultat och utvärdering av resultat behandlas. Den skriftliga inlämningen rättas. Vid godkänt på inomhus- och fältlaborationerna kan bonuspoäng erhållas till tentamensresultatet om arbetet med laborationerna bedöms vara speciellt bra genomfört. Vid arbetet med konstruktionsuppgiften samt inomhus- och fältlaborationerna tränas färdigheterna: grupparbete, skriftlig presentation och laborativt arbete.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Lärandemål (1) och (2) examineras genom en skriftlig individuell tentamen. Betygssättningen sker enligt betygsskala GU345. Lärandemål (3) examineras genom rättning av konstruktionsuppgiften. Betygssättningen sker enligt betygsskala UG#. Lärandemål (4) examineras genom rättning av laborationsmomenten. Betygssättningen sker enligt betygsskala UG#. Lärandemål (5) är en generell färdighet och examineras samtidigt som lärandemål (3) och (4). Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen. Slutbetyget ges utifrån betygssättningen på kursens tentamen. Observera dock att bonuspoäng till tentamensresultatet kan erhållas från resultat på dugga, konstruktionsuppgift och laborationer i enlighet med vad som beskrivs under Genomförande.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen G0003B motsvarar kursen ABG102

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 3 | Obligatorisk | H07 |  |
| 0004 | Konstruktionsuppgift | UG | 3 | Obligatorisk | V27 |  |
| 0005 | Laboration | UG | 1,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-01-11

## Kursplanen fastställd

av Institutionen för Samhällsbyggnad 2007-01-31
