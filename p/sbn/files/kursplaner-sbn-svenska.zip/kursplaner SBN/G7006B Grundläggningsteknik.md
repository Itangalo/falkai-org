---
kurskod: "G7006B"
titel: "Grundläggningsteknik"
hp: "7,5"
titel_en: "Foundation Engineering"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7006B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7006B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7006b-grundlaggningsteknik"
---

# Grundläggningsteknik (G7006B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

G0003B Geoteknik gk eller motsvarande kurs. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Att ge studenten kunskap inom områdena jord- och markförstärkning, yt- och djupgrundläggning, stödkonstruktioner samt CRS-försök. Studenten skall efter kursen kunna genomföra ett grundläggningsprojekt inbegripet val av lämplig typ av markförstärkning och grundläggning samt dess dimensionering.

Kursens nedbrutna mål är:

Du ska kunna tillämpa:

- Eurokod för grundläggningsdimensioneringar

- Teorier för analys och beräkning av bärförmåga och sättningar vid ytgrundläggning

- Dimensionering vid ytgrundläggning och djupgrundläggning

- Teorier för analys av bärförmåga och sättningar för pålar

- Beräkning av pålar i kohesionsjord och friktionsjord med hänsyn till bärförmåga och sättning

- Analyser av pålgrupper med vertikal och horisontell last enligt förskjutningsmetoden

- Dimensionering av isostatiska och semi-isostatiska pålgrupper

- Jordtryck mot spont med Rankine´s metod

- Dimensionering av en enkel konsolspont och en bakåtförankrad spont

- Principerna för bestämning av staglängd

- Dimensionering av en enkel ankarplatta

- Analys med CRS-försök

Du skall känna till och kunna beskriva:

- Olika metoder för förstärkning av undergrunden

- Samverkan byggnad-undergrund

- Olika typer av pålgrundläggning och dess klassificering

- Övrig djupgrundläggning såsom pålväggar, jordankare och kassuner

- Allmänna tredimensionella pålgrupper

- Olika stödkonstruktioner och sponttyper

Kursen har även som mål att öva de generella färdigheterna skriftlig och muntlig presentation.

## Kursinnehåll

Kursen behandlar följande områden:

- Jord- och markförstärkningsmetoder

- Ytgrundläggning

- Djupgrundläggning

- allmänt pålgrundläggning

- dimensionering av enskilda pålar

- knäckning av pålar, stötvågsmätning av pålar

- pålgrupper

- Stödkonstruktioner

- Konsolspont och bakåtförankrad spont

- CRS-försök

- Skriftlig och muntlig presentation av en seminarieuppgift

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar med mindre inslag av övningar. I kursen ingår fem obligatoriska konstruktionsuppgifter:

- K1: Ytgrundläggning

- K2: Pålars bärförmåga och stabilitet

- K3: Dimensionering av pålgrupp

- K4: Spontdimensionering

- K5: Jord- och markförstärkningsmetoder (seminarieuppgift).

Uppgifterna löses i grupper om normalt tre studenter. K5 är en större seminarieuppgift där varje grupp väljer en jord- och markförstärkningsmetod att studera närmare, skriver en uppsats om den valda metoden och presenterar arbetet muntligt på ett seminarium i slutet av kursen. Studentgrupperna opponerar på varandras arbeten vid presentationerna. I seminarieuppgiften övas de generella färdigheterna skriftlig och muntlig presentation. Alla uppgifterna rättas av lärare och studentgrupperna erhåller feedback. Kursen avslutas med en individuell muntlig tentamen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Lärandemålen i kursen examineras vid granskning av konstruktionsuppgifterna och vid den muntliga individuella tentamen. Alla lärandemålen i kursen examineras vid den muntliga tentamen. Lärandemålen relaterade till konstruktionsuppgifterna där studenterna ska kunna ”tillämpa” examineras på en djupare nivå genom granskning av konstruktionsuppgifterna. Genom kursens seminarieuppgift övas de generella färdigheterna skriftlig och muntlig presentation. Läraren ger feedback på presentationstekniken vid de muntliga presentationerna. Både modulen Muntlig tentamen och Konstruktionsuppgifter betygssätts enligt betygsskalan UG#. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen. Slutbetyget ges som ett vägt medelvärde av prestationerna på muntlig tentamen och konstruktionsuppgifter utifrån betygsskalan GU345.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen G7006B motsvarar kursen ABG115

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Muntlig tentamen | UG | 4,5 | Obligatorisk | V27 |  |
| 0004 | Konstruktionsuppgifter | UG | 3 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
