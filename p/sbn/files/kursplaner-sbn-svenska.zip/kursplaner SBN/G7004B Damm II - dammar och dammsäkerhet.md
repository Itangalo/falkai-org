---
kurskod: "G7004B"
titel: "Damm II - dammar och dammsäkerhet"
hp: "7,5"
titel_en: "Dam II - Dam and Dam Safety"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7004B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7004b-damm-ii---dammar--och-dammsakerhet"
---

# Damm II - dammar och dammsäkerhet (G7004B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Maskinteknik

## Behörighet

Grundkurs i hållfasthetslära, geoteknik, mekanik. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Ge de studerande grundläggande kunskaper om uppbyggnad och funktion av dammar för vattenkraftsändamål samt för gruvdammar. Kunskaper om dammsäkerhet och underhåll av dammar. Kunna tillämpa hydrologikunskaper på dammar och deras säkerhet. Kursens nedbrutna mål är:

Studenten ska kunna:
- Uppbyggnad samt konstruktionsmetoder för vattenkrafts- och gruvdammar
- Dammarnas delar och funktion
- Utskov, luckor, redundans (dubbel säkerhet)
- Vattnets kretslopp
- Genomföra enklare hydrologiska beräkningar
- Genomföra beräkningar rörande friyteströmning
- Strömlinjenät och grundvattenströmning (dammkropp och undergrund)

Du skall kunna tillämpa:
- Hydrologiska beräkningsverktyg
- Vattenkraftindustrins normer och analysmetoder för dammsäkerhet RIDAS, GruvRIDAS, ICOLD etc.
- Beräkningar med strömlinjenät
- Stabilitetsanalyser
- olika mätmetoder rörande dammar och deras funktion

Du skall förstå:
- Vilka faktorer som påverkar dammsäkerheten: Materialtransport via vattenströmning, konstruktionens beteende, grundläggning
- geofysiska mätmetoder för läckage och strömning.
- Erosion; inre och yttre • Mätningar i fysikaliska modeller
- Skalfaktorer
- Geologins betydelse för dammsäkerheten stabilitetshöjande åtgärder

## Kursinnehåll

Dimensionering av olika typer av vattenkraftsdammar

- olika zoner och deras funktioner

- konstruktion (packning av jord etc)

- riktlinjer för dimensionering: RIDAS, ICOLD etc

Faktorer som påverkar dammsäkerhet

- materialtransport orsakad av vattenflöden

- dammars beteende, undergrund, läckage etc.

- geofysiska mätmetoder

- släntstabilitet etc.

Fallbeskrivningar – dammhaverier och incidenter

Underhåll av dammar

Gruvdammar (uppbyggnad, funktion, säkerhet etc)

Hydrologi med tillämpning mot dammar och dammdimensioning – uppsamling av vatten – ackumulation av snö, snösmältning – mätmetoder och beräkningsmodeller

Friyteströmning

Underjordskonstruktioner

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Lektioner, övningar och inlämningsuppgifter. Laborationer på Vattenfalls forskningsanläggning i Älvkarleby (om möjligt). Gästlärare från industrin.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Fyra inlämningsuppgifter ingår i kursen. Syftet med dessa är att ge studenterna möjlighet att tillämpa den teoretiska informationen från kursen.

A1: Seminarieuppgift

Studenterna skriver en seminarieuppgift relaterat till en fallstudie inom ämnet dammar och dammsäkerhet. Studenterna kan föreslå en fallstudie eller välja från en lista som tillhandahålls av den kursansvarige. I denna uppgift ska studenterna: öva på att kritiska granska dammsäkerhetsproblem, samt kunna lyfta fram tekniska aspekter av deras fallstudie.

A2: Flödesanalys

Flöden igenom och under en dammkropp är ett viktigt område inom dammsäkerhet, både för underhåll och dimensionering. I denna uppgift kommer studenterna använda det numeriska programmet SEEP/W av GeoStudio för att analysera flödesnät och läckage genom sektioner i olika dammar och undergrunder.

A3: Energiomvandling

Energiomvandlare utformas på nedströmssidan av en vattenkraftsdamm (utskov) för att minska erosionen. I denna uppgift dimensionerar studenterna energiomvandlare relaterade till vattensprång i en vattenkraftsdamm.

A4: Laboratorieuppgift

Sammanställning av resultat från laboratoriearbete som utförts under studiebesöket i Vattenfalls forskningslaboratorium i Älvkarleby. Under studiebesöket utförs olika hydrauliska laborationer samt rundvandring i kraftverket och på dammarna. Studenterna presenterar en sammanfattning och diskussion av resultaten från laborationen i en rapport. Är inte studiebesöket möjligt att genomföra, ges en teoretisk uppgift inom samma område.
Den skriftliga tentamen omfattar både teoretiska och praktiska frågor relaterade till dammar och dammsäkerhet. De teoretiska frågorna är utformade på sådant sätt att studenterna bör tillämpa sina teoretiska kunskaper för att lösa ett dammsäkerhetsproblem.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen G7004B motsvarar kurser ABG132, ABG108

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 4,5 | Obligatorisk | H07 |  |
| 0004 | Inlämningsuppgifter | UG | 3 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
