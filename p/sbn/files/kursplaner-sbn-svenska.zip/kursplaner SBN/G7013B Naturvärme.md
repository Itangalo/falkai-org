---
kurskod: "G7013B"
titel: "Naturvärme"
hp: "7,5"
titel_en: "Natural Energy Sources"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7013B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7013B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7013b-naturvarme"
---

# Naturvärme (G7013B)

## Behörighet

F0032T Termodynamik och värmetransport eller motsvarande.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

- Redogöra för olika tekniker för att utvinna eller lagra naturvärme (även kallad geoenergi) för uppvärmningsändamål

- uppskatta lönsamheten för olika geoenergianläggningar

- uppskatta maximal teoretisk solinstrålning, samt utvärdera olika typer av solvärmeanläggningar

- göra enkla dimensioneringar av bergvärmeanläggningar

- utföra en förstudie till ett projekt inom geoenergi, samt redovisa resultat i skriftlig rapport och muntlig presentation

## Kursinnehåll

Kursen omfattar grundläggande kunskaper om solfångare, naturvärmesystem och termisk energilagring. Inom dessa områden behandlas teknik, dimensionering och kostnader:

- Värmeöverföring och värmetransport: Fysikalisk beskrivning av ledning, strålning och konvektion. Olika materials värmelagrande förmåga.

- Solenergi: Aktiv och passiv solenergi, solinstrålning mot ett lutande plan.

- Solvärmetillämpningar, beräkningsexempel plana solfångare, olika typer av solfångare

- Naturvärme: Naturvärmekällor i luft, mark och vatten, översiktligt om värmepumpar.

- Återladdning av markvärmesystem.

- Termisk energilagring: Aktuell forskning. Olika tekniker. Lagring av värme/kyla. Effektlager, energilager. Kort- och långtidslagring. Ekonomi. Beräkningsexempel lagerstorlek, energiförluster etc.

- Projektarbete: Projektering av energilagringssystem. Definiering och uppdelning av projekt. Val av system. Inhämtning av tekniska data och kostnadsdata. Optimering av termiska energilagringssystem. Rapportering.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar och övningar. Huvuddelen av kursen består av ett projektarbete, ofta på uppdrag av näringsliv eller universitet. Datalabbar med programmen EarthEnergyDesigner (EED) och Polysun är obligatoriska. Programmen används senare som hjälpmedel i projektarbeten. Projektarbetet dokumenteras skriftligt samt framförs på ett gemensamt seminarium.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examinationen sker genom bedömning av ingående konstruktionsuppgifter från EED och Polysun, projektrapport, samt muntlig presentation. För kursen ges betyg enligt skalan U 3 4 5.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen G7013B motsvarar kursen E7002B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgift | GU345 | 5,5 | Obligatorisk | H16 |  |
| 0002 | Muntlig presentation | U G# | 1 | Obligatorisk | H16 |  |
| 0003 | Övrigt | U G# | 1 | Obligatorisk | H16 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-

02-17

## Kursplanen fastställd

av Eva Gunneriusson 2016-02-10
