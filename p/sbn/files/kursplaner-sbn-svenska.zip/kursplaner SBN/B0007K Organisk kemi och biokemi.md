---
kurskod: "B0007K"
titel: "Organisk kemi och biokemi"
hp: "7,5"
titel_en: "Organic Chemistry and Biochemistry"
giltig: "Höst 2024 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2024-02-14"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Kemi"
amnesgrupp_scb: "Kemi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B0007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B0007K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/b00/b0007k-organisk-kemi-och-biokemi"
---

# Organisk kemi och biokemi (B0007K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Grundläggande behörighet samt K0016K Kemiska principer eller motsvarande

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten ha grundläggande kunskaper i organisk kemi och biokemi som kan tillämpas i senare kurser i civilingenjörsprogrammet Hållbar process- och kemiteknik.

Efter kursen förväntas studenterna kunna:

1. Beskriva organiska föreningars struktur, nomenklatur och reaktionsmekanismer

2. Förklara sambandet mellan struktur och egenskaper för vissa naturliga och syntetiska polymerer

3. Redogöra hur några kommersiellt viktiga organiska föreningar framställs inom industrin samt deras egenskaper/funktionalitet.

4. Beskriva de biokemiska reaktioner som sker i levande organismer för att de ska kunna omsätta energi och syntetisera makromolekyler

5. Beskriva hur biotekniska processer kan användas praktiskt i samhället

6. Genomföra, utvärdera och redovisa experimentellt arbete i grupp

7. Kunna identifiera sitt kunskapsbehov samt diskutera och utvecklas i ämnet

## Kursinnehåll

Inledningsvis behandlar kursen begreppet organiska föreningar, vilka utgör grunden för cellens molekylära uppbyggnad och funktion som behandlas i kursens senare del. I kursen belyses också hur några vanliga organiska föreningar används kommersiellt samt exempel på industriella biokemiska processer.

Del 1 : Organisk kemi

Denna del består i stora drag av följande moment:

1. Klassificering av organiska föreningar och deras nomenklatur (alkaner, alkener, alkyner, aromater, etrar, alkoholer, aldehyder, ketoner, karboxylsyror och halogenerade kolväten)

2. Isomeri: geometrisk-och stereoisomeri

3. Additions- och substitutionsreaktioner samt mekanismer

4. Struktur och funktion hos vissa syntetiska polymerer (polyuretaner, polylaktid, polyhydroxybutyrat)

5. Introduktion till industriell och medicinsk kemi

Del 2 : Biokemi

Denna del består i stora drag av följande moment:

1. Struktur och funktion hos naturliga polymerer (polypeptider, polysackarider och nukleinsyror)

2. Struktur och funktion hos lipider och biologiska membran.

3. Enzymatisk katalys av reaktioner samt reglering av enzymaktivitet

4. Bioenergi och metabolism

5. Biotekniska applikationer inom forskning och industrin

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, obligatoriska inlämningsuppgifter och diskussioner kring dessa, samt laborationer. Aktivt deltagande på föreläsningarna bidrar till att lära sig grunderna i ämnet och inlämningsuppgifterna ger träning i att både skriftligt och muntligt beskriva och förklara frågeställningar inom ämnet. Genom laborationerna tränas färdigheter i laborativt arbete, samarbete och problemlösning, samt muntlig och skriftlig kommunikation. Vidare breddas inblicken i ämnet, samt ämnets koppling till samhället, genom olika gästföreläsningar som ges av forskare och industrirepresentanter.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Lärandemål 1-5 och 7 examineras genom godkända skriftliga inlämningsuppgifter och diskussioner under kursens gång, samt individuella skriftliga tentamina för del 1 och del 2 i kursen, med betygsskalan G/U. Resultaten från dessa två tentamina ligger till grund för slutbetyget, enligt betygsskala U 3 4 5. Lärandemål 6 bedöms genom två laborativa moment och påföljande skriftliga rapporter, med betygsskalan G/U. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen B0007K motsvarar kurser K0002K, B0005K

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0004 | Inlämningsuppgifter | U G# | 2 | Obligatorisk | H10 |  |
| 0006 | Laboration | U G# | 1,5 | Obligatorisk | H10 |  |
| 0007 | Tentamen biokemi | GU345 | 2 | Obligatorisk | H10 |  |
| 0008 | Tentamen organisk kemi | GU345 | 2 | Obligatorisk | H10 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Institutionen för Tillämpad kemi och geovetenskap 2010-08-05
