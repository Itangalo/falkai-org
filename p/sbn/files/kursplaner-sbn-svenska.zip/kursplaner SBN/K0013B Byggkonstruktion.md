---
kurskod: "K0013B"
titel: "Byggkonstruktion"
hp: "7,5"
titel_en: "Structural Design"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0013B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0013B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0013b-byggkonstruktion"
---

# Byggkonstruktion (K0013B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Grundläggande behörighet samt B0002B Konstruktionsteknik och K0002B Byggmaterial

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursens mål är att studenten ska kunna

- beskriva och förklara grunderna i dagens dimensioneringsfilosofi

- bestämma dimensionerande laster på byggnadsverk och byggnadsdelar

- dimensionera stål-, trä- och betongelement för böjande moment, tvärkraft och normalkraft

- beräkna moment-, tvärkrafts- och normalkraftskapacitet för stål-, trä- och betongelement

- dimensionera de vanligaste förbanden för stål- och träelement

- prova och utvärdera inverkan av armeringsmängd och betongens mognadsgrad på bärförmågan

- prova och utvärdera inverkan av tvärsnittsform, materialegenskaper och konstruktiv utformning på bärförmågan

- planera och utföra laborationsuppgifter i grupp, bearbeta resultat och presentera dem skriftligt (laborationsrapport)

## Kursinnehåll

Grunderna i dagens dimensioneringsfilosofi

- statistiskt/probabilistiskt synsätt

- säkerhet mot brott, bärförmåga och lasteffekt, gränstillstånd

- säkerhetsklass

Dimensionerande laster på byggnadsverk och byggnadsdelar

- lasters variation – i rummet och över tid

- lasttyper – egentyngd, nyttig last, snölast, vindlast, brand, jordtryck osv.

- lastnivåer – karakteristiskt värde, kombinationsvärde, frekvent värde och kvasi-permanent värde

- lastkombinationer – statisk jämvikt, brottgränstillstånd, bruksgränstillstånd, olyckslast

Betong-, stål- och träelement

- dimensioneringsprinciper

- dimensionering och bärförmåga med hänsyn till moment och tvärkraft

- dimensionering och bärförmåga med hänsyn till knäckning

Stål- och träförband

- förbandstyper

- dimensionering av pelarfot, pelartopp, skarvar

Inverkan av armeringsmängd och betongens mognadsgrad på bärförmågan hos betongelement undersöks i laboration genom

- gjutning, lagring och provning av tre balkar (en oarmerad, en böjarmerad och en böj- och skjuvarmerad)

Inverkan av tvärsnittsform och materialegenskaper samt konstruktiv utformning på bärförmågan undersöks i laboration genom provning av två träbalkar respektive genom byggande och provning av en fackverksbro av trä.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Studenterna deltar på föreläsningar där bakgrunder och teorier till kursinnehållet härleds, presenteras och exemplifieras.

Studenterna övar på dimensioneringsmetodik

- enskilt på övningspass i klassrum för enklare element

Studenterna övar på förmågan att planera och utföra uppgifter i grupp i tre laborationsuppgifter genom

- en träbro som konstrueras och byggs varefter lastkapaciteten kontrolleras (inverkan av tvärsnittsform och materialegenskaper samt konstruktiv utformning)

- två balkar av limträ och konstruktionsvirke, stagade mot vippning, som provas i trepunktsböjning till brott (inverkan av tvärsnittsform och materialegenskaper)

- tre betongbalkar (oarmerad, böjarmerad, böj- och skjuvarmerad) som gjuts och lagras varefter bärförmågan provas efter olika lång mognad (inverkan av armeringsmängd och betongens mognadsgrad)

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Bakgrund och teorier samt dimensioneringsmetodik för enklare bärverk examineras med skriftlig tentamen. Betygsskala: U, 3, 4, 5.

Dimensioneringsmetodik samt förmågan att planera och utföra laborationsuppgifter i grupp, bearbeta data och presentera resultat examineras genom skriftliga laborationsrapporter. Betygsskala U, G.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0013B motsvarar kursen ABS121

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Tentamen | GU345 | 5 | Obligatorisk | H08 |  |
| 0003 | Laborationer | UG | 2,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Institutionen för samhällsbyggnad och naturresurser 2011-02-07
