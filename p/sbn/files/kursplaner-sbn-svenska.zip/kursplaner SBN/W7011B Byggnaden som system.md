---
kurskod: "W7011B"
titel: "Byggnaden som system"
hp: "7,5"
titel_en: "The Building as a System"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2023-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=W7011B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=W7011B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/w70/w7011b-byggnaden-som-system"
---

# Byggnaden som system (W7011B)

## Ingår i huvudområde

Arkitektur

## Behörighet

- Kunskaper i projektarbete och projektledning motsvarande exempelvis kursen P0007B Byggprojektledning
- Kunskaper i husbyggnadsteknik motsvarande exempelvis kursen W700XB Byggteknik
- Kunskaper i konstruktionslära motsvarande exempelvis kursen K7012B Konstruktionslära
- Kunskaper i rums- och byggnadsakustik motsvarande exempelvis kursen Z7001B Rums- och byggnadsakustik
- Kunskaper i livscykelanalyser motsvarande exempelvis kursen W7008B Miljöeffektivt byggande

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens syfte är att du ska utveckla förståelse och förmåga att i ett givet sammanhang föreslå och utvärdera renoveringsåtgärder för en byggnad som ett system, där byggnaden betraktas som en teknisk och arkitektonisk helhet.

Kunskap och förståelse

Efter godkänd kurs ska du kunna:

- beskriva renoveringsprocessen, dess skeden och förutsättningar

- beskriva och diskutera hur en byggnads utformning, konstruktion och tekniska system påverkar dess funktion och prestanda

- relatera utredningsprojekt inom renovering till relevant forsknings- och utvecklingsarbete

Färdighet och förmåga

Efter godkänd kurs ska du kunna:

- planera och aktivt bidra till utredningsprojekt inom renovering genom att:

- föreslå en uppsättning lämpliga renoveringsåtgärder för att förbättra en byggnads funktion och prestanda utifrån rådande förutsättningar
- utreda och bedöma hur föreslagna renoveringsåtgärder påverkar byggnaden som system, baserat på hänsyn till några utvalda tekniska och arkitektoniska aspekter, ur ett livscykelperspektiv
- redogöra för och motivera de bedömningar och överväganden som ligger till grund för föreslagna renoveringsåtgärder

- sammanställa, redovisa och diskutera genomförande och resultat från utredningsprojekt på ett strukturerat sätt, både skriftligt och muntligt

Värderingsförmåga och förhållningssätt

Efter godkänd kurs ska du kunna:

- reflektera kring konsekvenser av föreslagen byggnadsrenovering utifrån en helhetssyn på byggnaden som system

- reflektera kring sociala, ekonomiska, miljömässiga och arbetsmiljömässiga konsekvenser av föreslagen byggnadsrenovering

## Kursinnehåll

I kursen tillämpar och fördjupar du kunskaper och färdigheter inom projektledning och husbyggnad som du förvärvat i tidigare kurser i programmet. Tillämpningen och fördjupningen sker inom området byggnadsrenovering. Kursen behandlar begrepp, process, förutsättningar, lösningar och metoder för renovering med utgångspunkt från en helhetssyn på byggnaden som system. Därtill behandlar kursen utmaningar och begränsningar som råder när man arbetar med befintliga byggnader. Kursen omfattar och lägger särskilt vikt vid, tillämpning av kursstoffet i ett utredningsprojekt om möjliga renoveringsåtgärder för en verklig befintlig byggnad.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. I kursen genomför du ett kvalificerat utredningsuppdrag i form av ett projektarbete i grupp. Arbetet stöds av föreläsningar, handledningstillfällen och dialoger vid presentationstillfällen. Utredningsprojektet omfattar tre etapper som bygger på varandra: Planering, Inventering och Utredning. Därtill genomför du individuell granskning av ett annat utredningsprojekt och reflektion kring det egna utredningsprojektet.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Fem examinationsmoduler (Prov 0001, 0002, 0003, 0004 och 0005) ingår i kursen, där samtliga måste ska vara avklarade för slutbetyg i kursen.

Lärandemålen som rör kunskap och förståelse examineras genom Prov 0002, 0003 och 0005. Lärandemålen som rör färdighet och förmåga examineras genom Prov 0001, 0002, 0003, 0004 och 0005. Lärandemålen som rör värderingsförmåga och förhållningssätt examineras genom Prov 0005.

Prov 0001 (Planering; G U) examineras genom en skriftligt redovisad projektplanering i grupp. Prov 0002 (Inventering; G U) examineras genom en muntlig presentation i grupp. Prov 0003 (G U) examineras genom en kombination av en skriftlig rapport och en muntlig presentation i grupp. Prov 0004 (G U) examineras genom en skriftlig individuell inlämningsuppgift. Prov 0005 (U 3 4 5) examineras genom en skriftlig individuell inlämningsuppgift och en muntlig reflektion.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen W7011B motsvarar kursen W7009B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Planering | U G# | 0,5 | Obligatorisk | H23 |  |
| 0002 | Inventering | U G# | 1,5 | Obligatorisk | H23 |  |
| 0003 | Utredning | U G# | 3 | Obligatorisk | H23 |  |
| 0004 | Granskning | U G# | 0,5 | Obligatorisk | H23 |  |
| 0005 | Reflektion | GU345 | 2 | Obligatorisk | H23 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13
