---
kurskod: "M7007K"
titel: "Processmineralogi"
hp: "7,5"
titel_en: "Process mineralogy"
giltig: "Vår 2019 Lp 4 - Höst 2022 Lp 2"
beslutsdatum: "2019-01-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Mineralteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7007K&lasPeriod=209&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/m70/m7007k-processmineralogi"
---

# Processmineralogi (M7007K)

## Behörighet

90hp inom kemiteknik. Kursen M0001K Fysikaliska separationmetoder ska ingå.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Examinator

Yousef Ghorbani

## Mål/Förväntat studieresultat

Studenten ges möjlighet att utveckla färdigheter i processmineralogi Efter kursen förväntas studenterna kunna:
- beskriva principerna bakom processmineralogi och de kvantitativa analysmetoder som används,
- praktiskt använda olika forsknings- och analysmetoder av betydelse för processmineralogi, t ex optisk mikroskopering, XRD, SEM, renkrossningsstudier,
- utvärdera, analysera och tolka processmineralogiska data kvantitativt
- formulera en processmineralogisk handlingsplan för olika slags processrelaterade frågeställningar.

## Kursinnehåll

Kursen beskriver mineralogin hos de vanligaste malmtyperna i Sverige och dess inflytande på anrikningsprocesserna. Viktiga analysmetoder gås igenom, hur analyserna görs i praktiken, hur data hanteras och hur resultaten tolkas. Följande moment ingår:
- processmineralogiska analys- och forskningsmetoder: optisk mikroskopi, XRD, SEM, WDS,
- mineralogiska kalkyler: element-mineralomvandling, fördelning av element mellan siktfraktioner, provs densitet, mineralfraktioner,
- processhantering av partiklar; viktigaste processtegen
- karakterisering av partiklar: partikelstorlek, renmalningsgrad
- processmineralogin hos de viktigaste malmtyperna i Sverige.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, PC-lektioner, räkneövningar, obligatoriska laborationer och obligatoriska seminarier.
- Föreläsningarna skall ge möjlighet för eleverna att kunna planera och utföra processmineralogiska undersökningar samt att kunna redogöra för teoretiska begrepp.
- PC-lektioner och räkneövningar ägnas åt att träna beräkningsprocedurer och tekniker.
- Laborationerna är på analysmetoder, kalkyler och resultattolkning.
- Projekt med seminarierna ägnas åt att i grupp beskriva, analysera, utvärdera, tolka, rapportera och presentera resultatet av en processmineralogisk undersökning. Undersökningen avrapporteras vid två seminarietillfällen, där det första ägnas åt att inför andra grupper redogöra för forskningsfrågan, materialet och det planerade arbete. Det andra seminariet ägnas åt redovisning av det utförda arbetet och där det då finns en förberedd opponentgrupp. Opponentgruppen skall ha skrivit en kort utvärdering av den responderande gruppens rapport och de skall under seminariet muntligen opponera på den förelagda rapporten. Laborations- och projektrapporter skall vara tekniskt, mineralogiskt och språkligt korrekta.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Laborationer, processmineralogisk undersökning och seminarier är obligatoriska. Laborationsrapporter, projekt med seminarier, undersökningsrapport och opponering bedöms med poäng inom dessa delar. Uppgifter och rapporter skall inlämnas inom föreskriven tid i annat fall sker avtrappning av max uppnåbara poäng på momentet. Den totala poängproduktionen ger totalbetyget för kursen, som ges med graderade betyg i skala U 3 4 5. För betyg 3 skall eleven kunna beskriva procedurer för och utföra rutinmässiga processmineralogiska delmoment. För betyg 4 skall eleven kunna utvärdera och tolka processmineralogi med hjälp av olika analytiska tekniker och redovisa undersökningsresultat. För betyg 5 skall eleven kunna tillämpa sina kunskaper på ett nytt processmineralogiskt material, tolka, rapportera och presentera resultatet samt försvara sina slutsatser.

## Övrigt

Första lektionen är obligatorisk för alla studenter. Frånvaro beviljas av kursansvarig. Studiehandledning återfinns på LMS i aktuellt kursrum.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Laborationer | GU345 | 3,5 | Obligatorisk | V13 |  |
| 0004 | Projekt | GU345 | 4 | Obligatorisk | H14 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Litteratur

*Litteratur. Gäller från Vår 2013 Lp 3* Kompendiematerial tillhandahålles av Mineralteknik.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-01-11

## Kursplanen fastställd

av Eva Gunneriusson 2012-03-14
