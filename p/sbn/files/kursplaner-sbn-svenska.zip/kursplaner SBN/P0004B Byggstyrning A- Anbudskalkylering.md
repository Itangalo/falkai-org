---
kurskod: "P0004B"
titel: "Byggstyrning A- Anbudskalkylering"
hp: "7,5"
titel_en: "Construction management A- tender cost estimation"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2023-06-02"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "UG"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0004B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p00/p0004b-byggstyrning-a--anbudskalkylering"
---

# Byggstyrning A- Anbudskalkylering (P0004B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Studenten ska efter kursen: - Ha en grundläggande förståelse i planering och kalkylering av ett byggprojekt . - Ha kunskap i datainsamling av relevanta uppgifter för planeringen och kalkyleringen av ett byggprojekt samt presentera dessa i såväl skriftlig som muntlig form. - Tolka och kunna förstå ett förfrågningsunderlag. - kunna identifiera risker och möjligheter i ett förfrågningsunderlag. - Kunna kommunicera med beställare om innehåll i beskrivningar. - Kunna ställa samma och presentera ett anbud.

## Kursinnehåll

Fastställande av omfattningen för projektet Planering och styrning av anbudsarbetet
- Aktivitetsbestämning, aktivitetsberäkning Anbudsgivning
- Upprättande av anbud
- Mängdberäkning
- Val av produktionsmetod

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen är uppbyggd kring projektarbete i grupper. Kunskapstillskott sker genom undervisningsmoment som behandlar de olika ingående momenten För genomförande av projektuppgiften ges handledning fortlöpande och även vid simulerade förhandlingar. Vid dessa möten deltar en lärare som spelar rollen av byggherre.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examinationen sker utifrån redovisning av projektuppgift och skriftlig dugga. De skriftliga rapporterna värderas vad avser både form och innehåll.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen P0004B motsvarar kursen ABP114

## Övrigt

Kursen kan på grund av överlappning ej ingå i examen tillsammans med P0001B eller annan kurs med liknande innehåll.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0006 | Projektuppgift | UG | 6 | Obligatorisk | V27 |  |
| 0007 | Skriftlig dugga | UG | 1,5 | Obligatorisk | V27 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02

## Kursplanen fastställd

av Institutionen för Samhällsbyggnad 2007-01-31
