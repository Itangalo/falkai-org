---
kurskod: "F0018B"
titel: "Arkitekturhistoria - En modern metropol och dess historia - en exkursion till Paris"
hp: "7,5"
titel_en: "Architectural History - A Modern Metropolis and its History - A Fieldtrip to Paris"
giltig: "Vår 2024 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2023-06-02"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "U G#"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F0018B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F0018B&lasPeriod=214&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/f00/f0018b-arkitekturhistoria---en-modern-metropol-och-dess-historia---en-exkursion-till-paris"
---

# Arkitekturhistoria - En modern metropol och dess historia - en exkursion till Paris (F0018B)

## Behörighet

Grundläggande behörighet samt F0008B Arkitekturhistoria

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kunskap och förståelse

Efter kursen skall studenten kunna:

1) Utifrån exempel ge en översiktlig beskrivning av Paris, både som levande

referens i arkitekturhistorien och som modern storstadsmiljö.

Färdighet och förmåga

Efter kursen skall studenten ha:

2) Förmågan att i tal och skrift presentera en plats eller en byggnad för potentiella

kollegor, samarbetspartners och/eller beställare.

Värderingsförmåga och förhållningssätt

Efter kursen skall studenten kunna:

3)Beskriva sin erfarenhet av studieresan som verktyg för att inhämta praktiskt relaterad

kunskap och inspiration för egna arbetsuppgifter.

## Kursinnehåll

Kursen består av en föreläsningsserie om studieresans historia och betydelse, samt arkitektur- och stadsbyggnadshistoria, med särskild tonvikt på staden Paris. Varje kursdeltagare förbereder samtidigt genom litteraturstudier en redovisning av en plats, en byggnad eller en stadsmiljö. Förberedelserna utformas i samarbete med läraren till en gemensam reseguide. Under upp till fem kursdagar i Paris presenterar kursdeltagarna

förberedda inlägg, vars innehåll och muntliga presentation diskuteras och kritiseras av lärare och gruppen gemensamt.

hp                                                                                        Lp3

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av förberedande seminarier och aktiviteter på LTU och lärarledda seminarier vid utvalda objekt i Paris. Studenterna tar själv fram en gemensam reseguidebok under lärarens ledning. Resan och alla utgifter bekostas av deltagarna själva.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Aktivt deltagande i kursens seminarier och aktiviteter är centralt för kursen.

För godkänd kurs krävs godkänd skriftlig och muntlig presentation samt aktivt deltagande under hela studieresan.

I modul 0002 examineras lärandemål 1 och 2 genom en muntlig presentation på plats (betygsskala: U G #)

I modul 0003 examineras lärandemål 1 genom aktivt deltagande på seminarier och onlineuppgifter (betygsskala: U G #)

I modul 0004 examineras lärandemål 2 och 3 genom en skriftlig uppgift (betygsskala: U G #)

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Kursen kan på grund av överlappning ej ingå i examen tillsammans med F0016B och F0017B eller kurs med liknande innehåll.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Studieresa och muntlig presentation | U G# | 4 | Obligatorisk | V20 |  |
| 0003 | Seminarier | U G# | 0,5 | Obligatorisk | V20 |  |
| 0004 | Skriftlig inlämningsuppgift | U G# | 3 | Obligatorisk | V20 |  |
| hp |  |  |  | Lp3 |  |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-02-14
