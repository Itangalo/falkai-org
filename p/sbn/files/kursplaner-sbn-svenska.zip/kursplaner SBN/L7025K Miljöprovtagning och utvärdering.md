---
kurskod: "L7025K"
titel: "Miljöprovtagning och utvärdering"
hp: "7,5"
titel_en: "Environmental sampling and evaluation"
giltig: "Höst 2014 Lp 1 - Tills vidare"
beslutsdatum: "2014-02-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "U G#"
amne: "Miljöteknik"
amnesgrupp_scb: "Miljövård och miljöskydd"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser  Prov Provnr       Typ                                                               Hp          Betyg  0001         Dugga                                                             2,5         U G#  0002         Inlämningsuppgifter                                               2,5         U G#  0003         Projektuppgift                                                    2,5         U G#"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7025K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7025K&lasPeriod=188&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l70/l7025k-miljoprovtagning-och-utvardering"
---

# Miljöprovtagning och utvärdering (L7025K)

## Behörighet

90hp inom geovetenskap eller kemiteknik

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Examinator

Christian Maurice

## Mål/Förväntat studieresultat

Den övergripande målsättningen med kursen är studenten ska kunna:
- Reflektera över hur provtagningsstrategi, provbehandling och analytiska metoder kan påverka informationen som erhålls från ett miljöövervakningsprogram
- Tillämpa de vanligaste provtagnings- och analysteknikerna som används av industrin och konsulter för olika typer av miljöprov (jord, sediment, vatten)
- Välja bland de vanligaste analysmetoderna för olika typer av miljöprov * Utföra relevanta statistiska analyser på dataset * Planera, prissätta, genomföra och rapportera en traditionell recipient undersökning.

## Kursinnehåll

- Provtagnings- och analytiska metoder i miljöövervakningsprogram
- Statistiska analyser och beräkningar som används i miljöövervakningsprogram
- Miljökvalitetsnormer och lagstiftning
- Fältövningar och demonstrationer
- Laborationer och demonstrationer
- Studiebesök
- Projektuppgift i grupp
- Individuell inlämningsuppgift

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Lektioner, fältövningar och demonstrationer, studiebesök till kommersiellt laboratorium, laborationer och demonstrationer, projektuppgift. Obligatorisk närvaro på första lektionen. I kursen används exempel tagna ur verkligheten (t.ex. konsultrapporter) för att illustrera vilken typ av uppgifter den blivande civilingenjören kommer att arbeta med

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Godkända inlämningsuppgifter och genomförd projektuppgift, skriftlig tentamen (dugga) på de teoretiska delarna av kursen.

## Överlappning

Kursen L7025K motsvarar kursen L7026K

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser

Prov Provnr       Typ                                                               Hp          Betyg

0001         Dugga                                                             2,5         U G#

0002         Inlämningsuppgifter                                               2,5         U G#

0003         Projektuppgift                                                    2,5         U G#

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Litteratur

*Litteratur. Gäller från Höst 2013 Lp 1*
- Lakes and Watercourses, Report 5050, Swedish EPA
- Hand-outs och rapporter från Naturvårdsverket (tillgänglig on-line)

## Revidering fastställd

av Eva Gunneriusson 2014-02-11

## Kursplanen fastställd

av Eva Gunneriusson 2012-03-14
