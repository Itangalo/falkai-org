---
kurskod: "D7012B"
titel: "Avancerad tillförlitlighetsteknik"
hp: "7,5"
titel_en: "Advanced Reliability Engineering"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7012B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7012b-avancerad-tillforlitlighetsteknik"
---

# Avancerad tillförlitlighetsteknik (D7012B)

## Ingår i huvudområde

Underhållsteknik

## Behörighet

Kurser om minst 60 hp i några av de följande områdena ska ingå: Drift och underhållsteknik, Energiteknik, Maskinteknik, Materialteknik, Väg- och vattenbyggnad, Träteknik eller motsvarande kunskaper, samt minst 15 hp i matematik.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter avslutad kurs ska deltagarna kunna:

- visa förståelse för grundläggande definitioner och begrepp relaterade till tillförlitlighetsteknik.

- tillämpa både parametriska och icke-parametriska metoder för att analysera feldata och estimera relevanta modellparametrar.

- utföra probabilistisk modellering av fel för reparerbara enheter med t.ex. förnyelseprocesser, Poissonprocesser, icke-homogen Poissonprocess

- modellera felutveckling hos ett system med flera enheter

- bestämma optimala tillförlitlighetsbaserade underhållsstrategier för att uppfylla systemfunktioner

## Kursinnehåll

Inom kursen kommer olika aspekter av tillförlitlighet och underhållsteknik att diskuteras enligt följande:

- Introduktion till RAMS och grundläggande begrepp

- Produktens funktionssäkerhet, tillförlitlighetsdata och datakällor

- Insamling av data för tillförlitlighetsanalys och datakvalitet

- Preliminär dataanalys

- Icke-parametriska och parametriska metoder för analys av tillförlitlighetsdata

- Modellering av första fel – standardfördelningar (icke-reparerbara enheter)

- Modellval, parameteruppskattning och hypotesprovning

- Konfidensintervall och underliggande koncept

- Tillförlitlighetsanalys av reparerbara enheter

- Mean Cumulative Function (MCF)

- Systemtillförlitlighet

- Tillförlitlighetsbaserad underhållsmodellering och optimering

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Föreläsningar introducerar grundläggande koncept med exempel med hjälp av presentationsmaterial och tavla. Föreläsningarna följs av gruppuppgifter för att förstärka förståelse för varje del. Studenterna måste interagera för att lösa ett problem, tillämpa, förklara, analysera eller identifiera en aspekt av ämnet som presenterades. Studenterna kommer också att arbeta med ett antal utökade grupprojekt och individuella övningar och inlämningsuppgifter för att stärka sitt lärande. Vid grupparbete krävs att studenten lämnar in en rapport och presenterar resultatet muntligt för att få kommentarer och förslag på förbättringar från studenter och lärare. Enskilda inlämningsuppgifter kommer att granskas av lärarna för att ge studenterna konstruktiv återkoppling.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursens lärandemål examineras genom en skriftlig tentamen och inlämningsuppgifter. Slutbetyget ges i enlighet med den skriftliga tentamen, kvaliteten på inlämningsuppgifterna och aktivt deltagande i diskussioner och gruppresentationer.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Skriftlig tentamen | GU345 | 5 | Obligatorisk | H17 |  |
| 0004 | Inlämningsuppgifter | U G# | 2,5 | Obligatorisk | H17 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2017-02-10
