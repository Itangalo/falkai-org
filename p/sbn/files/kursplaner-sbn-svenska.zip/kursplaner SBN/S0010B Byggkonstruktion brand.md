---
kurskod: "S0010B"
titel: "Byggkonstruktion brand"
hp: "7,5"
titel_en: "Structural Design and Fire"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "GU345"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S0010B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S0010B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s00/s0010b-byggkonstruktion-brand"
---

# Byggkonstruktion brand (S0010B)

## Behörighet

Grundläggande behörighet samt B0002B Konstruktionsteknik och K0002B Byggmaterial eller motsvarande kurser.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursens mål är att studenten

dels ska kunna

- beskriva och förklara grunderna i dagens dimensioneringsfilosofi

- bestämma dimensionerande laster på byggnadsverk och byggnadsdelar

- dimensionera stål-, trä- och betongelement för böjande moment, tvärkraft och normalkraft

- kunna beräkna moment-, tvärkrafts- och normalkraftskapacitet för stål-, trä- och betongelement

under normala förhållanden och vid brand,

dels kunna

- beskriva byggnadstekniskt brandskydd och utformning av byggnader för utrymning vid brand

- beskriva grundläggande materialegenskaper vid brand

- förklara grundläggande krav på konstruktioner utsatta för brand

samt

- kunna planera och utföra laborationsuppgifter i grupp, bearbeta resultat och presentera dem skriftligt (laborationsrapport)

## Kursinnehåll

Grunderna i dagens dimensioneringsfilosofi

- statistiskt/probabilistiskt synsätt

- säkerhet mot brott, bärförmåga och lasteffekt, gränstillstånd

- säkerhetsklass

Dimensionerande laster på byggnadsverk och byggnadsdelar enligt norm

- lasters variation – i rummet och över tid

- lasttyper – egentyngd, nyttig last, snölast, vindlast, brand, jordtryck osv.

- lastnivåer – karakteristiskt värde, kombinationsvärde, frekvent värde och kvasi-permanent värde

- lastkombinationer – statisk jämvikt, brottgränstillstånd, bruksgränstillstånd, olyckslast

Betong-, stål- och träelement

- dimensioneringsprinciper

- dimensionering och bärförmåga med hänsyn till moment och tvärkraft

- dimensionering och bärförmåga med hänsyn till knäckning

- Inverkan av tvärsnittsform och materialegenskaper samt konstruktiv utformning på bärförmåga undersöks i laboration genom provning av två träbalkar respektive genom byggande och provning av en fackverksbro av trä.

Brand

- byggnadsklassificering och brandsäkerhetsklasser vid förenklad dimensionering

- standardbränderna och deras tillämpning

- enklare temperaturberäkningar enligt tabell

- materialegenskaper vid förhöjd temperatur

- kritisk temperatur och kritisk last för oskyddade element

- dimensionering av brandskydd

- Inverkan på bärförmågan hos ett element belastat med normalkraft och av brand undersöks i laboration

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Bakgrunder och teorier till kursinnehållet härleds, presenteras och exemplifieras på föreläsningar.

Dimensioneringsmetodik till kursinnehållet tränas

- enskilt på övningspass i klassrum för enklare element

Förmågan att planera och utföra uppgifter i grupp tränas i tre laborationsuppgifter där teorier och dimensioneringsmetodik verifieras genom

- en träbro som konstrueras och byggs varefter lastkapaciteten kontrolleras

- två balkar av limträ och konstruktionsvirke, stagade mot vippning, som provas i trepunktsböjning till brott

- ett element belastat med normalkraft och av brand varefter lastkapaciteten kontrolleras

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Bakgrund och teorier samt dimensioneringsmetodik för enklare bärverk examineras med skriftlig tentamen. Betygsskala: U, 3, 4, 5.

Dimensioneringsmetodik samt förmågan att planera och utföra laborationsuppgifter i grupp, bearbeta data och presentera resultat examineras genom skriftliga laborationsrapporter. Betygsskala U, G.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Skriftlig tentamen | GU345 | 5 | Obligatorisk | V21 |  |
| 0003 | Laboration | UG | 2,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når

lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-02-14
