---
kurskod: "O0007K"
titel: "Strukturgeologi"
hp: "7,5"
titel_en: "Structural Geology"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2023-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0007K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0007K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o00/o0007k-strukturgeologi"
---

# Strukturgeologi (O0007K)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet samt O0035K Geologi eller motsvarande.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursens mål är att studenten genom studier av deformationsmekanismer och strukturanalys av deformerade bergarter 1) ska kunna identifiera de vanligaste geologiska strukturerna, 2) förklara hur dessa strukturer bildats, 3) visualisera strukturgeologiska mätdata genom stereografisk projektion, samt 4) vara medveten om olika typer av osäkerheter som finns i geologiskt kartmaterial och grovt kunna planera en berggrundskartering.

Studenten kommer genom kursen att få en bas för olika typer av praktiskt arbete inom geologi, gruvbrytning, malm- och mineralletning samt ingenjörsgeologi.

Studenten ska kunna bearbeta resultat och presentera dem både skriftligt (rapport) och muntligt (presentation).

## Kursinnehåll

Under kursen kommer följande strukturgeologiska delar att tas upp: plattektonik, stress och strain, sekundära strukturer i berggrunden som deformationszoner och veckning, kinematiska indikatorer, mätning av strukturer i fält, berggrundskartering samt olika tillämpningar av strukturgeologi i samhället. Kursen avhandlar strukturgeologi från mikroskala till regional skala. Kursen omfattar plottning och modellering av strukturgeologiska data i 2D/3Dmjukvaror.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Föreläsningarna tar upp den grundläggande teorin och olika praktiska tillämpningar av strukturgeologi. Lektionerna omfattar lösning av strukturgeologiska problem med stereografisk projektion, geologiska kartor och profiler. Ett projektarbete (fältarbetsmoment) samt en exkursion ingår.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Mål 1 och 2 examineras genom en skriftlig tentamen med differentierade betyg (3,5 hp) som täcker in föreläsningar och kurslitteratur.

Mål 3 examineras som övningsuppgift (1,5 hp) och omfattar deltagande vid strukturgeologiska mätningar under en fältexkursion samt en associerad klassrumsövning där data från exkursionen plottas och tolkas.

Mål 4 examineras som projektuppgift (2,5 hp) och omfattar en praktisk övning i berggrundskartering. Kopplat till fältarbetet skrivs en rapport vilken även presenteras och diskuteras muntligt.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen O0007K motsvarar kursen KGO003

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0004 | Tentamen | GU345 | 3,5 | Obligatorisk | H07 |  |
| 0005 | Projektuppgift | U G# | 2,5 | Obligatorisk | H07 |  |
| 0006 | Övningsuppgift | U G# | 1,5 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
