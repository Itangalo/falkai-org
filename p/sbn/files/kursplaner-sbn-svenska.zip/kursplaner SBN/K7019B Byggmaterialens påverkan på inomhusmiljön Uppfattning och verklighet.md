---
kurskod: "K7019B"
titel: "Byggmaterialens påverkan på inomhusmiljön: Uppfattning och verklighet"
hp: "7,5"
titel_en: "Building Materials Influence on Indoor Environment: Perception and Reality"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2022-02-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7019B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7019B&lasPeriod=214&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7019b-byggmaterialens-paverkan-pa-inomhusmiljon-uppfattning-och-verklighet"
---

# Byggmaterialens påverkan på inomhusmiljön: Uppfattning och verklighet (K7019B)

## Ingår i huvudområde

Väg- och vattenbyggnad

## Behörighet

För att uppfylla det allmänna behörighetskravet till kursen krävs att studenten har genomfört minst 120 hp högskolestudier inom civilingenjör, arkitektur, materialvetenskap eller liknande. Dessutom kräver denna kurs en genomförd introduktionskurs i byggmaterial som byggmaterial K0002B eller motsvarande. Kunskaper i engelska, motsvarande engelska B/6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens mål är att studenten ska utveckla sin kunskap i byggmaterialens påverkan på inomhusmiljön.

Efter genomgången kurs ska studenten kunna:

1. Behärska begrepp och tekniker om byggmaterials påverkan på inomhusklimatet.

2. Utvärdera möjlig påverkan av utvalda byggmaterial på inomhusmiljön.

3. Reflektera över inomhusluftproblem som härrör från byggmaterial och ge möjliga lösningar på problem.

4. Visa medvetenhet om potentiella risker med olika byggmaterial.

5. Visa en djupare förståelse för byggnadsmaterials inverkan på människors hälsa.

6. Förklara hur uppfattningen om byggnadsmaterials hälsoeffekter formas och påverkas.

## Kursinnehåll

På grund av sin helhetssyn omfattar kursen många områden inom byggmaterial, inomhusklimat och hälsa. Kursen förklarar betydelsen av inomhusklimatet som en väsentlig del av komfort och livskvalitén. Olika faktorer som bestämmer inomhusklimatet påverkas enormt av materialvalet. Inomhusklimat och utsläpp från själva byggmaterialet som VOCs och radon omfattas. Samt påverkan av felaktig användning av byggmaterial som leder till t.ex. mögel. Den här kursen kommer att täcka flera ämnen relaterade till inomhusklimat, för att säkerställa att studenterna lär sig om potentiella risker och hur man kan minimera problem. Studenterna kommer också att lära sig om hur byggmaterials hälsoeffekter formas och påverkas.

Ämnen som behandlas är bl.a.:

- Byggmaterial och luftfuktighet

- Mögel

- Strålning och Radon

- Farliga byggnadsmaterial (asbest)

- Passivhus

- Uppfattning om olika byggmaterials påverkan på människors hälsa

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar som presenteras av flera lärare. Föreläsningar fokuserar på ämnesområdets teoretiska bakgrund. Praktiska färdigheter tränas genom beräkningar/övningar i klassrummet och i laborativa uppgifter. Arbetet i laboratoriet utförs i grupper och resultat från laborationerna redovisas skriftligt av grupperna. Laborationer och övningar kommer att vara kopplade till föreläsningar och utförs parallellt. Studiebesök genomförs om möjligt för att se praktiska tillämpningar i industrin. Dokumenthantring sker i lärplattformen Canvas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Under kursen kommer studenterna att arbeta med korta skriftliga inlämningsuppgifter, som kommer att betygsättas U/G. Istället för slutprov kommer studenten att lämna in en längre skriftlig projektuppgift som betygsätts U/3/4/5. OBS: Genom denna metod kan alla lärandemål täckas. Observera att alla skriftliga inlämningsuppgifter kan skrivas på engelska eller svenska.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Korta individuella inlämningsuppgifter | U G# | 4 | Obligatorisk | V23 |  |
| 0002 | Skriftlig projektuppgift | GU345 | 2 | Obligatorisk | V23 |  |
| 0003 | Laboration och platsbesök | U G# | 1,5 | Obligatorisk | V23 |  |

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11
