---
kurskod: "P0005B"
titel: "Byggstyrning B- Produktionsplanering"
hp: "7,5"
titel_en: "Construction management B- Construction Planning"
giltig: "Vår 2022 Lp 3 - Vår 2023 Lp 4"
beslutsdatum: "2021-04-20"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "U G#"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0005B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0005B&lasPeriod=206&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p00/p0005b-byggstyrning-b--produktionsplanering"
---

# Byggstyrning B- Produktionsplanering (P0005B)

## Behörighet

Grundläggande behörighet samt P0004B Byggstyrning A - anbudskalkylering

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Examinator

Johan Larsson

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

- Beskriva produktionsplanering av ett byggprojekt

- Samla in relevanta uppgifter för produktionsplaneringen av ett byggprojekt samt presentera dessa i såväl skriftlig som muntlig form

- Identifiera risker och möjligheter i produktionsskedet

- Kommunicera med aktörer som deltar i byggprocessen

- Strukturera ett byggprojekt och upprätta tidplan

- Följa upp och stämma av en produktionstidplan

- Upprätta och följa upp en projektekonomi

## Kursinnehåll

Kursen behandlar:

- Planering och styrning av byggprojekt för produktionsskedet, arbetsberedning

- Logistik på arbetsplatsen (Leveranser, upplag, försörjningar)

- Ekonomi (Upprätta och stämma av en produktionsbudget)

- Kvalitets- och miljöplanering (Identifiering och styrning av kvalitets- och miljörisker, kontrollplaner)

- Organisationsplanering (Ledarskap, ansvarsfördelning, kommunikationsplanering, samordning, arbetsmiljö inkl. psykosocial arbetsmiljö)

- Riskplanering (Riskanalyser, arbetsberedning)

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen är uppbyggd kring projektarbete i grupper. Kunskapstillskott sker genom undervisningsmoment/föreläsningar som behandlar de olika ingående momenten För genomförande av projektuppgiften ges handledning fortlöpande och även vid simulerade förhandlingar. Vid dessa möten deltar en lärare som spelar rollen av byggherre/beställare.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examinationen sker utifrån redovisning av genomförd projektuppgift samt skriftlig dugga. De skriftliga rapporterna värderas vad avser både form och innehåll. Vid de muntliga redovisningarna bedöms presentationstekniken.

## Överlappning

Kursen P0005B motsvarar kursen ABP115

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Projektuppgift | U G# | 6 | Obligatorisk | H07 |  |
| 0004 | Skriftlig dugga | U G# | 1,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Litteratur

*Litteratur. Gäller från Vår 2022 Lp 3* Rekommenderad:
- Mats Persson (upplaga 1:2) Planering och beredning av bygg- och anläggningsprojekt. Studentlitteratur Lund. ISBN978-91-44-05773-6
- Sveriges byggindustrier (2013). Byggarbetsplatsens teknikhandbok. ISSN: 1652-6384.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-04-20

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
