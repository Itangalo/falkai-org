---
kurskod: "L7026K"
titel: "Provtagning och utvärdering vid miljökontroll"
hp: "7,5"
titel_en: "Sampling and Evaluation of Environmental Data"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2023-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Miljöteknik"
amnesgrupp_scb: "Miljövård och miljöskydd"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7026K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7026K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l70/l7026k-provtagning-och-utvardering-vid-miljokontroll"
---

# Provtagning och utvärdering vid miljökontroll (L7026K)

## Ingår i huvudområde

Naturresursteknik, Geovetenskap

## Behörighet

90hp inom geovetenskap eller kemiteknik

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter avslutad kurs ska deltagarna kunna

Kunskap och föreståelse

1. Förklara hur geokemiska och fysikaliska egenskaper kring miljöproblem påverkar provtagningsstrategier och demonstrera var relevant bakgrundinformation kan hämtas

2. visa förståelse för uppsatta jämställdhetsmål, regelverk för jämställdhet i arbetslivet samt ge exempel på förutsättning för jämställdhet i arbetslivet.

Färdighet och förmåga

3. Kritiskt utvärdera och tillämpa provtagnings- och analysteknikerna för olika typer av prover (vatten, sediment, jord)

4. Utföra relevanta statistiska analyser på dataset och kunna tillämpa relevanta databehandlingsprogram

5. Planera, prissätta, genomföra, rapportera och presentera monitoringsprogram

Värderingsförmåga och förhållningssätt

6. Kritiskt reflektera och diskutera över hur provtagningsstrategi, provbehandling och analytiska metoder kan påverka den geokemiska tolkningen och felkällor i ett miljöövervakningsprogram

## Kursinnehåll

Kursen är uppdelad i fyra sektioner. Den första sektionen innehåller information om miljökvalitetsnormer, lagstiftning, bakomliggande geokemi kring miljöproblem och provtagning av ytvatten, grundvatten, jord och sediment. I det andra blocket behandlas mätningar i fält, teoretisk information om olika laborativa test och besök till laboratorier för att se analytiska tekniker och instrument. Det tredje blocket fokuserar på utvärdering av geokemiskt data med hjälp av statistiska- och databehandlingsprogram. I det fjärde blocket behandlas jämställdhet.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. I kursen utvecklas studenterna självständighetsförmåga att planera arbete genom att ta del av förinspelade lektioner med basinformation och svara på instuderingsfrågor baserade på inspelningarna och kurslitteraturen. Genom att arbeta aktivt i grupp på seminarier tränar studenterna sin förmåga att samarbeta och lösa geokemiska problemställningar, men också att identifiera relevant bakgrundinformation och visualisera resultat inför de andra grupperna i kursen. Genom fältövningar och studiebesök arbetar studenterna med potentiellt kommande uppgifter i arbetslivet och får en helhetsförståelse av provtagning och utvärdering av miljödata. Under hela kursen arbetar studenterna med en projektuppgift där de använder informationen från kursen för att utveckla ett monitoringsprogram baserat på riktiga fall. Projektuppgiften presenteras individuellt för att utveckla färdigheter i presentationsteknik, och genom opponering av de andra grupparbetena övar studenterna på att ge och ta emot konstruktiv kritik.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Måluppfyllelsen kontrolleras genom

1. En muntligt tenta som examinerar mål 1, 3, 4 och 6 (Betyg G/U 3 4 5)

2. Individuell inlämningsuppgifter som examinerar mål 2 och 4 (Betyg G/U 3 4 5) 3. En skriftlig grupprapport om projekt uppgiften (Betyg G/U) och en individuell presentation av rapporten (Betyg G/U 3 4 5) examinerar mål 5.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen L7026K motsvarar kursen L7025K

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Projektuppgift | U G# | 2,5 | Obligatorisk | H18 |  |
| 0004 | Seminarieuppgift | GU345 | 1,5 | Obligatorisk | H18 |  |
| 0005 | Tentamen | GU345 | 3,3 | Obligatorisk | H18 |  |
| 0006 | Inlämningsuppgifter | GU345 | 0,2 | Obligatorisk | H18 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2018-02-13
