---
kurskod: "U0002B"
titel: "Industrialiserat byggande"
hp: "7,5"
titel_en: "Industrialized Building"
giltig: "Höst 2019 Lp 1 - Tills vidare"
beslutsdatum: "2019-06-19"
utbildningsniva: "Grundnivå"
betygsskala: "U G#"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=U0002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=U0002B&lasPeriod=200&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/u00/u0002b-industrialiserat-byggande"
---

# Industrialiserat byggande (U0002B)

## Behörighet

Grundläggande behörighet

## Examinator

Lars Stehn

## Mål/Förväntat studieresultat

Efter genomgången kurs skall studenterna:

- ha ett brett kunnande inom Valla Coach metoder och verktyg,

- ha utvecklat standardiserat arbete för användning inom industrialiserat byggande,

- ha tillämpat de olika stegen i en planerings- och styrningsprocess,

- ha ett brett kunnande om coachning både på individnivå och på gruppnivå,

- förstå coachning genom experiment och reflektion genom att ha tillämpat att leda förändring genom ett coachande och lärande förhållningssätt,

- kunna arbeta självständigt med att referera till litteratur och bygga upp vetenskapliga argument från en delmängd av litteratur.

## Kursinnehåll

Kursens teoretiska fördjupning tillämpningen av Lean i industrialiserat och traditionellt byggande, metoder för standardisering av arbetsberedningar och moment, metoder för faktabaserad mätningar för uppföljning av processer, planeringsmetoder och affärsmodeller inom industrialiserat byggande samt byggprocessens möjligheter och hinder för verksamhetsutveckling. Ämnen som tas upp är:

- Det industrialiserade byggandets historia, definitioner och VALLA Coach koncept.

- Lean och Lean Construction; likheter, skillnader och praktisk tillämpning

- Standardiserat arbetssätt, Last Planner, basera beslut på fakta och ständiga förbättringar

Kursens fördjupar även coachande och lärande, förändringsledning. Ämnen som tas upp är:

- Att skapa, leda och samverka i effektiva team. Coachande ledarskap, att coacha medarbetare, att coacha team.

- Konsten att samtala, vad är feedback? att ge och ta emot konstruktiv feedback.

- Lärande organisationer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen genomförs genom fem gemensamma träffar på internat där kvällsarbete ingår. Studenterna praktiserar metoderna mellan gångerna genom definierade uppgifter. Den individuella kunskapsuppbyggnaden stöds av föreläsningar.

Uppgifter genomförs företagsvis. Antalet deltagare från företagen variera men bör vara minst två. Uppgifterna startar efter första träffen och drivs av studenterna själva. Under vägen får studenterna handledning och debriefing av lärare och Valla Coacher. Resultat presenteras för gruppen löpande både muntligt och skriftligt.

Vidare ingår fem stycken individuella reflektionsuppgifter kopplat till coachning. Varje gång skall studenten lämna in en skriftlig reflektion baserat på en logg och ett protokoll. Reflektionen skall stöttas av litteratur.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras med en Projektuppgift och en Individuell uppgift

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektuppgift | U G# | 4,5 | Obligatorisk | H19 |  |
| 0002 | Individuell uppgift | U G# | 3 | Obligatorisk | H19 |  |

## Litteratur

*Litteratur. Gäller från Höst 2019 Lp 1*
- Lidelöw, H., Stehn, L., Lessing, J., & Engström, D. (2015). Industriellt husbyggande (2015)
- Effektivt byggande – Utmana dina processer (2017)
- Detta är Lean, specialutgåva, (2015).
- Jeffrey Liker, The Toyota Way (2009)
- Vetenskapliga artiklar kopplade till Industriellt Byggande och Lean Construction
- Whitmore, J. Coaching för bättre resultat: principer och strategier för coachande ledarskap (2018)
- Örtenblad, L. Lärande organisationer – vad och för vem! (2009)
- Artiklar kopplade till coachning

## Kursplanen fastställd

av Eva Gunneriusson 2019-06-19
