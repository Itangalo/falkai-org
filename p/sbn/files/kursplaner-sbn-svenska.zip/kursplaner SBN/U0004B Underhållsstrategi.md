---
kurskod: "U0004B"
titel: "Underhållsstrategi"
hp: "7,5"
titel_en: "Maintenance Strategy"
giltig: "Höst 2019 Lp 1 - Tills vidare"
beslutsdatum: "2019-09-04"
utbildningsniva: "Grundnivå"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=U0004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=U0004B&lasPeriod=208&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/u00/u0004b-underhallsstrategi"
---

# Underhållsstrategi (U0004B)

## Behörighet

Grundläggande behörighet

## Examinator

Mattias Holmgren

## Mål/Förväntat studieresultat

Kursen syftar till att ge de studerande en grundläggande förståelse i hur underhållsstrategier kan tillämpas för att nå produktionsmålen. Efter avslutad kurs ska studenten kunna utveckla underhållsstrategier för industriella system.

## Kursinnehåll

Kursen omfattar:

- Systemkartläggning av industriella system

- Underhållsmål och underhållsstrategi

- Avhjälpande underhåll och förebyggande underhåll

- Funktionssäkerhetsinriktat underhåll / Reliability-centred maintenance (RCM)

- Operatörsunderhåll (TPM)

- Underhållsavdelningens organisation

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen genomförs genom föreläsning och förinspelade teoretiska moment som varvas med diskussion och räknepass. Ett aktivt deltagande på lektionen förväntas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För godkänt betyg krävs godkända inlämningsuppgifter. Betygskriterier för 3 4 5 enligt studiehandledning.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 7,5 | Obligatorisk | H19 |  |

## Litteratur

*Litteratur. Gäller från Höst 2019 Lp 1* Meddelas vid kursstart.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-09-04
