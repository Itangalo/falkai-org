---
kurskod: "K0017B"
titel: "Tillämpad riskhantering"
hp: "7,5"
titel_en: "Applied Risk Management"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-01-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "UG"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0017B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0017b-tillampad-riskhantering"
---

# Tillämpad riskhantering (K0017B)

## Behörighet

Grundläggande behörighet samt 45 hp kurser inom teknik/naturvetenskap varav kursen K0007B Risk och säkerhet - Grundkurs ska ingå

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kunskap och förståelse Efter godkänd kurs ska studenten kunna:
- planera och göra en utredning med tillhörande projektering som visar hur det framtida brandskyddet behöver utformas för att möjliggöra en verksamhetsförändring av lokalerna.
- beskriva och förklara hur lagstiftning inom bland annat organisatoriskt och byggnadstekniskt brandskydd samt riskhantering se ut.
- Redogöra för forskningsarbete inom det studerade området

Färdighet och förmåga För godkänd kurs skall studenten kunna:
- ge exempel på hur metoder för riskhantering kan användas
- ge exempel på ingenjörens roll för att bidra till att skapa ett säkrare samhälle i sin professionsutövning.
- presentera uppgifter skriftligt, muntligt och opponera.
- visa förmåga till lagarbete och samverkan i grupp

Värderingsförmåga och förhållningssätt För godkänd kurs skall studenten kunna
- visa förmåga att förebygga olyckor och skador samt kunna utforma och planera för riskreducerande åtgärder
- visa förmåga att analysera och utvärdera komplexa frågeställningar avseende brandskydd.

## Kursinnehåll

Kursens innehåll kan sammanfattas med nedanstående punkter:

- Lagar och regler

- Brandskydd i byggprocessen. Grundprinciper i projektering av byggnadstekniskt brandskydd enligt BBR (byggnads- och verksamhetsklass, utrymning, aktiva brandskydd system). Systematiskt brandskyddsarbete (SBA)

- Riskhantering och olycksförebyggande arbete.

- Akademiskt skrivande

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, seminarier, studiebesök, grupparbeten, projekt och individuella uppgifter (quizzar, skriftliga reflektioner).

I kursen kommer bland annat olika gästföreläsare att berätta hur de praktiskt arbetar med tillämpningar inom bland annat kommunal räddningstjänst, region/landsting och brandkonsultföretag. Det är viktigt att närvara på gästföreläsningarna för att kunna genomföra examinationsuppgifterna i kursen.

Inför varje fysiskt kurstillfälle krävs att studenterna har bearbetat material i Canvasrummet för att öka sin kunskap och förståelse.

Studenterna ska skriva flera rapporter och inlämningsuppgifter individuellt och i grupp inom studerade område:

- fördjupningsarbete om olyckor och hur det olycksförebyggande arbetet bedrivs inom

- brandskyddanalys av byggnader

Studenter tränas att planera, utvärdera och utföra brandskydd i en byggnad samt skriftligt redovisa arbetsgång, resultat och analys i form av projektrapport. Studenterna ska även opponera på en annan grupps arbete. Den delen bygger på tidigare kunskap om rapportskrivning, opponering och referenshantering (K0007B).

I en inlämningsuppgift ska studenterna studera, analysera och reflektera på vetenskaplig artikel inom området Riskhantering.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För att bli godkänd på kursen krävs närvaro och aktivt deltagande vid muntliga redovisningar, seminarier och studiebesök samt godkänt på skriftliga rapporter och inlämningsuppgifter. För att erhålla godkänt slutbetyg krävs även minst 80 procent närvaro på alla föreläsningar.

Kursen består av flera moment:

- Grupparbete (projekt utfört i grupp) – skriftlig redovisning och opponering samt muntlig presentation med betygsskala G U.

- För att bli godkänd på muntlig presentation krävs obligatorisk närvaro och aktivt deltagande. Betygsskala G U.

- Rapport (i grupp) – skriftlig redovisning och muntlig presentation med betygsskala G U.

- Individuell inlämningsuppgift. Betygsskala G U

- föreläsningar, seminarier och studiebesök examineras individuellt. Betygsskala G U. För att erhålla godkänt slutbetyg krävs även minst 80 procent närvara på alla föreläsningar och närvaro på studiebesök

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta

innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0017B motsvarar kurser K0014B, K0009B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0009 | Inlämningsuppgift | UG | 1,5 | Obligatorisk | V27 |  |
| 0010 | Muntlig presentation | UG | 1 | Obligatorisk | V27 |  |
| 0011 | Rapport | UG | 1,5 | Obligatorisk | V27 |  |
| 0012 | Föreläsningar, seminarier och studiebesök | UG | 1,5 | Obligatorisk | V27 |  |
| 0013 | Grupparbete (proj utfört i grupp) | UG | 2 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-01-11

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-02-14
