---
kurskod: "T7023B"
titel: "Tunnelprojektering"
hp: "7,5"
titel_en: "Tunneling"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7023B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7023B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7023b-tunnelprojektering"
---

# Tunnelprojektering (T7023B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Grundläggande kunskaper om bergbyggandets enhetsoperationer, bergsprängning och gruvbrytning motsvarande T0013B, geoteknik motsvarande G0003B samt bergmekanik motsvarande T0014B.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Tunnelbyggande i hårt berg innefattar miljömedvetenhet med hänsyn till design av tunnlar innehållande bergmekanik, drivningsmetoder med focus på borra-spräng, förstärkning, hydrogeologi och injektering. Målet med kursen är ge studenten verktyg i hur en tunnelprojektering går till.

Kunskap och förståelse

För att få godkänt på kursen skall den framgångsrika studenten kunna:

1. Applicera svenska projekteringsregler och normer för ett tunnelprojekt i berg.

2. Beskriva olika skeden i projekteringen av en bergkonstruktion.

3. Föreslå lämpliga åtgärder relaterade till teknik, ekonomi och organisation för en effektivisering av tunnelbyggande.

Kompetens och färdigheter

För att få godkänt på kursen skall den framgångsrika studenten kunna:

1. Utan fullständig information på ett ingenjörsmässigt och vetenskapligt sätt analysera och besvara formulerad problemställning.

2. Beskriva vilket underlag som behövs för en ingenjörsgeologisk prognos

3. -Utföra beräkning, redogöra och argumentera för lämpligt innehåll i en inledande och fortsatt detaljerad förundersökning.

4. -Beskriva olika tunneldrivningsmetoder samt motivera och redogöra för val av dessa.

5. -Analysera, jämföra och motivera när ett tunnelalternativ är mer fördelaktigt att använda än andra föreslagna alternativ baserat på berganläggningstekniska förutsättningar.

6. -Presentera pågående forskning- och undermarksprojekt i Sverige och utomlands och förklara aktuella principer och arbetssätt som används inom tunnelprojektering.

Värderingsförmåga och förhållningssätt

För att få godkänt på kursen skall den framgångsrika studenten kunna:

1. Genomföra litteraturstudie och kritiskt värdera information och sammanfatta denna på ett vetenskapligt sätt.

2. Beskriva och relatera till samhälleliga aspekter som påverkar projektering av tunnel.

## Kursinnehåll

Kursen innehåller följande delar:

- Generell introduktion till tunnelbyggande

- Myndighetskrav och lagar rörande tunnelbyggande under mark

- Designen av förstärkning och bergmekaniken för en grunt förlagd tunnel

- Hydrogeologi för berg

- Design av injektering

- Design av sprängning med hänsyn till omgivningspåverkan (vibrationer).

- Genomföra en fältövning med vattenförlustmätning

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen innehåller föreläsningar, självstudier, mindre projektuppgifter och en projektrapport. Projektrapporten skall muntligen presenteras. Projektrapporten fokuserar på någon drivningscykelns steg och väljs av projektgruppen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen bedöms utifrån följande delar:

- Godkänd projektrapport innehållande de mindre projektuppgifterna och en slutlig projektrapport med muntlig presentation (4HP).

- Deltagit vid fältövningen (1HP).

- In skriftlig tentamen i form av en quiz (2.5HP).

Enligt kursmålen inom Kunskap och förståelse, punkt 1, 2 och 3 är direkt kopplade till målen för Kompetens och förmågor och bedöms genom de mindre projektuppgifterna med betygsskalan G/U 3 4 5, där betyg 3 är godkänt. Samma punkter bedöms på individuell nivå genom den skriftliga tentamen med samma betygsskala.

Kursmålen 1. inom Värderingsförmåga och förhållningssätt bedöms i litteraturstudien och hur detta är omhändertaget i projektrapporten.

Kursmålen 2. inom Värderingsförmåga och förhållningssätt bedöms i projektarbete

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen T7023B motsvarar kursen T7021B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Projektarbete | GU345 | 4 | Obligatorisk | V18 |  |
| 0004 | Quiz/Tentamen | GU345 | 2,5 | Obligatorisk | V18 |  |
| 0005 | Obligatorisk fältstudie | UG | 1 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2017-06-16
