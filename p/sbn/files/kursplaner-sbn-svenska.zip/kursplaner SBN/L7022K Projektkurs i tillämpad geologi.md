---
kurskod: "L7022K"
titel: "Projektkurs i tillämpad geologi"
hp: "7,5"
titel_en: "Senior Design Project in Applied Geology"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7022K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7022K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l70/l7022k-projektkurs-i-tillampad-geologi"
---

# Projektkurs i tillämpad geologi (L7022K)

## Ingår i huvudområde

Geovetenskap

## Behörighet

90hp inom naturresursteknik eller motsvarande varav 30hp miljögeokemi eller motsvarande. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Studenten ska självständigt utforma, genomföra och rapportera ett projekt inom ämnet geokemi.

Detta innebär att studenten efter avslutad kurs skall:

1. kunna formulera ett relevant syfte utifrån en given problemställning inom geokemi

2. planera, strukturera och genomföra ett projekt inom givna tidsramar.

3. bedöma den vetenskapliga och praktiska relevansen av de erhållna resultaten.

4. uttrycka sig väl skriftligt och muntligt

5. genomföra en muntlig presentation av projektets resultat, argumentera och försvara de uppnådda slutsatserna för relevanta intressenter.

## Kursinnehåll

Kursen omfattar följande områden:

Inledning - Genomgång av kursens mål, beskrivning av tillgängliga projekt och intressenter.

Projektplanering – Planering av projekt, definierar mål, formulera aktiviteter och tidsplan

Genomgång av muntlig och skriftliga presentationers krav

Projektgenomförande, vilket kan inkludera laborativt arbete, fältarbete eller arbete med befintligt data.

Skriftlig presentation av arbete

Muntlig presentation av arbete för relevanta intressenter.

Innehåll utformas i dialog med examinator och utsedd handledare och eventuella intressenter. Projekten är inom ämnet geokemi

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten arbetar självständigt under handledning. Planering av laboratoriearbete och fältarbete genomförs i samarbete med handledare och eventuella intressenter involverade i projektet. Analytiska undersökningar och fältarbete genomförs tillsammans med intressenter och/eller handledare. Regelbundna möten med handledare sker under hela projektperioden. Muntlig och skriftig presentation för relevanta intressenter och forskningsgruppen inom Tillämpad geokemi.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Samtliga mål examineras och bedöms i den skriftlig redovisning samt i den muntlig presentation.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Godkänd muntlig och skriftlig redovisning | GU345 | 7,5 | Obligatorisk | H07 | Ja |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-

02-11

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
