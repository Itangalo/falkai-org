---
kurskod: "S0006B"
titel: "Brandtekniska beräkningar"
hp: "7,5"
titel_en: "Analysis and design of fire loading in buildings"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S0006B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S0006B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s00/s0006b-brandtekniska-berakningar"
---

# Brandtekniska beräkningar (S0006B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kunskap och förståelse Efter godkänd kurs ska studenten kunna:

- beskriva och förklara bränders termiska påverkan på olika material och konstruktioner

- särskilja och tillämpa de tre olika typerna av värmeöverföring

- särskilja, förklara och tillämpa de tre olika typerna av termiska randvillkor

- särskilja och välja metod bland de vanligaste och enklaste metoderna för mätning av temperaturer vid brand.

Färdighet och förmåga

För godkänd kurs skall studenten kunna:

- beräkna värmeöverföring till ytor som utsätts för heta gaser och strålning genom brand

- beräkna med enkla metoder de temperaturer som uppstår i konstruktioner och strukturer som utsätts för brand

- uppskatta tiden det tar för olika material att antändas

- visa förmåga till lagarbete och samverkan i olika grupper för att utföra enkla brandtekniska. beräkningar genom att definiera frågeställningar, planera och välja metod, utföra beräkningar och svara på dessa frågor skriftligt och muntligt på svenska och engelska.

Värderingsförmåga och förhållningssätt

För godkänd kurs skall studenten:

- visa förmåga att göra bedömningar av lämplighet för olika typer av brandtekniska problem med hänsyn till relevanta begränsningar ock fysikaliska fenomen.

## Kursinnehåll

Kursen innehåller grundläggande kunskaper inom värmelära och spridning av värme genom ledning, konvektion och strålning.

Kursen innehåller flera moment där matematiska kunskaper och förmågor utvecklas och tillämpas:

- De fysikaliska fenomenen värmeövergång genom naturlig och påtvingad konvektion studeras och tillämpas i olika brandtekniska sammanhang.

- Värmeöverföring genom strålning är ett fenomen som har stor betydelse i brandtekniska sammanhang. Approximativa metoder studeras för att beräkna strålningsintensitet från flammor. Begreppen resulterande emissivitet och vinkelkoefficient introduceras för att beräkna strålningsintensitet mellan ytor.

- Förhållandet mellan konvektion och strålning diskuteras ingående. Begreppet adiabatisk yttemperatur, som bygger på nya forskningsrön, introduceras, förklaras och tillämpas i beräkningar.

- Mätning av temperaturer vid brand

- Antändighet

- Enkla numeriska beräkningar

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av lektioner, inlämningsuppgifter (laboration, quizzar samt skriftlig och muntlig redovisning av inlämningsrapport). Undervisning i klassrum och tentamen sker på svenska. Vid lektionerna genomgås de olika momenten ovan muntligt och kompletteras med adekvata räkneövningar.

I en laboration får studenterna en fördjupad insikt om värmelära och spridning av värme genom ledning, konvektion och strålning och deras relativa betydelse.

I kursen tränas följande färdigheter:

- Kunna utföra enkla brandtekniska beräkningar enskilt (quizzar) och i grupp (inlämningsuppgift, labbrapport)

- Förmåga till lagarbete och samverkan i grupper där studenter bestämmer grupperna.

- I samband med laborationen tränas studenterna i att planera, utföra och utvärdera försök samt skriftligt redovisa på engelska i form av labbrapport. Muntlig och skriftlig presentation samt opponering. Den delen byggs på tidigare kunskap om rapportskrivning, referenshantering (byggs på kunskap och färdighet att utrycka sig i skrift och tal bland annat i kurs K0007B).

- Identifiera och använda lämplig litteratur som extra stöd inom området brandtekniska beräkningar.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen består av två delar:

- Skriftlig tentamen med betygsskala G U 3 4 5.

- Inlämningsdelen som består av flera quizzar, labbrapport och inlämningsuppgift. Inlämningsuppgift ska presenteras skriftligt och muntligt. För att bli godkänd på inlämningsdelen krävs obligatorisk närvaro och aktivt deltagande på laborationen och vid muntlig redovisning av grupp inlämningsuppgiften. Betygssättning sker enligt betygsskala G U.

Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 4,5 | Obligatorisk | V12 |  |
| 0004 | Inlämningsuppgifter | UG | 3 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

av Institutionen för samhällsbyggnad och naturresurser 2011-02-08
