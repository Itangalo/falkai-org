---
kurskod: "A0013B"
titel: "Avfallsteknik"
hp: "7,5"
titel_en: "Waste Science and Technology"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-11-07"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Miljöteknik"
amnesgrupp_scb: "Miljövård och miljöskydd"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=A0013B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=A0013B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/a00/a0013b-avfallsteknik"
---

# Avfallsteknik (A0013B)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet + Fysik 1b1 eller 1a, Matematik 2a eller 2b eller 2c. Eller: Fysik nivå 1a1 eller nivå 1b, Matematik nivå 2a eller nivå 2b eller nivå 2c.

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Mål efter avslutad kurs är att:

- Förstå grundläggande fysiska, kemiska och biologiska förutsättningar för materialomvandlingar

- Kunna beskriva och reflektera över avfallshanteringssystemens uppbyggnad och funktion i samhället

- Kunna beskriva vanliga egenskaper hos olika kommunala och industriella avfall

- Kunna beskriva och diskutera metoder för mekanisk, biologisk och termisk avfalls¬behandling

- Kunna förklara och motivera ett avfallsupplags konstruktion och funktion

- Kunna ange och förklara tekniska strategier och lösningar som kan användas i arbetet för en hållbar avfallshantering

- Beskriva olika metoder för avfallskaraktärisering

## Kursinnehåll

Kursen behandlar följande ämnen:

- Avfallsströmmar i samhället och hållbar avfallshantering. Här beskrivs statistik om avfallsgenerering, avfallshantering och ett historiskt perspektiv på avfall i Sverige. Informationen kontextualiseras med internationell statistik. Flödesscheman som ett verktyg för att beskriva avfallsflöden i vårt samhälle diskuteras. Avfallshanteringens funktion och användning, avfallshanteringens miljömässiga hållbarhet, avfallet och cirkulär ekonomi, vem som ansvarar för avfallshantering i vårt samhälle liksom rättsliga ramar, avfallshierarki och miljöpåverkan av avfallshantering ur ett systemperspektiv, behandlas översiktligt.

- Mekanisk, biologisk och termisk avfallshantering samt slutförvaring på deponier är de fyra grundläggande avfallsbehandlingarna som kursen omfattar. För varje behandling behandlas på introduktionsnivå:

- mål och funktion för varje behandling.

- egenskaper hos avfall som är lämplig för varje behandling samt karakterisering av avfall.

- strategier för att bestämma när behandlingen är lämplig

- grundläggande fysikaliska, kemiska och biologiska principer bakom tekniken som behandlingen bygger på.

- tillgänglig teknik

- Miljöpåverkan.

- Hushållsavfall. Olika insamlingssystem och hur dessa system används i Sverige; återvinning av papper, plast, metaller och glas i Sverige och energiåtervinning från brännbara avfallsfraktioner behandlas översiktligt.

- Kommunalt och industriellt avfall. Här presenteras exempel på viktiga avfallsströmmar för att få specifik kunskap om dessa avfall och länka dem till de ämnen som presenterades tidigare i kursen. Avfall som kan presenteras i detta avsnitt är, till exempel, gruvavfall, byggavfall, industriavfall i allmänhet och farligt avfall.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Ämnet presenteras i form av föreläsningar. Fördjupning i ämnet sker genom ett projektarbete i små grupper som innehåller en litteraturstudie, skriftligt och muntligt redovisning samt gruppdiskussioner. Praktiska färdigheter tränas genom laborativa uppgifter samt ett studiebesök. Dokumenthantering och kommunikation sker via lärplattformen CANVAS.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Skriftlig tentamen, som utvärderar alla kursmål, med differentierade betyg. Betygsskala: 5 4 3 U.

För att blir godkänd på kursen krävs det att studenten genomför den laborativa uppgiften och lämnar in tillhörande rapport, deltar i studiebesöket och lämnar in skriftlig reflektionen kring besöket samt genomför projektarbetet med godkänt rapport och aktivt deltagande i gruppdiskussioner.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 3 | Obligatorisk | V12 |  |
| 0004 | Seminarieuppgift | UG | 2,3 | Obligatorisk | V27 |  |
| 0005 | Laboration och studiebesök | UG | 2,2 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-11-07

## Kursplanen fastställd

av Institutionen för samhällsbyggnad och naturresurser 2011-02-07
