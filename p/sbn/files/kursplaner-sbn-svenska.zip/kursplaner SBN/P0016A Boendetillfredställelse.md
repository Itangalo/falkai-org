---
kurskod: "P0016A"
titel: "Boendetillfredställelse"
hp: "7,5"
titel_en: "Residential satisfaction"
giltig: "Höst 2009 Lp 1 - Tills vidare"
beslutsdatum: "2007-02-28"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser  Prov Provnr       Typ                                                             Hp           Betyg  0001         Individuellt projektarbete                                      7,5          GU345"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0016A"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0016A&lasPeriod=162&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p00/p0016a-boendetillfredstallelse"
---

# Boendetillfredställelse (P0016A)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Examinator

Géza Fischl

## Mål/Förväntat studieresultat

Efter genomgången kurs skall studenten kunna
- Förklara psykologiska begrepp om miljöbeskrivningen
- Tillämpa relevanta begrepp med avseende på lokalutformning
- Utveckla en specifik typ av lokal med ArchiCAD och Art-lantis
- Presentera idéer muntlig och med hjälp av visualisering

## Kursinnehåll

Kursen innehåller en teoretisk och en praktisk tillämpningsdel. Kursen består i stora drag av följande moment:
- Beskrivning av psykologiska begrepp som kan påverka människors upplevelse i den byggda miljön
- Grundläggande rumsdesign
- Övning i att använda ArchiCAD och Art-lantis
- Fallstudie för att utformning av rumsmiljö

## Genomförande

Kursen grundar sig på följande arbetssätt: lektioner, övningar och slutseminarium. Individuellt projektarbete med tillgång till lärarhandledning.

## Examination

Skriftlig och muntlig presentation av individuellt projektarbete (lokalutformningsförslag). Obligatorisk närvaro kan gälla vid vissa lektioner. Obligatorisk närvaro vid handledning och slutseminarium av projektarbete.

## Överlappning

Kursen P0016A motsvarar kursen ARP122

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser

Prov Provnr       Typ                                                             Hp           Betyg

0001         Individuellt projektarbete                                      7,5          GU345

## Litteratur

*Litteratur. Gäller från Höst 2007 Lp 1* Evans, G. W. & McCoy, J. M. (1998). When buildings dont work: The role of architecture in human health. Journal of Environmental Psychology, 18, 85-94. Grossmann, P. R. & Wisenblit, Z. J. (1999) What we know about consumers color choice. Journal of Marketing Practice, 5, 78-88.

## Revidering fastställd

Kursplanen har fastställts av Institutionen för arbetsvetenskap 2007-02-28

## Kursplanen fastställd

Kursplanen har fastställts av Institutionen för arbetsvetenskap 2007-02-28
