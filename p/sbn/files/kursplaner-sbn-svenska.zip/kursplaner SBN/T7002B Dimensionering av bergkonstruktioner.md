---
kurskod: "T7002B"
titel: "Dimensionering av bergkonstruktioner"
hp: "7,5"
titel_en: "Design of Rock Constructions"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7002B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7002b-dimensionering-av-bergkonstruktioner"
---

# Dimensionering av bergkonstruktioner (T7002B)

## Ingår i huvudområde

Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

Grundläggande bergmekanik, tex. T0014B Introduktion till Bergmekanik eller T7001B Bergmekanikens grunder, alternativt Q0038B Bergmekanik tillsammans med Q0028B Bergmekanik 2, eller motsvarande.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

1. förklara linjäraelastiska och plastiska materialmodeller samt tillämpa dem i analytiska och numeriska (stabilitets)analyser av konstruktioner i berg

2. välja lämplig indata för analytiska och numeriska (stabilitets)analyser av konstruktioner i berg

3. kunna utföra linjärelastiska och plastiska numeriska analyser samt kunna utvärdera och förklara erhållna resultat

4. för olika geologiska förhållanden välja och beräkna lämplig förstärkning för konstruktioner i berg

5. beskriva dynamiska beteenden hos bergmassor samt beskriva mät- och observationsprogram för olika typer av bergkonstruktioner och situationer

6. presentera analyser och resultat skriftligt samt diskutera slutsatser och kunskap och argument som ligger till grund för det

## Kursinnehåll

Kursen omfattar följande områden:

- Introduktion - Kursutformning, repetition av relevant innehåll från tidigare kurser i bergmekanik

- Icke-linjärelastiskt beteende – Plastiseringsbrott i berg, hur man modellerar linjärelastiskt och ickematerialbeteendet i numeriska analyser

- Numerisk metoder - En kort introduktion till den teoretiska bakgrunden till olika numeriska metoder; de olika typerna av tillgängliga numeriska koder; en översikt över hur man gör numeriska analyser; lära sig att använda en numerisk applikation, hur man tillämpar den på bergmekaniska problem, hur man utvärderar och tolkar resultaten och hur man presenterar numeriska analyser och dess resultat skriftligen.

- Bergförstärkning - Förstärkningsprinciper och förutsättningar. Samverkan mellan bergförstärkning och berg. Olika typer av bergförstärkningselement och deras verkningssätt. Dynamisk förstärkning och bergförstärkning med hjälp av bergmasseklassificering.

- Mätning och övervakning - Instrumentering och övervakning av sluttningar och underjordiska konstruktioner, identifiering av de viktiga storheterna för olika konstruktioner och situationer. Instrumentens mätprinciper och deras för- och nackdelar.

- Dynamiska processer - Allmänna principer, stressvågor, vågreflexioner, brott genom dynamiska processer, dvs. sprängning, seismicitet vid gruvdrift, dvs. smällberg.

- Destressing - En metod för att minska spänningar i omkring en bergkonstruktion.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av:

- Lektioner - De är en mix av flera undervisnings-/inlärningsaktiviteter: (i) kort teorigenomgång där föreläsaren förklara de viktigaste teoretiska aspekterna relaterade till kursens innehåll och (ii) tillsammans lösa och/eller diskutera typiska bergmekaniska problem samt frågor vilket ger dig möjlighet att på olika sätt arbeta med flera aspekter kring empiriska, analytiska och numeiska stabilitetsanalyser av olika undermarkskonstruktioner i berg ur en praktisk och teoretisk synvinkel samt träna beräkningsprocedurer för frågeställningar relaterade till dessa.

- Datorövningar - Under dessa arbetar vi i datasal där vi praktisk övar på olika numeriska applikationer och hur de kan användas för att analysera materialbeteenden, spänningar, deformationer, stabilitet och förstärkning hos undermarkskonstruktioner i berg.

- Inlämningsuppgifter - Du arbetar tillsammans med andra studenter och använder dina kunskaper för att lösa olika problem. Du presenterar ditt arbete i skriftliga rapporter. Du tränas i att med utgångspunkt från de analytiska och numeriska analyser som utförs samt nyttogörande av föreläsningar, föreslå och motivera hur en bergkonstruktion ska göras stabil samt förklarar ditt arbete skriftligt.

- Mellan lektionerna - Du förväntas förbereda dig inför varje lektion genom att arbeta igenom rekommenderat materialet, rekommenderade övningar och instuderingsfrågor så att du är beredd att bidra och delta i läraktiviteterna (problemlösning, diskussion, mm) under föreläsningarna och datorövningarna.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:

- Skriftliga delprov - Består av frågor som testar din teoretiska kunskap och förståelse för vissa bergmekaniska aspekter relaterade till kursens innehåll.

- Inlämningsuppgifter - Består av problem där du tränar och tillämpar din teoretiska kunskap, förståelse och förmåga samt gör analyser och förklarar dina resultat skriftligt.

- Skriftlig tentamen - Du löser problem som liknar de som du stöter på under kursen (i föreläsningar och uppgifter) för att testa din individuella kunskap, förståelse, skicklighet och förmågor. Kurskompendiet är tillåtet hjälpmedel på tentamen.

Mål 2-6 examineras via skriftlig tentamen. Betygsskala: G U 3 4 5.

Mål 1-5 examineras via skriftliga delprov.

Mål 1-6 examineras via inlämningsuppgifter. Ingår i övrigt med betygsskalan G U.

För att blir godkänd på modulen Övrigt krävs att du är godkänd på inlämningsuppgifter samt godkänd på skriftliga delprov.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen T7002B motsvarar kursen ABM024

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 3 | Obligatorisk | H07 |  |
| 0003 | Övrigt | UG | 4,5 | Obligatorisk | V27 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
