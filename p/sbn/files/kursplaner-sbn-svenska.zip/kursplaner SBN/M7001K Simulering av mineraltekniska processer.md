---
kurskod: "M7001K"
titel: "Simulering av mineraltekniska processer"
hp: "7,5"
titel_en: "Simulation of Mineral Processing"
giltig: "Höst 2026 Lp 1 - Tills vidare"
beslutsdatum: "2026-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Mineralteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7001K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7001K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/m70/m7001k-simulering-av-mineraltekniska-processer"
---

# Simulering av mineraltekniska processer (M7001K)

## Ingår i huvudområde

Kemiteknik, Geovetenskap

## Behörighet

90 högskolepoäng inom kemiteknik, inklusive kursen Fysikaliska separationsmetoder (M0001K), eller motsvarande kunskaper. Goda kunskaper i engelska motsvarande Engelska 6/nivå 2..

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursen syftar till att ge studenten kunskap och färdighet att kunna genomföra enklare datorstödda simuleringar av processer för partikulära material.

Efter fullgjord kurs ska studenten kunna:

- identifiera situationer där simuleringsteknik kan bidra till förståelse av processen,

- ta fram nödvändiga indata för simulering av mineraltekniska processer,

- konstruera och avgränsa flödesscheman för simulering,

- redovisa resultat från simuleringar,

- bedöma om simuleringsresultaten är relevanta,

- tolka resultaten i processtekniska termer,

- formulera hypoteser om förändringar i processen baserat på resultaten från simuleringarna.

## Kursinnehåll

Kursen omfattar teoretiska modeller och praktiska tillämpningar av simulering av processer för partikulära material.

Torra processer:

- Modeller för sönderdelning och fragmentering (krossning) av hårda, kristallina material

- Modeller för siktning

- Simulering av krosskretsar

Våta nedbrytningsprocesser:

- Modeller för sönderdelning i kvarnar med tillverkade eller autogena malkroppar

- Modeller för klassering

- Simulering av malkretsar

Separationsprocesser baserade på skillnader i densitet:

- Modeller för suspensionsanrikning med tillverkade eller autogena medier

- Simulering av våtmekanisk krets

Separationsprocesser baserade på skillnader i ytegenskaper:

- Enkla och avancerade modeller för flotation

- Simulering av flotationskretsar

Separationsprocesser baserade på andra skillnader i fysikaliska egenskaper:

- Enkla modeller för magnetseparation

- Modeller för förtjockare och filter

- Simulering av jordtvättsanläggning

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, läsanvisningar, frågetester (quiz), övningar, inlämningsuppgifter och obligatoriska seminarier.

Föreläsningarna används för att introducera och förklara teoretiska begrepp. För varje kursmoment finns läsanvisningar som sammanfattar centralt material från kurslitteraturen, innehåller referenser till simuleringsprogrammet samt hjälper studenten att beskriva modellstrukturer och förklara teoretiska samband. Frågetester (quiz) används för att kontrollera faktakunskaper. Övningarna syftar till att träna användning av modeller och simuleringstekniker.

Inlämningsuppgifterna genomförs i grupper och omfattar att planera, utföra, utvärdera, tolka och presentera resultat från simuleringar. Varje grupp ska muntligt presentera sitt arbete vid ett gemensamt seminarium samt opponera på ett annat grupparbete genom en skriftlig och muntlig utvärdering.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras genom inlämningsuppgifter, frågetester (quiz) och seminarier, vilka samtliga är obligatoriska.

Varje delmoment bedöms med poäng utifrån uppnådd nivå. Inlämningsuppgifter och oppositioner ska lämnas in i tid, annars sker avdrag på den maximalt möjliga poängsumman. Den totala poängproduktionen ligger till grund för slutbetyget, som ges enligt betygsskalan 3, 4, 5.

- För betyg 3 ska studenten kunna ta fram indata, genomföra en simulering och redovisa resultaten.

- För betyg 4 ska studenten även kunna bedöma resultatens relevans, tolka dem i processtekniska termer och rapportera resultaten.

- För betyg 5 ska studenten, utöver ovanstående, kunna formulera och motivera förslag till förändringar i processer (modellparametrar) samt redovisa och presentera resultaten.

Närvaro vid första introduktionsföreläsningen och vid seminarierna är obligatorisk.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen M7001K motsvarar kursen KGM005

## Övrigt

Obligatorisk närvaro vid första sammankomsten.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Inlämningsuppgifter | GU345 | 3,5 | Obligatorisk | H26 |  |
| 0003 | Seminarier | GU345 | 3 | Obligatorisk | H26 |  |
| 0004 | Frågetester (quiz) | GU345 | 1 | Obligatorisk | H26 |  |

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28 att gälla från H07.
