---
kurskod: "G7011B"
titel: "Vägar och järnvägar, fortsättningskurs"
hp: "7,5"
titel_en: "Road and Railway Engineering, Advanced Course"
giltig: "Höst 2023 Lp 1 - Höst 2025 Lp 2"
beslutsdatum: "2021-04-20"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7011B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7011B&lasPeriod=218&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7011b-vagar-och-jarnvagar-fortsattningskurs"
---

# Vägar och järnvägar, fortsättningskurs (G7011B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Underhållsteknik

## Behörighet

G0003B Geoteknik samt G0002B Vägar och järnvägar eller motsvarande. Goda kunskaper i engelska, motsvarande Engelska B/6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens mål är att förbereda studenterna för att kunna arbeta inom väg- och järnvägssektorn som en geotekniker.

I denna kurs kommer studenterna jobba med
- Planeringsprocessen kring vägar och järnvägar
- Vägars transportsystem
- Järnvägars transportsystem

I kursen kommer extrema klimatförhållanden, underhåll och effekten av olika lastfall gås igenom i detalj samt relateras till dimensioneringskrav från Trafikverket.

## Kursinnehåll

Järnvägar:
- Bakgrunden till järnvägssystemet
- Järnvägsspårens beteende (stabiliserad och naturlig mark)
- Vanligt förekommande problem och förstärkningsåtgärder av järnvägsspår

Jords beteende:
- Grundläggande koncept om laboratorie- och fältundersökningar
- Jords beteende relaterat till vägar och järnvägar
- Cykliskt och dynamiskt beteende samt deras utmaningar

Tjäle:
- Tjälprocessen, effekt på infrastruktur samt åtgärder
- Tillämpning av FEM-program (GeoStudio) för bedömning av tjäldjup under vägar. Introduktion till datorprogrammet med fokus på pågående forskningsprojektet “ Impact of culverts on frost penetration in road and railway embankments”

Vägar:
- Dimensionering av beläggning
- Dimensionering av överbyggnad inklusive en flexible beläggning (användning av ett dimensioneringsprogram)
- Översikt över in-situ metoder för utvärdering av vägars tillstånd
- Underhåll av infrastruktur: planering, tekniker, rutin, vinter
- Vanliga skador på vägar och järnvägar. Beskrivningar samt bakomliggande mekanismer
- Vad gäller underhåll av infrastruktur ligger fokus i kursen på dimensioneringsprocesser samt förebyggande åtgärder för att förlänga strukturens livslängd

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen sker genom lektioner, där moment ingår med problemlösning och informella diskussioner. Användande av datorprogram relevanta för kursens inlämningsuppgifter (GeoStudio, Design of roads). Seminarieuppgiften tar upp ett större perspektiv kring geoteknik i ett verkligt projekt.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Studenternas förmåga att förstå teori samt att tillämpa denna kommer bedömas under kursens gång. Studenternas kunskaper bedöms i en seminarieuppgift med betygsskala G/U 3 4 5. Inlämningsuppgifterna behöver vara godkända innan slutbetyg på kursen kan erhållas. Inlämningsuppgifternas betygsskala är G/U 3 4 5 och betyg på dessa kommer utgöra en del av kursens slutbetyg.

Det är obligatoriskt att närvara vid laboratoriearbete samt lektioner om GeoStudio och andra program.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts

som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgift, teori | U G# | 1,5 | Obligatorisk | H14 |  |
| 0002 | Inlämningsuppgifter, tillämpningar | GU345 | 6 | Obligatorisk | H14 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-04-20

## Kursplanen fastställd

av Eva Gunneriusson 2014-02-04
