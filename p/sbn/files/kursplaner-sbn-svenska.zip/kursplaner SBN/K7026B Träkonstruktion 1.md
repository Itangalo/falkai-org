---
kurskod: "K7026B"
titel: "Träkonstruktion 1"
hp: "7,5"
titel_en: "Design of Timber Structures 1"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "U G VG"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7026B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7026B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7026b-trakonstruktion-1"
---

# Träkonstruktion 1 (K7026B)

## Ingår i huvudområde

Samhällsbyggnadsteknik

## Behörighet

Minst 90 hp inom området Samhällsbyggnadsteknik eller motsvarande samt grundläggande kunskaper i konstruktionsteknik, mekanik eller hållfasthetslära med ett innehåll liknande någon av följande tre kurser; B0002B konstruktionsteknik, K0013B Byggkonstruktion eller M0032T Mekanik och hållfasthetslära eller motsvarande. Dessutom krävs Engelska 6/nivå 2 och Svenska 3/nivå 3.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

-redogöra för hur trämaterialets egenskaper särskiljer sig jämfört med andra byggmaterial i konstruktionshänseende

-beskriva olika brottmoder i träförband och deras orsaker

-förklara i vilka scenarier belastningar tvärs mot fiberriktningen kan uppträda i träkonstruktioner

-förklara resonemanget bakom formler i Eurocode

Färdighet och förmåga

-dimensionera träkonstruktioner utifrån Eurocode

-dimensionera förbandslösningar i träkonstruktioner

-beräkna spänningar och deformationer i konstruktionselement av trä

Värderingsförmåga och förhållningssätt

-bedöma beräkningsmetoders styrka, svagheter och tillämpbarhet

-bedöma tillförlitligheten i beräknade resultat

## Kursinnehåll

I kursen behandlas följande:

-dimensionering av träkonstruktioner och konstruktionselement enligt Eurocode

-dimensionering av förband i träkonstruktioner enligt Eurocode och riktlinjer för limmade träprodukter

-beräkning av spänningar och deformationer i limträbalkar och korslimmat trä

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen ges på distans och baseras på självstudier av litteratur och annat utdelat material enligt en studiehandledning, kompletterade med inspelade föreläsningar och föreläsningar i realtid med handledare. Färdighet och förmåga tränas genom övningsexempel. Studentens lärande följs kontinuerligt upp i handledarmöten där studenten förväntas ha förberett material enligt direktiv givna i studiehandledningen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examination sker kontinuerligt genom de obligatoriska inlämningsuppgifter. Kursen avslutas med en individuell muntlig tentamen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K7026B motsvarar kursen W7017T

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G VG | 5 | Obligatorisk | H26 |  |
| 0002 | Muntlig examination | U G# | 2,5 | Inaktiv | H26 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13
