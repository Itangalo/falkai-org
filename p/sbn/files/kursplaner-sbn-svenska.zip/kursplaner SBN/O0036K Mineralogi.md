---
kurskod: "O0036K"
titel: "Mineralogi"
hp: "7,5"
titel_en: "Mineralogy"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0036K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0036K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o00/o0036k-mineralogi"
---

# Mineralogi (O0036K)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet samt O0035K Geologi, grundkurs eller motsvarande

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter kursen skall studenterna kunna tillämpa teoretisk mineralogisk kunskap och optiska metoder för att identifiera geologiskt, ekonomiskt och tekniskt viktiga mineral, och kunna redogöra för mineralens kemiska och fysiska egenskaper och deras vanligaste förekomstsätt.

De studerande skall efter avslutad kurs kunna utföra mikroskopisk bestämning av de mineral och redogöra för principen för röntgendiffraktometriska mätningar och deras tillämpning inom mineralogi.

Efter kursen skall studenterna vara förtrogna med det fasta tillståndets kemi till den grad att de kan förklara och använda avancerade begrepp inom kristallografin. Studenten skall även kunna förklara och använda begrepp som enhetscell, kristallsystem, Bravais gitter, Miller index, och kunna använda dessa för att beskriva atomernas inbördes ordning i olika kristallstrukturer. Studenten skall även kunna redogöra för begrepp som fasta lösningar, substitution och blandserier av mineral.

## Kursinnehåll

Under kursen arbetar studenter med teoretiska aspekter av kristallografi, mineralogi och röntgendiffraktion, i kombination med praktiska moment där denna kunskap används för att karaktärisera kristallstrukturer. Studenterna ges en ingående genomgång i den optiska teori som ligger till grund för petrografisk mikroskopering och mineralidentifiering med polarisationsmikroskop i genomfallande och påfallande ljus. En genomgång av ett urval geologiskt, tekniskt och ekonomiskt viktiga mineral (malmmineral, industrimineral) och mineralgrupper (silikater, salter, oxider, sulfider, sulfater, karbonater) kombineras med praktiska övningar, där studenterna tillämpar sina kunskaper för identifiering av mineral.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Ämnet presenteras i form av klassföreläsningar av flera föreläsare och obligatoriska övningar i röntgendiffraktion, kristallografi, mikroskopering och mineralidentifiering. Övningarna är dels lärarhandledda, dels enskilda. Övningarna kommer delvis att vara kopplade till föreläsningar och utföras parallellt.

Dokumenthantering sker i lärplattformen CANVAS.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Skriftliga duggor utförs efter varje kursmodul med differentierade betyg (betygsskala: 5 4 3 U). För att blir godkänt på kursen krävs att studenten genomför och skriftligt redovisar alla praktiska uppgifter och får godkänt på dem.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0009 | Dugga i mineralkunskap | GU345 | 2 | Obligatorisk | H08 |  |
| 0011 | Dugga i opakmikroskopi | GU345 | 1,5 | Obligatorisk | H08 |  |
| 0013 | Dugga i transmissionsmikroskopi | GU345 | 1,5 | Obligatorisk | H08 |  |
| 0014 | Dugga i kristallografi och röntgendiffraktion | GU345 | 1,5 | Obligatorisk | H08 |  |
| 0015 | Övningar | U G# | 1 | Obligatorisk | H08 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Institutionen för Tillämpad kemi och geovetenskap 2008-01-22
