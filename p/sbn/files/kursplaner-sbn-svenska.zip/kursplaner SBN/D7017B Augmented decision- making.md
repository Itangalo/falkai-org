---
kurskod: "D7017B"
titel: "Augmented decision- making"
hp: "7,5"
titel_en: "Augmented Decision Making"
giltig: "Vår 2025 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7017B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7017b-augmented-decision-making"
---

# Augmented decision- making (D7017B)

## Behörighet

Minst 90 hp avklarade kurser inklusive grundläggande kunskaper i matematik, programmering och artificiell intelligens, motsvarande kurserna S0001M Matematisk statistik, D0009E Introduktion till programmering, och D0032E Introduktion till AI. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kunskap och förståelse:

1. Kunskaper om grundläggande begrepp inom systemteknik och systemtänkande.

2. Förstå begreppen RAMS (Reliability, Availability, Maintainability and Safety), livscykelkostnadsanalys och PHM (Prognostic Health Management) i industriella sammanhang.

Färdighet och Förmåga:

3. Utveckla koncept, teknologier och metoder i industriella sammanhang ur ett systemperspektiv med hjälp av industriell AI.

Värderingsförmåga och Förhållningssätt:

4. Bedömande förhållningssätt för att bedöma relevansen och tillämpbarheten av systemteknik och systemtänkande i olika industriella situationer.

## Kursinnehåll

Denna kurs omfattar:

- Koncept för systemteknik och systemtänkande
- Koncept för RAMS (Reliability, Availability, Maintainability and Safety), livscykelkostnadsanalys och PHM (Prognostic Health Management)
- Augmented Decision-making
- Fallstudier och praktiska tillämpningar inom industriella domäner

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

I undervisningen ingår föreläsningar, inlämningsuppgifter och laborationer. Föreläsningarna kan vara en kombination av online, självstudier och/eller klassrumsundervisning. Studenterna kommer att arbeta med en kombination av obligatoriska och valfria uppgifter som att utveckla mjukvarulösningar, rapportskrivning och labbsessioner.

En introduktionsföreläsning är schemalagd i början av kursen som inkluderar kursintroduktion med översikt över kursen, uppgifter och studiehandledning.

Kursen genomförs med hybridundervisning. Vissa moduler kommer att ha en föreläsningssession i klassrummet och vissa moduler kommer att ha material och undervisning online. I modulerna ingår ett tillfälle för att genomföra uppgifterna same ett uppföljningstillfälle.

Det finns 5 inlämningsuppgifter med 2 lektioner tilldelade för varje uppgift. För att lyckas med uppgiften är det väsentligt att studenterna gått igenom förberedelserna före lektionen. Givet att studenterna har förberett sig förväntas de kunna lösa uppgiften under den första lektionen med stöd av lärarna. Det finns också ett uppföljningstillfälle för varje uppgift om det inte finns tillräckligt med tid för att utföra alla demonstrationer under den ordinarie tillfället.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Denna kurs innehåller formativa bedömningar (för lärande) och summativa bedömningar (av lärande). Syftet med de summativa bedömningarna (i form av inlämningsuppgifter och rapporter) är att bedöma lärandemålen, medan syftet med de formativa bedömningarna (i klassdiskussioner, reflektioner, frågesporter, grupparbeten, återkoppling) är att stödja lärandet. Alla uppgifter kommer att behandlas under kursens gång med återkoppling från lärare och/eller studenter. Uppgifternas format kommer att vara rapportskrivning, praktiska uppgifter och seminarier. För att bli godkänd på kursen måste alla uppgifter vara klara.

För att bli godkänd på var och en av uppgifterna måste lösningen först demonstreras under den ordinarie lektioner eller det uppföljningstillfälle som tilldelats uppgiften. Efter att demonstrationen bedömts som tillfredsställande genomförd sker inlämning via Canvas för bedömning och betygssättning.

Inlämningsuppgifterna betygsätts enlig skalan (U,3,4,5). Alla inlämningsuppgifter värderas lika mycket. Det totala betyget på kursen är medelbetyget på alla uppgifter.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Obligatoriska uppgifter | GU345 | 7,5 | Obligatorisk | V25 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14
