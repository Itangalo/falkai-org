---
kurskod: "X0001K"
titel: "Examensarbete i Naturresursteknik, kandidat"
hp: "15"
titel_en: "Degree Project in Natural Resources Engineering, Bachelor"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2013-02-06"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2E"
betygsskala: "U G#"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=X0001K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=X0001K&lasPeriod=220&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/x00/x0001k-examensarbete-i-naturresursteknik-kandidat"
---

# Examensarbete i Naturresursteknik, kandidat (X0001K)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet samt Minst 150hp avklarade kurser av examensfordringarna. Examinator gör en bedömning om studenten har tillräckligt djup i sina förkunskaper för att kunna påbörja examensarbetet.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter fullgjord kurs ska studenten kunna:
- visa fördjupad förmåga att självständigt planera och genomföra ett mer omfattande projekt.
- tillämpa de kunskaper och färdigheter som förvärvats under studietiden.
- självständigt analysera och reflektera över problemställningar.
- presentera resultatet skriftligt i en teknisk-vetenskaplig rapport och muntligt vid ett seminarium på svenska eller engelska.

## Kursinnehåll

Examensarbetet bör genomföras inom ett ämne som har anknytning till specialiseringen under det avslutande studieåret. Den som gör examensarbetet i annat ämne anhåller om detta hos institutionen.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten skall i examensarbetet, enskilt eller tillsammans med en annan student, behandla en given uppgift. Examensarbetet skall ha karaktären av ett enklare forskningsarbete eller ett avancerat utredningsarbete. Studenten arbetar självständigt under handledning. Slutligen redovisas resultatet skriftligt och muntligt. Tidsbegränsning av examensarbete: Student som påbörjat sitt examensarbete och inte slutfört detta inom 15 månader kan inte kräva att få fullfölja detta arbete. Institutionen som svarar för examination och handledning har alltså inte skyldighet att fullfölja handledning av ett examensarbete som påbörjats längre tid tillbaka än 15 månader.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. För att examensarbetet ska godkännas erfordras att studenten utöver arbetet med det egna projektet;
- redovisar arbetet i en skriftlig rapport
- presenterar arbetet vid ett seminarium på institutionen -närvarar vid minst två andra studenters redovisningar

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen X0001K motsvarar kursen L0017K

## Övrigt

I det fall examensarbete utförs för extern uppdragsgivare gäller att examensarbetet, förutom i undantagsfall, skall vara godkänt av den externa uppdragsgivaren innan det kan bli slutgiltigt godkänt.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Påbörjat examensarbete | U G# | 0 | Obligatorisk | H13 |  |
| 0002 | Skriftlig rapport och muntlig redovisning | U G# | 15 | Obligatorisk | H13 | Ja |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Eva Gunneriusson 2013-02-06
