---
kurskod: "S7016B"
titel: "Projektkurs i brandteknik"
hp: "15"
titel_en: "Project Course in Fire Technology"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-19"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7016B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s70/s7016b-projektkurs-i-brandteknik"
---

# Projektkurs i brandteknik (S7016B)

## Behörighet

Minst 60 hp totalt inom områdena brandteknik, fysik och kemi. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2. För utbytesstudenter gäller att examinator gör individuell prövning av behörigheten beroende på typ av projekt.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Målet är att studenten självständigt skall utforma, genomföra och redovisa ett projekt inom Brandteknik.

Studenten skall efter avslutad kurs kunna:

- Formulera ett relevant problem för utredning inom ämnet Brandteknik.

- Tillämpa teoretiska kunskaper som förvärvats under studier inom ett forskningsprojekt på ett självständigt och systematiskt sätt.

- Välj och motivera valda forskningsmetoder för ett forskningsprojekt.

- Effektivt planera och genomföra ett projektarbete inom det valda forskningsämnet.

- Självständigt lösa problem som uppkommer i projektet.

- Identifiera och kritiskt granska vetenskaplig information som är relevant för projektet.

- Utvärdera projektresultat med hjälp av erhållen teoretiska kunskap.

- Skriva en vetenskaplig rapport, håll en muntlig presentation och argumentera för slutsatserna.

## Kursinnehåll

Projektets frågeställning kommer att vara relaterat till brandteknikens nuvarande forskningsfront och kommer att definieras i samarbete med examinator.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten kommer att arbeta självständigt under handledning av en lärare som tilldelas utifrån det valda forskningsämnet. Studenter kommer att ges tillgång till relevant laboratoriefaciliteter för brandteknik, inklusive analytisk utrustning. Innan vetenskaplig och analytisk utrustning används kommer lämpliga utbildnings- och säkerhetsinstruktioner att ges. Studenterna kommer att ha en regelbunden kommunikation med läraren för att säkerställa att de får lämpligt stöd och att projektets framskrider enligt plan.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Lärandemålen examineras genom en skriftlig rapport och en muntlig presentation. Betygssättning sker enligt betygsskala G U 3 4 5. Praktisk tillämpning av lärandemålen examineras via projektarbetet.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Godkänd muntlig och skriftlig redovisning | GU345 | 15 | Obligatorisk | V25 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-19

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-19
