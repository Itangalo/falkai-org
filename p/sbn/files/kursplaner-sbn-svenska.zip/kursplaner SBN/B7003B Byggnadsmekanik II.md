---
kurskod: "B7003B"
titel: "Byggnadsmekanik II"
hp: "7,5"
titel_en: "Structural Mechanics II"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Konstruktionsteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=B7003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=B7003B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/b70/b7003b-byggnadsmekanik-ii"
---

# Byggnadsmekanik II (B7003B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Grundkurser i hållfasthetslära och strukturmekanik tex kurserna B0002B Konstruktionsteknik och B7004B Byggnadsmekanik I.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens mål är att studenten ska kunna

- beräkna kritisk last (instabilitet) enligt första och andra ordningens teori för 1-dimensionella element och 2- dimensionella fackverk och ramar

- beräkna deformationer och påkänningar i skivor, plattor och skal

- beräkna snittkrafter och påkänningar av vridning av icke-cirkulära tvärsnitt

- planera och utföra beräkningsuppgifter, bearbeta resultat och presentera dem skriftligt (beräkningsrapport)

## Kursinnehåll

Kritisk last (instabilitet) för 1-dimensionella element

- enligt första ordningens teori

- med inverkan av tvärkrafter

- styvhetsmatris och lastvektor

- Eulers knäckfall

Kritisk last (instabilitet) för 2-dimensionella fackverk och ramar

- enligt första och andra ordningens teorier

- styvhetsmatris och lastvektor

- kondensering av styvhetsmatris och lastvektor

- kriterier för instabilitet

Deformationer och påkänningar i

- skivor

    - plant spännings- och plant töjningstillstånd

    - Airys spänningsfunktion

    - randvillkor

    - symmetriska spänningsfördelningar

    - linjär last på halvrymd

    - hål

- plattor

    - Kirschoffs platteori

    - Reissners platteori

    - energiekvationer

- skal

    - sfäriska skal

    - enkelkrökta skal

    - sadelytor

Snittkrafter och påkänningar av vridning för statiskt bestämda och obestämda element med icke-cirkulära tvärsnitt

- utan förhindrad välvning

    - Saint-Venants teori

    - tunnväggiga slutna tvärsnitt

- med förhindrad välvning

- skjuvcentrum och vridcentrum

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Studenterna deltar på föreläsningar där bakgrunder och teorier till kursinnehållet härleds, presenteras och exemplifieras.

Studenterna övar beräkningsmetodik och teorier till kursinnehållet

- enskilt dels på övningspass i klassrum för enklare bärverk, dels i datorsal i inlämningsuppgifter

- i grupp för större bärverk i projektuppgifter

Studenterna övar förmågan att planera, genomföra och redovisa beräkningsuppgifter enskilt i inlämningsuppgifter och i grupp i projektuppgifter.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Bakgrund, teorier och beräkningsmetodik för enklare bärverk (ett fåtal element) examineras med skriftlig sluttentamen. Betygsskala: U, 3, 4, 5.

Beräkningsmetodik för större bärverk examineras genom skriftliga beräkningsrapporter av inlämningsuppgifter och projektuppgifter. Betygsskala: U, G

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 6 | Obligatorisk | H08 |  |
| 0004 | Uppgifter | UG | 1,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når

lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2008-01-22 att gälla från H08.
