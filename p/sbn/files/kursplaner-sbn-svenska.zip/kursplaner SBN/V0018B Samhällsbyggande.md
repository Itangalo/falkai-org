---
kurskod: "V0018B"
titel: "Samhällsbyggande"
hp: "7,5"
titel_en: "Planning and construction in civil engineering"
giltig: "Höst 2023 Lp 1 - Vår 2026 Lp 4"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0018B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0018B&lasPeriod=216&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/v00/v0018b-samhallsbyggande"
---

# Samhällsbyggande (V0018B)

## Behörighet

Grundläggande behörighet + Fysik 2, Kemi 1, Matematik 4 eller Matematik E.

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter fullgjord kurs ska studenten kunna:

Färdighet och förmåga

1. Strukturera och skriva en teknisk rapport och göra källhänvisningar i text och referenslista

2. Utforma presentationsmaterial och muntlig presentationsteknik

3. Genomföra informationssökning på internet och i vetenskapliga databaser samt kritiskt granska information

4. Göra beräkningar med kalkylblad

Kunskap och förståelse

5. Använda begrepp som används i byggandet

6. Ge exempel på roller som finns inom samhällsbyggnadsbranschen och utmaningar som samhällsbyggandet står inför

7. Ge exempel på systemintegration i samhällsbyggandet

8. Ge exempel på beröringspunkter mellan samhällsbyggande och hållbar samhällsutveckling

9. Beskriva stadens tekniska system och fysiska strukturer

10. Beskriva de nationella jämställdhetsmålen och regelverk för jämställdhet i arbetslivet samt ge exempel på förutsättningar för jämställdhet i arbetslivet

## Kursinnehåll

Kursen ger en introduktion till byggande och samhällsbyggande och olika skeden i byggandet. Kursen visar på utmaningarna i det framtida samhällsbyggandet och komplexiteten i byggandet, hur olika system i staden hänger samman, är beroende av varandra och kanske även motverkar varandra. Därtill ges grundläggande kunskap om jämställdhet i arbetslivet. Kursen behandlar även olika generiska färdigheter såsom informationskompetens, rapportskrivande inklusive och referenshantering, presentationsteknik och beräkning med kalkylblad, färdigheter som kan tillämpas och utvecklas under studietiden och i arbetslivet.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen består av olika delar som examineras kontinuerligt. Undervisningen består av övningar, föreläsningar, förinspelade föreläsningar, seminarier, studiebesök och individuella skriftliga uppgifter såväl som grupparbeten, som varvas under kursens gång. Ett projektarbete löper under hela kursen som utföres i grupp och består av olika aktuella samhällbyggnadsprojekt i Sverige. Alla seminarier och redovisningar är obligatoriska eftersom de ingår i examinationen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Lärandemål 1, att strukturera och skriva en teknisk rapport samt göra källhänvisningar i text och referenslista, examineras genom seminarier och quizzar (moment 0007), två grupparbeten (moment 0003 och 0006) samt en individuell uppgift (0002). Lärandemål 2 om presentationsteknik examineras genom deltagande vid ett seminarium (moment 0005) samt att studenten vid tre tillfällen får genomföra muntliga presentationer med återkoppling (moment 0005, 0006 och 0008). Lärandemål 3 om informationssökning samt kritisk granskning av källor examineras genom deltagande vid seminarier/workshoppar med tillhörande quizzar (moment 0007) samt vid rapportskrivning (moment 0006) och bygglexikon (moment 0002). Lärandemål 4, beräkningar med kalkylblad, examineras genom en beräkningsrapport som utförs i grupp (moment 0003). Lärandemål 5, begrepp inom samhällsbyggnadsbranschen, examineras genom att sammanställa ett bygglexikon (moment 0002). Lärandemål 6, att ge exempel på olika roller och framtida utmaningar inom samhällbyggnadsbranschen, lärandemål 7 om systemintegration i samhällsbyggande samt lärandemål 8 om beröringspunkter mellan samhällsbyggande och hållbar samhällsutveckling examineras genom deltagande i kursens seminarieserie med tillhörande inlämningsuppgifter (moment 0005). Systemintegration och beröringspunkter mellan samhällsbyggande och hållbar samhällsutveckling examineras även i den tekniska rapporten (moment 0006). Lärandemål 9 examineras genom beräkningsuppgiften (moment 0003). Lärandemål 10, om jämställdhetsmål och regelverk för jämställdhet i arbetslivet samt förutsättningar för jämställdhet i arbetslivet, examineras genom quizzar (moment 0009). Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen. Betygssättning av alla moment samt slutbetyg sker enligt betygsskala U G. Såvida man inte deltar vid något av de schemalagda seminarierna och studiebesöken i moment 0005, 0007 och 0008 så får det, i mån om plats, genomföras annat läsår.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen V0018B motsvarar kursen V0020B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Bygglexikon | U G# | 1 | Obligatorisk | H15 |  |
| 0003 | Beräkningsuppgift | U G# | 1,5 | Obligatorisk | H15 |  |
| 0005 | Seminarier | U G# | 1 | Obligatorisk | H15 |  |
| 0006 | Teknisk rapport | U G# | 2 | Obligatorisk | H15 |  |
| 0007 | Informationssökning och rapportskrivning | U G# | 0,8 | Obligatorisk | H15 |  |
| 0008 | Presentationsteknik | U G# | 0,7 | Obligatorisk | H15 |  |
| 0009 | Quizzar om jämställdhet | U G# | 0,5 | Obligatorisk | H15 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2015-02-11
