---
kurskod: "V0017B"
titel: "Naturliga vattentransportprocesser"
hp: "7,5"
titel_en: "Natural Water Transport Processes"
giltig: "Höst 2021 Lp 1 - Höst 2025 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "U G#"
amne: "VA-teknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0017B&lasPeriod=205&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/v00/v0017b-naturliga-vattentransportprocesser"
---

# Naturliga vattentransportprocesser (V0017B)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet samt F0004T Fysik 1 och F0006T Fysik 3 eller motsvarande samt goda kunskaper i engelska, motsvarande Engelska 6

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Examinator

Kelsey Flanagan

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

- göra hydrologiska beräkningar avseende vattenbalanser, avrinning, avdunstning och snösmältning,

- göra beräkningar med enhetshydrograf och linjär-reservoir metoden

- utföra enklare mätningar i vattendrag (profil, vattendjup, flöde),

- beräkna endimensionell grundvattenströmning och grundvattenuttag i öppna och slutna akviferer,

- beskriva de fundamentala lagarna i hydraulik och kunna lösa problem som baseras på de teorierna, t.ex. beräkna vattendjup, -hastighet och –flöde,

- ställa upp och lösa hydrauliska problem för vattenströmning i kanaler och överfall,

- generera och utvärdera en enklare modell för snömältning och avrinning för samt utföra en enklare känslighetsanalys,

- beskriva olika strömningstillstånd i vattendrag och övergången från ett tillstånd till ett annat.

## Kursinnehåll

Den här kursen ska ge en övergripande förståelse för naturliga vattentransportprocesser och ge grundläggande beräkningskunskap inom hydrologi- och vattenströmning. Inom området behandlas specifikt: Vattnets kretslopp, vattenflöden (nederbörd, ytavrinning, avdunstning, kondensation, grundvattenavrinning) och vattenmagasinering i sjöar och vattendrag samt markvatten-, grundvatten-, ytvatten- och snömagasin. Friyteströmning, kontinuitetsekvationen, rörelsemängdsekvationen, energiekvationen, kanalströmning innefattande olika strömningstillstånd och övergångar mellan strömningstillstånd.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, räkneövningar som utförs individuellt samt en modelleringsövning och en obligatorisk fältövning som båda utförs i grupp. Pga väderförhållanden genomför fältövningen i läsperiod 1.

Genom kursen kommer studenterna att öva på samarbete (fält- och modelleringsövningar), skriftlig kommunikation (fältövning), problemlösning (räkneövningar) och muntlig kommunikation (fältövning, muntliga prov och modelleringsövningar).

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursen examineras genom fyra muntliga tentamina baserade på uppsättningar av hemövningar samt en skriftlig rapport som är kopplad till den obligatoriska fältövningen. Alla moment bedöms med betygsskalan U G#. För att bli godkänd på kursen behöver alla delmoment vara godkända.

## Överlappning

Kursen V0017B motsvarar kurser V0014B, V0021B

## Övrigt

Kursen motsvarar delar av kursen 00011K Geologi och hydrologi samt V0014B Hydraulik och geologi och kan ej ingå i samma examen som dessa kurser.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Hemskrivning 1 | U G# | 1,1 | Obligatorisk | H12 |  |
| 0004 | Hemskrivning 4 | U G# | 1,5 | Obligatorisk | H12 |  |
| 0005 | Fältövning | U G# | 0,4 | Obligatorisk | H12 |  |
| 0006 | Hemskrivning 2 | U G# | 2,5 | Obligatorisk | H12 |  |
| 0007 | Hemskrivning 3 | U G# | 2 | Obligatorisk | H12 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Litteratur

*Litteratur. Gäller från Höst 2017 Lp 1* Hamill, L., (2011). Understanding Hydraulics. 3 ed. Basingstoke: Palgrave Macmillan. ISBN: 9780230242753. Davie, T. (2008): Fundamentals of hydrology. 2nd ed. London; New York: Routledge. ISBN: 0-415-22028-9 (hbk); ISNB: 0-415-22029-7 (pbk). (Tillgängligt som e-book via biblioteket) Lundberg, A. (2009): Kompendium i hydrologi. Geovetenskap, Luleå tekniska universitet. (Läggs ut i Canvas)

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2012-03-14
