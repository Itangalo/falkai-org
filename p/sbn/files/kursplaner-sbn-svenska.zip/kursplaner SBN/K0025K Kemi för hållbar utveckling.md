---
kurskod: "K0025K"
titel: "Kemi för hållbar utveckling"
hp: "7,5"
titel_en: "Chemistry for Sustainable Development"
giltig: "Vår 2026 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2024-02-14"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Kemi"
amnesgrupp_scb: "Kemi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0025K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0025K&lasPeriod=222&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0025k-kemi-for-hallbar-utveckling"
---

# Kemi för hållbar utveckling (K0025K)

## Ingår i huvudområde

Naturresursteknik, Kemiteknik, Energiteknik

## Behörighet

Grundläggande behörighet + Kemi 1, Matematik 3c eller Matematik D. Eller: Kemi nivå 1, Matematik fortsättning nivå 1c.

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter genomgången kurs skall kursdeltagarna kunna

- använda grundläggande terminologi samt behärska formelskrivning.

- beräkna omsättning och utbyten, inkluderande gasbildning.

- förklara sambandet mellan atomernas uppbyggnad och organisationen av grundämnena.

- förklara och systematisera olika ämnens egenskaper genom att tillämpa konceptet kemisk bindning på intra- och interpartikulär nivå.

- använda begreppet jämvikt för att förklara och förutse förändringen av förekomstformen hos olika ämnen vid förändring av parametrar som koncentration, pH, elektronaktivitet, tryck och volym samt kunna tillämpa jämviktsbegreppet för att förklara vissa ämnens förekomstformer och miljöpåverkan.

- Du skall även behärska beräkningar med enklare jämviktssystem (en jämvikt). Förutsättningarna för buffertverkan ska kunna anges och pH i ett buffrande system beräknas.

- tillämpa begreppen spontana och icke-spontana processer för att förutse och kvantifiera ett förlopp, samt även känna till dess samband med jämvikter och redoxprocesser.

- använda och förklara begreppen

    - Entalpi, Inre energi, arbete, tillståndsfunktion, standardtillstånd och bildningsentalpi.

    - Entropi, absolut entropi, spontanitet och Gibbs fria energi.

- beräkna jämviktskonstanter och standardpotentialer ut Gibbs fria energi och även i omvänd riktning.

- definiera och förklara termodynamikens huvudsatser

- applicera dina kunskaper för att förklara olika miljö-, material- och processrelaterade frågeställningar med global- och även lokal relevans.

Efter genomgången kurs skall deltagarna även kunna ge exempel på kemirelaterad miljöpåverkan, förklara de bakomliggande mekanismerna och ange potentiella lösningar för att uppnå ett hållbarare samhälle.

Deltagarna ska även ha utvecklat sin förmåga att bearbeta och lösa vetenskapliga problemställningar.

## Kursinnehåll

Del 1 Kemiska grundbegrepp:

Begrepp och definitioner. Kemisk terminologi och namngivning. Reaktionsformler.

Stökiometri: Omsättning. Koncentration och koncentrationsenheter. Gaser.

Del 2 Atomens uppbyggnad:

Atomens uppbyggnad och periodiska systemet. Kemisk bindning: Intra- och intermolekylär bindning. Hybrid- och molekylorbitalteori. Den globala värmebalansen. Metallernas egenskaper. Bandteori halvledare.

Del 3 Jämvikter:

Jämvikter allmänt. Syrabasjämvikter, lösligheter. Buffrande system. Koldioxidsystemets reglerande roll. Redoxreaktioner. Redoxreaktioners betydelse i naturen. Galvaniska celler. Elektrolys

Del 4 Termodynamik:

System och omgivning. Inre energi och arbete. Entalpi. Entropi. Gibbs fria energi. Spontana och icke-spontana processer. Maximalt arbete. Termodynamikens huvudsatser. Sambanden med jämvikter och elektrodpotentialer. Reaktionskinetiska begränsningar.

Kopplingar till miljö-, material- och processfrågor behandlas i de olika avsnitten.

Kemi för hållbar utveckling

- Globala och lokala miljöfrågor

    - Atmosfären: Den globala värmebalansen. Luftburna föroreningar.

    - Hydrosfären: pH-reglering i hav och vattendrag. Alkalinitet och försurning.

    - Jord och mark: Gruvbrytningens miljökonsekvenser. Fasta föroreningar vid förbränning, Biocider och pesticider.

- Kemikalier i samhället och deras hantering. Risker och säkerhet vid hantering av farliga kemikalier i arbetsmiljön.

- Ny teknik för en hållbar utveckling.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av övergripande föreläsningar, eget arbete med inläsning av kurslitteratur och övningsuppgifter. Stöd i arbetet finns tillgängligt genom kontakt med lärare.

Vid första lektionstillfället presenteras kursens upplägg och examination. Närvaro vid detta tillfälle är obligatorisk, frånvaro kan i vissa fall beviljas av kursansvarig. Den student som inte personligen registrerat sig under läsperiodens första tre dagar riskerar att förlora sin plats på kursen. Detta gäller även studenter med platsgaranti.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Tentamen del 1 examinerar de två första punkterna i målbeskrivningen.

Tentamen del 2 examinerar punkt tre och fyra i målbeskrivningen.

Tentamen del 3 examinerar punkt fem och sex i målbeskrivningen.

Tentamen del 4 examinerar punkt sju till tio i målbeskrivningen.

Modulen 0005 Kemi för hållbar utveckling, examinerar det näst sista stycket i målbeskrivningen genom inlämningsuppgifter.

Den sista punkten i målbeskrivningen samt det sista stycket examineras partiellt av alla i kursen ingående i tentamina.

Slutbetyg sätts genom en sammanvägning av betygen i förhållande till antalet Hp för Modul 0001-0004.

Godkända uppgifter för avsnittet Kemi för hållbar utveckling.

Vid behov av omtentamen för distansstudenter genomförs dessa på av LTU godkända tentamensplatser. Se https://www.ltu.se/student/Studera/Tentamen/Tentamen-distansstudent

Endast förstagångsregistrerade studenter är beviljade att delta i tentamen under pågående läsperiod.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0025K motsvarar kursen K0016K

## Övrigt

De senaste studiehandledningarna finns tillgänglig via LTU:s lärplattform.

Fulla förkunskaper från tidigare kursdelar förutsätts vid därpå följande examination.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen del 1 | GU345 | 1,5 | Obligatorisk | H20 |  |
| 0002 | Tentamen del 2 | GU345 | 2 | Obligatorisk | H20 |  |
| 0003 | Tentamen del 3 | GU345 | 1,5 | Obligatorisk | H20 |  |
| 0004 | Tentamen del 4 | GU345 | 1,5 | Obligatorisk | H20 |  |
| 0006 | Kemi för hållbar utveckling | U G# | 1 | Obligatorisk | H20 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-02-14
