---
kurskod: "L7027K"
titel: "Hydrogeokemi"
hp: "7,5"
titel_en: "Hydrogeochemistry"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L7027K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L7027K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l70/l7027k-hydrogeokemi"
---

# Hydrogeokemi (L7027K)

## Behörighet

Minst 90 hp inom områdena geovetenskap, geologi, naturresursteknik, gruvteknik eller anläggningsteknik. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

1. Beskriva hur hydrologin i avrinningsområden och de fysikaliska egenskaperna i jord och berg påverkar grundvattenbildning och flöde.

2. Förklara hur naturliga geokemiska processer i jord och berg samt föroreningar kan påverka grundvattenkvalitet.

3. Förklara hur klimatförändringar kan påverka grundvattennivåer och kvalitet.

Färdighet och förmåga

4. Hämta grundvattendata från öppna databaser och använd syre- och väteisotoper och geokemisk programvara för att tolka dessa grundvattendata.

5. Skriva en vetenskaplig rapport och presentera geokemiska data.

Värderingsförmåga och förhållningssätt

6. Använda hydrogeokemiska principer för att arbeta för en hållbar användning av grundvattenresurser i ett föränderligt klimat.

## Kursinnehåll

Kursen behandlar grundläggande begrepp relaterade till jord/berg, hydrologi/grundvatten och geokemi. Dessa grundläggande begrepp används sedan för att tolka grundvattendata och för att bedöma potentiella effekter av klimatförändringar på grundvattenkvaliteten.

Avsnittet om jord och berg täcker bildning och utbredning av kvartära sediment, jordars fysikaliska och kemiska egenskaper som porositet, permeabilitet, kapillaritet och katjonbyteskapacitet. Grundvattenförekomst i berg.

Avsnittet om hydrologi och grundvatten omfattar grundläggande avrinningshydrologi, grundvattenbildning och grundvattenflöde i akviferer. Samspel mellan grundvatten och ytvatten med tillämpningar i grundvattenreservoarer. Demonstration av grundvattenprovtagning och provtagningsutrustning.

Avsnittet om geokemi behandlar samspelet mellan jord, berg och grundvatten, och hur detta samspel påverkar grundvattenkvaliteten. Grundvattenföroreningar och föroreningstransport i grundvatten. Syre- och väteisotoper används som ett verktyg för att spåra grundvattens ursprung. Programvara som ioGAS och QGIS används för att tolka grundvattendata.

Potentiella effekter på grundvattennivåer och kvalitet i ett föränderligt klimat diskuteras i relation till verkliga fall

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Grundläggande teori om de fysikaliska och kemiska egenskaperna hos jord och berg, avrinningshydrologi och grundvattenegenskaper presenteras under föreläsningar. Tre obligatoriska övningar baserade på data från relevanta fältområden ger en djupare förståelse av den grundläggande teorin relaterad till hydrologiska och geokemiska aspekter. Hydrologiska och geokemiska aspekter integreras i en obligatorisk projektuppgift som ger övning i samarbete, vetenskapligt skrivande och datapresentation. Studiebesök vid vattenverk eller annan plats.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Måluppfyllelsen kontrolleras genom:

1. En individuell, skriftlig dugga (GU 3 4 5) som examinerar kursmål 1, 2 och 3.

2. Tre övningar (UG#) som examinerar kursmål 4 och 5.

3. En skriftlig rapport (UG#) som examinerar kursmål 5 och 6.

Alla prov som ingår i modulen måste vara avklarade för godkänt kursbetyg.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Dugga | GU345 | 3 | Obligatorisk | V25 |  |
| 0004 | Projektuppgift | UG | 1,5 | Obligatorisk | V27 |  |
| 0005 | Övningar | UG | 3 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14
