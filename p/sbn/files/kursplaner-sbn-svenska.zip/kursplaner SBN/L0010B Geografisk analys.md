---
kurskod: "L0010B"
titel: "Geografisk analys"
hp: "7,5"
titel_en: "Spatial Analysis"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-06-14"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "U G#"
amne: "Geografisk informationsteknologi"
amnesgrupp_scb: "Geografisk informationsteknik och lantmäteri"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0010B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0010B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0010b-geografisk-analys"
---

# Geografisk analys (L0010B)

## Behörighet

Grundläggande behörighet samt Grundläggande kunskaper i geografisk informationsteknik motsvarande L0020B, Geografisk informationsteknik

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten (generella GIS-användare, såväl som specialister):

- kunna utföra bättre och mer kvalitativa geografiska analyser inom olika tillämpningsområden,

- ha en fördjupad kunskap om metoder och tekniker som används för modellering av geografiska data, med fokus på praktisk tillämpning.

## Kursinnehåll

Raster- och vektoranalys, interpolationsmetoder, spatial analys, nätverk.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Allt kursmaterial och programvaror finns under LTU’s Citrixportal och där hittas mer detaljerade beskrivningar över kursens innehåll och dess genomförande. Det finns inga inspelade föreläsningar och det är inte några obligatoriska sammankomster. Föreläsningar i textform, en del av kursen utgörs av kurser från ESRI.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursens mål examineras med inlämningsuppgifter som görs individuellt och examineras under kursens gång. Betygssättning av inlämningsuppgifter sker enligt betygsskala U/G. Samtliga inlämningsuppgifter ska vara avklarade för slutbetyg. Inlämningsuppgifterna finns under LTU’s Citrixportal.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts

som tillåtna är otillåtna.

## Överlappning

Kursen L0010B motsvarar kursen ABL032

## Övrigt

Kurs som ska följas via Internet kräver att studenten har tillgång till någon form av bredbandsuppkoppling, minst motsvarande ADSL.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G# | 7,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-06-14

## Kursplanen fastställd

av Institutionen för samhällsbyggnad 2007-01-31
