---
kurskod: "T0024B"
titel: "Praktisk bergmekanik"
hp: "7,5"
titel_en: "Rock mechanics in field"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0024B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0024B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t00/t0024b-praktisk-bergmekanik"
---

# Praktisk bergmekanik (T0024B)

## Behörighet

Grundläggande behörighet samt - grundläggande kunskaper om tunnel och ortdrivning motsvarande kursen T0013B Berganläggningsteknik eller liknande kurs
- teoretiska grundläggande kunskap inom bergmekanik såsom spänningar och deformationer i berg motsvarande kursen T0014B Introduktion till bergmekanik eller liknande kurs

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

1. bestämma och välja lämpliga materialparametrar samt tillämpa dem i analytiska och linjärelastiska numeriska analyser av konstruktioner i berg

2. för olika geologiska förhållanden välja och beräkna lämplig förstärkning för konstruktioner i berg

3. beskriva mät- och observationsprogram för olika typer av bergkonstruktioner och situationer

4. genomföra fältarbete med beprövade metoder för att bedöma bergmassans hållfasthet samt bergmassans tillstånd via skadekartering

5. presentera analyser och resultat muntligt och skriftligt samt diskutera de slutsatser och den kunskap och de argument som ligger till grund för dessa

## Kursinnehåll

Kursen omfattar följande områden:

- Inledning - Kursutformning, repetition av relevant innehåll från tidigare kurser i bergmekanik

- Numerisk analyser - Introduktion till numeriska metoder; hur man gör numeriska analyser; hur man tillämpar den på bergmekaniska problem, hur man utvärderar och tolkar resultaten och hur man presenterar numeriska analyser och dess resultat

- Bergmekaniska parametrar samt skadekartering - Brott i berg, residual hållfasthet, hur olika brottformer ser ut i praktiken, bestämma bergmassaparametrar, presentera skadekartering

- Förstärkning i berg – Förstärkningselement och metoder, problem vid förstärkning, skador på förstärkning, beräkna förstärkningsbehov

- Mätning och övervakning – Hur man mäter och övervakar slänter och underjordiska konstruktioner, instrumentens mätprinciper och deras för- och nackdelar.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av:

- Lektioner - De är en mix av flera undervisnings-/inlärningsaktiviteter: (i) teorigenomgång där föreläsaren förklara de viktigaste teoretiska aspekterna relaterade till kursens innehåll och (ii) tillsammans lösa och/eller diskutera typiska bergmekaniska problem samt frågor vilket ger dig möjlighet att på olika sätt arbeta med flera aspekter kring bergmekanik utifrån en praktisk och teoretisk synvinkel samt träna beräkningsprocedurer för frågeställningar relaterade till dessa.

- Datorövningar - Under dessa arbetar vi i (virtuel)datasal där vi praktisk övar på olika numeriska applikationer och hur de kan användas för att analysera materialbeteenden, spänningar, deformationer, stabilitet och förstärkning hos undermarkskonstruktioner i berg.

- Inlämningsuppgifter - Du arbetar tillsammans med andra studenter och använder dina kunskaper för att lösa olika problem. Du presenterar ditt arbete i skriftliga rapporter. Du tränas i att med utgångspunkt från de analytiska och numeriska analyser som utförs samt nyttogörande av föreläsningar, föreslå och motivera hur en bergkonstruktion ska analyseras samt förklarar ditt arbete skriftligt.

- Fältövning - Här tränas du i att kartera berg och sprickor samt skadekartera befintlig bergkonstruktion. Du presenterar ditt arbete muntligt samt skriftlig i form av en rapport

- Mellan lektionerna - Du förväntas förbereda dig inför varje lektion genom att arbeta igenom rekommenderat materialet, rekommenderade övningar och instuderingsfrågor så att du är beredd att bidra och delta i läraktiviteterna (problemlösning, diskussion, mm) under föreläsningarna och datorövningarna.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:

- Skriftliga delprov - Består av frågor som testar din teoretiska kunskap och förståelse för vissa bergmekaniska aspekter relaterade till kursens innehåll.

- Inlämningsuppgifter - Består av problem där du tränar och tillämpar din teoretiska kunskap, förståelse och förmåga samt gör analyser och förklarar dina resultat skriftligt.

- Fältövning - Genom övning i fält samt inlämning av skriftlig lösning samt muntlig redovisning.

- Skriftlig tentamen - Du löser problem som liknar de som du stöter på under kursen (i föreläsningar och uppgifter) för att testa din individuella kunskap, förståelse, skicklighet och förmågor. Kurskompendiet är tillåtet hjälpmedel på tentamen.

Mål 1-5 examineras via skriftlig tentamen. Betygsskala: G U 3 4 5.

Mål 1-2 och 4-5 examineras via fältövning. Ingår i övrigt med betygsskalan G U.

Mål 1-5 examineras via skriftliga delprov och inlämningsuppgifter. Ingår i övrigt med betygsskalan G U.

För att blir godkänd på modulen Övrigt krävs att du är godkänd på skriftliga inlämnade inlämningsuppgifter, muntlig och skriftlig redogörelse av fältövningen samt godkänd på skriftliga delprov.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 3 | Obligatorisk | H13 |  |
| 0002 | Övrigt | U G# | 4,5 | Obligatorisk | H13 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13

## Kursplanen fastställd

av Eva Gunneriusson 2013-02-08
