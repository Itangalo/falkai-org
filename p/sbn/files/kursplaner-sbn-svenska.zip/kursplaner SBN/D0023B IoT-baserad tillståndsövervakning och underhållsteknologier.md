---
kurskod: "D0023B"
titel: "IoT-baserad tillståndsövervakning och underhållsteknologier"
hp: "7,5"
titel_en: "IoT-Enabled Condition Monitoring and Maintenance Technologies"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D0023B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D0023B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d00/d0023b-iot-baserad-tillstandsovervakning-och-underhallsteknologier"
---

# IoT-baserad tillståndsövervakning och underhållsteknologier (D0023B)

## Behörighet

Grundläggande behörighet samt M0048M Linjär algebra och integralkalkyl eller motsvarande kurs. Goda kunskaper i engelska motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter genomgången kurs ska deltagarna kunna:

Kunskap och förståelse

1. Visa grundläggande kunskaper om Sakernas Internet och dess implementering.

2. Visa grundläggande kunskaper om begrepp inom Python-programmering, inklusive syntax, datatyper och datastrukturer.

3. Förklara hur Sakernas Internet och tillståndsövervakning kan användas som stöd för underhållsbeslut.

Färdighet och förmåga

4. Genomföra mätningar med sensorer, mikrokontroller, DSP-plattformar eller liknande system för insamling av signaler och mätdata.

5. Programmera enklare tillämpningar för datainsamling, signalbehandling och kommunikation mellan enheter inom Sakernas Internet.

6. Analysera signaler och mätdata med hjälp av grundläggande signalbehandlingstekniker.

7. Självständigt och i grupp planera och genomföra tillståndsövervakning med uppkopplade mätsystem, molntjänster och applikationer.

## Kursinnehåll

Denna kurs omfattar:

- Grundläggande begrepp tillståndsövervakning och tillståndbaserat underhåll

- Sakernas internet, mätteknik, mikrokontroller, sensorer och molntjänster

- Programmering för datainsamling, signalbehandling och kommunikation inom IoT-system.

- Signalanalys, i tids- och frekvensdomän, trendanalys och maskininlärning

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen består av tre delar. Den första delen är teoretisk med föreläsningar och lektioner om tillståndsövervakning, Sakernas Internet, programmering och signalanalys. Andra delen består av laborationer kopplade till sensorer, mätsystem och Sakernas Internet. I den tredje delen genomförs ett projektarbete där det ingår att planera och genomföra tillståndsövervakning med hjälp av Sakernas Internet.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För att erhålla godkänt betyg på kursen måste inlämningsuppgifterna, laborationerna och projekt vara avslutade med godkänt betyg.

- Inlämningsuppgifter bedömer kunskap och förståelse relaterat till målen (1-3) samt förmåga att analysera mätdata beskrivit i mål 6.

- Laborationer utvärderar den praktiska kompetenserna och färdigheterna som beskrivs i mål 4 och 5. Laborationerna kommer att genomföras i grupper och examineras med labbrapporter och muntlig redovisning.

- Projektuppgiften examinerar förmågan att självständigt planera och genomföra tillståndsövervakning enligt mål 7. Projektuppgiften redovisas både muntligt och skriftligt.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 4 | Obligatorisk | H26 |  |
| 0002 | Laboration | U G# | 1,5 | Inaktiv | H26 |  |
| 0003 | Projektarbete | U G# | 2 | Inaktiv | H26 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13
