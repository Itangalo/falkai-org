---
kurskod: "L0021B"
titel: "ArcGIS Pro"
hp: "7,5"
titel_en: "ArcGIS Pro"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Geografisk informationsteknologi"
amnesgrupp_scb: "Geografisk informationsteknik och lantmäteri"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0021B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0021B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0021b-arcgis-pro"
---

# ArcGIS Pro (L0021B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kursens mål är att ge studenterna förmåga att, med hjälp av geografisk informationsteknik,

- samla in, lagra, analysera och presentera geografiska data,

- vara förtrogen med att bygga upp geografiska databaser,

- planera och genomföra grundläggande geografiska analyser i programvaran ArcGIS Pro.

## Kursinnehåll

Introduktion till ämnet Geografiska informationssystem (GIS)

-ArcGIS Pro Uppbyggnad och funktionssätt

-Praktiska övningar innefattande: Lagerhantering Tabellhantering och databashantering Skapa och redigera data Bearbetning av data Arbetsflöden Analys Kartografi

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Allt kursmaterial och programvara finns under LTU’s Citrixportal och där hittas mer detaljerade beskrivningar över kursens innehåll och dess genomförande. Det finns inga inspelade föreläsningar och det är inte några obligatoriska sammankomster. Boken utgör inlärningsmaterialet och bör följas enligt dess instruktioner.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursens mål examineras med inlämningsuppgifter som görs individuellt eller i grupp om två personer och examineras under kursens gång. Betygssättning av inlämningsuppgifter sker enligt betygsskala U/G. Samtliga inlämningsuppgifter ska vara avklarade för slutbetyg. Inlämningsuppgifterna finns under LTU’s Citrixportal.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Kurs som ska följas via Internet kräver att studenten har tillgång till någon form av bredbandsuppkoppling.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G# | 7,5 | Obligatorisk | H20 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-02-14
