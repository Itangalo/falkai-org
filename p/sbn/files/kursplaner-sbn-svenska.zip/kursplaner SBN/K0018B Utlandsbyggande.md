---
kurskod: "K0018B"
titel: "Utlandsbyggande"
hp: "7,5"
titel_en: "International construction"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2020-04-21"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "U G#"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0018B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0018B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0018b-utlandsbyggande"
---

# Utlandsbyggande (K0018B)

## Behörighet

Grundläggande behörighet samt Kursen V0011B Samhällsbyggande samt minst två av kurserna T0013B Berganläggningsteknik, K0013B Byggkonstruktion och P0001B Bygg och anläggningsproduktion

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursens övergripande mål är att studera internationella byggprojekt. Kursen ger inblick i hur byggprojekt bedrivs i andra länder med förutsättningar som skiljer sig från de i Sverige tex avseende lagstiftning, normer, klimat, arbetsmiljö och säkerhet. Studenten skall dessutom öva, utveckla och visa färdigheter i att arbeta i projekt med deltagare med bakgrund i andra traditioner än den svenska.

Det innebär att studenten efter kursen ska kunna:

- Tillsammans med övriga studenter redogöra för de internationella byggprojekt de studerat

- Tillämpa kunskaper från lästa kurser och erfarenheter från svenska byggprojekt för att jämföra med de studerade projkten

- Arbeta tillsammans i projekt där alla bidrar mot samma mål.

- Arbeta med deltagare på andra språk än svenska.

- Arbeta med tidigare okända samarbetspartners

- Ta fram och arbeta med budget.

## Kursinnehåll

Studenterna planerar tillsammans en studieresa till ett annat land. I studieresan besöks byggarbetsplatser, gruvor och/eller universitet med verksamhet som är av intresse för studenternas framtida yrkeskarriärer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenterna som deltar i kursen planerar och genomför studieresan och samlar sina erfarenheter från resan i en rapport. Resan har en varaktighet på mellan 2 och 3 veckor.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Skriftlig rapport från studieresan (gemensam för gruppen).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0018B motsvarar kursen T0028B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Deltagit i studieresan och godkänd rapport | U G# | 7,5 | Obligatorisk | V21 |  |

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-04-21
