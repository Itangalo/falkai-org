---
kurskod: "O7023K"
titel: "Tillämpad fältprospektering"
hp: "3"
titel_en: "Applied Field Exploration"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Malmgeologi"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O7023K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O7023K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o70/o7023k-tillampad-faltprospektering"
---

# Tillämpad fältprospektering (O7023K)

## Behörighet

90hp inom geovetenskap.

Goda kunskaper i engelska motsvarande Engelska 6/nivå 2

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter genomförd kurs skall studenten ha uppnått följande mål:

- kunskap om geologiska, geofysiska och geokemiska prospekteringsmetoder och hur de används i en prospekteringskampanj.

- kunskap om metoder för kartering och provtagning i fält.

- viss kännedom om förberedande och uppföljande arbete vid prospektering, kännedom om strategier för val av geografiska målområden vid prospektering och betydelsen av lokala faktorer.

- kännedom om dataprogram för behandling av geografisk, geologisk, geofysik och geokemisk information.

## Kursinnehåll

Geologiska, geofysiska ocg geokemiska metoder i VMS prospektering. Fältövningar i strukturgeologi, geofysik, hydrotermal omvandling. Fältövningar i geofysiska mätningar användandes drönarteknologi. Syntes av fältdata i GIS miljö för att välja ett målområde. Borrkärnekartering och provtagning.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen genomförs i form av ett antal tematiska kursmoduler i Canvas där teoretisk genomgång varvas med praktiska övningar. Under en vecka i Juni så sker praktiska fältövningar på plats i studieområdet. Efter fältövningarna så sammanställer studenterna resultaten individuellt i en slutrapport.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Godkända övningsuppgifter och projektarbete med differentierade betyg. Redovisning av projektrapporter skriftligt.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Projektuppgift | GU345 | 1,8 | Obligatorisk | V21 |  |
| 0001 | Övningsuppgifter | U G# | 1,2 | Inaktiv | V21 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-10-13
