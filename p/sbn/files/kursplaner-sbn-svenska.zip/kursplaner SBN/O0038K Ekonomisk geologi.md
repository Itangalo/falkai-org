---
kurskod: "O0038K"
titel: "Ekonomisk geologi"
hp: "7,5"
titel_en: "Economic Geology"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2025-04-16"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Malmgeologi"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0038K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0038K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o00/o0038k-ekonomisk-geologi"
---

# Ekonomisk geologi (O0038K)

## Behörighet

Grundläggande behörighet samt O0035K Geologi, grundkurs samt O0036K Mineralogi eller motsvarande.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter kursen ska studenten kunna: 1) redogöra för de viktigaste malmbildande processerna i tid och rum, 2) redogöra för de viktigaste malmtypernas karaktär och bildningsbetingelser, 3) ha kännedom om de viktigaste malmregionerna i Sverige, 4) utföra enklare kartering av borrkärnor.

## Kursinnehåll

Klassificering av malmtyper. Malmbildande processer och de viktigaste malmtypernas bildningsbetingelser, karaktär, geologiska uppträdande och koppling till plattektoniska miljöer. Industrimineral, deras förekomst, bildningsbetingelser och användning. Ballast, natursten och energiråvaror av geologiskt ursprung. Sveriges viktigare malmdistrikt och mineralförekomster. Metoder för kärnkartering.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen omfattar föreläsningar där grundläggande teori presenteras och förklaras och omfattar malmbildande processer, de viktigare malmtypernas karaktär och bildningsprocess, industrimineral, ballast, natursten och energiråvaror. Praktiska övningar är kopplade till föreläsningarna och fokuserar på studentens färdigheter i att beskriva, tolka och förklara malmer och industriminerals karaktär och geologiska uppträdande. Svenska malmdistrikt och mineralförekomster presenteras i föreläsningar och genom studentens eget projektarbete med muntlig redovisning, samt genom övning i kärnkartering.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Skriftlig tentamen med graderat betyg samt godkända övningar och muntlig redovisning av projektarbete.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0012 | Skriftlig tentamen | GU345 | 5,5 | Obligatorisk | H09 |  |
| 0014 | Övningsuppgifter | UG | 1 | Obligatorisk | V27 |  |
| 0015 | Projektuppgift fyndighetsgeologi | UG | 1 | Obligatorisk | V27 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-04-16

## Kursplanen fastställd

av Institutionen för Tillämpad kemi och geovetenskap 2009-02-19
