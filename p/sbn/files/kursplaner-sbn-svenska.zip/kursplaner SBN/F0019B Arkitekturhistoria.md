---
kurskod: "F0019B"
titel: "Arkitekturhistoria"
hp: "7,5"
titel_en: "History of Architecture"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-14"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "UG"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F0019B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F0019B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/f00/f0019b-arkitekturhistoria"
---

# Arkitekturhistoria (F0019B)

## Ingår i huvudområde

Arkitektur

## Behörighet

Grundläggande behörighet samt Minst 30hp kurser inom teknik och/eller samhällsvetenskap

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kunskap och förståelse

Efter kursen skall studenten kunna:

- Översiktligt kunna beskriva huvuddragen i arkitekturens och stadsbyggandets historia från antiken till nutid.

- Beskriva några viktiga arkitekt- och ingenjörsinsatser som påverkat utvecklingen under olika epoker.

- Ge exempel på hur arkitektur och stadsbyggande under alla tider har varit och är viktiga områden för människans strävan efter en väl fungerande värld.

Färdighet och förmåga

Efter kursen skall studenten kunna:

- Beskriva och tolka kvaliteter i arkitektur och stadsbyggande utifrån ett historiskt perspektiv.

Värderingsförmåga och förhållningssätt

Efter kursen skall studenten kunna:

- Reflektera över arkitektur- och stadsbyggnadshistorien, dess roll i samtiden, och vad den kan betyda för framtiden.

## Kursinnehåll

Historien för västerländsk arkitektur och stadsbyggande från antiken till nutid.

Samband mellan arkitektonisk utformning och samhälle, klimat, teknik o s v.

Arkitektens och ingenjörens uppgifter och roller under olika epoker, i ljuset av ett samtidsperspektiv.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen bedrivs i föreläsningsform och genom olika övningar. Till varje huvudavsnitt finns dessutom instuderingsfrågor för att stödja lärandet.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examination sker genom återkommande övningsuppgifter under kursens gång. Övningsuppgifterna är till för att studenterna skall bearbeta och reflektera kring innehållet i kursen under hela kurstiden.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen F0019B motsvarar kursen F0008B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Övningsuppgifter | UG | 7,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institut 2019-06-14
