---
kurskod: "L0049K"
titel: "Hållbar mineralutvinning 1"
hp: "15"
titel_en: "Sustainable Resource Engineering 1"
giltig: "Vår 2026 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2022-02-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0049K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0049K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0049k-hallbar-mineralutvinning-1"
---

# Hållbar mineralutvinning 1 (L0049K)

## Ingår i huvudområde

Naturresursteknik, Geovetenskap

## Behörighet

Grundläggande behörighet + Engelska 6, Fysik 2, Kemi 1, Matematik 3c eller Matematik D. Eller: Engelska nivå 2, Fysik nivå 2, Kemi nivå 1, Matematik fortsättning nivå 1c.

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kursen ger grundläggande kunskaper i mineral och metallvärdekedjan, hur de olika delarna av värdekedjan hör ihop samt relationen till omgivande samhälle och miljö.

Efter avslutad kurs skall studenten kunna:

Kunskap och förståelse

1. Beskriva mineral och metallvärdekedjan baserat på vetenskaplig grund.

2. Kunna beskriva och till viss del använda teknologier för nyttjande av mineralresurser.

3. Kunna samla in tekniskt och naturvetenskapligt data

Färdighet och förmåga

4. Visa förmåga att söka och samla vetenskaplig information om mineral och metallvärdekedjan

5. Visa förmåga att lösa uppgifter inom givna tidsramar

6. Muntligt och skriftlig kunna presentera och diskutera mineral och metallvärdekedjan och dess samhälleliga kontext.

Värderingsförmåga och förhållningssätt

7. Visa insikt om mineral och metallers roll i samhället och hur de utvinns samt ha kännedom om aktuellt kunskapsläge.

8. Göra bedömning med hänsyn till tekniska och naturvetenskapliga effekter.

## Kursinnehåll

Kursen är en projektkurs som ger grundläggande kunskap om mineral och metallvärdkedjan. Dvs hur man hittar, bryter, utvinner samt återvinner mineral och metall och hur detta påverkar omgivande miljö. Kursen består av delmoment längs med värdekedjan i projektform, både självständigt och i grupp i olika form i samverkan med företag inom området. Kursen består av både praktiska och teoretisk moment och av vikt är muntlig och skriftlig presentation.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Projektarbete i grupp och självständigt kombinerat med föreläsningar, fältövningar och laborationer.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Mål examineras genom skriftliga projektinlämningar samt muntliga projektpresentationer och skriftliga delprojekt/inlämningsuppgifter

Projektarbete 1,3 samt muntlig presentation 1,3 examinerar delmål 1,4,5,6,7,8

Projektarbete 2 samt muntlig presentation 2 examinerar delmål 2,5,6,7,8

Inlämningsuppgift/delprojekt examinerar delmål 2,3,5,6

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektarbete 1 | U G# | 3 | Obligatorisk | H22 |  |
| 0002 | Projektarbete 2 | U G# | 3 | Obligatorisk | H22 |  |
| 0003 | Projektarbete 3 | U G# | 3 | Obligatorisk | H22 |  |
| 0004 | Muntlig presentation och opponering 1 | U G# | 0,7 | Obligatorisk | H22 |  |
| 0005 | Muntlig presentation och opponering 2 | U G# | 0,7 | Obligatorisk | H22 |  |
| 0006 | Muntlig presentation och opponering 3 | U G# | 0,7 | Obligatorisk | H22 |  |
| 0007 | Delprojekt/inlämningsuppgifter 1 | U G# | 1,3 | Obligatorisk | H22 |  |
| 0008 | Delprojekt/inlämningsuppgifter 2 | U G# | 1,3 | Obligatorisk | H22 |  |
| 0009 | Delprojekt/inlämningsuppgifter 3 | U G# | 1,3 | Obligatorisk | H22 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11
