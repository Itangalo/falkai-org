---
kurskod: "S0005B"
titel: "Projektkurs i brandteknik"
hp: "7,5"
titel_en: "Project course in fire engineering"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2022-01-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "UG"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S0005B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S0005B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s00/s0005b-projektkurs-i-brandteknik"
---

# Projektkurs i brandteknik (S0005B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

- beskriva räddningstjänstens metod och teknik vid brand i byggnad, trafikolycka, utsläpp av farligt ämne och vattenlivräddning och arbete på hög höjd

- hantera den utrustning som krävs för att lösa dessa situationer

- beskriva och förstå de risker som uppkommer i ovanstående situationer samt redogöra för de säkerhetsåtgärder som krävs för att möta denna riskbild

- förklara räddningstjänstens och andra samhällsaktörers roller på en olycksplats

Färdighet och förmåga

För godkänd kurs skall studenten kunna:

- agera som brandman, enskilt och i grupp, i vissa enkla, okomplicerade räddningstjänstsituationer

- identifiera utvecklingsområden samt muntligt och skriftlig beskriva hur räddningstjänster i dagsläget jobbar inom det aktuella utvecklingsområdet

## Kursinnehåll

Kursen behandlar följande områden som utgör grundläggande förståelse för räddningstjänstsarbete:

- Grundläggande brandteori, brandförlopp.

- Genomgång av standardrutiner vid brand i byggnad (Taktik, organisation och viktig utrustning).

- Släckmedel/släckverkan (Även alternativa släckmetoder).

- Andningsskydd.

- Sökteknik (sökövning i kall rök).

- Vattenlivräddning: standardrutiner, utrusning och metoder.

- Trafikolycka: standardrutiner, metoder och teknik.

- Utsläpp av farligt ämne: standardrutiner, utrusning och metoder.

- Arbete på hög höjd.

En projektuppgift ingår i kurs. Projektuppgift är skriftlig fördjupningsrapport inom något av räddningstjänstens operativa områden. Arbetet ska omfatta en kort beskrivning av nuläget, dvs. hur räddningstjänsterna i dagsläget jobbar inom det aktuella området.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Genomförande:

Undervisningen består av tre veckors praktiska och teoretiska övningar på räddningstjänstens övningsfält, Hertsön, och självstudier inför de praktiska övningarna. Övningsveckorna kan helt eller delvis genomföras utanför ordinarie terminstid, vilket beslutas i samråd mellan examinator, räddningstjänsten och studenter.

I kursen tränas följande färdigheter:

- Förmåga till lagarbete och samverkan (projektarbete) i grupper där läraren bestämmer grupperna.

- Förmåga till lagarbete och samverkan (de praktiska övningarna på räddningstjänstens övningsfält).

- Muntlig och skriftlig presentation. Muntlig opponering

- Identifiera och använda lämplig litteratur inom det valda fördjupningsområdet

- Agerande som brandman, enskilt och i grupp, i vissa enkla, okomplicerade räddningstjänstsituationer

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen består av två delar: de praktiska övningarna och projektuppgift. Betygssättning sker enligt betygsskala G U. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen. För att bli godkänd på kursen krävs obligatorisk närvaro och aktivt deltagande vid muntlig redovisning av projektuppgiften och alla planerade praktiska övningar på Räddningstjänst övningsfält.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen S0005B motsvarar kursen ABS130

## Övrigt

Vissa kostnader i samband med kursveckorna utanför Porsön står den enskilde studenten för.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Rapport | UG | 3 | Obligatorisk | V27 |  |
| 0004 | Praktiska övningar | UG | 4,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-01-11

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
