---
kurskod: "V0016B"
titel: "VA-system"
hp: "7,5"
titel_en: "Urban Water systems"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2009-01-20"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "GU345"
amne: "VA-teknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=V0016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=V0016B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/v00/v0016b-va-system"
---

# VA-system (V0016B)

## Ingår i huvudområde

Naturresursteknik, Samhällsbyggnadsteknik, Väg- och vattenbyggnad

## Behörighet

Grundläggande behörighet samt Universitetskurser motsvarande 60 Hp som inkluderar minst 7,5 Hp matematik, t ex M0047M Differentialkalkyl, och 7.5 hp fysik t ex F0004T Fysik 1, samt grundläggande kunskaper i Hydraulik, t ex V0014B Hydraulik och geologi eller motsvarande.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter fullgjord kurs ska studenten kunna:

Kunskap och förståelse

1. beskriva VA-system och kunna förklara funktionen av dess komponenter, 2. beskriva olika berednings/behandlingsprocesser på vatten- och reningsverk och kunna förklara vad de uträttar, 3. beskriva vilka kvalitetsskillnader som det finns mellan olika typer av vatten,

Färdighet och förmåga 4. utföra hydrauliska beräkningar för strömning i rör, 5. dimensionera ledningar, pumpar och vattenmagasin för VA-system, 6. beräkna dagvattenflöden med ”rationella metoden” och ”Tid-area-metoden” 7. referera till referenser i löpande text enligt gängse metoder för teknisk-vetenskaplig sektor och presentera insamlad data i ändamålsenliga diagram.

Värderingsförmåga och förhållningssätt 8. ge exempel på för- och nackdelar för olika VA-lösningar utifrån tekniska aspekter och reflektera över hållbarhetsaspekter, och relatera dessa lösningar till FNs globala mål för hållbar utveckling.

## Kursinnehåll

Den här kursen ger dig en övergripande bild över hur vatten- och avloppssystemet ser ut och hur det har utvecklats över tid. Du får kunskap om hur svenska samhällen försörjs med dricksvatten och hur avloppsvatten tas om hand. Du lär dig att göra hydrauliska beräkningar på ledningsnät och även hur vatten- och avloppsledningsnät dimensioneras. Du lär dig att dimensionera andra komponenter i distributionssystemet för dricksvatten, tex reservoarer och pumpar. Du får även möjlighet att bredda dina kunskaper om vatten- och avloppssystem, tex om hur vatten- och avloppsförsörjningen går till på landsbygden, eller hur nya typer av ledningsnät, exempelvis vakuumsystem, fungerar. I kursen finns tillfälle att göra vattenkvalitetanalyser och möta och samtala med VAingenjörer som jobbar i branschen.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Genom föreläsningar, instuderingsuppgifter och litteraturstudier inläses grundläggande systemkunskap under kursens gång. Beräkningskunskaper fås genom att delta på föreläsningar som inkluderar räkneövningar samt genom att på egen hand lösa räkneuppgifter och arbeta med en större beräkningsuppgift. Beräkningsuppgiften görs i grupp och redovisas skriftligt och muntligt och obligatorisk närvaro gäller för redovisningstillfället. För att få en större förståelse för vattenkvalitet och hur data kan presenteras genomförs en laborationsövning i små grupper. En laborationsrapport skrivs och datapresentationen och diskussionen av data bedöms i denna uppgift. En litteraturuppgift genomförs i ett projektarbete för bredare förståelse för VA-system och hållbarhetsaspekter knutna till dessa. I denna uppgift introduceras även referensmetoder i text som övas på i litteraturrapporten. Litteraturuppgiften redovisas med en skriftlig rapport, där förutom innehåll, även refereringen bedöms, samt med en muntlig obligatorisk redovisning.

För att ytterligare belysa olika aspekter för hållbar utveckling av VA-system hålls ett seminarium. För godkänt på laborationen och seminariet krävs ett aktivt deltagande. Dessa moment är obligatoriska.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Grundläggande systemkunskap (Mål 1 och 2) examineras med tentamen (#0018) i slutet på kursen. Beräknings- och dimensioneringskunskaper (mål 4-6) examineras med en skriftlig deltentamen (#0017) under kursen. Båda dessa tentamina bedöms enligt graderade betygsskalor. Fördjupande beräknings- och dimensioneringskunskaper (mål 5-6) examineras genom en beräkningsuppgift (#0015) som redovisas skriftligen och muntligen och bedöms enligt en graderad betygsskala. Litteraturuppgiften (#0010) examinerar målen som rör en bredare förståelse för VA-systemets funktion och uppbyggnad samt hur man refererar i text (mål 1, 2, 7 och 8) och den skriftliga rapporten bedöms enligt en graderad betygsskala. Laborationen (#0016) bedöms U/G och examinerar målen som rör vattnets kvalitet, och datapresentation (mål 3 och 7). Seminariet (#0014) examinerar målen som rör en bredare förståelse för VA-systemets funktion och för- och nackdelar med olika typer av lösningar (mål 1, 8).

För erhållande av slutbetyg krävs att alla moment är slutförda samt även aktiv och obligatorisk närvaro på genomförd laboration samt obligatorisk närvaro vid seminarium och redovisningar av beräknings- och litteraturuppgifterna. Såvida man inte deltar vid något av de schemalagda fältövningstillfällena får laborationen genomföras annat läsår, i mån om plats.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0010 | Projektuppgift | GU345 | 1 | Obligatorisk | H09 |  |
| 0015 | Beräknngsuppgift | GU345 | 1,7 | Obligatorisk | H09 |  |
| 0017 | Deltentamen | GU345 | 3 | Obligatorisk | H09 |  |
| 0018 | Tentamen | GU345 | 1,3 | Obligatorisk | H09 |  |
| 0019 | Laboration och presentation | UG | 0,3 | Obligatorisk | V27 |  |
| 0020 | Seminarium | UG | 0,2 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Institutionen för Samhällsbyggnad 2009-01-20
