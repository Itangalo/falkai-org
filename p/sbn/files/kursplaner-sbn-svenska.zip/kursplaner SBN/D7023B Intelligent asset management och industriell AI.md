---
kurskod: "D7023B"
titel: "Intelligent asset management och industriell AI"
hp: "3"
titel_en: "Intelligent Asset Management and Industrial AI"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7023B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7023B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7023b-intelligent-asset-management-och-industriell-ai"
---

# Intelligent asset management och industriell AI (D7023B)

## Behörighet

Kurser om minst 90 hp i tekniska ämnen eller motsvarande reella kompetens erhållen genom praktiska erfarenheter. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2. Läs mer om hur du ansöker om reell kompetens via denna länk: https://www.ltu.se/studentwebben/dina-studier/reell-kompetens

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter genomgången kurs ska deltagarna kunna:

- beskriva termerna eMaintenance och Industrial AI

- förstå grunderna för förvaltning och underhåll av tillgångar

- analysera avancerade dataanalystekniker relaterade till drift- och underhållsprocesser i industriella sammanhang

- demonstrera AI och digitalisering i industriella sammanhang

## Kursinnehåll

Denna kurs omfattar:

- Förstå begreppen eMaintenance och Industrial AI

- Förstå grunderna för tillgångsförvaltning och underhåll

- Industriell AI för tillgångsförvaltning och underhåll

- Fallstudier och praktiska tillämpningar inom industriella domäner

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen kombinerar online- och personliga sessioner i ett hybridformat. Leveransmetoder inkluderar föreläsningar, uppgifter, laboratorier och analyser av verkliga fallstudier

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen inkluderar både formativa bedömningar (för lärande) och summativa bedömningar (av lärande). De summativa bedömningarna, i form av uppgifter och rapporter, examinerar de angivna lärandemålen, medan de formativa bedömningarna (klassdiskussioner, reflektioner, quiz, grupparbeten, återkoppling) stödjer lärandet.

För att klara kursen måste tre uppgifter slutföras. För att klara varje uppgift måste studenten först demonstrera sin lösning för den tilldelade handledaren, helst under den löpande sessionen eller sammanfattningssessionen för den uppgiften. Efter godkänd demonstration lämnas filerna in via Canvas. Handledaren granskar filerna och markerar uppgiften som godkänd eller begär en revidering.

Slutbetyget (3, 4 eller 5) baseras på medelbetyget för de tre uppgifterna, där varje uppgift har lika vikt.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 3 | Obligatorisk | V26 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
