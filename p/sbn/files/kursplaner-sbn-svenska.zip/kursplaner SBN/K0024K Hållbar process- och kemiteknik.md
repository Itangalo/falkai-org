---
kurskod: "K0024K"
titel: "Hållbar process- och kemiteknik"
hp: "7,5"
titel_en: "Sustainable Process and Chemical Engineering"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2022-02-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Kemiteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0024K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0024K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0024k-hallbar-process--och-kemiteknik"
---

# Hållbar process- och kemiteknik (K0024K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Grundläggande behörighet + Fysik 2, Kemi 1, Matematik 4 eller Matematik E. Eller: Fysik nivå 2, Kemi nivå 1, Matematik fortsättning nivå 2 (äldre kurs Matematik E).

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter genomgången kurs ska studenten kunna ge exempel på

- betydelsen av hållbarhetsperspektiv inom process- och kemiteknisk industri.

- behovet av kemi- och processteknisk kompetens för att kunna uppnå en ökad hållbarhet inom samhället.

- den forskning inom det process- och kemitekniska området som bedrivs i syfte att uppnå ett hållbart samhälle.

- ingenjörens roll och ansvar för en hållbar utveckling i sin professionsutövning.

- olika etiska aspekter inom arbetsliv och forskning inklusive jämställdhetsperspektiv.

Studenten ska även

- kunna redogöra för och kritiskt förhålla sig till de globala hållbarhetsmålen, deras bakgrund, dess olika nutida definitioner, yttringar och etiska utgångspunkter

- ha genomfört och presenterat en projektuppgift med hållbarhetsperspektiv inom det process- eller kemitekniska området enligt uppställda ramar, inklusive förberedande informationssökning.

- ha deltagit i arbetet med det skriftliga redovisandet och därigenom uppnått grundläggande färdighet i rapportskrivning.

## Kursinnehåll

- Föreläsningar inom de områden som fordras för att nå kursens målsättningar.

- Gästföreläsningar.

- Studiebesök till företag inom process- och kemitekniska området.

- Introduktion till informationssökning.

- Projektgenomförande och redovisning.

- Etik och jämställdhetsfrågor.

- Eget arbete med examinerande inlämningsuppgifter baserade på föreläsningsmaterial, däri inkluderande etik- och jämställdhetsfrågor.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Föreläsningar med fokus mot hållbar utveckling.

Inom ramen för projektuppgiften ingår litteratursökning, muntlig och skriftlig presentation av projektuppgift.

Studenterna tränas i att självständigt planera och utföra ett projektarbete samt att skriftligt och muntligt redovisa arbetsgång och resultat.

Studiebesök. Resa med övernattning utanför Luleå kan ingå.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Modulen studiebesök (0001) syftar till att bidra till uppfyllandet av de fem första punkterna av kursens mål, modulen inlämningsuppgifter (0002) examinerar de sex första målen. Projektarbeten (0003) examinerar de tre första samt de två sista målen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Obligatorisk närvaro vid

- kursstart.

- studieresa

- projektintroduktion och projektredovisning

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0004 | Studiebesök | U G# | 1 | Inaktiv | H18 |  |
| 0005 | Projekt | U G# | 4 | Inaktiv | H18 |  |
| 0006 | Inlämningsuppgifter | U G# | 2,5 | Inaktiv | H18 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2018-02-13
