---
kurskod: "K7016B"
titel: "Hallbyggnader"
hp: "7,5"
titel_en: "Industrial Buildings"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2022-11-03"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Konstruktionsteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7016B&lasPeriod=213&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7016b-hallbyggnader"
---

# Hallbyggnader (K7016B)

## Behörighet

Kunskaper i
- byggnadsmaterial motsvarande kursen K0002B byggnadsmaterial
- hållfasthetslära och byggnadsmekanik motsvarande kurserna B0002B konstruktionsteknik och B7004B Byggnadsmekanik I
- byggkonstruktion motsvarande kurserna K0013B byggkonstruktion eller W7006B Konstruktionslära

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten
- kunna förklara verkningssättet hos de vanligaste konstruktiva lösningarna för hallbyggnader
- förstå skillnaden mellan primär- och sekundärbärverk och kunna dimensionera vanligt förekommande komponenter
- kunna frilägga konstruktionselement från en komplicerad bärande struktur
- kunna sätta samman en hallbyggnad med ett stabiliserande system och kunna utforma och dimensionera detta system
- ha förståelse för knutpunkters utformning och verkningssätt

## Kursinnehåll

- Bärverk: Konstruktion av enkla och avancerade moment-, normalkrafts- och tvärkraftsbelastade takstolar, skivor, balkar och pelare.         Stomstabilisering med skivverkan, fackverk och ramverk.
- Förband: utformning och konstruktion av knutpunkter och förband.
- Konstruktionssystem: utformning, dvs. dimensionering och sammanfogning av enskilda element till strukturer, och vilken teknisk effekt olika val får på slutprodukten.
- Systemförståelse och systemdesign: träning i holistisk systemdesign av stora konstruktionssystem, hur valt system påverkar byggbarheten, samt att kunna dimensionera det stabiliserande systemet i en hallbyggnad.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen omfattar två uppgifter med föreläsningar som stöd för genomförandet av

uppgifterna.

Den första uppgiften utförs individuellt och omfattar dimensionering av en traverskranbana inklusive bärande pelare i stål.

Den andra uppgiften genomförs som ett projektarbete i grupper om två till tre personer där bärverk inklusive stabiliserande system till en hallbyggnad i trä dimensioneras. I projektarbetet tränas utvärdering av olika tekniska lösningar mot varandra och val av lösningar som är konstruktionstekniskt sunda och byggtekniskt realiserbara.

Båda uppgifterna redovisas skriftligt enligt rådande praxis för redovisning av konstruktionsberäkningar (beräkningsrapport och ritningar). Projektarbetet redovisas även muntligt.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Individuell konstruktionsuppgift med skriftlig redovisning: U, 3, 4, 5 Projektarbete i grupp med muntlig och skriftlig redovisning: U, 3, 4, 5 Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Kursen ersätter delar av W7005B Träbyggnad och kan inte kombineras med denna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Konstruktionsuppgift | GU345 | 3 | Obligatorisk | H19 |  |
| 0002 | Projektarbete | GU345 | 4,5 | Obligatorisk | H19 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-11-03

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-02-14
