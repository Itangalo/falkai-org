---
kurskod: "C7001B"
titel: "Trafik för en attraktiv stad"
hp: "7,5"
titel_en: "Traffic in the city"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Trafikteknik"
amnesgrupp_scb: "Samhällsbyggnadsteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=C7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=C7001B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/c70/c7001b-trafik-for-en-attraktiv-stad"
---

# Trafik för en attraktiv stad (C7001B)

## Ingår i huvudområde

Arkitektur

## Behörighet

Grundläggande kunskaper i urban planering (F0002B Urban design) eller motsvarande, samt rapportskrivning och muntlig framställan (V0015B Hållbart byggande) eller motsvarande.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten

Kunskap och förståelse

- ha kunskap om

    - grundläggande trafiktekniska begrepp

    - grunderna för dimensionering av trafiksystem för olika trafikslag

    - trafikstrategier för tätorter

Färdighet och förmåga

- kunna

    - genomföra, tillämpa och utvärdera trafikstrategi för tätorter

    - samverka i grupp med olika sammansättningar och presentera sina resultat muntligen och skriftligt för kollegor

Värderingsförmåga och förhållningssätt

- ha förståelse för helhetstänkande om trafikteknik i samhällsbyggnad

## Kursinnehåll

Arbeta med trafikstrategi för tätorten med stöd av handboken TRAST. Systematisk litteraturinventering baserad på vetenskapliga källor. Samhällsekonomiska kalkyler och kapacitet och framkomlighet i korsningar. Kursen behandlar främst tätortens trafik, trafik utanför tätorten behandlas översiktligt. Kursen behandlar:

- Stadens karaktär
- Resor och transporter, vart och varför reser man
- Säkerhet, tillgänglighet och trygghet
- Gångtrafik, Cykeltrafik, Mopedtrafik
- Kollektivtrafik
- Bytespunkter, järnvägsstationer
- Biltrafik

Godstrafik och uttryckningstrafik behandlas i den här kursen översiktligt som en del av biltrafik. Kursen inleds med ett teoretiskt arbete. Individuella instuderingsfrågor används för att snabbt komma in i litteraturen. Efter detta följer projektarbete och laborationer om dels samhällsekonomiska kalkyler och dels kapacitet och framkomlighet i korsningar.

Därefter följer fältövning och analys, samt individuella litteraturstudier. Arbetet resulterar i en individuell skriftlig rapport som presenteras och diskuteras.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. I kursen genomförs föreläsningar, seminarier, laborationer och fältövning/inventering. Kursen inleds med föreläsningar och seminarier. I kursen tränas muntlig/skriftlig presentation, projektarbete, grupparbete/samarbete, i arbete med öppna problemställningar. Syftet med projektuppgiften är att ge studenterna möjlighet att arbeta med trafikstrategi för tätorten.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:

Kursen examineras med 80 % deltagande i föreläsningar samt aktivt deltagande i muntliga redovisningar/seminarier, aktivt deltagande i fältövning/inventering. Lärandemålen under kunskap och förståelse examineras genom individuella skriftliga projektuppgifter. Lärandemålen under färdighet och förmåga examineras genom skriftligt och muntligt grupparbete. Lärandemålen för värderingsförmåga och förhållningssätt examineras genom individuella skriftliga projektuppgifter med graderat betyg.

Obligatorisk närvaro vid lektioner, muntliga redovisningar/seminarier och fältövning/inventering

Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Språk: svenska.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Muntlig och skriftlig framställan projektarbete | GU345 | 1,5 | Obligatorisk | H07 |  |
| 0006 | Projektarbetet, del 1 | UG | 2 | Obligatorisk | V27 |  |
| 0007 | Föreläsningar | UG | 1 | Obligatorisk | V27 |  |
| 0008 | Fältövning, inventering | UG | 1 | Obligatorisk | V27 |  |
| 0009 | Projektarbetet, del 2 | UG | 2 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
