---
kurskod: "T7009K"
titel: "Avancerad kemisk reaktionsteknik"
hp: "7,5"
titel_en: "Advanced Chemical Reaction Engineering"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2019-11-05"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Kemisk teknologi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7009K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7009K&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7009k-avancerad-kemisk-reaktionsteknik"
---

# Avancerad kemisk reaktionsteknik (T7009K)

## Behörighet

90hp i kemiteknik samt kursen T0006K Grundläggande kemisk reaktionsteknik.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Studenten skall efter avslutad kurs:
- ha fördjupad kunskap om de teoretiska grunderna för att kunna välja och dimensionera reaktorer och geometrisk storlek på katalysatorpartiklar för kemiska processers genomförande samt för att bestämma driftsätt och optimering av dessa reaktorer.
- kunna redogöra för de olika processer som begränsar reaktionshastigheten samt hur begränsningarna av dessa processer minimeras.
- kunna redogöra för de olika kinetiska regimerna i multifasreaktorer samt kunna välja lämplig reaktortyp på baserat på information om kinetisk regim.
- kunna matematiskt beskriva och samt lösa avancerade problem inom reaktionstekniken omfattande bl.a. reaktioner med kopplad mass- och värmetransport samt icke-ideala reaktorer.

## Kursinnehåll

Strömningsförhållande i reella reaktorer, växelverkan mellan kemiska reaktioner och fysikaliska transportprocesser, transportprocesser kopplade med kemisk reaktion i system med fast katalysator, masstransport och kemisk reaktion i gas-vätskesystem samt bioreaktorer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av lektioner, räkneövningar och ett projektarbete. Lektionerna belyser den viktigaste teorin bakom kemisk reaktionsteknik. Under räkneövningarna går läraren igenom hur de vanligaste typerna av problem löses. Obligatoriska inlämningsuppgifter som utförs i mindre grupper tränar studenten i matematisk modellering av reaktorer/reaktorsystem, lösning av de erhållna modellerna, analys av resultatet samt muntlig presentation. Projektarbetet innefattande modellering och analys av reaktorer med kopplad masstransport – reaktion, ställer studenterna inför problem med osäkra data såsom ofta är fallet i industrin. Projektet tränar studenten i skriftlig presentation eftersom det presenteras som en skriftlig teknisk rapport. 1:a lektionen är obligatorisk för alla studenter.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Examinationen består av inlämningsuppgifter, projektuppgift samt skriftlig tentamen. På momenten inlämningsuppgifter och projekt ges betyget godkänd – icke godkänd, dessa moment examineras kontinuerligt under kursens gång (stoppdatum). På tentamen ges betyg enligt skalorna U(underkänd) 3, 4 och 5. Student som underkänts vid fem provtillfällen har ej rätt att genomgå ytterligare prov.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen T7009K motsvarar kursen T7002K

## Övrigt

Kursen ges på avancerad nivå och ingår i avslutningen i förnybara produkter och bränslen på civilingenjörsprogrammet i Industriell miljö- och processteknik. Studiehandledning återfinns i Canvas i aktuellt kursrum.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 3 | Obligatorisk | H17 |  |
| 0002 | Inlämningsuppgifter | U G# | 3 | Obligatorisk | H17 |  |
| 0003 | Projekt | U G# | 1,5 | Obligatorisk | H17 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2019-11-05

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2017-02-13
