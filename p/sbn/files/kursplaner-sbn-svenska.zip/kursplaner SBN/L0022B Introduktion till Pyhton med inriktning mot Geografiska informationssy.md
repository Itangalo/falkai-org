---
kurskod: "L0022B"
titel: "Introduktion till Pyhton med inriktning mot Geografiska informationssystem (GIS)"
hp: "7,5"
titel_en: "Introduction to Python with a focus on Geographic Information Systems (GIS)"
giltig: "Höst 2025 Lp 1 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Geografisk informationsteknologi"
amnesgrupp_scb: "Geografisk informationsteknik och lantmäteri"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0022B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0022B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0022b-introduktion-till-python-med-inriktning-mot-geografiska-informationssystem-gis"
---

# Introduktion till Pyhton med inriktning mot Geografiska informationssystem (GIS) (L0022B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter avslutad kurs ska studenterna kunna: 1. Förstå hur Python-syntax och strukturer tillämpas för skriptning och automatisering av uppgifter i GIS-miljöer. 2. Tillämpa Python-programmeringstekniker för att bearbeta och analysera både raster- och vektordata i GIS. 3. Analysera geografiska data genom att skriva algoritmer för att identifiera mönster, trender och samband i rumsliga dataset. 4. Utvärdera prestanda och effektivitet hos olika algoritmer för att lösa GIS-relaterade problem. 5. Skapa egna skript och algoritmer för att samla in, lagra, analysera och presentera geografisk information som svar på verkliga problem inom GIS.

## Kursinnehåll

I kursen ges en introduktion till grundläggande Pyhton-programmering, algoritm-programmering, scriptprogrammering samt övriga grundläggande Python-programmeringsdelar relaterade till GIS-applikationer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Allt kursmaterial och programvaror finns under LTU’s Citrixportal och där hittas mer detaljerade beskrivningar över kursens innehåll och dess genomförande. Det finns inga inspelade föreläsningar och det är inte några obligatoriska sammankomster. Föreläsningar ges i textform.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursens mål examineras med inlämningsuppgifter som görs individuellt eller i grupp om två personer och examineras under kursens gång. Betygssättning av inlämningsuppgifter sker enligt betygsskala U/G. Samtliga inlämningsuppgifter ska vara avklarade för slutbetyg. Inlämningsuppgifterna finns under LTU’s Citrixportal.

hp                                                                                   Lp1

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G# | 7,5 | Obligatorisk | H25 |  |

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
