---
kurskod: "G7002B"
titel: "Projektkurs i geoteknik, fördjupning"
hp: "7,5"
titel_en: "Senior Design Project in Soil Mechanics and Foundation Eng"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2023-06-02"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "U G#"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7002B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7002b-projektkurs-i-geoteknik-fordjupning"
---

# Projektkurs i geoteknik, fördjupning (G7002B)

## Behörighet

Minst 60 hp inom området Väg- och vattenbyggand, där kursen G0003B Geoteknik gk eller motsvarande ska ingå. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2. För utbytesstudenter gäller att examinator gör individuell prövning av behörigheten beroende på typ av projekt.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Målet är att studenten självständigt skall utforma och genomföra ett projekt.

Du skall kunna:
- Väsentliga delar av det kursmaterial som överenskommits mellan examinator och student.
- Arbeta självständigt med att inhämta och förstå material från olika källor
- Värdera olika kunskapskällor
- Sammanställa den inhämtade kunskapen på ett strukturerat sätt.
- Utforma en skriftlig rapport om det inhämtade materialet
- Presentera materialet och rapporten muntligt

## Kursinnehåll

Avgörs från fall till fall i samråd med studenterna som läser kursen.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Självständigt projektarbete med stöd av examinator eller en handledare som utsetts av examinator.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Bedömning av inlämningsuppgift.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i

förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen G7002B motsvarar kursen ABG106

## Övrigt

Kursen utformas i samråd med den eller de studenter som önskar fördjupa sig i någon del av geotekniken.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgift | U G# | 7,5 | Obligatorisk | H07 | Ja |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
