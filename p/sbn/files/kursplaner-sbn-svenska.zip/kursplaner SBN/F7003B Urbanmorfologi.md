---
kurskod: "F7003B"
titel: "Urbanmorfologi"
hp: "7,5"
titel_en: "Urban Morphology"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-11-02"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7003B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7003B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/f70/f7003b-urbanmorfologi"
---

# Urbanmorfologi (F7003B)

## Ingår i huvudområde

Arkitektur

## Behörighet

Kunskaper motsvarande kurs F0002B Urban design. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursen ger grundkunskaper om teorier för stadsform, bebyggelsemönster, stadsplanering och stadsutveckling nationellt och internationellt.

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

- Beskriva urbanmorfologiska teorier för stadsform, stadsplanering, stadsutveckling och urban design.

Färdighet och förmåga

- Analysera en stadsmiljö genom ett urval av urbanmorfologiska teorier.

- Presentera stadsmiljöanalysen muntligt, samt genom text och illustrationer.

- Sammanfatta urbanmorfologiska teorier i en litteraturöversikt.

Värderingsförmåga och förhållningssätt

- Reflektera över och förklara hur stadsutveckling sker ur ett urbanmorfologiskt perspektiv.

## Kursinnehåll

Kursen behandlar urbanmorfologiska teorier avseende historiska, sociala och ekonomiska dimensioner i stadsbyggnad- och stadsutveckling.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, litteraturseminarier, projektarbete, och handledningstillfällen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursen mål examineras genom seminarier och en projektuppgift. För att bli godkänd på seminarierna (U/G) krävs aktivt deltagande samt godkänd skriftlig litteraturuppgift. För att bli godkänd på projektarbetet krävs aktivt deltagande, samt godkänd muntlig, skriftlig, och illustrerad redovisning och bedöms med graderad betygsskala.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektuppgifter | GU345 | 6 | Obligatorisk | H07 |  |
| 0003 | Seminarier | UG | 1,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-11-02

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
