---
kurskod: "M7012K"
titel: "Offentliggörande av mineralresurser och tillståndsprocesser"
hp: "7,5"
titel_en: "Mineral Resource Disclosure and Permitting Processes"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2023-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Mineralteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M7012K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M7012K&lasPeriod=212&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/m70/m7012k-offentliggorande-av-mineralresurser-och-tillstandsprocesser"
---

# Offentliggörande av mineralresurser och tillståndsprocesser (M7012K)

## Behörighet

60 hp i geovetenskap, gruvteknik, processteknik eller liknande områden eller motsvarande kunskaper från mångårig praktisk arbetslivserfarenhet (minst 5 år).Styrks med intyg från arbetsgivare. Goda kunskaper i engelska, motsvarande Engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursen syftar till att skapa kännedom om lagstiftning som är relevant för gruvutveckling och gruvproduktion och om uppskattning och rapportering av mineraltillgångar. Efter fullgjord kurs skall studenten kunna:

- Känna till och kunna redogöra för begreppen miljö- och sociala konsekvensbedömningar och förstår tillståndsförfarandena (inklusive ESIA och intressenternas engagemang)

- Upprätta delar av den tekniska dokumentationen för bedömning av potentiell miljöpåverkan från gruvdrift och mineralanrikning

- Beskriva olika metoder som används vid uppskattning av mineraltillgångar och förklara etablerade rapporteringsstandarder och rutiner för information om mineraltillgångar

- Utföra en enklare uppskattning av mineraltillgångar

## Kursinnehåll

Denna kurs omfattar:

Gruvrelaterad lagstiftning

- Nordisk, EU och internationell miljölagstiftning

- Lagstiftning relaterad till markförvaltning, fysisk planering och naturresurser

- Prospekterings- och gruvtillstånd

Social- och miljökonsekvensbedömning

- Förutsättningar och rutiner

- Teknisk projektbeskrivning och tillståndsansökan

- Krav på samråd, mänskliga och urbefolkningars rättigheter, SLO

Mineraltillgångar och rapportering

- Blockmodellens grunder och databas för uppskattning av mineraltillgångar

- Internationella rapporteringsstandarder

- Geometallurgisk blockmodellering

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar som kombineras med inlämningsuppgifter och ett mindre projekt.

Föreläsningar ska ge studenterna kunskap och förståelse för olika gruvrelaterade lagstiftningar och rutiner i tillståndsprocessen samt rapportering av mineraltillgångar.

Inlämningsuppgifterna och projektet ska träna studenten att självständigt bearbeta och fördjupa utvalda delområden.

Seminarier ägnas åt att i grupp beskriva, analysera, tolka och presentera ett komplext ämne inom det tematiska området.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Inlämningsuppgifter samt seminarier och projekt är obligatoriska. Inlämningsuppgifter och projekt bedöms med poäng i dessa delar. Seminarier betygsätts godkänd/ej godkänd. Den totala poängproduktionen ger totalbetyget för kursen , som ges med graderade betyg i skala 3 4 5.

Obligatorisk närvaro vid första lektionstillfället. Tillstånd att vara frånvarande ges av kursansvarig lärare.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | GU345 | 3 | Obligatorisk | H23 |  |
| 0002 | Seminarier | U G# | 2 | Obligatorisk | H23 |  |
| 0003 | Prejekt | GU345 | 2,5 | Obligatorisk | H23 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-02-13
