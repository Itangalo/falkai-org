---
kurskod: "M0002K"
titel: "Miljöanalys"
hp: "7,5"
titel_en: "Environmental Analysis"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Miljöteknik"
amnesgrupp_scb: "Miljövård och miljöskydd"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M0002K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M0002K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/m00/m0002k-miljoanalys"
---

# Miljöanalys (M0002K)

## Behörighet

Grundläggande behörighet samt Behärskande av lösningsjämvikter i naturliga vatten motsvarande vad som ingår i kursen K0006K, Vattenkemi.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursen syftar till att skapa kännedom om olika befintliga verktyg för värdering av miljökonsekvenser, energiförbrukning, mm, beroende på olika processval, materialval etc, samt att kritiskt kunna granska de resultat som erhålls.

Efter fullgjord kurs skall eleven kunna:

- redogöra för tillvägagångssättet i livscykelanalys och miljökonsekvensbeskrivningar,

- beskriva hur geografiska informationssystem används för att ta fram planeringsdata,

- utföra enklare livscykelanalys,

- upprätta delar av tekniskt underlag för bedömning av potentiell miljöpåverkan,

- redogöra för och kritiskt förhålla sig till begreppet hållbar utveckling på nationell och global nivå; hur det uppstått, utvecklats över tiden, dess olika nutida definitioner, yttringar och etiska utgångspunkter,

- förklara vilka ekonomiska rättsliga och politiska styrmedel som finns, såväl nationellt som internationellt och kunna kritiskt förhålla sig till deras utformning, begränsningar och tillämpningar visavi en hållbar utveckling av samhället generellt och teknikens utveckling och tillämpning specifikt.

- Visa förmåga att utveckla och utforma produkter, processer och system med hänsyn till människors förutsättningar och behov och samhällets mål för ekonomiskt, socialt och ekologist hållbar utveckling

## Kursinnehåll

Kursen behandlar:

Livscykelanalys.

- Teoretiska aspekter på LCA: vilken typ av grunddata krävs, vilka antagande görs, hur påverkar detta resultatet av LCA?

- PC-lektioner och PC-laborationer

Geografiska informationssystem.

- Vad innebär GIS, hur hanteras och utvinns information.

- PC-lektioner och en PC-laboration

Miljökonsekvensbeskrivningar.

- När och hur upprättas MKB, vilket tekniskt underlag krävs, hur definieras samhällets intressen.

- Social konsekvensbeskrivning

- Rättssystemet kring miljöfrågor och MKB

- Projekt

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, PC-lektioner, PC-laborationer och ett stort projekt.

Föreläsningarna skall ge möjlighet för eleverna att kunna planera och utföra enklare analyser samt att kunna redogöra för teoretiska begrepp.

PC-lektionerna ägnas åt att träna beräkningsprocedurer och tekniker.

PC-laborationerna utförs gruppvis och introducerar inlämningsuppgifterna, som görs klara senare, och som tränar eleven att i grupp planera och utföra livscykelanalys och GIS-arbete samt att rapportera resultaten i tekniska sammanställningar.

Projektet ägnas åt att i grupp beskriva, analysera, utvärdera, tolka, rapportera och presentera resultat för MKB utifrån ett processtekniskt datamaterial. Projektet avrapporteras vid två seminarietillfällen, där det första ägnas åt att inför andra grupper redogöra för datamaterialet och det planerade arbete. Grupperna får inför MKB företräda olika intressen: företag, samhälle, myndigheter etc, och skall utifrån dessa roller författa olika underlag och partsinlagor. Det andra seminariet ägnas åt redovisning av det utförda arbetet i form av en simulerad miljöprövning och där de olika grupperna får representera sina intressenter. Inlämningsuppgifter och projektrapporten skall vara tekniskt, statistiskt och språkligt korrekta.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Inlämningsuppgifter, projektuppgift och seminarier är obligatoriska. Inlämningsuppgifter, seminarier och projekt bedöms med poäng inom dessa delar. Uppgifter och rapporter skall inlämnas inom föreskriven tid i annat fall sker avtrappning av max uppnåbara poäng på momentet. Den totala poängproduktionen ger totalbetyget för kursen, som ges med graderade betyg i skala U G 3 4 5.

- För betyg 3 skall eleven kunna beskriva procedurer för och utföra rutinmässiga livscykelanalyser, GIS-extraktioner samt kunna beskriva gången i MKB.

- För betyg 4 skall eleven kunna utvärdera och tolka LCA och GIS-data samt kunna redovisa resultat från MKB.

- För betyg 5 skall eleven kunna tillämpa sina kunskaper på ett nytt datamaterial, tolka, rapportera och presentera resultatet samt försvara sina slutsatser.

Obligatorisk närvaro vid första lektionstillfället.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Obligatorisk närvaro vid första lektionstillfället.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Inlämningsuppgifter | GU345 | 4,5 | Obligatorisk | V15 |  |
| 0004 | Projekt | GU345 | 3 | Obligatorisk | V15 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2011-02-04
