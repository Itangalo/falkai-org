---
kurskod: "Y0010B"
titel: "Bygg och anläggning VFU"
hp: "15"
titel_en: "Civil Engineering, Practical Studies"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "UG"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=Y0010B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=Y0010B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/y00/y0010b-bygg-och-anlaggning-vfu"
---

# Bygg och anläggning VFU (Y0010B)

## Behörighet

Grundläggande behörighet samt 75 hp påbörjade studier på högskoleexamen, Bygg och anläggning.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

Beskriva verksamheten och de arbetsuppgifter som utförs vid arbetsplatsen.

Beskriva hur lokalt arbetsmiljöarbete bör bedrivas ute på arbetsplatsen.

Beskriva olika jämställdhetsperspektiv på arbetsplatsen.

Färdighet och förmåga

Delta i arbetsplatsens dagliga verksamhet och utföra tillhörande arbetsuppgifter.

Utvärdera hur lokalt arbetsmiljöarbete bedrivs ute på arbetsplatsen.

Värderingsförmåga och förhållningssätt

Utvärdera och beskriva arbetsplatsen utifrån ett jämställdhetsperspektiv.

## Kursinnehåll

Den verksamhetsförlagda utbildningen (VFUn) genomförs på ett företag, kommun, myndighet, eller liknande arbetsplats med anknytning till utbildningen. Följande kursmoment ingår:

Söka en individuell VFU-plats.

Planera VFU-arbete.

Delta i arbetsplatsens dagliga arbete i en yrkesmässig befattning.

Uppgift under VFUn: Utvärdera arbetsplatsen med avseende på arbetsmiljö och jämställdhet. Arbetet redovisas i form av en skriftlig rapport.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av självständiga studier med stöd av handledare/examinator från universitetet samt extern handledare på arbetsplatsen. Genomförandet utformas i anslutning till planeringen av VFUn.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:

Projektplan.

Intyg på genomförd VFU.

Skriftlig rapport.

Betygssättning sker enligt betygsskala G U. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen Y0010B motsvarar kursen Y0007B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Inlämningsuppgift | UG | 6 | Obligatorisk | V27 |  |
| 0004 | Fullgjort arbetsplatsförlagd period | UG | 9 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-02-14
