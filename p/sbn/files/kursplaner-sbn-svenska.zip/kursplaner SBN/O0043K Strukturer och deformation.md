---
kurskod: "O0043K"
titel: "Strukturer och deformation"
hp: "7,5"
titel_en: "Structures and Deformation"
giltig: "Höst 2025 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2025-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Malmgeologi"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=O0043K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=O0043K&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/o00/o0043k-strukturer-och-deformation"
---

# Strukturer och deformation (O0043K)

## Behörighet

Grundläggande behörighet samt O0041K Geovetenskap eller motsvarande kurs. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Kursens mål är att studenten genom studier av geologisk deformerade bergarter

1. ska kunna identifiera de vanligaste geologiska strukturerna,

2. förklara hur dessa strukturer bildats,

3. genomföra fältförsök med beprövade metoder samt med analytiska, empiriska och numeriska metoder utvärdera berg- och sprickparametrar samt bergmassans kvalitet

4. visualisera strukturgeologiska mätdata och identifiera strukturellt styrda brottformer i bergslänter och undermarkskonstruktioner med hjälp av sfärisk projektion och ingenjörsgeologiska beskrivningar av bergmassan, och där möjligt kunna beräkna säkerheten mot brott

5. redogöra för och diskutera skriftligt sina analyser, modeller, resultat och slutsatser

## Kursinnehåll

- Strukturgeologi – Bergskedjabildande processer, stress och strain, sekundära strukturer i berggrunden som deformationszoner och veckning, mätning av strukturer i fält.

- Materialet berg – Teoretiskt och praktiskt arbeta med bergmekanisk förundersökning och bergmasseklassificering, geologiska strukturer i berg och deras betydelse för det mekaniska beteendet, strukturstyrda brott, sfärisk projektion, insamling och analys av fältdata, presentation av ingenjörsarbete och fältdata, etc.

- Släntstabilitet - Strukturstyrda brottformer i slänter, cirkulärt skjuvbrott i slänt, stabilitetsanalyser av slänter, säkerhetsfaktor, effekten av grundvattentryck och effekten av dränering.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

- Lektioner - De är en mix av flera undervisnings-/inlärningsaktiviteter: (i) kort teorigenomgång där föreläsaren förklarar de viktigaste teoretiska aspekterna relaterade till kursens innehåll och (ii) tillsammans lösa och/eller diskutera typiska problem samt frågor vilket ger dig möjlighet att på olika sätt arbeta med flera aspekter kring empiriska och analytiska stabilitetsanalyser av olika underjordskonstruktioner i berg ur en praktisk och teoretisk synvinkel samt träna beräkningsprocedurer för frågeställningar relaterade till dessa.
- Datorövningar - Under dessa arbetar vi i datasal där vi praktiskt övar på olika numeriska applikationer och hur de kan användas för att analysera sprickdata, och stabiliteten hos undermarkskonstruktioner i berg.
- Fältövning - Här tränas du i att utföra och utvärdera försök i fält.
- Inlämningsuppgifter - Du arbetar tillsammans med andra studenter och använder dina kunskaper för att lösa olika problem. Du tränas i att med utgångspunkt från empiriska och analytiska analyser bearbeta insamlade fältdata samt teori från föreläsningar. Ni redovisar skriftligt er arbetsgång och era resultat.
- Mellan lektionerna - Du förväntas förbereda dig inför varje lektion genom att arbeta igenom rekommenderat materialet, rekommenderade övningar och instuderingsfrågor så att du är beredd att bidra och delta i läraktiviteterna (problemlösning, diskussion, mm) under föreläsningarna och datorövningarna.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

- Fältövning - Genom övning i fält samt inlämning av skriftlig lösning. (ILO 3, 4, 5)
- Skriftlig tentamen - Du besvarar frågor samt löser problem som liknar de som du stöter på under kursen (i föreläsningar och uppgifter) för att testa din individuella kunskap, förståelse, skicklighet och förmågor. (ILO 1, 2, 4, 5)

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Skriftlig tentamen | GU345 | 3,5 | Obligatorisk | H25 |  |
| 0002 | Fältövning | U G# | 4 | Obligatorisk | H25 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar

information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
