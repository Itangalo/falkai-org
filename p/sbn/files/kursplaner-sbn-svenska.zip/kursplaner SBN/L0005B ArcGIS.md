---
kurskod: "L0005B"
titel: "ArcGIS"
hp: "7,5"
titel_en: "ArcGIS"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Geografisk informationsteknologi"
amnesgrupp_scb: "Geografisk informationsteknik och lantmäteri"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0005B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0005B&lasPeriod=219&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0005b-arcgis"
---

# ArcGIS (L0005B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna

- samla in, lagra, analysera och presentera geografiska data.

- bygga upp geografiska databaser och designa mindre geografiska informationssystem med grundläggande funktionalitet.

- dokumentera eget arbete enligt vedertagen metodologi.

- konstruera enklare applikationer.

## Kursinnehåll

- Introduktion till ämnet Geografiska informationssystem (GIS)

- ArcGIS

Konceptet

Uppbyggnad och funktionssätt

Programvaran

Praktiska övningar innefattande:

* Lagerhantering

* Tabellhantering och databashantering

* Bearbetning

* Skapa och redigera data

* Kartografi

* Analys

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Allt kursmaterial finns under LTU’s Citrixportal och där hittas mer detaljerade beskrivningar över kursens innehåll och dess genomförande. Det finns inga inspelade föreläsningar och inte heller några obligatoriska sammankomster. Boken utgör inlärningsmaterialet och bör följas enligt dess instruktioner.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen mål examineras med inlämningsuppgifter som görs individuellt eller i grupp om två personer och som examineras under kursens gång. Betygssättning av inlämningsuppgifter sker enligt betygsskala U/G. Samtliga inlämningsuppgifter ska vara avklarade för slutbetyg.

Inlämningsuppgifterna finns under LTU’s Citrixportal.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen L0005B motsvarar kursen ABL013

## Övrigt

Kurs som ska följas via Internet kräver att studenten har tillgång till någon form av bredbandsuppkoppling.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G# | 7,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når

lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
