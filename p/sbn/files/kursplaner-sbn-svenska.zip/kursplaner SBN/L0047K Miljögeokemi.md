---
kurskod: "L0047K"
titel: "Miljögeokemi"
hp: "7,5"
titel_en: "Environmental geochemistry"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0047K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0047K&lasPeriod=222&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0047k-miljogeokemi"
---

# Miljögeokemi (L0047K)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Grundläggande behörighet samt K0016K Kemiska principer, O0035K Geologi, grundkurs eller motsvarande kurser.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter avslutad kurs ska deltagarna kunna…

Kunskap och föreståelse

1. förklara de allmänna geokemiska principer som styr grundämnenas förekomst och geokemiska karaktär i mineral och vattenlösningar

2. redogöra för geokemiska cykler på jordens yta

Färdighet och förmåga

3. analysera och förklara vilka biogeokemiska processer som påverkar halterna av huvudelementen i ett grundytvatten

4. Balansera viktiga geokemiska vittringsreaktioner

5. Identifiera geokemiska processer i fält

6. Diskutera hur koldioxidhalten och syrehalten i atmosfären har reglerats under geologisk tid

7. Sammanfatta relevanta vetenskapliga artiklar i ett abstrakt

Värderingsförmåga och förhållningssätt

1. Utifrån en vetenskaplig grund reflektera över hur människan påverkar koldioxid halterna i ett kort och långt tidsperspektiv

## Kursinnehåll

Kursen innehåller information om geokemiska begrepp som krävs för att förstå naturliga processer som sker på jordens yta, verktyg som hjälper att skilja på naturliga och onaturliga föroreningar i miljön, samt bakomliggande geokemi för att förstå klimatförändringar. I kursen behandlas generella kemiska begrepp så som pH och redox potential, och hur dessa parametrar kontrollerar mobiliteten av olika grundämnen mellan olika reservoarer (berg, jord, sediment, grundvatten och ytvatten).

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen börjar med en quiz där studenterna reflekterar över de kunskaper de erhållit från tidigare relevanta kurser. I kursen arbetar studenterna aktivt i grupper för att diskutera och summera information baserat på givna kapitel i kurslitteraturen. Studenterna samarbetar med problemlösning genom att hantera komplexa geokemiska vittringreaktioner av primära mineral och bildning av sekundära mineral, genom att analysera geokemiskt data, och genom att visualisera och presentera geokemiska cykler.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Måluppfyllelsen kontrolleras genom

1. En individuell inlämningsuppgift (G/U) som examinerar mål 7

2. En projektuppgift (G/U) som examinerar mål 2

3. en slutlig individuell skriftlig tentamen med graderat betyg (G / U 3 4 5) som examinerar alla övriga mål i kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Skriftlig tentamen | GU345 | 6 | Obligatorisk | H13 |  |
| 0003 | Inlämningsuppgift | U G# | 0,5 | Obligatorisk | H13 |  |
| 0004 | Projektuppgift | U G# | 1 | Obligatorisk | H13 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2013-02-06
