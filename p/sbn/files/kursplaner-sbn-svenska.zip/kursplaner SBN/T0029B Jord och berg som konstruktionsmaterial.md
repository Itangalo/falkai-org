---
kurskod: "T0029B"
titel: "Jord och berg som konstruktionsmaterial"
hp: "7,5"
titel_en: "Soil and Rock as a Construction Material"
giltig: "Vår 2026 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2024-02-14"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0029B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0029B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t00/t0029b-jord-och-berg-som-konstruktionsmaterial"
---

# Jord och berg som konstruktionsmaterial (T0029B)

## Behörighet

Grundläggande behörighet + Fysik 2, Kemi 1, Matematik 3c eller Matematik D. Eller: Fysik nivå 2, Kemi nivå 1, Matematik fortsättning nivå 1c.

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Efter avslutad kurs ska studenten kunna

Kunskap och förståelse

1. visa allmänt kunnande om jord och berg som konstruktionsmaterial.

Färdighet och förmåga

2. visa förmåga att muntligt och skriftligt redogöra för och diskutera sina slutsatser och den kunskap och de argument som ligger till grund för dessa gällande sitt eget lärande samt jord och berg som konstruktionsmaterial.

3. visa förmåga till lagarbete och samverkan i grupper med olika sammansättning.

Värderingsförmåga och förhållningssätt

4. visa insikt kring möjligheter och begränsningar för jord och berg som konstruktionsmaterial samt dess roll i samhället

5. visa förmåga att identifiera sitt behov av ytterligare kunskap och att fortlöpande utveckla sin kompetens.

## Kursinnehåll

Kursen behandlar följande områden: Introduktion - Kursutformning, kursupplägg, kursmål, läraktiviteter, examination, etc. Jord och berg som konstruktionsmaterial – Varför och hur bygger man i jord och berg, vad behöver man veta om materialet, vad blir konsekvenserna vid fel, vilka aktörer finns det inom jord-, berg- och gruvbranschen? Studiebesök - besöker pågående projekt kopplat till jord och/eller berg. Studieteknik med fokus på distansstudier – lärandeteori, rekommendationer, etc. Skriftlig/muntlig redovisning – hur man skriver rapport samt hur man presenterar muntligt. Hur man arbetar i grupp – planera och genomföra uppgifter inom givna tidsramar, hur man återkopplar på andras arbete, hur man utvärderar sitt arbete. Kunskapsbehovet - identifiera och reflektera kring behovet av ytterligare kunskap och behovet att utveckla sin kompetens. Aktuell forskning inom ämnesområdet – få en inblick i vilka frågeställningar som är viktiga inom ämnesområdet jord- och bergbyggnad. Projektuppgift – inom ämnesområdet jord- och bergbyggnad.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av:
- Lektioner - De är en mix av flera undervisnings-/inlärningsaktiviteter: (i) kort teorigenomgång där föreläsaren förklara de viktigaste teoretiska aspekterna relaterade till kursens innehåll och (ii) tillsammans lösa och/eller diskutera typiska problem eller frågor vilket ger dig möjlighet att på olika sätt arbeta med frågeställningar kring jord och berg som konstruktionsmaterial. Endera i form av förinspelade teoretiska avsnitt eller lektioner med teoretiska avsnitt samt interaktiva aktiviteter.
- Mellan lektionerna - Du förväntas förbereda dig inför varje lektion genom att arbeta igenom anvisat materialet (till exempel övningar och frågor) så att du är beredd att bidra och delta i läraktiviteterna (problemlösning, diskussion, mm) under föreläsningarna.
- Projektuppgifter - Du arbetar själv och tillsammans med andra studenter och använder dina kunskaper för att studera olika frågeställningar. Du presenterar ditt arbete i skrift och muntligt samt återkopplar på andras arbete.
- Studiebesök – vi besöker ett pågående projekt kopplat till jord och/eller berg och samlar information till en skriftlig eller muntlig redogörelse av besöket.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:
- Projektuppgift - Grupp – inlämning av rapporter där deltagarna redogörs sin uppgift samt hur de planerat och utfört arbetet. Studenten ger även återkoppling på annan students gruppuppgift samt reflektera kring den egna gruppens arbete och sitt eget lärande. Examinerar mål 1, 2, 3, 4, 5.
- Projektuppgift - Individuell – inlämning av rapporter där studenten redogörs sin uppgift. Studenten ger även återkoppling på annan students uppgift samt reflektera kring sitt eget arbete och sitt eget lärande. Examinerar mål 1, 2, 4, 5.
- Muntlig presentation - Genomföra muntliga presentationer kopplade till projektuppgifterna. Studenten ska även ge återkoppling på annan students muntliga presentation samt reflektera kring sin egen muntliga presentation. Examinerar mål 2.
- Studiebesök – obligatorisk närvaro vid studiebesök samt inlämning av skriftlig eller muntlig redogörelse av besöket. Del av examination för mål 1 och 2.

Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektuppgift - grupp | U G# | 3,5 | Obligatorisk | H24 |  |
| 0002 | Projektuppgift - individuell | U G# | 2 | Obligatorisk | H24 |  |
| 0003 | Muntlig presentation | U G# | 1 | Obligatorisk | H24 |  |
| 0004 | Studiebesök | U G# | 1 | Obligatorisk | H24 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14
