---
kurskod: "T0028B"
titel: "Utlandsbyggande"
hp: "7,5"
titel_en: "International construction"
giltig: "Höst 2017 Lp 1 - Tills vidare"
beslutsdatum: "2017-06-16"
utbildningsniva: "Grundnivå"
fordjupningskod: "G2F"
betygsskala: "U G#"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser  Prov Provnr       Typ                                                           Hp            Betyg  0001         Deltagit i studieresan och godkänd rapport                    7,5           U G#"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0028B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0028B&lasPeriod=198&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t00/t0028b-utlandsbyggande"
---

# Utlandsbyggande (T0028B)

## Behörighet

Grundläggande behörighet samt Kursen V0011B Samhällsbyggande samt minst två av kurserna T0013B Berganläggningsteknik, K0013B Byggkonstruktion och P0001B Bygg och anläggningsproduktion

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Examinator

Martin Nilsson

## Mål/Förväntat studieresultat

Kursens övergripande mål är att studera internationella byggprojekt. Kursen ger inblick i hur byggprojekt bedrivs i andra länder med förutsättningar som skiljer sig från de i Sverige tex avseende lagstiftning, normer, klimat, arbetsmiljö och säkerhet. Studenten skall dessutom öva, utveckla och visa färdigheter i att arbeta i projekt med deltagare med bakgrund i andra traditioner än den svenska .

Det innebär att studenten efter kursen ska kunna:

- Tillsammans med övriga studenter redogöra för de internationella byggprojekt de studerat

- Tillämpa kunskaper från lästa kurser och erfarenheter från svenska byggprojekt för att jämföra med de studerade projkten

- Arbeta tillsammans i projekt där alla bidrar mot samma mål.

- Arbeta med deltagare på andra språk än svenska.

- Arbeta med tidigare okända samarbetspartners

- Ta fram och arbeta med budget.

## Kursinnehåll

Studenterna planerar tillsammans en studieresa till ett annat land. I studieresan besöks byggarbetsplatser, gruvor och/eller universitet med verksamhet som är av intresse för studenternas framtida yrkeskarriärer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Studenterna som deltar i kursen planerar och genomför studieresan och samlar sina erfarenheter från resan i en rapport. Resan har en varaktighet på mellan 2 och 3 veckor.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Skriftlig rapport från studieresan (gemensam för gruppen)

## Överlappning

Kursen T0028B motsvarar kursen K0018B

Kursen T0xxxB motsvarar X0003B och bägge kan inte ingå i samma examen

## Övrigt

Studenten står själv för alla kostnader för resa och boende i samband med studieresan.

En av institutionens lärare deltar i studieresan. Studenterna föreslår och examinatorn utser den som ska medfölja. Institutionen betalar för den medföljande läraren.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser

Prov Provnr       Typ                                                           Hp            Betyg

0001         Deltagit i studieresan och godkänd rapport                    7,5           U G#

## Litteratur

*Litteratur. Gäller från Höst 2017 Lp 1* Beslutas senare

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2017-06-16

## Kursplanen fastställd

av Eva Gunneriusson, biträdande huvudansvarig utbildningsledare vid Institutionen för Samhällsbyggnad och naturresurser 0204-06-12
