---
kurskod: "P0012B"
titel: "Projektering"
hp: "7,5"
titel_en: "Engineering Design"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2025-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P0012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P0012B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p00/p0012b-projektering"
---

# Projektering (P0012B)

## Ingår i huvudområde

Samhällsbyggnadsteknik

## Behörighet

Grundläggande behörighet + Fysik 2, Kemi 1, Matematik 4 eller Matematik E. Eller: Fysik nivå 2, Kemi nivå 1, Matematik fortsättning nivå 2 (äldre kurs Matematik E).

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Övergripande målet efter godkänd kurs är att studenten ska ha grundläggande förståelse för projekteringsprocessen, metoder och teknisk kunskap om olika leveranser från projekteringen inom samhällsbyggnadsprocessen.

Kunskaper och förståelse

1. Studenten ska erhålla kunskaper om olika projekteringsprocesser inom samhällsbyggnadssektorn och erhålla förståelse för olika stödjande metoder inklusive dess aktiviteter, aktörer samt olika rollers ansvarsområden.

2. Studenten ska bygga en teoretisk bas inom branschstandarder för bygghandlingar, systematiskt byggande och byggnadsinformationsmodellering (BIM).

Färdigheter och förmågor

Studenten skall:

3. Kunna arbeta individuellt samt i grupp.

4. Ta in och bearbeta samt använda instruktioner på engelska och svenska.

5. Tillämpa enklare projektplanering inklusive aktivitets- och processindelning

6. Tillämpa CAD-verktyg inom verkligt samhällsbyggandsprojekt på grundläggande nivå

7. Presentera informationsmängder, ritningar och digitala modeller (BIM)

Värderingsförmåga och förhållningssätt

8. Analysera och relatera inhämtad kunskap mot branschspecifika utmaningar

9. Reflektera över olika projekteringsprocessers metoder och digitala tillämpningar

## Kursinnehåll

Denna kurs ger allmän kunskap av projekteringsprocesser inom samhällsbyggnad, med fokus mer ingående på metoder och genomförande av leveranser. Projektering är en central delprocess inom samhällsbyggandet inom vilken man planerar, utformar och bestämmer utformningen av byggnadsverk och infrastrukturer. Både att planera och genomföra projekteringen är den del av byggprocessen där arkitektens intentioner realiseras och beskrivs så att byggnadsverket/infrastrukturen kan uppföras av en eller flera entreprenörer. Kursen beskriver främst projekteringsprocessen utifrån både byggande av byggnader, byggnadsverk såväl som infrastruktur mellan vilka det finns både likheter och skillnader. Projekteringsprocessen för både byggnader och infrastruktur delas in i flera faser med ökad detaljeringsgrad ju närmare produktionsprocessen man kommer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Lärandeaktiviteterna består av föreläsningar, projektarbete, seminarier, reflektionsuppgifter och skriftliga quizzar. Aktiviteterna innehåller både individuellt såväl som projektarbete i grupp för de olika delmomenten. Projektarbete genomförs främst vid tillämpning av CAD-verktyg medan de individuella momenten på olika sätt relaterar till projektering genom både praktiknära och teoretiska inslag. Teoretiska kunskaper inhämtas främst genom föreläsningar och kurslitteratur medan de praktiska momenten även innefattar seminarier och laborationer.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För teori och tillämpning process och teknologi examineras momenten i betygsskala U, 3, 4, 5 där nivå 3 bedöms utifrån att studenten tillägnat sig merparten av de färdigheter som övats inom kursen på projektet Studenten skall tillägnat sig merparten av de färdigheter som övats inom kursen på projektet. Studenten skall

förstå vad förelagd uppgift innebär och kunna tillämpa den mot de krav som ställs i instruktionen.

För bedömningsnivå 4 skall studenten även tydligt visa på förmågor i tillämpningen och

självständigt lösa problem längs momenten. För bedömning nivå 5 skall studenten utöver tidigare kriterier

utveckla, analysera och presentera sina resultat på ett djupare och mer fullständigt sätt.

Examination genom dugga och inlämningar för teori och tillämpning process och teknologi.

Kursen examineras på flera olika sätt för att passa de olika målen. Lärandemålen som relaterar till förståelse för de teoretiskt inhämtade kunskaperna (lärandemål 1 och 2) examineras utifrån dessa, betygssättning sker enligt betygsskala U 3 4 5. Lärandemålen 3,5 och 7 examineras genom att genomföra skriftliga rapporter och övningar, betygssättning sker enligt betygsskala U 3 4 5, respektive U G#. Lärandemålen 6 vilket handlar om att lära sig att tillämpa informationshantering med BIM, examineras via inlämningsuppgift, betygsättning sker enligt betygsskala U 3 4 5. Lärandemålen 8 och 9 vilka handlar om att tillämpa branschspecifika tillämpningar för bygghandlingar och tekniska beskrivningar examineras i seminarieform, betygsättning sker enligt betygsskala U G#.

För att kunna nå godkänt betyg (3) på kursen krävs G# på alla ingående examinationer. För att uppnå högre betyg (4 och 5) krävs inte bara godkända inlämningar utan högre betyg på de examinationer som har betygsskala U 3 4 5.

Kursen innefattar obligatorisk närvaro på campus vid seminarier, externa föreläsningar (kopplat till reflektioner) samt skriftlig dugga.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Teori och tillämpning process och teknologi | GU345 | 4,5 | Obligatorisk | H25 |  |
| 0002 | Förståelse och reflektion leveranser, standarder och regelverk | U G# | 3 | Inaktiv | H25 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
