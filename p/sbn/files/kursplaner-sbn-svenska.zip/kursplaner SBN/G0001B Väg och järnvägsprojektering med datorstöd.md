---
kurskod: "G0001B"
titel: "Väg och järnvägsprojektering med datorstöd"
hp: "7,5"
titel_en: "Road and Railroad Design with Computers"
giltig: "Höst 2015 Lp 1 - Vår 2019 Lp 3"
beslutsdatum: "2015-06-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G#"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser  Prov Provnr       Typ                                                              Hp           Betyg  0001         Konstruktionsuppgift                                             6            U G#  0002         Övrigt                                                           1,5          U G#"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G0001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G0001B&lasPeriod=193&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g00/g0001b-vag-och-jarnvagsprojektering-med-datorstod"
---

# Väg och järnvägsprojektering med datorstöd (G0001B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Examinator

Tommy Edeskär

## Mål/Förväntat studieresultat

Kursen skall ge kunskaper om planeringsprocessen och den geometriska utformningen av vägar och järnvägar. Begreppen byggs upp av det regelverk som Vägverket och Banverket använder.

Följande skall du kunna tillämpa/beräkna:
- Geometrisk utformning i plan, profil och sektion för väg/järnvägssträckor
- Vägar och gators geometriska utformning (VGU)

Följande begrepp skall du kunna:
- Planeringsprocessen för väg- och järnvägsbyggande med ingående dokument.

Följande begrepp skall du känna till:
- Manuell beräkning av linjeelement för väg- och järnvägslinjer.

## Kursinnehåll

För projektuppgiften används Novapoint som är ett skalprogram utanpå AutoCad Map.

Novapoint Väg Prof är ett verktyg för effektiv framställning av byggplaner för alla typer av vägar, gator och korsningar. Modulen innehåller kompletta funktioner för projektering, beräkning, vägmodell, höjdplanering, korsningskonstruktion, ritningsproduktion och 3D-uppritning.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av lektioner, studiebesök och en stor projekteringsuppgift som utförs med hjälp av datorprogrammet Novapoint.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Viss kontinuerlig examination. Några kontrollskrivningar ges under kursens gång. Projekteringsuppgiften betygsätts med godkänd (eller icke godkänd).

## Överlappning

Kursen G0001B motsvarar kursen ABG023

## Övrigt

Grundläggande kunskaper i AutoCAD är en fördel men inte nödvändigt. Kursen kan efter överenskommelse ges för engelskspråkiga studenter.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser

Prov Provnr       Typ                                                              Hp           Betyg

0001         Konstruktionsuppgift                                             6            U G#

0002         Övrigt                                                           1,5          U G#

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Litteratur

*Litteratur. Gäller från Höst 2011 Lp 1* Kompendium i Väggeometri. Geometrisk utformning av vägar och gator. Lars Olov Alm 1995. Kompendium i Vägprojektering. Monica Berntman, Gunnar Lannér 1995. Div litteratur från vägverket. Ovanstående litteratur finns tillgänglig via fronter

Vägen - en bok om vägarkitektur, Benny Birgersson, Vägverket, ISBN 91-88250-52-0, http://publikationswebbutik.vv.se/shopping/ShowItem____1747.aspx

## Revidering fastställd

av Eva Gunneriusson 2015-06-11

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
