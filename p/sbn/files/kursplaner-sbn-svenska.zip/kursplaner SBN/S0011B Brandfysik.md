---
kurskod: "S0011B"
titel: "Brandfysik"
hp: "7,5"
titel_en: "Fire Physics"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S0011B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S0011B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s00/s0011b-brandfysik"
---

# Brandfysik (S0011B)

## Behörighet

Grundläggande behörighet samt M0055M Flervariabelanalys eller motsvarande

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna

- Förklara och genomföra beräkningar på elektromagnetisk växelverkan mellan bränder och dess omgivningar.

- Förklara och genomföra beräkningar på kondenserade tillståndets fysik för materialegenskaper relevanta inom bränder, såsom längdutvidgningskoefficient, värmeledningsförmåga och specifik värme.

- Förklara och genomföra beräkningar på hur sot och vätskesprayer växelverkar med bränder.

- Förklara och genomföra beräkningar på fluiddynamiska fenomen relevanta för bränder.

## Kursinnehåll

Kursen behandlar teoretiska kunskaper inom elektromagnetiska spektra, spektralt upplöst emissivitet/absorptivitet, Kirchoffs lag, Beer-Lamberts lag och uppvärmning av semitransparenta material, värmeöverföring, längdutvidgningskoefficient, värmeledningsförmåga, specifik värme, termiska egenskaper hos sot, fluiddynamik, dropp- och sprayfysik, elektromagnetisk växelverkan med sprayer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, räkneövningar, konsultationer, quizzar och duggor.

Dokumenthantering sker i lärplattformen Canvas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras med skriftlig tentamen med betygsskala U 3 4 5. Frivilliga quizzar och duggor ges under kursen och godkända sådana ger poäng tillgodo på den skriftliga tentamen. Alla tre momenten (skriftlig tentamen, quizzar och duggor) täcker var och en in alla delar av kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Skriftlig tentamen | GU345 | 7,5 | Obligatorisk | H20 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-02-14
