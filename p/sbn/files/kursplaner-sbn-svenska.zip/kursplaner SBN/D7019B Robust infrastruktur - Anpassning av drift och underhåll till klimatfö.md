---
kurskod: "D7019B"
titel: "Robust infrastruktur - Anpassning av drift och underhåll till klimatförändringar"
hp: "7,5"
titel_en: "Robust infrastructure - Adapting Operation and Maintenance to Climate Change"
giltig: "Höst 2025 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7019B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7019B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7019b-robust-infrastruktur---anpassning-av-drift-och-underhall-till-klimatforandringar"
---

# Robust infrastruktur - Anpassning av drift och underhåll till klimatförändringar (D7019B)

## Behörighet

Kurser om minst 90 hp inom något av följande områden: underhållsteknik, maskinteknik, samhällsbyggnad eller motsvarande. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Syftet med kursen är att ge omfattande kunskap, teori, verktyg och praktiska tillämpningar för att anpassa drift och underhåll av transportinfrastruktur till de utmaningar som klimatförändringarna medför.

Efter genomgången kurs ska studenten kunna

Kunskap och förståelse

1. Beskriv transportinfrastrukturens roll för att uppnå målen för hållbar utveckling (SDG).

2. Beskriva principer för tillförlitlighet, robusthet och resiliens kopplat till strategier för klimatanpassning.

Färdighet och förmåga

3. Analysera klimatprognoser och deras inverkan på transportinfrastrukturtillgångar.

4. Utvärdera livscykelkostnader för olika till strategier för klimatanpassning av drift och underhåll.

5. Identifiera potentiella risker, utmaningar och krav för att uppnå ett resilient transportsystem.

Värderingsförmåga och förhållningssätt

6. Utvärdera och kritiskt granska information som används i kursen.

## Kursinnehåll

Denna kurs behandlar begrepp och teorier som är väsentliga för att utveckla klimatresilienta drift- och underhållsstrategier för transportinfrastruktur. Kursen inkluderar en översikt över hållbara utvecklingsmål (SDG) som gäller för transportsystem, framtida klimatprognoser med Representative Concentration Pathways (RCPs) och Shared Socioeconomic Pathways (SSPs), och metoder för att bedöma klimatfaror, exponering, sårbarheter och associerade risker och kaskadeffekter på infrastrukturen.

Vidare innehåller kursen principerna för driftsäkerhet i relation till klimatförändringens effekter. Dessutom använder kursen livscykelkostnadsbedömning (LCC) för att utvärdera de ekonomiska effekterna av framtida klimatrisker och effekter på infrastrukturdrift och underhåll och att vägleda valet av lämpliga klimatanpassningsåtgärder.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Föreläsningar kommer att presentera viktiga koncept med exempel. Föreläsningarna kan vara en kombination av online, självstudier och/eller klassrumsinteraktion. Gruppuppgifter integrerade i föreläsningar kommer att stärka studenternas förståelse för varje ämne genom samverkande problemlösning, där de kommer att tillämpa, förklara, analysera eller identifiera relevanta ämnesaspekter. Dessutom kommer studenterna att engagera sig i utökade gruppprojekt och individuella övningar för att fördjupa sitt grepp om varje ämne. För gruppprojekt kommer eleverna att lämna in en rapport och leverera en grupppresentation, vilket möjliggör feedback från studiekamrater och instruktörer för ytterligare förfining. Individuella uppgifter kommer att granskas av instruktörer, som kommer att erbjuda konstruktiv feedback och vägledning för att stödja elevernas inlärningsframsteg.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kunskap och förståelse kommer att bedömas genom projektrapporter, seminarier och inlämningsuppgifter. Färdigheter och förmågor samt värderingsförmåga och förhållningssätt granskas genom projektuppgifter och muntliga och skriftliga presentationer. Den muntliga presentationen sker genom presentationer och diskussioner. Skriftlig redovisning sker via inlämningsuppgifter, projektuppgifter och reflektioner. Alla ingående examinationsmoment ska vara avklarade för slutbetyg i kursen (7,5 hp, betygsskala: G 3 4 5).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Inlämningsuppgifter | U G# | 3,5 | Obligatorisk | H25 |  |
| 0004 | Projektarbete | GU345 | 4 | Obligatorisk | H25 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar

information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
