---
kurskod: "K0002B"
titel: "Byggmaterial"
hp: "7,5"
titel_en: "Building materials"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2022-02-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0002B&lasPeriod=224&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0002b-byggmaterial"
---

# Byggmaterial (K0002B)

## Ingår i huvudområde

Arkitektur, Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Grundläggande behörighet + Fysik 2, Kemi 1, Matematik 4 eller Matematik E. Eller: Fysik nivå 2, Kemi nivå 1, Matematik fortsättning nivå 2 (äldre kurs Matematik E).

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kursens mål är att studenten ska utveckla sina grundläggande kunskaper inom byggmaterial.

Efter genomgången kurs ska studenten:

1. känna till vanliga förekommande byggnadsmaterial och deras egenskaper

2. kunna redogöra för grundläggande egenskaper hos vanliga byggnadsmaterial inom värme och fukt

3. kunna reflektera över problem som härrör från byggmaterialens produktion och användning

4. visa medvetenhet om potentiella risker med olika byggmaterial.

5. kunna utföra grundläggande mätningar och analyser med teknisk utrustning som används i ett betonglabb.

6. kunna ge exempel på hur man uppnår ett hållbart byggande

## Kursinnehåll

Kursen behandlar de olika byggnadsmaterialen och deras tillverkning, användning och viktigaste egenskaper. Studenterna kommer att lära sig grundläggande begrepp och beräkningar inom värme- och fuktfrågor. Kursen ger en kort introduktion till hållbart byggande och byggmaterialens miljöpåverkan. Laborationen skapar möjlighet för framställning av provkroppar och mätningar i det experimentella labbet.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar som presenteras av flera lärare. Föreläsningar fokuserar på ämnesområdets teoretiska bakgrund. Praktiska färdigheter tränas genom beräkningar/övningar i klassrummet, hemuppgifter och i laborativa uppgifter. Arbetet i laboratoriet utförs i grupper och resultat från laborationerna redovisas skriftligt av grupperna. Laborationer och övningar kommer att vara kopplade till föreläsningar.

Dokumenthantering sker i lärplattformen Canvas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Under kursen kommer studenterna att arbeta med skriftliga räkneuppgifter, som kommer att betygsättas U/G.

Under kursen kommer studenterna att arbeta i labbet och skriva en labbrapport, som kommer att betygsättas U/G.

Tentamen är skriftlig och betygsätts U,3,4,5.

Ett godkänt kursbetyg förutsätter att alla tre moment (räkneuppgifter, laboration inklusive rapport och tentamen) är godkända.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0002B motsvarar kursen ABK031

## Övrigt

Kursen ges på grundläggande nivå och ingår i kärnkurspaketet för civilingenjör Arkitektur och civilingenjör Väg- och Vatten.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 4,5 | Obligatorisk | H07 |  |
| 0002 | Inlämningsuppgifter | U G# | 1,5 | Inaktiv | H07 |  |
| 0003 | Laborationer och grupparbeten | U G# | 1,5 | Inaktiv | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
