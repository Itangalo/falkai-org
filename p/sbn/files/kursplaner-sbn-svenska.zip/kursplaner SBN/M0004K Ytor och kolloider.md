---
kurskod: "M0004K"
titel: "Ytor och kolloider"
hp: "7,5"
titel_en: "Surfaces and Colloids"
giltig: "Vår 2026 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Kemiteknik"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=M0004K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=M0004K&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/m00/m0004k-ytor-och-kolloider"
---

# Ytor och kolloider (M0004K)

## Behörighet

Grundläggande behörighet samt Kurserna M0031M Linjär algebra och K0010K Fysikalisk kemi eller motsvarande kurser samt goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter avslutad kurs skall studenten kunna:

- Definiera och redogöra för grundläggande yt- och kolloidkemiska begrepp, som exempelvis ytenergi, ytpotential, koagulering, kapillärkondensation, viskositet och hydrofobicitet

- Beskriva kolloidala partiklars diffusion och ljusspridning

- Redogöra för ytaktiva ämnens associationsegenskaper dvs. hur de bildar aggregat i vatten

- Diskutera fenomen relaterade till adsorption i gränsytor mellan olika faser som luft-vatten, fast fas-vatten och fast fas-gas

- Tillämpa DLVO-teorin samt förklara faktorer som påverkar kolloidal stabilitet dvs. hur förhindras eller underlättas aggregering

- Identifiera samt kategorisera begrepp inom reologi och kunna beskriva olika faktorer som påverkar viskositet

- Relatera yt- och kolloidkemisk grundteori till olika tillämpningar i industriella processer

- Utarbeta matematiska lösningar på enklare yt- och kolloidkemiska problem, med koppling till de fenomen som behandlas i kursens teoridel

## Kursinnehåll

Kursen behandlar

- kolloidala tillstånd,

- kinetiska och optiska egenskaper,

- adsorptionsjämvikter i gränsytor mellan faser,

- laddade ytor,

- kolloidal stabilitet samt

- emulsioner och skum.

Teorin tillämpas vid räkneövningar, laborationer. Vid tentamen examineras både teoretiska kunskaper och tillämpningar i form av beräkningsexempel. Till exempel kan mätning av zeta-potential ge information om ytladdningen och kontaktvinkelmätning kan betraktas som en metod för att bedöma ythydrofobicitet.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen sker i form av lektioner, räkneövningar och laborativt arbete. Teori och praktiska moment vägs ihop så att den teoretiska undervisningen tillämpas under laborationer och beräkningsövningar. Studenterna förväntas delta aktivt under föreläsningarna, såväl som räkneövningstillfällen. För en aktiv dialog mellan student och lärare kommer även mindre övningar och diskussionstillfällen att ingå i teorilektionerna. Detta ger läraren större möjlighet att försäkra sig om att studenten absorberar den teoretiska informationen och att rätta till eventuella missförstånd. Övningar och laborativa inslag i kursen är till för att studenten skall få en mera konkret förståelse för teorin och dess koppling till praktiska tillämpningar.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Godkända laborationsredogörelser och godkänd skriftlig tentamen är en förutsättning för godkänd kurs. I tentamen ingår både teoretiska frågeställningar och beräkningsuppgifter som ska utmana studentens förmåga att analytiskt behandla ytkemiska problem eller lösa teoriuppgifter och bidra till ökad förståelse av ämnet. Differentierade sifferbetyg tillämpas. Betygsskala: 3-4-5.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen M0004K motsvarar kursen K7002K

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 5 | Obligatorisk | H16 |  |
| 0002 | Laborationsraport | U G# | 1,5 | Obligatorisk | H16 |  |
| 0003 | Räkneövningsuppgifter | U G# | 1 | Obligatorisk | H16 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2016-01-19
