---
kurskod: "KX002K"
titel: "Kemi G1, gymnasiekomplettering"
hp: "7,5"
titel_en: "Chemistry G1, Highschool Supplementary Course"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Förberedande nivå"
betygsskala: "GU345"
amne: "Kemi"
amnesgrupp_scb: "Kemi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=KX002K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=KX002K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/kx0/kx002k-kemi-g1-gymnasiekomplettering"
---

# Kemi G1, gymnasiekomplettering (KX002K)

## Behörighet

Grundläggande behörighet

## Mål/Förväntat studieresultat

Efter avslutad kurs ska studenten

- Ha tillägnat sig kunskaper och färdigheter som i huvudsak motsvarar gymnasiets Kemi 1

- Kunna redogöra för grundläggande begrepp och teorier

- Kunna balansera kemiska formler och utföra stökiometriska beräkningar

- Kunna koppla materias egenskaper till olika typer av kemisk bindning

- Ha kännedom om kemins tillämpningar och betydelse för industri och teknologisk utveckling, vardagsliv, miljö och hälsa

- Kunna genomföra, tolka och redovisa experiment

## Kursinnehåll

Kursen behandlar grundläggande kemiska begrepp, atomteori, periodiska systemet, kemisk bindning, aggregationsformer, reaktionsformelskrivning, stökiometri, syror och baser, termokemi, redox, elektrokemi

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen sker i form av lektioner och laborativt arbete i grupp. Lektionerna går igenom relevant teoriinnehåll med diskussion runt olika frågeställningar och praktiska exempel. Laborationerna ger möjlighet till praktisk erfarenhet av teoriinnehållet. Resultaten redovisas skriftligt i form av laborationsrapporter. Närvaro vid laborationstillfällena är obligatorisk.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Godkända laborationsrapporter och godkänd skriftlig tentamen är en förutsättning för godkänd kurs.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen KX002K motsvarar kurser KGK036, KX001K

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

Kod          Benämning                              Betygsskala    Fup.     Tillstånd            Gäller      Titel från

0001         Tentamen 1                             GU345          3,2      Obligatorisk         V15

0002         Tentamen 2                             GU345          3,1      Obligatorisk         V15

0005         Laboration 2                           UG             0,6      Obligatorisk         V27

0006         Laboration 1                           UG             0,6      Obligatorisk         V27

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2014-02-04
