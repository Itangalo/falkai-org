---
kurskod: "A7001B"
titel: "Upplagsteknik"
hp: "7,5"
titel_en: "Landfill Technology"
giltig: "Höst 2024 Lp 1 - Höst 2025 Lp 2"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Miljöteknik"
amnesgrupp_scb: "Miljövård och miljöskydd"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=A7001B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=A7001B&lasPeriod=221&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/a70/a7001b-upplagsteknik"
---

# Upplagsteknik (A7001B)

## Ingår i huvudområde

Naturresursteknik, Väg- och vattenbyggnad

## Behörighet

Minst 90 hp i kemiteknik, geovetenskap eller naturresursteknik. Goda kunskaper i engelska motsvarande Engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens syfte är att förmedla en grundläggande förståelse för avfallsupplags design, konstruktion, funktion och roll i samhället, samt att förmedla praktiska färdigheter inom området som krävs för vidare arbete t.ex. som konsult, inom industri, hos privata eller kommunala avfallsbolag eller på kommunala miljökontor.

Efter godkänd kurs ska studenten kunna:
- Tillämpa naturvetenskapliga principer och metoder inom upplagsteknik.
- Beräkna konsekvenser av viktiga processer i och kring deponier, t ex lakvattenbildning eller gasbildningspotential genom att tillämpa kemiska och fysikaliska principer.
- Redogöra för säkerhetsregler i miljölaboratoriet och utföra praktiska laboratorieuppgif-ter.
- Arbeta i grupp, både som gruppmedlem och som projektledare.
- Bearbeta resultat och presentera dem både skriftligt (teknisk rapport) och muntligt (presentation).

Studenten skall kunna beskriva och diskutera :
- Upplagets roll inom avfallshanteringssystem
- Upplagets uppbyggnad och utformning
- Omvandlingsprocesser i avfallsupplag
- Metoder för omhändertagande och behandling av deponigas och lakvatten
- Samverkan mellan avfallsupplag och omgivning

Studenten skall kunna redogöra för:
- Det regelverk som styr deponering
- Viktigare kemiska och biologiska processer som påverkar avfallsupplag
- Metoder för avfallskarakterisering

## Kursinnehåll

Kursen behandlar avfallsupplagets roll och funktion i avfallshanteringssystemet, dess lokali-sering, uppbyggnad, drift och avslutning. Både tekniska aspekter och gällande lagstiftning inom området berörs. I kursen diskuteras faktorer som påverkar lokalisering och etablering av nya avfallsupplag som t.ex. de geologiska och hydrologiska förutsättningarna, men också avfallets egenskaper som t ex lakbarhet och biologisk nedbrytbarhet, som styr omvandlingsprocesserna och leder till uppkomsten av emissioner. Deponigas och lakvatten är exempel på materialströmmar som måste kontrolleras och behandlas. Vi kommer t.ex. att beräkna hur mycket gas som kan förväntas bildas i ett upplag och diskutera hur den kan omhändertas. Avslutning, sluttäckning och efterbehandling diskuteras ur både teknisk synvinkel och med tanke på depone-ringens långsiktiga hållbarhet.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen sker i form av föreläsningar, seminarier, ett studiebesök, laborationer, enskilt arbete och projekt¬arbete i grupp. Varje student tar reda på och presenterar muntligt om deponering i sin hemkommun respektive sitt hemland. Områdets huvuddrag presenteras i ett antal föreläsningar; fördjupande frågor samt relevanta beräkningar diskuteras i efterföljande semi-narier. Tidigt i kursen initieras ett projektarbete i grupper á 3-5 studenter med anknytning till aktuell forskning inom upplagsteknik. Projektarbetet innehåller två delar - en litteraturstudie och en experimentell del med laborativt arbete. Förutom att skriva en rapport presenterar varje grupp sitt projekt två gånger - planeringen samt de laborativa metoderna i början och resultaten och utvärderingen i slutet av kursen. Även opponering av en annan grupps rapport och muntlig presentation ingår i projektarbetet. Stort fokus läggs på utvärderingen av resultaten, samarbete i gruppen samt grupperna emellan.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:

Lärandemålen avseende kunskap om avfallsupplag, naturvetenskapliga principer och metoder inom upplagsteknik inklusive beräkningar examineras genom en skriftlig individuell tentamen. Betygssättning sker enligt betygsskala G U 3 4 5. För att blir godkänt på kursen krävs dessutom att studenten genomför projektarbetet (i grupp) med godkänd rapport, två presentationer och opposition, deltar i studie¬besöket och muntligt presenterar en självvald deponi inför klassen. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen A7001B motsvarar kursen ABA003

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0009 | Projektarbete | U G# | 3 | Obligatorisk | H07 |  |
| 0010 | Deponipresentation och studiebesök | U G# | 1 | Obligatorisk | H07 |  |
| 0011 | Skriftlig tentamen | GU345 | 3,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Institutionen för Samhällsbyggnad 2009-03-10
