---
kurskod: "F7016B"
titel: "Detaljplanering"
hp: "7,5"
titel_en: "Detailed Planning"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7016B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7016B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/f70/f7016b-detaljplanering"
---

# Detaljplanering (F7016B)

## Ingår i huvudområde

Arkitektur

## Behörighet

Kännedom om fysisk planering speciellt på detaljnivån t ex F0002B Urban design eller motsvarande.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna upprätta en komplicerad detaljplan med tillhörande dokument och ha kunskap om detaljplaneprocessens alla moment samt plangenomförande.

Kunskap om och förståelse för:

Detaljplaner i förhållande till övriga planeringsnivåer, detaljplanering som regleringsinstrument, detaljplaneprocessens alla moment samt plangenomförande. Samarbete med andra experter, samråd med planchef/stadsarkitekt, andra kommunala förvaltningar, statliga myndigheter och allmänhet.

Färdighet och förmåga att:

Upprätta en komplicerad detaljplan med tillhörande delar enligt gällande lagstiftning. Genomföra detaljplaneprocessens alla moment och handlingar; formell detaljplan med bestämmelser, illustration, planbeskrivning, genomförandebeskrivning och samrådsredogörelse.

Värderingsförmåga och förhållningssätt:

Detaljplaner i förhållande till övriga planeringsnivåer. Detaljplaneringens möjligheter och begränsningar

## Kursinnehåll

Plan- och Bygglag, syfte med detaljplanering, dess möjligheter och begränsningar innehåll och dess rättsverkan, planeringsprocesser. Plankartan, planbestämmelser, planbeskrivning, samt åskådlig planredovisning. Konsekvensbeskrivningar och metoder för dem. Samråd med fackmän och berörda parter. Fastighetsrättsliga genomförandemedel, begrepp inom planekonomin, ersättningsregler.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen omfattar föreläsningar, studiebesök, övningar, individuella konstruktions- och projektuppgifter och seminarier enligt detaljschema.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För att bli godkänd krävs deltagande på studiebesök, godkänt deltagande i seminarier, godkända skriftliga projektuppgifter, godkänd konstruktionsuppgift.

Lärandemålen Kunskap om och förståelse för examineras genom Projektuppgifter ( U G#). Värderingsförmåga och förhållningssätt examineras genom deltagande i studiebesök, seminarier (U G#) Lärandemålet Färdighet och förmåga examineras genom en Konstruktionsuppgift (G U 3 4 5).

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Konstruktionsuppgift | GU345 | 6 | Obligatorisk | H15 |  |
| 0006 | Studiebesök, seminarier | UG | 0,5 | Obligatorisk | V27 |  |
| 0007 | Projektuppgifter | UG | 1 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2015-02-09
