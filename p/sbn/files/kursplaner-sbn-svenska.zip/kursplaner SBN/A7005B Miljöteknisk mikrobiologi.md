---
kurskod: "A7005B"
titel: "Miljöteknisk mikrobiologi"
hp: "7,5"
titel_en: "Environmental Engineering Microbiology"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2022-11-03"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Miljöteknik"
amnesgrupp_scb: "Miljövård och miljöskydd"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=A7005B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=A7005B&lasPeriod=214&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/a70/a7005b-miljoteknisk-mikrobiologi"
---

# Miljöteknisk mikrobiologi (A7005B)

## Ingår i huvudområde

Naturresursteknik

## Behörighet

Minst 90 hp varav K0016K Kemiska principer eller motsvarande kurs ska ingå.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursens syfte är att ge en grundläggande kunskap om allmän mikrobiologi och avancerad kunskap om dess tillämpningar inom miljötekniken, framförallt inom avfallsteknik.

Målet efter avslutad kurs är att:

Du skall kunna tillämpa:

- Naturvetenskapliga grunder inom teknikområdet.

Du skall kunna genomföra:

- Enklare mikrobiologiska undersökningar

- Utformning och skrivande av en teknisk rapport, inklusive korrekt formalia.

- Informationssökning i databas

- Enklare miljötekniska beräkningar.

- Arbeta i grupp, både som gruppmedlem och som projektledare

- Kritiskt bedöma, designa och utveckla enhetsprocesser för tillämpning av miljöteknisk mikrobiologi.

Du skall kunna beskriva och reflektera över:

- Hur mikroorganismer påverkar och påverkas av sin livsmiljö

- Mikroekologiska processer

- Processers funktion och samband mellan substrat, mikrobiologi, processutformning och behandlingsresultat.

Du skall redogöra för:

- Mikrobiologiska begrepp

- Viktigare mikrobiologiska processer i naturen

- Viktiga miljötekniska tillämpningar

- Säkerhetsregler för laboratoriearbete

## Kursinnehåll

Enhetsoperationer för biologisk avfallsbehandling och andra miljötekniska applikationer. Studenten bedömer processerna utifrån realistiska problem med avseende på omgivning, processens karaktär, användbara mikroorganismer, dimensionering och design av anläggningar. De biologiska processernas möjligheter och begränsningar analyseras, t.ex. med ledning av prestandakrav och praktiska omständigheter. Till stöd för tillämpningarna ges orientering om grundläggande mikrobiologi. I denna del fokuseras på huvudgrupper av mikroorganismer, olika typer av ämnesomsättning, krav för tillväxt och tillväxtkontroll. Även mikrobiell ekologi och enklare metoder för karakterisering av mikrobiota ingår.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, laborationer, projektarbete i grupp, seminarier och studiebesök. Kursen domineras av ett problembaserat projektarbete med laborativt arbete. Projektarbetet presenteras muntligt samt skriftlig i en rapport per grupp och inkluderar individuella fördjupningar. Föreläsningar om grundläggande mikrobiologi och några få föreläsningar om dess tillämpningar inom avfallsteknik ges i början av kursen. Om studenterna efterfrågar fördjupningar som stöd till projektarbetet erbjuds enskild handledartid för varje grupp.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Skriftlig tentamen med differentierade sifferbetyg. Obligatoriska laborationer och projektarbete med skriftlig och muntlig redovisning samt opponering.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0006 | Tentamen | GU345 | 4 | Obligatorisk | H10 |  |
| 0007 | Laboration och projektarbete | U G# | 3,5 | Obligatorisk | H10 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-11-03

## Kursplanen fastställd

av Lars Bernspång 2010-03-01
