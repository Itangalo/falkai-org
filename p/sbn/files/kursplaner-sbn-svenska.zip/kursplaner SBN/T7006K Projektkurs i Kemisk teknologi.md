---
kurskod: "T7006K"
titel: "Projektkurs i Kemisk teknologi"
hp: "7,5"
titel_en: "Senior Design Project in Chemical Technology"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Kemisk teknologi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T7006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T7006K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t70/t7006k-projektkurs-i-kemisk-teknologi"
---

# Projektkurs i Kemisk teknologi (T7006K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

Minst 90hp inom kemiteknik. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2. För utbytesstudenter gäller att examinator gör individuell prövning av behörigheten beroende på typ av projekt.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Projektkursens övergripande mål är att studenten ska kunna hantera viktiga vetenskapliga frågor inom kemisk separationsteknik och katalysområden.

Efter avslutad kurs ska studenten kunna:

- Formulera en relevant problemställning inom ämnesområdet.

- Planera ett projektarbete på ett effektivt sätt.

- Designa och genomföra ett projekt inom ämnet.

- Självständigt lösa problem i projektet

- Utvärdera resultaten med hjälp av den teoretiska kunskap de lärt sig.

- Skriva en vetenskaplig rapport, ge en muntlig presentation och försvara slutsatserna.

## Kursinnehåll

Projekttema väljs i samarbete med examinator och skall vara relaterat till modern forskning och utveckling.

Vissa avancerade karakteriseringsinstrument, som SEM, BET och separationsutrustning eller katalytisk installation kommer att användas.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Studenten kommer att arbeta självständigt under handledning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Skriftlig rapport och muntlig presentation.

I rapporten och presentationen ska studenten visa förmågan att:

- Samla in viktig information som är relevant för det formulerade problemet.

- Beskriva projektet på ett vetenskapligt sätt som inkluderar projektets planering, design och genomförande samt resultat och slutsatser.

- Använda den teoretiska kunskap de lärt sig för att diskutera de erhållna resultaten

- Ge en muntlig presentation för att presentera sitt eget arbete.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Godkänd muntlig och skriftlig redovisning | GU345 | 7,5 | Obligatorisk | H07 | Ja |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för Tillämpad kemi och geovetenskap 2007-05-28 att gälla från H07.
