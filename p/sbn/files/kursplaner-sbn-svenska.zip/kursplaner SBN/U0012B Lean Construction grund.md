---
kurskod: "U0012B"
titel: "Lean Construction grund"
hp: "1,5"
titel_en: "Lean Construction Essentials"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2024-02-19"
utbildningsniva: "Grundnivå"
betygsskala: "U G#"
amne: "Byggproduktion"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=U0012B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=U0012B&lasPeriod=212&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/u00/u0012b-lean-construction-grund"
---

# Lean Construction grund (U0012B)

## Behörighet

Grundläggande behörighet

## Mål/Förväntat studieresultat

Efter genomförd kurs ska studenten kunna:

Förstå och beskriva grunderna i Lean Construction samt kunna ge exempel på tillämpliga metoder och verktyg.

## Kursinnehåll

Kursen behandlar skillnaden mellan att arbeta resurseffektivt och flödeseffektivt samt vad det innebär för byggsektorn. Vilka verktyg och metoder som är lämplig för att skapa bättre flöden, ökat värde och minska slöserier i byggprocessen. Kursen har även belyst vilka utmaningar som finns i ett införande av en Lean verksamhetsstrategi samt vikten av ett inkluderande och coachande ledarskap.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen är uppbyggd med moduler för olika kunskapsblock och bygger på pedagogiken med Flipped Classroom.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Examinationen består ett slutprov med kunskapstest för olika moduler. På hela kursen ges betyget U G. Systemet beskrivs i detalj i kursbeskrivningen som delas ut vid kursens start. Obligatorisk närvaro gäller för digitala seminarier samt aktivt deltaganden i respektive moduls reflektionsuppgift.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Deltagande seminarier | U G# | 0,5 | Obligatorisk | H23 |  |
| 0002 | Detagande i reflektioner och diskussioner | U G# | 0,5 | Obligatorisk | H23 |  |
| 0003 | Skriftlig tentamen | U G# | 0,5 | Obligatorisk | H23 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-19
