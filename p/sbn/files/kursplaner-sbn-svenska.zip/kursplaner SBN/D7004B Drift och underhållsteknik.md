---
kurskod: "D7004B"
titel: "Drift och underhållsteknik"
hp: "7,5"
titel_en: "Operation and Maintenance Engineering"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Underhållsteknik"
amnesgrupp_scb: "Övriga tekniska ämnen"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=D7004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=D7004B&lasPeriod=216&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/d70/d7004b-drift-och-underhallsteknik"
---

# Drift och underhållsteknik (D7004B)

## Ingår i huvudområde

Väg- och vattenbyggnad

## Behörighet

60 högskolepoäng i tekniska ämnen

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursen är utformad för att förse deltagarna med grundläggande begrepp, principer och processkunskap om tillförlitlighet och underhållsteknik, så att de kan delta i utvecklingen av underhållsprogram. Efter avslutad kurs kommer deltagarna att kunna:

- modellera och analysera funktionssäkerheten hos ett icke-reparerbara system.

- utföra grundläggande tillförlitlighetsanalys av reparerbara enheter,

- bedöma relaterade risker av ett funktionsfel,

- använda olika underhållsstrategier,

- planera och genomföra Funktionssäkerhetsinriktat underhåll (Reliability Centered Maintenance, RCM),

- utföra grundläggande optimering av intervall för underhåll.

- beskriva hur mänskliga faktorer kan inverka på en säker och effektiv drift och underhåll.

## Kursinnehåll

Inom kursen kommer olika aspekter av tillförlitlighet och underhållsteknik att diskuteras enligt följande:

- Grunderna för RAMS (funktionssäkerhet, tillgänglighet, underhållsmässighet och säkerhet)

- Bedömning av systemets prestanda

- Parametrisk och icke-parametrisk tillförlitlighetsanalys

- Grundläggande analys av funktionssäkerhet för reparerbara system

- Systemtillförlitlighetsanalys

- Riskanalys

- Funktionssäkerhetsinriktat underhåll

- Underhållsmodellering och optimering

- Tillståndbaserat underhåll

- Mänsklig faktor inom underhållsteknik

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Föreläsningar introducerar grundläggande koncept med exempel med hjälp av presentationsmaterial och tavla. Föreläsningarna följs av gruppuppgifter för att förstärka förståelse för varje del. Studenterna måste interagera för att lösa problem, tillämpa, förklara, analysera eller identifiera en aspekt av ämnet som presenterades. Studenterna kommer också att arbeta med ett antal utökade grupprojekt, individuella övningar och uppgifter för att fördjupa sin förståelse. Vid grupparbete krävs att studenten lämnar in en rapport och presenterar resultatet muntligt för att få kommentarer och förslag på förbättringar från studenter och lärare. Enskilda inlämningsuppgifter kommer att granskas av lärarna för att ge studenterna konstruktiva återkoppling.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursen kommer att examineras med en skriftlig tentamen och inlämningsuppgifter. Slutbetyget ges i enlighet med den skriftliga tentamen, kvaliteten på inlämningsuppgifterna och aktivt deltagande i diskussioner och gruppresentationer.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 5 | Obligatorisk | H07 |  |
| 0003 | Inlämningsuppgifter | U G# | 2,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
