---
kurskod: "L0050K"
titel: "Geokemi"
hp: "7,5"
titel_en: "Geochemistry"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2025-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "GU345"
amne: "Geovetenskap"
amnesgrupp_scb: "Geovetenskap och naturgeografi"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=L0050K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=L0050K&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/l00/l0050k-geokemi"
---

# Geokemi (L0050K)

## Behörighet

Grundläggande behörighet + Engelska 6, Fysik 2, Kemi 1, Matematik 4 eller Matematik E. Eller: Engelska nivå 2, Fysik nivå 2, Kemi nivå 1, Matematik fortsättning nivå 2 (äldre kurs Matematik E).

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kursen ger en geokemisk verktygslåda (grundläggande principer och tekniker) som kan användas för att förstå mekanismer som styr stora geovetenskapliga system, såsom litospfären, hydrosfären och atmosfären. Studenterna kommer att lära sig om ursprunget och förekomsten av element, deras förekomst och de former de existerar i de huvudsakliga geokemiska reservoarerna på jorden samt deras användning i samhället. Kursen kommer att skapa ett brett geokemiskt fundament som kan användas i en framtida geovetenskaplig karriär inom akademi och industri (t.ex. miljökonsulter eller gruvrelaterade yrken).

Efter att ha avslutat kursen ska deltagarna kunna:

Kunskap och förståelse

1. Förklara interaktionen mellan jordens sfärer och elementmobilitet.

2. Beskriva stabila, radiogena och radioaktiva isotopsystem och deras tillämpningar.

3. Tillämpa geokemiska principer som reglerar elementförekomst i litospfären, hydrosfären och atmosfären.

Kompetens och färdigheter

4. Visa förmåga att söka, sammanställa och kritiskt tolka relevant litteratur och information samt implementera konstruktiv kritik för att utveckla kompetenser som att skriva och presentera.

5. Diskutera hur koncentrationer av metaller och näringsämnen påverkas i sötvatten och jord/sediment, genom att identifiera och förklara geokemiska principer.

6. Presentera och sammanfatta vetenskaplig forskning i skriftlig och muntlig form.

Värderingsförmåga och förhållningssätt

7. Utföra grundläggande kvalitativa och kvantitativa tolkningar samt datavisualisering av fältdata med relevant programvara.

8. Visa insikter i den geokemiska verktygslådan och hur den kommer att lägga grunden för många processer som diskuteras i den senare delen av kandidatprogrammet, t.ex. hållbara gruvmetoder och extraktiv metallurgi.

## Kursinnehåll

- Ursprung av element och nukleosyntes [Big Bang]

#förstå hur element bildas

- Kemisk sammansättning och differentiering av solsystemet, planeter och månar

#förstå grundläggande kemisk fördelning i universum, solsystemet och planeter

- Gaser i jordsystemet, idealiska gaser, gaslager [stökiometri och mol begrepp; molaritet; koncentrationer]

#förstå olika materialtillstånd: gaser; tillämpa stökiometri, enhetsomvandling, kvantitetsfärdigheter

- Syror-bas principer, pH-buffert i naturliga vattendrag

#förstå vattnets dissociation och veta vad som skiljer svaga från starka syror/baser. Förklara vad en buffert är, känn till naturliga buffertar på jorden. Bli bekant med pH-diagram.

- Koldioxidcykeln. Karbonatsystemet i sötvatten och hav. Vad styr den globala kolcykeln?

#förstå och tillämpa det kolsyresystemet med avseende på buffertkapacitet och pH:s relation i naturliga vattendrag.

- Redox geokemi i geologiska system (principer för kopplade reduktions-oxidationsreaktioner). Elektrontornet och energin hos redox reaktioner. Redox stege [balansering av viktiga geokemiska redox reaktioner]

#förstå mekanismerna bakom redox reaktioner [kunna balansera redox reaktioner]. Förstå kemisk jämvikt, syra/basbeteende och redox kemi i relation till varandra.

- Geokronologiska principer med hjälp av radiogena isotoper, epsilonnotation (halveringstid, sönderdelningskonstanter, åldersbestämning)

#förstå och tillämpa dateringskoncept för olika isotopsystem.

- Stabila isotopsystem, delta-notation och fraktionerings-ekvationer

#förstå isotopnotation och fraktionering, isotop jämvikt, mm.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen består av föreläsningar där grundläggande teori presenteras och förklaras. Teoretisk kunskap omvandlas till praktiska tillämpningar och ökad förståelse genom uppgifter, gruppdiskussioner, problembaserade seminarier samt muntliga och skriftliga presentationer.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Denna kurs betygsätts (U, G, 3, 4, 5) individuellt. Slutbetyget baseras på inlämningsuppgifter (4 uppgifter, 1,5 hp), en individuell tentamen (1,5 hp), en skriftlig geokemisk datautvärdering med ioGAS-rapport (2,0 hp) och en avslutande tentamen (2,5 hp).

Kursen bedöms genom fyra moduler, och alla moduler måste vara slutförda för att få ett kursbetyg.

Modul 1: Inlämningsuppgift

Bedömer ILO 1, 2, 3, 4, 6

Under denna uppgift kommer studenterna att besvara en fråga relaterad till kursinnehållet. Studenten förväntas spendera 1,5 till 3 timmar på dessa frågor genom att forska, sortera sina tankar och skriva 250 till 400 ord. Totalt kommer det att finnas 4 uppsatser, viktade 5% vardera. Studenterna kan visa och förbättra sin förmåga att sammanfatta vetenskapliga begrepp i skriftlig form.

Modul 2: Dugga

Bedömer ILO 1, 2, 5

Mellanexamen gör det möjligt för studenten att befästa sin förståelse. De har möjlighet att studera strategiskt och utveckla en djupare förståelse av hälften av materialet som täcks i kursen, vilket kommer att ligga till grund för den återstående delen av kursen.

Modul 3: Datarapport och presentation

Bedömer ILO 5, 6, 7, 8

Gruppmodul. Varje grupp får ett dataset som de ska utvärdera och tolka med relevant programvara. Programvaran kan användas för att verifiera och visualisera data. Studenterna ska sedan skriva en rapport tillsammans och tydligt markera vilken del som är skriven av vem. Denna uppgift syftar till att fördjupa den kunskap som erhållits från inlämningsuppgifterna genom att skriva en kortfattad forskningsrapport i form av en vetenskaplig publikation och presentera den inför en publik.

Modul 4: Tentamen Bedömer ILO 1-8

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i

förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Dugga | GU345 | 1,5 | Obligatorisk | H25 |  |
| 0003 | Datarapport och presentation | GU345 | 2 | Obligatorisk | H25 |  |
| 0004 | Skriftlig tentamen | GU345 | 2,5 | Obligatorisk | H25 |  |
| 0001 | Inlämningsuppgift | U G# | 1,5 | Inaktiv | H25 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
