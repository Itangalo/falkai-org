---
kurskod: "P7012K"
titel: "Design för hållbar processteknik"
hp: "3"
titel_en: "Design for Sustainable Processing"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2026-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "UG"
amne: "Processmetallurgi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7012K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7012K&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p70/p7012k-design-for-hallbar-processteknik"
---

# Design för hållbar processteknik (P7012K)

## Behörighet

180 hp inom teknik/naturvetenskap. Goda kunskaper i engelska motsvarande Engelska 6/nivå 2 eller motsvarande reella kompetens erhållen genom praktiska erfarenheter. Läs mer om hur du ansöker om reell kompetens via denna länk: https://www.ltu.se/studentwebben/dina-studier/reell-kompetens

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter avslutad kurs skall studenten kunna:

1. Känna till begreppet hållbar utveckling

2. Känna till några av de vanligaste teknikerna som används i återvinningsprocesser för metallåtervinning

3. Förstå koppling mellan processval och materialsammansättning

4. Vara medveten om hur restprodukter genereras i metallurgiska högtemperaturprocesser och ha kännedom om möjliga användningsområden

5. Känna till begränsningar för återvinning av olika typer av metallinnehållande skrot och användning av metalinnehållande restprodukter

6. Känna till hur design av en produkt påverkar återvinning av den uttjänta produkten

## Kursinnehåll

Kursen behandlar återvinning av metaller från konsumtionsskrot och metallurgiska restprodukter.

Metallurgiska smältprocesser för återvinning av metaller gås igenom, med fokus på återvinning av koppar från elektronikskrot och stål från uttjänta fordon. Bildning av restprodukter vid högtemperatur processer kommer att gås igenom samt olika alternativ för återvinning och/eller användning i olika applikationer, däribland användning som konstruktionsmaterial. Kursen kommer att ge en inblick i kopplingen mellan materialsammansättning och återvinningsmöjligheter genom projektuppgift och seminarium. Kursen omfattar quizzar för varje delområde med uppföljande webinar för att ge kunskap om olika processer för återvinning och vilka restprodukter som genereras.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Kursen, som ges på distans, har en tidplan men erbjuder individuell flexibilitet genom tillgång till inspelade föreläsningar, quizzar och individuella inlämningsuppgifter uppgifter i det digitala kursrummet.

Webinarier hålls för att stödja inlärning och möjliggöra studenters diskussion av kursens inspelade föreläsningar. Under seminariet ska studenterna presentera och reflektera över uppgifter som genomförs individuellt.

Rapportering sker såväl skriftligt som muntligt.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Projektuppgift, webinarier och seminarium är obligatoriska. Projektuppgift presenteras skriftligt och muntligt under seminariet och bedöms med godkänd (G), underkänd (U) och deltagit.

Målen 1,2, 4 och 5 examineras genom quizzar och uppföljande webinarier.

Målen 3 och 6 examineras genom presentation på seminarium och skriftlig rapport

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Övrigt

Kursen P7012K motsvarar delvis P7009K.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Quizzar & webinarier | UG | 1,5 | Obligatorisk | V27 |  |
| 0004 | Projektuppgift & seminarium | UG | 1,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13
