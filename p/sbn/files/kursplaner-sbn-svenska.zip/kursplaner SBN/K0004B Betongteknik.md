---
kurskod: "K0004B"
titel: "Betongteknik"
hp: "7,5"
titel_en: "Concrete Technology"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2022-02-11"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1N"
betygsskala: "U G VG *"
amne: "Konstruktionsteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K0004B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K0004B&lasPeriod=226&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k00/k0004b-betongteknik"
---

# Betongteknik (K0004B)

## Behörighet

Grundläggande behörighet

## Urval

Urvalet grundas på betyg och högskoleprov

## Mål/Förväntat studieresultat

Kursens mål är att studenten ska utveckla sina grundläggande kunskaper inom betongteknik.

Efter genomgången kurs ska studenten kunna:

1. Definiera materialet betong

2. Förklara grundläggande egenskaper hos betong i färskt, hårdnande och hårdnat tillstånd

3. ge exempel på betongformar och deras användning

4. visa kunskaper om armering

5. Utföra enklare konstruktionsberäkningar och utforma enkla konstruktionselement

6. Behärska grundläggande teknik, mätningar och analyser som används i ett betonglabb.

## Kursinnehåll

Betong är det mest använda byggmaterialet. Kursen ger omfattande kunskaper om byggmaterial betong. Kursen ger en introduktion till formgjutning och kännedom om armering. Kursen även ger kunskaper om regelverk som används. Dessutom ger kursen en introduktion till konstruktionsberäkningar. Kursens innehåll omfattar även ett labbmoment där studenterna själv lär känna betong på ett praktiskt sätt.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar som presenteras av två lärare. Föreläsningar fokuserar på ämnesområdets teoretiska och praktiska bakgrund. Praktiska färdigheter tränas genom beräkningar/övningar i klassrummet, hemuppgifter/projekt och i laborativa uppgifter. Arbetet i laboratoriet utförs i grupper men resultat från laborationerna redovisas skriftligt av varje enskild student. Laborationer och övningar kommer att vara kopplade till föreläsningar och utförs parallellt. Studiebesök genomförs om möjligt för att se praktiska tillämpningar i industrin.

Dokumenthantering sker i lärplattformen Canvas.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Under kursen kommer studenterna att arbeta med inlämningsuppgifter, som kommer att betygsättas U/G. Slutprov betygsätts U/G/VG. Genom dessa metoder kan alla lärandemål täckas.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K0004B motsvarar kursen ABK124

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | U G VG * | 3 | Obligatorisk | H07 |  |
| 0002 | Inlämningsuppgifter | U G VG * | 4,5 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-02-11

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
