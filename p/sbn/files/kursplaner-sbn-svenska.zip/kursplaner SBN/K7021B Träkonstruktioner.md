---
kurskod: "K7021B"
titel: "Träkonstruktioner"
hp: "7,5"
titel_en: "Timber Structures"
giltig: "Vår 2026 Lp 3 - Höst 2026 Lp 2"
beslutsdatum: "2024-02-14"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "GU345"
amne: "Konstruktionsteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7021B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7021B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7021b-trakonstruktioner"
---

# Träkonstruktioner (K7021B)

## Ingår i huvudområde

Väg- och vattenbyggnad, Samhällsbyggnadsteknik

## Behörighet

Minst 90 hp avklarade kurser där 30 hp kurser i byggmaterial, konstruktionsteknik, byggkonstruktion och byggnadsmekanik ska ingå, t ex K0002B Byggmaterial, B0002B Konstruktionsteknik, K0013B Byggkonstruktion och B7004B Byggnadsmekanik I. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs skall studenten kunna:

Kunskap och Förståelse:

1. Beskriva egenskaper och karakteristika hos konstruktionsvirke och vanliga träbaserade produkter.

2. Förklara styrkor och svagheter hos olika träbaserade material med hänsyn till deras användning inom konstruktion och prestanda.

3. Förklara funktionsprincipen för typiska konstruktionslösningar för industri- och flervåningsbyggnader i trä.

Kompetens och Färdigheter:

4. Tillämpa relevanta Eurocode-designregler för att utföra strukturella beräkningar för olika träelement under statiska belastningar, inklusive tryck, drag, böjning och kombinationer av dessa krafter. Hantera problem med instabilitet för dessa belastningssätt.

5. Tillämpa lämpliga regler för att välja och dimensionera träanslutningar med hänsyn till både design och utförande.

Bedömning och Tillvägagångssätt:

6. Identifiera och lösa strukturella och tekniska utmaningar som är specifika för träbyggnader, inklusive problem som uppstår under monteringsfasen.

7. Skapa välstrukturerade tekniska rapporter och dokumentation som underlättar förståelse för tekniskt kunniga personer, säkerställande av konsistens i arbetsförståelse och slutsatser.

## Kursinnehåll

Kursen behandlar

- Konstruktionsvirke och de vanligaste träbaserade ingenjörsmaterialen, deras egenskaper och användningsområden.

- Generella tekniska utmaningar i träkonstruktioner relaterade till brand, fukt och ljud.

- ULS (Ultimate Limit State) och SLS (Serviceability Limit State).

- Träelement som utsätts för tryck, drag, böjning, skjuvning och kombinationer av dessa belastningar.

- Förband i träkonstruktioner.

- Lokala och globala stabilitetsproblem och stabiliseringsmetoder.

- System i trä för flervåningsbyggnader.

- System i trä för industribyggnader

- Träbroar.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Den här kursen inkluderar föreläsningar där teorin och bakgrunden förklaras och exemplifieras av läraren. En av föreläsningarna ges av en gästföreläsare som delar med sig av sin expertis och erfarenhet av att arbeta med träkonstruktioner. Under seminarier övar studenterna själva på att lösa designproblem och får handledning av läraren om det behövs i projektarbetet. Projektet för en industribyggnad utförs av studenterna antingen individuellt eller i små grupper.

Under kursens gång erbjuds studenterna möjligheten att delta i en studieresa för att närmare studera verkliga exempel på träkonstruktioner och/eller produktionsanläggning relaterade till trä.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Resultatet av kursen bedöms genom en projektuppgift som kommer att utvärderas delvis eller som en helhet. För att ytterligare bedöma den teoretiska förståelsen kommer studenterna att genomföra en obligatorisk quiz.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Projektuppgift | GU345 | 6,5 | Obligatorisk | H24 |  |
| 0002 | Quiz | U G# | 1 | Obligatorisk | H24 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-14
