---
kurskod: "P7006K"
titel: "Högtemperaturmaterial"
hp: "7,5"
titel_en: "High Temperature Materials"
giltig: "Vår 2026 Lp 3 - Tills vidare"
beslutsdatum: "2023-06-02"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Processmetallurgi"
amnesgrupp_scb: "Kemiteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=P7006K"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=P7006K&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/p70/p7006k-hogtemperaturmaterial"
---

# Högtemperaturmaterial (P7006K)

## Ingår i huvudområde

Kemiteknik

## Behörighet

90hp inom kemiteknik. Goda kunskaper i engelska, motsvarande Engelska 6/nivå 2.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter avslutad kurs skall studenten kunna:

Kunskap och förståelse

1 redogöra för smältors termodynamik, kristallografi samt kinetik.

2 förklara innebörden av begreppet sintring.

3 redogöra för keramers tillverkningsmetoder, mikrostruktur, tekniska tillämpningar samt fysikaliska och mekaniska egenskaper.

Färdighet och förmåga

4 självständigt analysera samt konstruera egna fasanalysdiagram.

5 använda termodynamiska beräkningsprogram och modellera samt förutsäga skeenden

6 nyttja olika typer av materialkaraktäriseringsutrustning samt analysera experimentellt data från dessa.

7 Visa förmåga att formulera och lösa problem inom uppsatta tidsramar.

8 Visa förmåga att muntligt och skriftligt utvärdera, sammanställa och presentera experimentella försök.

9 Identifiera, formulera och hantera komplexa frågeställningar

Värderingsförmåga och förhållningssätt

10 Göra bedömning, värdera och jämföra olika sorters experimentellt data samt teoretisk information.

## Kursinnehåll

Kursen består av termodynamik, kristallografi, fasanalys, kinetik. Grundläggande termodynamik samt metaller och oxiders kristallstrukturer, amorfa strukturer, defekter, diffusionsförlopp samt grundläggande reaktionskinetik. Dessutom behandlas fasomvandlingar, korntillväxt och fastfasreaktioner. Begreppen sintring samt metoder för tillverkning av högtemperaturmaterial behandlas också i kursen. Kursen innehåller datorlaborationer för termodynamisk simulering samt ett kortare projekt i materialkaraktärisering.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen har både teoretiska och praktiska inslag består av föreläsningar, övningar, datorlaborationer, materialkaraktärisering, metallurgiska laborationer samt skriftlig och muntlig rapportering.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Mål examineras genom skriftlig tentamen samt skriftlig och muntlig projektpresentation samt laborationsrapport

Tentamen examinerar delmål 1-4,6,7,9

Laborationer samt projektuppgift examinerar 4-10

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 5,3 | Obligatorisk | H07 |  |
| 0002 | Projektuppgift + Laborationer | GU345 | 2,2 | Obligatorisk | H07 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02

## Kursplanen fastställd

av Institutionen för Tillämpad kemi och geovetenskap 2007-02-28
