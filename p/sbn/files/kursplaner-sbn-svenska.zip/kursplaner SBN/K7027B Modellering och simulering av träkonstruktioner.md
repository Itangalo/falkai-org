---
kurskod: "K7027B"
titel: "Modellering och simulering av träkonstruktioner"
hp: "7,5"
titel_en: "Modeling and Simulation of Timber Structures"
giltig: "Höst 2026 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2026-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "U G#"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=K7027B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=K7027B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/k70/k7027b-modellering-och-simulering-av-trakonstruktioner"
---

# Modellering och simulering av träkonstruktioner (K7027B)

## Ingår i huvudområde

Samhällsbyggnadsteknik

## Behörighet

Minst 90 hp inom området Samhällsbyggnadsteknik eller motsvarande inklusive kurserna K7026B Träkonstruktion 1 och K0019B Trä som konstruktionsmaterial eller motsvarande. Dessutom krävs Engelska 6/nivå 2 och Svenska 3/nivå 3.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten:

Kunskap och förståelse

-redogöra grunderna för finita elementmetoden

-beskriva hur den finita elementmetoden kan användas för att analysera en träkonstruktion under olika scenarier

-redogöra för modelleringsantagandens betydelse för resultaten

Färdighet och förmåga

-välja lämpliga modelleringsantaganden vad avser elementindelning, randvillkor och materialparameterar, för att simulera en träkonstruktion

-analysera en träkonstruktion under olika scenarier med avseende på hållfasthet, styvhet och stabilitet

-bedöma resultaten av en simulering

Värderingsförmåga och förhållningssätt

-bedöma tillämpbarhet av den finita elementmetoden under konstruktionsprocessen

-bedöma lämpligheten av en modell för att lösa olika frågeställningar

-värdera tillförlitligheten av metoden för olika val av parametrar

## Kursinnehåll

Kursen ger en kunskap och förståelse för modellering med hjälp av finita element.

Följande delmoment och begrepp behandlas:

- Grundläggande teori om finita elementmetoden

-Elementtyper i 1D, 2D och 3D elementindelning

-Lösning av kvasistatiska problem

-Lösning av dynamiska problem och vibrationer

-Introduktion till icke-linjära problem

- Materialmodellering av trä och träbaserade konstruktionselement

- Praktiska övningar

Kursens fokus ligger på linjära problem och de praktiska datorövningarna genomförs med hjälp av programvaran RFEM.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen ges på distans. Kunskap och förståelse byggs upp genom föreläsningar, självstudier av litteratur och annat fördjupningsmaterial. Färdighet och förmåga tränas genom teoretiska övningsexempel och praktiska övningar. Progressionen i lärandet följs regelbundet upp av handledare i särskilda handledningsmöten.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Studenternas kunskaper och färdigheter examineras kontinuerligt genom både teoretiska och praktiska moment. De teoretiska kunskaperna prövas genom flera quiz, som kräver god förståelse och insikt i kursens innehåll. Den praktiska förmågan att tillämpa inlärda metoder och teorier bedöms genom individuella inlämningsuppgifter som omfattar skriftliga rapporter och en muntlig presentation.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i

förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen K7027B motsvarar kursen W7011T

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgift | U G# | 3,5 | Inaktiv | H26 |  |
| 0002 | Quiz | U G# | 3 | Inaktiv | H26 |  |
| 0003 | Muntlig examination | U G# | 1 | Inaktiv | H26 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Kursplanen fastställd

av Huvudutbildningsledare Michael Försth, Institutionen för samhällsbyggnad och naturresurser 2026-02-13
