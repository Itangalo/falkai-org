---
kurskod: "G7009B"
titel: "Gruvdammar och dammsäkerhet"
hp: "3"
titel_en: "Tailing dams and dam safety"
giltig: "Vår 2015 Lp 3 - Tills vidare"
beslutsdatum: "2014-11-04"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "U G#"
amne: "Väg- och vattenbyggnad"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser  Prov Provnr         Typ                                               Hp       Betyg  0001           Inlämningsuppgift                                 3        U G#"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7009B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7009B&lasPeriod=191&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7009b-gruvdammar-och-dammsakerhet"
---

# Gruvdammar och dammsäkerhet (G7009B)

## Behörighet

Grundläggande behörighet.Grundläggande kunskaper om dammar och geoteknik

## Examinator

Sven Knutsson

## Mål/Förväntat studieresultat

Kursens mål är att:

Ge studenten kompetens som krävs av dammsäkerhetsansvariga enligt GruvRIDAS

## Kursinnehåll

En kurs för dig som arbetar med gruvdammar inom gruvindustrin, på konsultföretag, entreprenörer eller hos övervakande myndigheter.

Kursen behandlar frågeställningar knutna till deponering av anrikningssand från gruvindustrin som deponeras i gruvdammar: &#61607; redovisning av utformning av några olika typer av gruvdammar och tillika deponeringsmetoder &#61607; redovisning av grundläggande faktorer som påverkar stabilitet och eventuella skador i dammkropparna &#61607; redovisning av olika metoder för drift, tillsyn, underhåll och återställning av gruvdammar &#61607; redovisning av gällande lagstiftning.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen sker i föreläsningsform, med eget arbete och arbete i grupp. Under kursens gång får kursdeltagarna genomföra övnings-, instuderings- och projektuppgifter. Uppgifterna redovisas dels muntligt, dels skriftligt

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Genomförda övnings-, instuderings- och projektuppgifter

## Överlappning

Kursen G7009B motsvarar kursen ABG133

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser

Prov Provnr         Typ                                               Hp       Betyg

0001           Inlämningsuppgift                                 3        U G#

## Litteratur

*Litteratur. Gäller från Höst 2008 Lp 1* All litteratur tillhandahålles i Fronter

## Revidering fastställd

av Eva Gunneriusson 2014-11-04

## Kursplanen fastställd

av Eva Gunneriusson 2014-11-04
