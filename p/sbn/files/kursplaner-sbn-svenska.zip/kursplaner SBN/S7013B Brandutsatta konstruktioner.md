---
kurskod: "S7013B"
titel: "Brandutsatta konstruktioner"
hp: "15"
titel_en: "Fire Exposed Structures"
giltig: "Höst 2023 Lp 2 - Tills vidare"
beslutsdatum: "2023-06-02"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "U G#"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7013B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7013B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s70/s7013b-brandutsatta-konstruktioner"
---

# Brandutsatta konstruktioner (S7013B)

## Behörighet

S0006B Brandtekniska beräkningar och S0003B Branddynamik I, samt någon av kurserna S0007B Brandutsatta konstruktionselement, S0004B Husbyggnadsteknik och brandhållfasthet, S0010B Byggkonstruktion brand, eller K0013B Byggkonstruktion, eller motsvarande kunskaper.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kunskap och förståelse För godkänd kurs skall studenten kunna:
- Återge generell dimensioneringsprocess för brandutsatta bärande konstruktioner.
- Återge den vetenskapliga grunden och beprövade erfarenheten för FEM-beräkningar (finita elementmetoden), speciellt tillämpat på beräkning av bärförmåga hos brandutsatta konstruktioner, samt återge de viktigaste aktuella forsknings- och utvecklingsområdena inom FEM för detta tillämpningsområde.

Färdighet och förmåga För godkänd kurs skall studenten kunna:
- Räkna typtal inom temperaturutveckling vid rumsbränder med enkla handräkningsmodeller.
- Lösa problem inom temperaturutveckling vid rumsbränder med CFD (computational fluid dynamics).
- Räkna typtal inom värmespridning från bränder till konstruktioner med enkla handräkningsmodeller.
- Lösa problem inom värmespridning från bränder till konstruktioner med FEM.
- Räkna typtal inom bärförmåga hos konstruktioner vid förhöjda temperaturer med handräkningsmodeller.
- Lösa problem inom bärförmåga hos konstruktioner vid förhöjda temperaturer med FEM.
- Lösa dimensioneringsproblem med avseende på bärförmåga vid brand genom att kritiskt och systematiskt integrera kunskap, även med begränsad information.
- Planera, genomföra, analysera och tolka komplexa dimensioneringsberäkningar med avseende på bärförmåga vid brand, samt överskådligt och vetenskapligt presentera resultat från dessa.
- Visa förmåga till lagarbete och skriftligt samt muntligt i dialog med olika grupper klart redogöra för och diskutera sina slutsatser från dimensionering med avseende på bärförmåga vid brand, och redogöra för och diskutera den kunskap och de argument som ligger till grund för dessa.

Värderingsförmåga och förhållningssätt För godkänd kurs skall studenten kunna:
- Värdera olika modeller och arbetsprocesser för dimensionering av bärförmåga vid brand samt visa insikt i ingenjörens ansvar att välja och redovisa parametrar så att resultaten används korrekt.
- Visa förmåga att identifiera sitt behov av ytterligare kunskap inom dimensionering av bärförmåga vid brand och att fortlöpande utveckla sin kompetens.

## Kursinnehåll

- Repetition av grunderna i värmelära och statik med tillämpning inom brandtekniken

- Dimensioneringsprocessen för brandutsatta bärande konstruktioner

- Enkla handräkningsmodeller för beräkning av temperaturutveckling vid rumsbrand

- CFD för beräkning av temperaturutveckling vid rumsbrand

- Enkla handräkningsmodeller för beräkning av värmespridning till konstruktioner

- FEM-beräkningar för beräkning av värmespridning till konstruktioner

- Enkla handräkningsmodeller för beräkning av bärförmåga vid förhöjda temperaturer

- FEM-beräkningar för beräkning av bärförmåga vid förhöjda temperaturer.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av självstudier, föreläsningar, räkneövningar, konsultationer, individuella quizzar, individuella inlämningsuppgifter, projektuppgift som genomförs i grupp med muntlig och skriftlig redovisning, samt individuell reflektionsuppgift.

För att nå kursens mål rörande kunskap och förståelse bör studenten ta del av föreläsningar och självständigt studera angiven kurslitteratur.

För att nå kursens mål rörande färdighet och förmåga bör studenten dessutom delta vid räkneövningarna, genomföra de individuella quizzarna och inlämningsuppgifterna, medverka aktivt vid arbetet med samt vid den skriftliga och muntliga redovisningen av projektuppgiften, samt aktivt delta vid de konsultationstillfällen som ges.

För att nå kursens mål rörande värderingsförmåga och förhållningssätt bör studenten dessutom delta i diskussioner om kursinnehållet vid föreläsningar och räkneövningar, samt genomföra reflektionsuppgiften.

Eleverna förväntas ha tillgång till egna datorer.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

För att erhålla godkänt slutbetyg krävs godkända quizzar samt att läraren godkänt alla inlämningsuppgifter, den skriftliga och muntliga presentationen av projektuppgiften, samt reflektionsuppgiften. Betygsskalan är U G.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0003 | Inlämningsuppgifter | U G# | 15 | Obligatorisk | H22 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Övergångsbestämmelser

Kursen kan inte ingå i en examen tillsammans med någon av kurserna S7005B Temperaturberäkningar i konstruktioner, S7012B Kollapsmekanismer hos brandutsatta konstruktioner, S7006B Brandutsatta konstruktioner.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2020-02-14
