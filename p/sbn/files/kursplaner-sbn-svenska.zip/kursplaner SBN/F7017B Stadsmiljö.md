---
kurskod: "F7017B"
titel: "Stadsmiljö"
hp: "7,5"
titel_en: "Urban Spaces"
giltig: "Höst 2023 Lp 1 - Höst 2026 Lp 2"
beslutsdatum: "2022-02-11"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=F7017B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=F7017B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/f70/f7017b-stadsmiljo"
---

# Stadsmiljö (F7017B)

## Ingår i huvudområde

Arkitektur

## Behörighet

Kunskaper motsvarande kurs F0002B Urban design

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Kursen syftar till att studenterna ska använda sina kunskaper från tidigare kurser (stadsbyggnadsteorier, urban design, urbanmorfologi, planeringsmetoder etc.) och kombinera dem genom att utveckla ett stadsbyggnadsprojekt från vision till konkret förslag samt göra en plan för genomförande.

Efter godkänd kurs ska studenten kunna:

Kunskap och förståelse

- Förklara olika stadsbyggnadsteorier och föreslå lämpliga analysmetoder för genomförandet av stadsbyggnadsprojekt.

Färdighet och förmåga

- Analysera komplexa stadsmiljöer och bedöma dess utvecklingspotential.

- Utarbeta ett stadsutvecklingsförslag.

- Identifiera faktorer och aktörer som krävs för genomförande av stadsbyggnadsprojekt.

- Utarbeta en strategi för genomförande av stadsbyggnadsprojekt.

- Självständigt söka och välja lämplig akademisk litteratur som stödjer det föreslagna stadsbyggnadsprojektet.

- Presentera stadsbyggnadsförslaget och genomförandestrategin muntligt, samt genom text och illustrationer.

Värderingsförmåga och förhållningssätt

- Reflektera och kritiskt bedöma teorier och metoder för genomförandet av storskaliga stadsutvecklingsprojekt.

## Kursinnehåll

Kursen behandlar analys av en stadsdel, samt utvecklingsförslag inklusive vision och förslag för genomförande.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Undervisningen består av föreläsningar, litteraturseminarier, projektarbete, och handledningstillfällen.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursens mål examineras genom seminarier och en projektarbete. För att bli godkänd på seminarierna (U/G) krävs aktivt deltagande samt godkänd skriftlig reflektionsuppgift. För att bli godkänd på projektarbetet krävs aktivt deltagande, samt godkänd muntlig, skriftlig, och illustrerad redovisning och bedöms med graderad betygsskala.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0002 | Projektarbete | GU345 | 6 | Obligatorisk | H16 |  |
| 0003 | Seminarier | U G# | 1,5 | Obligatorisk | H16 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2022-

02-11

## Kursplanen fastställd

av Eva Gunneriusson 2016-01-19
