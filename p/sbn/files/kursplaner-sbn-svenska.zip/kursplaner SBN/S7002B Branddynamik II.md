---
kurskod: "S7002B"
titel: "Branddynamik II"
hp: "7,5"
titel_en: "Fire dynamics II"
giltig: "Höst 2023 Lp 2 - Höst 2026 Lp 2"
beslutsdatum: "2023-06-02"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7002B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7002B&lasPeriod=225&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s70/s7002b-branddynamik-ii"
---

# Branddynamik II (S7002B)

## Behörighet

S0003B Branddynamik I eller motsvarande kunskaper

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna

- förklara och lösa problem för hur branden utvecklas avseende alstring av rök och giftiga gaser samt rökfyllnadstider vid rumsbränder

- förklara och genomföra beräkningar om branddetektion

- förklara och genomföra beräkningar om ventilationssystem och brandgasspridning

- förklara grunderna för hur datorprogram används för simulering av brandutveckling i byggnader samt lösa problem med ett tvåzonsprogram

## Kursinnehåll

Kursen behandlar bevarandeekvationer och hur dessa används för att beräkna rökfyllnad vid rumsbränder. En datorlaboration ingår i kursen där en tvåzonsmodell används för att numeriskt beräkna rökfyllnad i mer komplexa scenarier. Brandgasventilation är en central del av kursen och behandlas på en grundläggande nivå, baserad på grundläggande fluidmekaniska principer, såväl som på en mer praktisk nivå. Även brandrökens koncentration av giftiga gaser behandlas utifrån begreppet yield och plymekvationer. Slutligen berörs även detektion av bränder i kursen.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, räkneövningar, datorlaboration, samt grupparbete med muntlig och skriftlig redovisning och quiz. Vid föreläsningarna presenteras kursinnehållet dels översiktligt men vissa moment behandlas i dessutom i detalj. Datorlaborationen består av en gemansam genomgång med obligatorisk närvaro och genomförs sedan i grupper som skriver varsin rapport. Grupparbetet behandlar kursinnehållet vetenskapliga grund och består av studier av forskningsartiklar och presentation av dessas innehåll. Grupparbetet kompletteras med en individuell quiz.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt. Hela kursinnehållet examineras med en skriftlig tentamen med betygsskala U 3 4 5. För att bli godkänd på kursen behöver studenten dessutom tillsammans med sin grupp ha genomfört datorlaborationen och skrivit en laborationsrapport som godkänts av lärare. Grupparbetet examineras genom muntlig presentation samt opponering på andra grupper. Quizen examineras genom rättning i Canvas. Närvaro är obligatorisk vid introduktionen till datorlaborationen samt vid presentationen av grupparbetet.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen S7002B motsvarar kurser ABS128, S7014B

## Övrigt

Kursen S7002B motsvarar kursen ABS128.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Tentamen | GU345 | 4,5 | Obligatorisk | H07 |  |
| 0002 | Inlämningsuppgifter | U G# | 3 | Obligatorisk | H07 |  |

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2023-06-02

## Kursplanen fastställd

Kursplanen är fastställd av Institutionen för samhällsbyggnad 2007-01-31 att gälla från H07.
