---
kurskod: "T0032B"
titel: "Hållbar gruvdrift och tunnelbyggande"
hp: "7,5"
titel_en: "Sustainable Mining and Tunneling"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "GU345"
amne: "Berg- och mineralteknik"
amnesgrupp_scb: "Berg- och mineralteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=T0032B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=T0032B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/t00/t0032b-hallbar-gruvdrift-och-tunnelbyggande"
---

# Hållbar gruvdrift och tunnelbyggande (T0032B)

## Behörighet

Grundläggande behörighet samt T0013B Berganläggningsteknik eller motsvarande kurs. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter avslutad kurs ska studenten kunna

Kunskap och förståelse

1. Redovisa olika brytningsmetoder och dess lämplighet för undermarksbyggande och tunneldrivning samt deras miljöpåverkan.

2. Redovisa och förstå processen för bergbyggande; från projektering till drift

3. Visa förståelse om hållbarhetsperspektiven; miljö, ekonomi, socialt och FN 17 globala hållbarhetsmål

Färdighet och förmåga

4. visa förmåga att muntligt och skriftligt redogöra för och diskutera sina slutsatser och den kunskap och de argument som ligger till grund för dessa gällande sitt eget lärande

5. visa förmåga till samverkan i grupper med olika sammansättning.

Värderingsförmåga och förhållningssätt

6. visa insikt kring möjligheter och begränsningar vid gruvbrytning och tunnelbyggande samt dess roll i samhället

7. visa förmåga att identifiera sitt behov av ytterligare kunskap och att fortlöpande utveckla sin kompetens.

## Kursinnehåll

Kursen kommer behandla miljöaspekter och hållbarhetsaspekter vid gruvdrift och vid tunnelbyggnad – vi arbetar med samma bergmaterial men problemen är olika. Med grund i FN:s 17 globala hållbarhetsmål kopplas läraktiviteterna till dessa, så som föreläsningar, gruppuppgifter samt gästföreläsare, kommer studenterna kunna redogöra för bland annat vilka maskiner som används, hur bergmassor deponeras på ett hållbart sätt, hur grundvatten påverkas, hur grundvattenpåverkan och grundvattensänkning kan minskas, metoder för att ta hand om kväveutsläpp, hur omgivning påverkas av gruvdrift samt tunnelbyggnationer, hur vibrationer och stomljud uppstår och kan reduceras, vad en miljökonsekvensbeskrivning är, samt vilken lagstiftning som gäller vid olika typer av bergarbeten.

Introduktion

Introduktion till FN:s 17 globala hållbarhetsmål kopplat till tunnelbyggande brytningsmetoder.

Introduktion till brytningsmetoder – Varför och hur bryter man malm?, vad behöver man veta om fyndigheten, vilka risker finns det, Hur ser svensk gruvindustri ut? Sveriges roll inom råvaruförsörjningen?

Introduktion till tunnel- och undermarksbyggande – Vilka metoder finns för tunnlar, typer av tunnlar, maskiner som lämpar sig för lika metoder och bergtyper.

Hållbarhetsperspektiven

Vilka processer krävs och lagar följas för att öppna en gruva eller bygga en tunnel?

Hur designar man en gruva under jord? Vad måste finnas? Vad måste man tänka på?

Hur designar man en tunnel i urban miljö? Hur påverkas omgivningen, hur kan metoder väljas för minimal påverkan.

Studiebesök

- besöker pågående projekt kopplat till bergbyggande.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av:

- Lektioner - Flera olika former av flera undervisnings-/inlärningsaktiviteter, där varje lektion inleds med en kort teorigenomgång där föreläsaren förklara de viktigaste teoretiska aspekterna relaterade till kursens innehåll och (ii) tillsammans lösa och/eller diskutera typiska problem eller frågor vilket ger dig möjlighet att på olika sätt arbeta med frågeställningar kring gruvbrytning och tunnelbyggande. Endera i form av förinspelade teoretiska avsnitt eller lektioner med teoretiska avsnitt samt interaktiva aktiviteter.

- Mellan föreläsningarna – Det förväntas att du förbereder dig inför varje lektion genom att arbeta igenom anvisat materialet (till exempel övningar och frågor ställde vid tidigare föreläsningar eller i utskick) så att du är beredd att bidra och delta i läraktiviteterna (problemlösning, diskussion, mm) under föreläsningarna.

- Projektuppgifter - Ni arbetar själv och tillsammans med andra studenter och använder dina kunskaper för att studera olika frågeställningar. Du presenterar ditt arbete i skrift och muntligt samt återkopplar på andras arbete. Utifrån en byggmetod för gruva och tunnel ska förbättringar föreslås givet minst tre av FN:s globala hållbarhetsmål. Förbättringarna ska vara av sådan karaktär att de är genomförbara med dagens teknik och kunskap.

- Studiebesök – vi besöker ett pågående projekt kopplat till bergbyggnad och samlar information till en skriftlig eller muntlig redogörelse av besöket.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras på följande sätt:

- Projektuppgift - Grupp – inlämning av rapporter där deltagarna redogörs sin uppgift samt hur de planerat och utfört arbetet. Studenterna ger även återkoppling på annan studenters gruppuppgift samt reflektera kring den egna gruppens arbete och sitt eget lärande. Examinerar mål 1, 2, 3, 4, 5, 6, 7

- Muntlig presentation - Genomföra muntliga presentationer kopplade till projektuppgifterna. Studenten ska även ge återkoppling på annan students muntliga presentation samt reflektera kring sin egen muntliga presentation. Examinerar mål 2.

- Studiebesök – obligatorisk närvaro vid studiebesök samt inlämning av skriftlig eller muntlig redogörelse av besöket. Del av examination för mål 1 och 2.

- Tentamen/Quiz - Examinerar målen 1,2 och 3

Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0004 | Quiz | GU345 | 3 | Obligatorisk | V26 |  |
| 0005 | Projektuppgift - grupp | UG | 3,5 | Obligatorisk | V27 |  |
| 0006 | Studiebesök | UG | 0,5 | Obligatorisk | V27 |  |
| 0007 | Muntlig presentation | UG | 0,5 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13
