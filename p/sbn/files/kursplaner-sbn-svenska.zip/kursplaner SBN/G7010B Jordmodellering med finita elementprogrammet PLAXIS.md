---
kurskod: "G7010B"
titel: "Jordmodellering med finita elementprogrammet PLAXIS"
hp: "7,5"
titel_en: "Soil modelling with the finite element program PLAXIS"
giltig: "Höst 2025 Lp 1 - Tills vidare"
beslutsdatum: "2025-02-13"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1N"
betygsskala: "GU345"
amne: "Geoteknik"
amnesgrupp_scb: "Väg- och vattenbyggnad"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=G7010B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=G7010B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/g70/g7010b-jordmodellering-med-finita-elementprogrammet-plaxis"
---

# Jordmodellering med finita elementprogrammet PLAXIS (G7010B)

## Ingår i huvudområde

Väg- och vattenbyggnad

## Behörighet

90 hp i tekniska ämnen där kurs i geoteknik eller geomekanik ska ingå. Goda kunskaper i engelska, motsvarande engelska 6.

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Lärandemålen i kursen är:

(1) Kunna tillämpa det kommersiella finita elementprogrammet PLAXIS vid analyser av jordkonstruktioner.

(2) Kunna den matematiska bakgrunden till icke linjär finit elementmetod tillräckligt bra för att kunna avgöra huruvida de resultat som erhålls är korrekta.

(3) Kunna bestämma parametervärden till konstitutiva modeller i programmet utifrån laboratorieförsök och fältförsök.

(4) Öva de generella färdigheterna skriftlig och muntlig presentation.

## Kursinnehåll

Kursen behandlar handhavande av finita elementprogrammet PLAXIS. Huvudsakliga användningsområden för programmet. Genomgång av valda delar av programmets matematiska bakgrund; med speciell tonvikt på de ingående konstitutiva modellerna. Metoder att i fält och laboratorium bestämma värden på de parametrar som ingår i de konstitutiva modellerna. Allmänna råd om vad man bör tänka på vid finita elementanalyser. När bör finita elementanalyser genomföras och när är analytiska beräkningsverktyg tillräckliga? Efter att en finit elementsimulering är genomförd bör resultaten granskas kritiskt, ni får härmed tillfälle att använda era kunskaper från tidigare kurser i geoteknik. Kursen innehåller även momenten rapportskrivning och muntlig presentation.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen genomförs till stor del genom praktiska övningar på egen hand eller gruppvis med programvaran. Lärare kommer att finnas tillgängliga för handledning. Lektioner ges på kursens teoridelar som beskrivs under Kursinnehåll. Fem stycken konstruktionsuppgifter där studenter enskilt eller i grupp arbetar med PLAXIS lämnas in till lärare som rättar och ger återkoppling. En av dessa uppgifter behandlar hur man bestämmer parametervärden till konstitutiva modeller. Ett större projektarbete av praktisk natur med programvaran genomförs gruppvis och presenteras skriftligt i form av en seminarieuppsats. Uppsatsen presenteras sedan muntligt med tillhörande opposition vid ett särskilt seminarium. Feedback på både uppsatsen och den muntliga presentationen ges av lärare och opponentgrupp vid seminariet. Opponentgruppen består av en annan studentgrupp. Alla studentgrupper ska agera opponentgrupp vid seminariet. Observera att läraren kommer att ge råd om presentationsteknik, hur man kan hantera nervositet etc. i samband med seminariepresentationerna.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Lärandemål (1) och (2) examineras vid granskning av konstruktionsuppgifter och seminarieuppsats. Lärandemål (3) examineras vid rättning av den konstruktionsuppgift som behandlar bestämning av parametervärden. Lärandemål (4) avser generella färdigheter och examineras i samband med kursens seminariepresentationer. Respektive modul konstruktionsuppgifter och seminarieuppsats betygsätts enligt betygsskalan GU345. Samtliga ingående examinationsmoment ska vara avklarade för slutbetyg på kursen. Slutbetyget ges utifrån ett vägt medelvärde av betygen på respektive examinationsmoment.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Seminarieuppsats | GU345 | 3,7 | Obligatorisk | H12 |  |
| 0002 | Konstruktionsuppgifter | GU345 | 3,8 | Obligatorisk | H12 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2025-02-13

## Kursplanen fastställd

av Eva Gunneriusson 2012-03-14
