---
kurskod: "C0025B"
titel: "Samhällets planering för risker och kriser"
hp: "7,5"
titel_en: "Society's Planning for Hazards"
giltig: "Vår 2027 Lp 3 - Tills vidare"
beslutsdatum: "2024-02-19"
utbildningsniva: "Grundnivå"
fordjupningskod: "G1F"
betygsskala: "UG"
amne: "Arkitektur"
amnesgrupp_scb: "Arkitektur"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=C0025B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=C0025B&lasPeriod=227&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/c00/c0025b-samhallets-planering-for-risker-och-kriser"
---

# Samhällets planering för risker och kriser (C0025B)

## Behörighet

Grundläggande behörighet samt Minst 30 hp avklarade kurser inom området teknik eller samhällsbyggnad

## Urval

Urvalet grundas på 1-165 högskolepoäng.

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten:

- kunna beskriva olika samhällsplaneringsprocesser samt hur lagstiftning styr dessa processer;

- kunna delta med riskanalyser i planeringsprocessen;

- visa förmåga att simulera risker och sårbarheter i samhällsplaneringen med utgångspunkt i relevant information;

- visa kunskap om områdets vetenskapliga grund; samt

- kunna använda referenser i löpande text enligt gängse metoder för vetenskapliga arbeten

## Kursinnehåll

Kursen fokuserar på hantering av risker i samhällsplaneringen, samhällsplaneringsprocesser, samt de begrepp som används inom samhällsplaneringsområdet framför allt gällande översiktlig planering samt fördjupad översiktsplan.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida. Kursen genomförs via föreläsningar, studiebesök, litteraturseminarium, projektarbete i grupp, samt individuell opponering på annan grupps projektarbete. Föreläsningarna och litteraturen belyser främst hur risker av olika slag kan hanteras i samhällsplaneringen med riskanalyser som utgångspunkt; hur lagstiftning används som styrmedel för att risker ska beaktas i samhällsplaneringen; samt olika centrala, regionala och kommunala myndigheters samt företags syn på begreppet ”riskhänsyn i samhällsplaneringen”. Genom projektuppgiften övas studenten i att utföra riskanalyser i planeringsprocessen, framför allt gällande översiktlig planering samt fördjupad översiktsplan, samt akademiskt rapportskrivande. För att avgränsa projektarbetets omfattning utförs projektarbetet med hjälp av programvaran Ibero.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform. Kursens mål examineras genom projektarbete, studiebesök, föreläsningar samt litteraturseminarium. För godkänt projektarbete krävs aktivt deltagande i projektarbete, godkänd muntlig och skriftlig redovisning av projektuppgift, samt godkänd opponering på annan grupps projektarbete. Opponering på annan grupps arbete sker individuellt. För godkänt på kursens övriga delar krävs närvaro vid studiebesök, minst 80 % närvaro på föreläsningar, samt godkänt litteraturseminarium.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen C0025B motsvarar kursen C0024B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0005 | Studiebesök | UG | 0,2 | Obligatorisk | V27 |  |
| 0006 | Litteratureminarium | UG | 2 | Obligatorisk | V27 |  |
| 0007 | Projektarbete | UG | 4,3 | Obligatorisk | V27 |  |
| 0008 | Föreläsningar | UG | 1 | Obligatorisk | V27 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-19

## Kursplanen fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2024-02-19
