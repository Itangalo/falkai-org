---
kurskod: "S7008B"
titel: "Tillämpad branddynamik"
hp: "7,5"
titel_en: "Applied Fire Dynamics"
giltig: "Höst 2023 Lp 1 - Tills vidare"
beslutsdatum: "2021-02-17"
utbildningsniva: "Avancerad nivå"
fordjupningskod: "A1F"
betygsskala: "U G#"
amne: "Brandteknik"
amnesgrupp_scb: "Byggteknik"
kursgivare: "Institutionen för samhällsbyggnad och naturresurser (SBN)"
kursplan_url: "https://www.ltu.se/utbildning/utbildningsplan-och-kursplan/kursplan?id=S7008B"
pdf_url: "https://epok.ltu.se/epok/dynpdf/public/kursplan/downloadPublicKursplan.pdf?kursKod=S7008B&lasPeriod=214&locale=sv"
kurssida_url: "https://www.ltu.se/utbildning/kurs/s70/s7008b-tillampad-branddynamik"
---

# Tillämpad branddynamik (S7008B)

## Behörighet

Genomgångna kurser i Branddynamik 1 och Branddynamik 2

## Urval

Urvalet grundas på 30-285 högskolepoäng

## Mål/Förväntat studieresultat

Efter godkänd kurs ska studenten kunna

- förklara byggprodukters och lös inrednings brandegenskaper

- förklara provningsmetoder och brandklassifikation av produkter

- förklara och genomföra beräkningar på antändlighet, flamspridning, angiven värmeeffekt

- lösa problem med datorprogrammet Fire Dynamics Simulator, FDS

- förklara och lösa problem inom brandteknisk dokumentation och brandskyddsteknisk projektering

## Kursinnehåll

I inledande föreläsningar presenteras CFD, Computational Fluid Dynamics och speciellt FDS-kodens användningsområde och uppbyggnad av indatafil. Kursen innehåller förklaring av de aktuella byggreglerna och illustrerar de brandtekniska krav som samhället ställer på nya byggnader. Betydelsen och begränsningar av den analytiska dimensioneringen av byggnaders brandsäkerhet diskuteras från myndighetens och brukarens perspektiv. Brandegenskaper för trä, olika plastmaterial, mineralull mm och dess användning som ytbeklädnad, isolering och andra användningsområden i byggnader diskuteras. Utöver det visas brandegenskaper för material i möbler och annan lös inredning t.ex. textilier, stoppnings material.Termiska modeller för antändning och flamspridning, avgiven värmeeffekt, och relativ betydelse för parametrar såsom termisk tröghet för brandförloppet kommer att presenteras, liksom analys av rökproduktion och produktion av giftiga gaser från brandrök.

Brandparametrar som används att deklarera produkters brandegenskaper och deras användning och koppling till teori samt bakgrund till Internationell standardisering ISO, IMO, CEN presenteras.

## Genomförande

Kursens undervisningsspråk samt undervisningsform anges för varje kurstillfälle och framgår av kurssidan på Luleå tekniska universitets hemsida.

Undervisningen består av föreläsningar, räkneövningar, datorlaborationer, inlämningsuppgifter samt konsultation med lärare. Vid föreläsningarna och räkneövningarna i FDS ska eleverna arbeta i grupper och varje grupp ska ha tillgång till en bärbar dator. Kursen består i sin helhet av fyra inlämningsuppgifter, varav en inom materialegenskaper, två inom FDS, och en inom brandskyddsteknisk projektering, som genomförs i grupper och som rapporteras i skriftlig rapport och muntlig redovisning.

## Examination

Om det finns beslut om särskilt pedagogiskt stöd, i enlighet med Riktlinjen Studentens rättigheter och skyldigheter vid Luleå tekniska universitet, finns möjlighet till anpassad eller alternativ examinationsform.

Kursen examineras genom att de fyra skriftliga rapporterna ska vara godkända av lärare samt genom att lärare intygat att studenten aktivt presenterat, och deltagit i diskussioner vid andras presentationer, vid presentationerna av inlämningsuppgifterna. Betygsskalan på kursen är G U. Närvaro är obligatorisk vid alla undervisningstillfällen och eventuell frånvaro ska kompenseras med muntligt förhör med lärare för att säkerställa att studenten tillgodogjort sig de kunskaper som presenterats vid det missade undervisningstillfället.

## Otillåtna hjälpmedel vid prov och bedömning

Om en student, genom användande av otillåtna hjälpmedel, försöker vilseleda vid prov eller när en studieprestation ska bedömas, får disciplinära åtgärder vidtas. Uttrycket ”otillåtna hjälpmedel” betyder de hjälpmedel som lärare i förväg inte uppgett som tillåtna hjälpmedel och som kan vara till hjälp vid lösandet av examinationsuppgiften. Detta innebär att alla hjälpmedel som inte uppgetts som tillåtna är otillåtna.

## Överlappning

Kursen S7008B motsvarar kursen S7018B

## Kursgivare

Institutionen för samhällsbyggnad och naturresurser (SBN)

## Moduler

| Kod | Benämning | Betygsskala | Hp | Tillstånd | Gäller | Titel |
|---|---|---|---|---|---|---|
| 0001 | Inlämningsuppgifter | U G# | 7,5 | Obligatorisk | V14 |  |

## Studiehandledning

Studiehandledning finns i lärplattformen Canvas före kursstart. Du som är ny student hittar all information du

behöver på www.ltu.se/studentwebben/ny-student. Du som redan studerar vid Luleå tekniska universitet hittar information om kursstart via schema på studentwebben alternativt via kursrummet i lärplattformen. Du når lärplattformen via Mitt LTU.

## Revidering fastställd

av Biträdande huvudutbildningsledare Eva Gunneriusson, Institutionen för samhällsbyggnad och naturresurser 2021-02-17

## Kursplanen fastställd

av Eva Gunneriusson 2013-02-15
